# wallet_enforcer.py — Universal Miner Pro ULTIMATE EDITION v4.0
# CRITICAL SECURITY MODULE — Forces all pool payouts to internal wallet only.
# No funds can be directed to external addresses via miner configuration.
# External transfers only happen explicitly via wallet_api.py /api/transfer routes.
#
# Drop-in: imported by miner_config.py get_miner_cmd() and miner_manager.py
# ARM-safe: no f-strings, no walrus, stdlib only.

import os
import sqlite3

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
WALLET_DB   = os.path.join(BASE_DIR, "wallet.db")
MINER_DB    = os.path.join(BASE_DIR, "miner.db")

# ---------------------------------------------------------------------------
# Coin -> internal wallet coin mapping
# Some pools pay in a different coin than what's mined; map to the receive coin.
# ---------------------------------------------------------------------------
POOL_PAYOUT_COIN = {
    # Pool ID        : {mined_coin -> payout_coin}
    "kryptex"        : {},           # Kryptex pays to your Kryptex account (BTC equiv); use kryptex_wallet field
    "unmineable"     : {},           # unMineable pays selected coin to unmineable_wallet
    "moneroocean"    : {"*": "XMR"}, # MoneroOcean always pays XMR
    "viabtc"         : {},           # ViaBTC pays same coin
    "miningpoolhub"  : {},           # MPH pays same coin
    "binance"        : {},           # Binance Pool pays same coin
    "direct_wallet"  : {},           # Direct: pays exact coin
}

# Internal wallet coin aliases — the coin stored in wallet_coins table
WALLET_COIN_ALIAS = {
    "ZEPH": "XMR",   # No ZEPH in HD wallet — use XMR address as receive address
    "SAL":  "XMR",   # Same
    "ETHW": "ETH",
    "BCH":  "BTC",   # Fallback — user should use BTC address
}

# ---------------------------------------------------------------------------
# Core: get the internal wallet address for a given coin
# ---------------------------------------------------------------------------
def get_internal_address(coin):
    """
    Return the internal wallet address for the given coin symbol.
    Returns (address, coin_used) or (None, None) if no wallet configured.
    Applies WALLET_COIN_ALIAS fallbacks automatically.
    """
    if not os.path.exists(WALLET_DB):
        return None, None

    coin = coin.upper().strip()
    lookup_coin = WALLET_COIN_ALIAS.get(coin, coin)

    try:
        conn = sqlite3.connect(WALLET_DB)
        c    = conn.cursor()

        # Find active wallet name from session table if it exists
        active_wallet = None
        try:
            c.execute("SELECT value FROM wallet_session WHERE key='active_wallet' LIMIT 1")
            row = c.fetchone()
            if row:
                active_wallet = row[0]
        except sqlite3.OperationalError:
            pass

        # Fallback: pick the first wallet in the DB
        if not active_wallet:
            c.execute("SELECT wallet_name FROM wallet_keystore ORDER BY id LIMIT 1")
            row = c.fetchone()
            if row:
                active_wallet = row[0]

        if not active_wallet:
            conn.close()
            return None, None

        c.execute(
            "SELECT address FROM wallet_coins WHERE wallet_name=? AND coin=? LIMIT 1",
            (active_wallet, lookup_coin)
        )
        row = c.fetchone()
        conn.close()
        if row and row[0]:
            return row[0], lookup_coin
        return None, None
    except Exception as e:
        print("[wallet_enforcer] DB error: " + str(e))
        return None, None

# ---------------------------------------------------------------------------
# Core: enforce internal wallet in a profile dict
# ---------------------------------------------------------------------------
def enforce_internal_wallet(profile):
    """
    Given a miner profile dict, overwrite all wallet/address fields with
    the internal wallet addresses.  Returns (modified_profile, warnings[]).

    This is called by get_miner_cmd() before building the command.
    Fields overwritten:
      - xmr_wallet        (XMR / ZEPH / SAL / MoneroOcean)
      - btc_wallet        (BTC / Kryptex BTC payout)
      - unmineable_wallet (unMineable payout wallet)
      - mo_wallet         (MoneroOcean)
      - miner_user        (when it contains a wallet address — RandomX / X11)

    Kryptex pools: miner_user format is "solo:{wallet}/{worker}".
    ViaBTC / MPH:  miner_user is "account.worker" — not a wallet address,
                   payout is to the pool account; we update xmr_wallet/btc_wallet
                   in the profile for reference but cannot auto-inject into account.
    """
    profile  = dict(profile)   # shallow copy — never mutate caller's dict
    warnings = []

    coin        = str(profile.get("selected_coin", "XMR")).upper().strip()
    pool_id     = str(profile.get("selected_pool", "kryptex")).lower().strip()
    algo_key    = str(profile.get("active_algo",   "RANDOMX")).upper().strip()
    miner_user  = str(profile.get("miner_user",    "")).strip()

    # ── Determine which coin the pool pays out in ──────────────────────────
    pool_map     = POOL_PAYOUT_COIN.get(pool_id, {})
    payout_coin  = pool_map.get(coin) or pool_map.get("*") or coin

    # ── Fetch internal address for payout coin ─────────────────────────────
    internal_addr, addr_coin = get_internal_address(payout_coin)

    if internal_addr is None:
        warnings.append(
            "No internal wallet configured. Create a wallet at /wallet/ first. "
            "Mining is BLOCKED until a wallet exists."
        )
        return profile, warnings

    # ── XMR-family: overwrite xmr_wallet ──────────────────────────────────
    if payout_coin in ("XMR", "ZEPH", "SAL") or coin in ("XMR", "ZEPH", "SAL"):
        xmr_addr, _ = get_internal_address("XMR")
        if xmr_addr:
            if profile.get("xmr_wallet") != xmr_addr:
                warnings.append("xmr_wallet overridden with internal XMR address: " + xmr_addr[:16] + "...")
            profile["xmr_wallet"] = xmr_addr
            profile["unmineable_wallet"] = xmr_addr   # unMineable also uses this
            profile["mo_wallet"]  = xmr_addr

    # ── BTC-family: overwrite btc_wallet ──────────────────────────────────
    if payout_coin in ("BTC", "BCH", "LTC"):
        btc_addr, _ = get_internal_address(payout_coin)
        if btc_addr is None:
            btc_addr, _ = get_internal_address("BTC")  # BTC fallback
        if btc_addr:
            if profile.get("btc_wallet") != btc_addr:
                warnings.append("btc_wallet overridden with internal " + payout_coin + " address: " + btc_addr[:16] + "...")
            profile["btc_wallet"] = btc_addr

    # ── ETH/ETC/ETHW: overwrite eth wallet field ───────────────────────────
    if payout_coin in ("ETH", "ETC", "ETHW"):
        eth_addr, _ = get_internal_address("ETH")
        if eth_addr:
            profile["eth_wallet"] = eth_addr

    # ── Rewrite miner_user for pools that use wallet address in --user ──────
    # Only rewrite if miner_user contains a wallet address (not a pool username).
    # Detection: wallet addresses are 34–106 chars, no spaces, specific prefixes.
    if _looks_like_wallet_address(miner_user):
        # Extract worker suffix if present (e.g. "ADDR.worker" or "solo:ADDR/worker")
        worker  = _extract_worker(miner_user, pool_id)
        new_user = _build_user_string(internal_addr, worker, pool_id, algo_key)
        if new_user and new_user != miner_user:
            warnings.append("miner_user overridden: " + miner_user[:20] + "... -> " + new_user[:30] + "...")
            profile["miner_user"] = new_user
    elif pool_id in ("kryptex",) and miner_user.startswith("solo:"):
        # Kryptex solo format: "solo:{wallet}/{worker}" — always rewrite wallet part
        worker  = _extract_worker(miner_user, pool_id)
        new_user = "solo:" + internal_addr + "/" + worker
        if new_user != miner_user:
            warnings.append("miner_user (Kryptex solo) overridden -> " + new_user[:30] + "...")
            profile["miner_user"] = new_user
    elif pool_id == "unmineable":
        # unMineable format: "XMR:{wallet}.{worker}#ref" — always rewrite wallet
        worker   = _extract_worker(miner_user, pool_id)
        ref      = str(profile.get("unmineable_ref", "")).strip()
        xmr_addr, _ = get_internal_address("XMR")
        if xmr_addr:
            ref_part = ("#" + ref) if ref else ""
            new_user = "XMR:" + xmr_addr + "." + worker + ref_part
            if new_user != miner_user:
                warnings.append("miner_user (unMineable) overridden -> " + new_user[:40] + "...")
                profile["miner_user"] = new_user

    return profile, warnings

# ---------------------------------------------------------------------------
# Wallet address detection helpers
# ---------------------------------------------------------------------------
def _looks_like_wallet_address(s):
    """Return True if s appears to be a crypto wallet address (not a pool username)."""
    if not s:
        return False
    # Strip common pool prefixes
    for prefix in ("solo:", "XMR:", "BTC:", "ETH:", "DASH:", "LTC:"):
        if s.startswith(prefix):
            s = s.split(":", 1)[1]
            break
    # Strip worker suffix
    for sep in ("/", "."):
        if sep in s:
            s = s.split(sep)[0]
    s = s.strip()
    if len(s) < 26:
        return False
    # BTC legacy (1...), bech32 (bc1...), ETH (0x...), XMR (4.../8...), DASH (X...)
    import re
    patterns = [
        r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$',     # BTC legacy
        r'^bc1[a-z0-9]{6,87}$',                     # BTC bech32
        r'^0x[0-9a-fA-F]{40}$',                     # ETH
        r'^4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}$',     # XMR (95 chars)
        r'^8[0-9AB][1-9A-HJ-NP-Za-km-z]{93}$',     # XMR subaddress
        r'^X[a-km-zA-HJ-NP-Z1-9]{33}$',             # DASH
        r'^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$',     # LTC
        r'^ltc1[a-z0-9]{6,87}$',                    # LTC bech32
        r'^[a-km-zA-HJ-NP-Z1-9]{95}$',              # XMR raw 95-char
    ]
    for pat in patterns:
        if re.match(pat, s):
            return True
    return False

def _extract_worker(user_str, pool_id):
    """Extract the worker name from a miner_user string."""
    s = user_str.strip()
    # Remove pool-specific prefix
    for prefix in ("solo:", "XMR:", "BTC:", "ETH:"):
        if s.startswith(prefix):
            s = s[len(prefix):]
    # Kryptex solo: "wallet/worker"
    if pool_id == "kryptex" and "/" in s:
        return s.split("/", 1)[1].split("#")[0].strip() or "worker1"
    # Most pools: "wallet.worker" or "wallet.worker#ref"
    if "." in s:
        part = s.split(".", 1)[1]
        return part.split("#")[0].strip() or "worker1"
    return "worker1"

def _build_user_string(wallet_addr, worker, pool_id, algo_key):
    """Build the pool-appropriate miner_user string with the internal wallet."""
    if pool_id == "kryptex":
        return "solo:" + wallet_addr + "/" + worker
    if pool_id == "unmineable":
        return "XMR:" + wallet_addr + "." + worker
    # Default: wallet.worker (Kryptex, ViaBTC, MPH, MoneroOcean, direct)
    return wallet_addr + "." + worker

# ---------------------------------------------------------------------------
# Validation: called by miner_config.py save_profile() to block bad addresses
# ---------------------------------------------------------------------------
def validate_profile_wallets(profile):
    """
    Return list of error strings.  Empty list = OK to save.
    Rejects any profile that tries to set pool payout to a non-internal address.
    """
    errors   = []
    coin     = str(profile.get("selected_coin", "")).upper().strip()
    pool_id  = str(profile.get("selected_pool", "")).lower().strip()

    # Pool-specific wallet fields that must match internal wallet
    checks = [
        ("xmr_wallet",        "XMR"),
        ("btc_wallet",        "BTC"),
        ("unmineable_wallet", "XMR"),
        ("mo_wallet",         "XMR"),
    ]
    for field, check_coin in checks:
        val = str(profile.get(field, "")).strip()
        if not val:
            continue
        if not _looks_like_wallet_address(val):
            continue
        internal_addr, _ = get_internal_address(check_coin)
        if internal_addr and val != internal_addr:
            errors.append(
                field + " (" + val[:16] + "...) does not match internal wallet "
                + check_coin + " address. Only the internal wallet can receive mining payouts."
            )
    return errors

# ---------------------------------------------------------------------------
# Guard: raises ValueError if no wallet configured — call from get_miner_cmd()
# ---------------------------------------------------------------------------
def require_internal_wallet():
    """Raise ValueError with instructions if no internal wallet exists."""
    if not os.path.exists(WALLET_DB):
        raise ValueError(
            "No internal wallet found. Go to /wallet/ and create a wallet first. "
            "All mining payouts must go to your internal wallet."
        )
    try:
        conn = sqlite3.connect(WALLET_DB)
        c    = conn.cursor()
        c.execute("SELECT COUNT(*) FROM wallet_keystore")
        count = c.fetchone()[0]
        conn.close()
        if count == 0:
            raise ValueError(
                "Internal wallet is empty. Go to /wallet/ and create or restore a wallet. "
                "Mining cannot start without a wallet to receive payouts."
            )
    except sqlite3.OperationalError:
        raise ValueError(
            "Wallet database not initialized. Visit /wallet/ to set up your wallet."
        )
