"""
ump_miner_registry.py
Universal Miner Pro ULTIMATE - Universal Miner & Coin Registry
Complete coin -> algo -> miner -> pool -> command mapping.
Covers CPU, GPU (NVIDIA/AMD), and unMineable proxied coins.

Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import platform

# ---------------------------------------------------------------------------
# CAPABILITY TAGS
# ---------------------------------------------------------------------------
CAP_CPU      = "CPU"
CAP_GPU      = "GPU"
CAP_ASIC     = "ASIC"
CAP_CPU_GPU  = "CPU_GPU"
CAP_PROXIED  = "PROXIED"    # mined via unMineable hash conversion

# ---------------------------------------------------------------------------
# ALGORITHM REGISTRY
# Keyed by algo_key string used throughout UMP.
# ---------------------------------------------------------------------------
ALGOS = {
    "RANDOMX": {
        "name":       "RandomX",
        "binary":     "xmrig",
        "spec":       "rx/0",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Monero ASIC-resistant PoW — CPU optimised, L3 cache intensive",
    },
    "X11": {
        "name":       "X11",
        "binary":     "cpuminer-multi",
        "spec":       "x11",
        "hr_unit":    "MH/s",
        "capability": CAP_CPU,
        "worker_fmt": "{coin}:{wallet}.{worker}#{referral}",
        "description": "11-algorithm chain; routed via unMineable for alt-coin payout",
    },
    "X11_DIRECT": {
        "name":       "X11 Direct",
        "binary":     "cpuminer-multi",
        "spec":       "x11",
        "hr_unit":    "MH/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "X11 direct pool mining -- DASH on Binance Pool and other X11 pools",
    },
    "KAWPOW": {
        "name":       "KawPow",
        "binary":     "t-rex",
        "spec":       "kawpow",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Ravencoin GPU algo — ProgPoW variant",
    },
    "ETHASH": {
        "name":       "Ethash",
        "binary":     "lolminer",
        "spec":       "ETHASH",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Classic Ethereum PoW — GPU DAG-based",
    },
    "AUTOLYKOS2": {
        "name":       "Autolykos2",
        "binary":     "lolminer",
        "spec":       "AUTOLYKOS2",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Ergo blockchain PoW",
    },
    "KHEAVYHASH": {
        "name":       "kHeavyHash",
        "binary":     "lolminer",
        "spec":       "KHEAVYHASH",
        "hr_unit":    "GH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Kaspa PoW — very high hashrates on modern GPUs",
    },
    "OCTOPUS": {
        "name":       "Octopus",
        "binary":     "t-rex",
        "spec":       "octopus",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Conflux PoW algo",
    },
    "ETCHASH": {
        "name":       "Etchash",
        "binary":     "lolminer",
        "spec":       "ETCHASH",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Ethereum Classic PoW",
    },
    "ALEPHIUM": {
        "name":       "Blake3-Alephium",
        "binary":     "lolminer",
        "spec":       "ALPH",
        "hr_unit":    "GH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Alephium sharded PoW",
    },
    "SHA256D": {
        "name":       "SHA256d",
        "binary":     "cpuminer-multi",
        "spec":       "sha256d",
        "hr_unit":    "GH/s",
        "capability": CAP_ASIC,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Bitcoin, Bitcoin Cash, BSV — ASIC dominated",
    },
    "SCRYPT": {
        "name":       "Scrypt",
        "binary":     "cpuminer-multi",
        "spec":       "scrypt",
        "hr_unit":    "KH/s",
        "capability": CAP_CPU_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Litecoin, Dogecoin — ASIC exists but CPU/GPU viable via unMineable",
    },
    "GHOSTRIDER": {
        "name":       "GhostRider",
        "binary":     "cpuminer-multi",
        "spec":       "ghostrider",
        "hr_unit":    "KH/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Raptoreum CPU-native algo",
    },
    "RANDOMARQ": {
        "name":       "RandomARQ",
        "binary":     "xmrig",
        "spec":       "rx/arq",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "ArQmA CPU mining",
    },
    "RANDOMSFX": {
        "name":       "RandomSFX",
        "binary":     "xmrig",
        "spec":       "rx/sfx",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Safex Cash CPU mining",
    },
    "RANDOMWOW": {
        "name":       "RandomWOW",
        "binary":     "xmrig",
        "spec":       "rx/wow",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Wownero CPU mining",
    },
}


# ---------------------------------------------------------------------------
# POOL REGISTRY
# ---------------------------------------------------------------------------
POOLS = {
    "kryptex": {
        "name":        "Kryptex Pool",
        "url":         "https://pool.kryptex.com",
        "payout_model":"Auto-convert to BTC",
        "fee_pct":     2.0,
        "payout_coin": "BTC",
        "user_format": "KRYPTEX_EMAIL.WORKER or WALLET.WORKER",
        "default_pass":"X",
        "tls":         True,
        "ports": {
            "XMR":  "xmr.kryptex.network:8029",
            "ZEPH": "zeph.kryptex.network:18081",
            "SAL":  "sal.kryptex.network:8080",
            "RVN":  "rvn.kryptex.network:8888",
            "ETC":  "etc.kryptex.network:8080",
            "KAS":  "kas.kryptex.network:8888",
            "ALPH": "alph.kryptex.network:8889",
        },
    },
    "moneroocean": {
        "name":        "MoneroOcean",
        "url":         "https://moneroocean.stream",
        "payout_model":"PPLNS auto-algo switching",
        "fee_pct":     0.0,
        "payout_coin": "XMR",
        "user_format": "XMR_WALLET_ADDRESS",
        "default_pass":"WORKER:EMAIL",
        "tls":         False,
        "ports": {
            "XMR":  "gulf.moneroocean.stream:10128",
        },
    },
    "unmineable": {
        "name":        "unMineable",
        "url":         "https://unmineable.com",
        "payout_model":"Hash conversion to any coin",
        "fee_pct":     1.0,
        "fee_pct_ref": 0.75,
        "payout_coin": "ANY",
        "user_format": "COIN:WALLET.WORKER#REF",
        "default_pass":"WORKER_NAME",
        "tls":         False,
        "ports": {
            "RANDOMX": "rx.unmineable.com:3333",
            "X11":     "rx.unmineable.com:3333",
        },
    },
    "viabtc": {
        "name":        "ViaBTC",
        "url":         "https://viabtc.com",
        "payout_model":"PPS+",
        "fee_pct":     4.0,
        "payout_coin": "XMR",
        "user_format": "VIABTC_USERNAME.WORKER",
        "default_pass":"123",
        "tls":         False,
        "ports": {
            "XMR":  "xmr.viabtc.com:3333",
        },
    },
    "mph": {
        "name":        "Mining Pool Hub",
        "url":         "https://miningpoolhub.com",
        "payout_model":"PPLNS",
        "fee_pct":     0.9,
        "payout_coin": "MULTI",
        "user_format": "MPH_USERNAME.WORKER",
        "default_pass":"x",
        "tls":         False,
        "ports": {
            "XMR":  "monero.usa.mining-pool-hub.com:20580",
            "ETC":  "hub.miningpoolhub.com:20535",
        },
    },
    "binance": {
        "name":        "Binance Pool",
        "url":         "https://pool.binance.com",
        "payout_model":"FPPS",
        "fee_pct":     2.5,
        "payout_coin": "BTC",
        "user_format": "BINANCE_ACCOUNT.WORKER_ID  (e.g. francoisnel321.001)",
        "default_pass":"123456",
        "tls":         False,
        "dash_port_primary":   "dash.poolbinance.com:1800",
        "dash_port_ssl":       "dash.poolbinance.com:443",
        "dash_port_alternate": "dash.poolbinance.com:3333",
        "ports": {
            "BTC":       "bs.poolbinance.com:1800",
            "DASH":      "dash.poolbinance.com:1800",
            "DASH_443":  "dash.poolbinance.com:443",
            "DASH_1800": "dash.poolbinance.com:1800",
            "DASH_3333": "dash.poolbinance.com:3333",
        },
    },
    "custom": {
        "name":        "Custom / Direct",
        "url":         "",
        "payout_model":"Custom",
        "fee_pct":     0.0,
        "payout_coin": "ANY",
        "user_format": "WALLET (pool specific)",
        "default_pass":"x",
        "tls":         False,
        "ports":       {},
    },
    "2miners": {
        "name":        "2Miners",
        "url":         "https://2miners.com",
        "payout_model":"PPLNS",
        "fee_pct":     1.0,
        "payout_coin": "COIN",
        "user_format": "WALLET.WORKER",
        "default_pass":"x",
        "tls":         False,
        "ports": {
            "XMR":  "xmr.2miners.com:2222",
            "ETC":  "etc.2miners.com:1010",
            "RVN":  "rvn.2miners.com:6060",
            "ERG":  "erg.2miners.com:8008",
        },
    },
    "f2pool": {
        "name":        "f2pool",
        "url":         "https://f2pool.com",
        "payout_model":"PPS+",
        "fee_pct":     2.5,
        "payout_coin": "COIN",
        "user_format": "F2POOL_USERNAME.WORKER",
        "default_pass":"x",
        "tls":         False,
        "ports": {
            "XMR":  "xmr.f2pool.com:13531",
            "ETC":  "etc.f2pool.com:8118",
            "KAS":  "kas.f2pool.com:11200",
        },
    },
    "flexpool": {
        "name":        "Flexpool",
        "url":         "https://flexpool.io",
        "payout_model":"PPLNS",
        "fee_pct":     1.0,
        "payout_coin": "COIN",
        "user_format": "WALLET",
        "default_pass":"WORKER",
        "tls":         True,
        "ports": {
            "ETC":  "eu1-etc.flexpool.io:4444",
        },
    },
}


# ---------------------------------------------------------------------------
# COIN REGISTRY
# Full coin definitions: algo, hardware type, best pool, payout info, etc.
# ---------------------------------------------------------------------------
COINS = {
    # ---- CPU COINS (RandomX / XMRig) ----
    "XMR": {
        "name":        "Monero",
        "algo_key":    "RANDOMX",
        "capability":  CAP_CPU,
        "best_pools":  ["moneroocean", "kryptex"],
        "payout_coin": "XMR",
        "wallet_type": "xmr",
        "notes":       "Best CPU coin. RandomX ASIC-resistant.",
        "hashrate_usd_per_hs_day": 0.00000030,
        "base_price_usd": 170.0,
    },
    "ZEPH": {
        "name":        "Zephyr Protocol",
        "algo_key":    "RANDOMX",
        "capability":  CAP_CPU,
        "best_pools":  ["kryptex"],
        "payout_coin": "ZEPH",
        "wallet_type": "xmr",
        "notes":       "RandomX variant. Lower difficulty = more coins.",
        "hashrate_usd_per_hs_day": 0.00000025,
        "base_price_usd": 0.5,
    },
    "SAL": {
        "name":        "Salvium",
        "algo_key":    "RANDOMX",
        "capability":  CAP_CPU,
        "best_pools":  ["kryptex"],
        "payout_coin": "SAL",
        "wallet_type": "xmr",
        "notes":       "New RandomX coin. Speculative.",
        "hashrate_usd_per_hs_day": 0.00000010,
        "base_price_usd": 0.02,
    },
    "RTM": {
        "name":        "Raptoreum",
        "algo_key":    "GHOSTRIDER",
        "capability":  CAP_CPU,
        "best_pools":  ["custom"],
        "payout_coin": "RTM",
        "wallet_type": "btc",
        "notes":       "GhostRider — CPU optimised, ASIC resistant.",
        "hashrate_usd_per_hs_day": 0.00000010,
        "base_price_usd": 0.001,
    },
    "WOW": {
        "name":        "Wownero",
        "algo_key":    "RANDOMWOW",
        "capability":  CAP_CPU,
        "best_pools":  ["custom"],
        "payout_coin": "WOW",
        "wallet_type": "xmr",
        "notes":       "Wownero RandomWOW variant.",
        "hashrate_usd_per_hs_day": 0.00000005,
        "base_price_usd": 0.01,
    },
    # ---- DASH (X11 direct on Binance Pool) ----
    "DASH": {
        "name":        "Dash",
        "algo_key":    "X11_DIRECT",
        "capability":  CAP_CPU,
        "best_pools":  ["binance", "custom"],
        "payout_coin": "DASH",
        "wallet_type": "btc",
        "pool_url":    "dash.poolbinance.com:1800",
        "pool_url_ssl":"dash.poolbinance.com:443",
        "pool_url_alt":"dash.poolbinance.com:3333",
        "user_format": "BINANCE_ACCOUNT.WORKER_ID",
        "user_example":"francoisnel321.001",
        "default_pass":"123456",
        "notes":       "X11 direct mining on Binance Pool. Worker=account.workerID. Pass=123456.",
        "hashrate_usd_per_hs_day": 0.00000001,
        "base_price_usd": 28.0,
    },

    # ---- CPU via unMineable proxy ----
    "DOGE": {
        "name":        "Dogecoin",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "DOGE",
        "wallet_type": "btc",
        "notes":       "Mine via unMineable. Payout in DOGE.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 0.12,
    },
    "ADA": {
        "name":        "Cardano",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "ADA",
        "wallet_type": "ada",
        "notes":       "Mine via unMineable. Payout in ADA.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 0.45,
    },
    "SOL": {
        "name":        "Solana",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "SOL",
        "wallet_type": "sol",
        "notes":       "Mine via unMineable. High value per coin.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 140.0,
    },
    "SHIB": {
        "name":        "Shiba Inu",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "SHIB",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable. Meme coin.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 0.000009,
    },
    "BNB": {
        "name":        "BNB",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "BNB",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable. Binance ecosystem.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 580.0,
    },
    "TRX": {
        "name":        "Tron",
        "algo_key":    "X11",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "TRX",
        "wallet_type": "trx",
        "notes":       "Mine via unMineable X11.",
        "hashrate_usd_per_hs_day": 0.00000020,
        "base_price_usd": 0.12,
    },
    "XRP": {
        "name":        "Ripple",
        "algo_key":    "X11",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "XRP",
        "wallet_type": "xrp",
        "notes":       "Mine via unMineable X11.",
        "hashrate_usd_per_hs_day": 0.00000020,
        "base_price_usd": 0.50,
    },
    "MATIC": {
        "name":        "Polygon",
        "algo_key":    "X11",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "MATIC",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable X11.",
        "hashrate_usd_per_hs_day": 0.00000020,
        "base_price_usd": 0.70,
    },
    "DOT": {
        "name":        "Polkadot",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "DOT",
        "wallet_type": "dot",
        "notes":       "Mine via unMineable.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 6.5,
    },
    "LINK": {
        "name":        "Chainlink",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "LINK",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 14.0,
    },
    "AVAX": {
        "name":        "Avalanche",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "AVAX",
        "wallet_type": "avax",
        "notes":       "Mine via unMineable.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 27.0,
    },

    # ---- GPU COINS ----
    "RVN": {
        "name":        "Ravencoin",
        "algo_key":    "KAWPOW",
        "capability":  CAP_GPU,
        "best_pools":  ["2miners", "kryptex"],
        "payout_coin": "RVN",
        "wallet_type": "btc",
        "notes":       "KawPow GPU algo. Mid-range GPU sweet spot.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.02,
    },
    "ETC": {
        "name":        "Ethereum Classic",
        "algo_key":    "ETCHASH",
        "capability":  CAP_GPU,
        "best_pools":  ["2miners", "f2pool"],
        "payout_coin": "ETC",
        "wallet_type": "eth",
        "notes":       "Etchash — lower DAG than original ETH.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 20.0,
    },
    "ERG": {
        "name":        "Ergo",
        "algo_key":    "AUTOLYKOS2",
        "capability":  CAP_GPU,
        "best_pools":  ["2miners"],
        "payout_coin": "ERG",
        "wallet_type": "erg",
        "notes":       "Autolykos2. GPU friendly.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 1.0,
    },
    "KAS": {
        "name":        "Kaspa",
        "algo_key":    "KHEAVYHASH",
        "capability":  CAP_GPU,
        "best_pools":  ["f2pool", "kryptex"],
        "payout_coin": "KAS",
        "wallet_type": "kas",
        "notes":       "kHeavyHash. Very fast on modern GPUs.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.12,
    },
    "ALPH": {
        "name":        "Alephium",
        "algo_key":    "ALEPHIUM",
        "capability":  CAP_GPU,
        "best_pools":  ["kryptex"],
        "payout_coin": "ALPH",
        "wallet_type": "alph",
        "notes":       "Blake3 variant. High GPU hashrates.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.40,
    },
    "CFX": {
        "name":        "Conflux",
        "algo_key":    "OCTOPUS",
        "capability":  CAP_GPU,
        "best_pools":  ["custom"],
        "payout_coin": "CFX",
        "wallet_type": "eth",
        "notes":       "Octopus algo via T-Rex.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.15,
    },
    "NEXA": {
        "name":        "Nexa",
        "algo_key":    "ETHASH",
        "capability":  CAP_GPU,
        "best_pools":  ["custom"],
        "payout_coin": "NEXA",
        "wallet_type": "nexa",
        "notes":       "GPU coin via lolMiner.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.00005,
    },

    # ---- ASIC-dominated (available via unMineable proxy) ----
    "BTC": {
        "name":        "Bitcoin",
        "algo_key":    "SHA256D",
        "capability":  CAP_ASIC,
        "best_pools":  ["kryptex", "unmineable"],
        "payout_coin": "BTC",
        "wallet_type": "btc",
        "notes":       "CPU solo not profitable. Use unMineable proxy for BTC payout.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 67000.0,
    },
    "LTC": {
        "name":        "Litecoin",
        "algo_key":    "SCRYPT",
        "capability":  CAP_ASIC,
        "best_pools":  ["unmineable"],
        "payout_coin": "LTC",
        "wallet_type": "btc",
        "notes":       "ASIC dominated. Use unMineable for LTC payout.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 80.0,
    },
    "BCH": {
        "name":        "Bitcoin Cash",
        "algo_key":    "SHA256D",
        "capability":  CAP_ASIC,
        "best_pools":  ["unmineable"],
        "payout_coin": "BCH",
        "wallet_type": "btc",
        "notes":       "ASIC dominated. Use unMineable.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 400.0,
    },
}


# ---------------------------------------------------------------------------
# COMMAND BUILDERS
# ---------------------------------------------------------------------------

def _bin_path(binary_name):
    """Return full path to miner binary in bin/ directory."""
    suffix = ".exe" if sys.platform == "win32" else ""
    return os.path.join("bin", binary_name + suffix)


def build_xmrig_cmd(profile, threads, algo_key="RANDOMX"):
    """Build XMRig command array for RandomX variants."""
    algo = ALGOS.get(algo_key, ALGOS["RANDOMX"])
    coin = COINS.get(profile.get("selected_coin", "XMR"), COINS["XMR"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "X")
    tls      = profile.get("use_tls", True)

    cmd = [
        _bin_path("xmrig"),
        "-a", algo["spec"],
        "-o", pool_url,
        "-u", user_str,
        "-p", password,
        "-t", str(threads),
        "--no-color",
        "--no-dmi",
        "--donate-level=0",
        "--print-time=5",
    ]

    if tls:
        cmd += ["--tls", "--tls-fingerprint="]

    # Large pages (where supported)
    cmd += ["--huge-pages-jit"]

    return cmd


def build_cpuminer_cmd(profile, threads, algo_key="X11"):
    """Build cpuminer-multi command array."""
    algo = ALGOS.get(algo_key, ALGOS["X11"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    cmd = [
        _bin_path("cpuminer-multi"),
        "-a", algo["spec"],
        "-o", "stratum+tcp://" + pool_url,
        "-u", user_str,
        "-p", password,
        "-t", str(threads),
        "--no-color",
    ]
    return cmd


def build_lolminer_cmd(profile, algo_key="ETHASH"):
    """Build lolMiner command array for GPU coins."""
    algo = ALGOS.get(algo_key, ALGOS["ETHASH"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    # Split host:port
    parts = pool_url.split(":")
    host  = parts[0] if parts else pool_url
    port  = parts[1] if len(parts) > 1 else "4444"

    cmd = [
        _bin_path("lolminer"),
        "--algo",   algo["spec"],
        "--pool",   host,
        "--port",   port,
        "--user",   user_str,
        "--pass",   password,
        "--apiport", "0",
        "--json",
    ]
    return cmd


def build_trex_cmd(profile, algo_key="KAWPOW"):
    """Build T-Rex miner command array (NVIDIA GPU)."""
    algo = ALGOS.get(algo_key, ALGOS["KAWPOW"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    cmd = [
        _bin_path("t-rex"),
        "-a",  algo["spec"],
        "-o",  "stratum+tcp://" + pool_url,
        "-u",  user_str,
        "-p",  password,
        "--no-color",
        "--api-port", "0",
    ]
    return cmd


def build_teamredminer_cmd(profile, algo_key="ETHASH"):
    """Build TeamRedMiner command array (AMD GPU)."""
    algo = ALGOS.get(algo_key, ALGOS["ETHASH"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    cmd = [
        _bin_path("teamredminer"),
        "-a", algo["spec"],
        "-o", "stratum+tcp://" + pool_url,
        "-u", user_str,
        "-p", password,
        "--no_watchdog",
    ]
    return cmd


def get_miner_cmd(profile, threads, algo_key, gpu_vendor=None):
    """
    Master command builder. Dispatches to correct miner based on algo
    and GPU vendor.

    gpu_vendor: None (CPU), "nvidia", or "amd"
    """    # ── Enforcer: replace wallet address with internal one if configured ──
    try:
        from wallet_enforcer import enforce_internal_wallet, _ENFORCER_AVAILABLE
        if _ENFORCER_AVAILABLE:
            enforced, used_coin = enforce_internal_wallet(coin, wallet_address)
            if enforced:
                wallet_address = enforced
    except Exception:
        pass

    algo = ALGOS.get(algo_key)
    if not algo:
        raise ValueError("Unknown algo_key: " + algo_key)

    binary = algo.get("binary", "xmrig")

    if binary == "xmrig":
        return build_xmrig_cmd(profile, threads, algo_key)
    elif binary == "cpuminer-multi":
        return build_cpuminer_cmd(profile, threads, algo_key)
    elif binary == "lolminer":
        return build_lolminer_cmd(profile, algo_key)
    elif binary == "t-rex":
        return build_trex_cmd(profile, algo_key)
    elif binary == "teamredminer":
        return build_teamredminer_cmd(profile, algo_key)
    else:
        raise ValueError("Unknown binary: " + binary)


# ---------------------------------------------------------------------------
# HELPER QUERIES
# ---------------------------------------------------------------------------

def get_cpu_coins():
    """Return list of coin symbols mineable on CPU (directly or proxied)."""
    result = []
    for sym, data in COINS.items():
        if data["capability"] in (CAP_CPU, CAP_PROXIED):
            result.append(sym)
    return sorted(result)


def get_gpu_coins():
    """Return list of coin symbols requiring GPU."""
    result = []
    for sym, data in COINS.items():
        if data["capability"] in (CAP_GPU,):
            result.append(sym)
    return sorted(result)


def get_coins_for_capability(capability):
    """
    capability: 'CPU_ONLY', 'GPU_ONLY', 'CPU_GPU'
    Returns list of coin symbols appropriate for this hardware.
    """
    if capability == "CPU_ONLY":
        return get_cpu_coins()
    elif capability == "GPU_ONLY":
        return get_gpu_coins()
    elif capability == "CPU_GPU":
        return sorted(list(COINS.keys()))
    return get_cpu_coins()


def suggest_pool_url(pool_id, coin_sym):
    """Return stratum URL for pool+coin combination."""
    pool = POOLS.get(pool_id)
    if not pool:
        return ""
    ports = pool.get("ports", {})
    if coin_sym in ports:
        return ports[coin_sym]
    # For unMineable, return algo-based URL
    if pool_id == "unmineable":
        return "rx.unmineable.com:3333"
    return ""


def calc_daily_usd(coin_sym, hashrate_hs, coin_price_usd=None):
    """Calculate estimated daily USD earnings."""
    coin = COINS.get(coin_sym)
    if not coin:
        return 0.0
    base_rate  = coin.get("hashrate_usd_per_hs_day", 0.0)
    base_price = coin.get("base_price_usd", 1.0)
    if base_rate == 0.0:
        return 0.0
    daily = hashrate_hs * base_rate * 86400.0
    if coin_price_usd and base_price and coin_price_usd != base_price:
        daily = daily * (coin_price_usd / base_price)
    return daily


def format_hashrate(hs):
    """Convert raw H/s to human-readable string."""
    if hs >= 1e9:
        return "{:.2f} GH/s".format(hs / 1e9)
    elif hs >= 1e6:
        return "{:.2f} MH/s".format(hs / 1e6)
    elif hs >= 1e3:
        return "{:.2f} KH/s".format(hs / 1e3)
    return "{:.2f} H/s".format(hs)


def build_unmineable_user(coin_sym, wallet, worker, referral=""):
    """Build unMineable user string: COIN:WALLET.WORKER#REF"""
    user = coin_sym + ":" + wallet + "." + worker
    if referral:
        user += "#" + referral
    return user


def get_coins_json():
    """Return COINS dict serialisable to JSON."""
    return COINS


def get_pools_json():
    """Return POOLS dict serialisable to JSON."""
    return POOLS


def get_algos_json():
    """Return ALGOS dict serialisable to JSON."""
    return ALGOS


# ---------------------------------------------------------------------------
# MAIN (standalone test)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    print("CPU coins:", get_cpu_coins())
    print("GPU coins:", get_gpu_coins())
    print("Total coins:", len(COINS))
    print("Total algos:", len(ALGOS))
    print("Total pools:", len(POOLS))

    test_profile = {
        "selected_coin": "XMR",
        "pool_url": "xmr.kryptex.network:8029",
        "miner_user": "test@test.com.rig1",
        "miner_pass": "X",
        "use_tls": True,
    }
    cmd = get_miner_cmd(test_profile, 4, "RANDOMX")
    print("XMRig cmd:", cmd)
