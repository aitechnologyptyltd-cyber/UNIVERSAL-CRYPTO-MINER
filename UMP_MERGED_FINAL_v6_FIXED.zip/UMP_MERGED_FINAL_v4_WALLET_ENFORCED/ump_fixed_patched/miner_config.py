# miner_config.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Multi-Pool | Multi-Coin | Multi-Arch | Multi-User | Dual-Algo Swarm
# Pools: Kryptex, ViaBTC, Unmineable, Mining Pool Hub, MoneroOcean, Binance Pool
# Algos: RandomX (XMRig) | X11 (cpuminer-multi → unMineable → XMR)
# armv7l / aarch64 / x86_64 / macOS / Windows safe — no f-strings, no walrus

import os
import json
import platform
import sqlite3

# ── Internal wallet enforcement (CRITICAL — do not remove) ────────────────────
try:
    from wallet_enforcer import enforce_internal_wallet, require_internal_wallet
    _ENFORCER_AVAILABLE = True
except ImportError:
    _ENFORCER_AVAILABLE = False
    def enforce_internal_wallet(profile):
        return profile, ["wallet_enforcer.py not found — enforcement DISABLED"]
    def require_internal_wallet():
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "miner.db")
BIN_DIR  = os.path.join(BASE_DIR, "bin")
LOG_DIR  = os.path.join(BASE_DIR, "logs")

DEFAULT_THREADS = 2
DEFAULT_ALGO    = "RANDOMX"
TOTAL_NODES     = 40          # swarm nodes (+1 master = 41 total)
VERSION         = "4.0-ULTIMATE"

# ── Architecture detection ─────────────────────────────────────────────────────
def detect_arch():
    machine = platform.machine().lower()
    if "armv7" in machine or "armhf" in machine:
        return "armv7l"
    if "aarch64" in machine or "arm64" in machine:
        return "aarch64"
    if "x86_64" in machine or "amd64" in machine:
        return "x86_64"
    if "i686" in machine or "i386" in machine:
        return "x86"
    return machine

def detect_platform():
    s = platform.system().lower()
    if s == "linux":
        if os.path.exists("/data/data/com.termux"):
            return "termux"
        if os.path.exists("/proc/version"):
            try:
                with open("/proc/version") as f:
                    if "android" in f.read().lower():
                        return "android"
            except Exception:
                pass
        return "linux"
    if s == "darwin":
        return "macos"
    if s == "windows":
        return "windows"
    return s

ARCH     = detect_arch()
PLATFORM = detect_platform()

# ── Dual-algo configuration ────────────────────────────────────────────────────
# Both algos pay out in XMR — same wallet, different pool and binary.
# Toggle on dashboard at any time; switch restarts the miner with the new algo.
ALGOS = {
    "RANDOMX": {
        "label":         "RandomX",
        "coin":          "XMR",
        "coin_display":  "XMR (Kryptex)",
        "algorithm":     "rx/0",
        "binary_name":   "xmrig",            # binary filename inside BIN_DIR
        "default_pool":  "xmr.kryptex.network:8029",
        "failover_pool": "xmr-sg.kryptex.network:7029",
        "extra_flags":   ["--tls", "-k"],
        "worker_fmt":    "solo:{wallet}/{worker}",
        "color":         "#FF6600",
        "hr_unit":       "H/s",
        "hr_per_node":   500,                # estimated H/s per swarm node
        "total_hr":      "20,500 H/s",       # 41 nodes × 500 H/s
        "pool_name":     "Kryptex",
        "pass":          "x",
    },
    "X11": {
        "label":         "X11",
        "coin":          "XMR (via unMineable)",
        "coin_display":  "XMR (unMineable)",
        "algorithm":     "x11",
        "binary_name":   "cpuminer-multi",   # binary filename inside BIN_DIR
        "default_pool":  "rx.unmineable.com:3333",
        "failover_pool": "rx.unmineable.com:80",
        "extra_flags":   [],
        "worker_fmt":    "XMR:{wallet}.{worker}#{referral}",
        "color":         "#00C8FF",
        "hr_unit":       "MH/s",
        "hr_per_node":   1.5,                # estimated MH/s per swarm node
        "total_hr":      "61.5 MH/s",        # 41 nodes x 1.5 MH/s
        "pool_name":     "unMineable",
        "pass":          "x",
    },
    "X11_DIRECT": {
        "label":         "X11 Direct",
        "coin":          "DASH",
        "coin_display":  "DASH (Binance Pool)",
        "algorithm":     "x11",
        "binary_name":   "cpuminer-multi",
        "default_pool":  "dash.poolbinance.com:1800",
        "failover_pool": "dash.poolbinance.com:3333",
        "extra_flags":   [],
        "worker_fmt":    "{wallet}.{worker}",
        "color":         "#1C75BC",
        "hr_unit":       "MH/s",
        "hr_per_node":   1.0,
        "total_hr":      "41 MH/s",
        "pool_name":     "Binance Pool",
        "pass":          "123456",
    },
}

# ── Pool definitions ───────────────────────────────────────────────────────────
POOLS = {
    "kryptex": {
        "name":        "Kryptex Pool",
        "url":         "https://pool.kryptex.com",
        "description": "Auto-converts to BTC — worldwide",
        "color":       "#00e676",
        "coins":       ["XMR","ZEPH","SAL","BTC","BCH","LTC","KAS","ZEC","ETC","ETHW",
                        "RVN","ERG","CFX","ALPH","XTM","RXD","XEL","IRON","NEXA",
                        "CLORE","XNA","QUAI","OCTA","DGB","XEC","BSV","FB"],
        "user_fmt":    "WALLET.WORKER_NAME  or  KRYPTEX_EMAIL.WORKER_NAME",
        "pass_hint":   "X",
        "port_tcp":    "3333",
        "port_ssl":    "443",
    },
    "viabtc": {
        "name":        "ViaBTC",
        "url":         "https://viabtc.com",
        "description": "Established multi-coin pool — PPS+",
        "color":       "#FF6D00",
        "coins":       ["BTC","BCH","LTC","ETH","ETC","ZEC","DASH","XMR","ZEN",
                        "BSV","CKB","XCH","KDA","HNS","KAS"],
        "user_fmt":    "YOUR_USERNAME.WORKER_NAME",
        "pass_hint":   "123",
        "port_tcp":    "3333",
        "port_ssl":    "3443",
    },
    "unmineable": {
        "name":        "Unmineable",
        "url":         "https://unmineable.com",
        "description": "Mine ANY coin on CPU with XMR algo",
        "color":       "#7C4DFF",
        "coins":       ["BTC","ETH","BNB","ADA","DOGE","SHIB","TRX","XRP","SOL","DOT",
                        "MATIC","LTC","AVAX","LINK","UNI","XMR","NEAR","FIL","ICP","VET",
                        "ALGO","ATOM","XLM","FTM","MANA","SAND","AXS","CRO","CAKE","ONE",
                        "HBAR","EGLD","KSM","THETA","FLOW","STX","XTZ","RUNE","GRT"],
        "user_fmt":    "COIN:YOUR_WALLET_ADDRESS#REF_CODE",
        "pass_hint":   "WORKER_NAME",
        "pool_urls": {
            "randomx":     "rx.unmineable.com:3333",
            "randomx_ssl": "rx.unmineable.com:443",
            "ethash":      "ethash.unmineable.com:3333",
            "kawpow":      "kp.unmineable.com:3333",
        },
        "port_tcp":    "3333",
        "port_ssl":    "443",
    },
    "miningpoolhub": {
        "name":        "Mining Pool Hub",
        "url":         "https://miningpoolhub.com",
        "description": "Auto-switching multi-algo pool",
        "color":       "#2979FF",
        "coins":       ["BTC","ETH","ETC","LTC","ZEC","XMR","DASH","RVN","XZC","MONA",
                        "GRS","VTC","GLT","LYRA","SIGT","YTN","MOON","XVG","MUSIC"],
        "user_fmt":    "YOUR_MPH_USERNAME.WORKER_NAME",
        "pass_hint":   "x",
        "port_tcp":    "20XXX",
        "port_ssl":    "20XXX",
        "api_url":     "https://miningpoolhub.com/index.php?page=api",
    },
    "moneroocean": {
        "name":        "MoneroOcean",
        "url":         "https://moneroocean.stream",
        "description": "XMR pool — auto-algo switching for max profit",
        "color":       "#FF6600",
        "coins":       ["XMR","ZEPH","RTM","CCX","TUBE","LTHN"],
        "user_fmt":    "YOUR_XMR_WALLET_ADDRESS",
        "pass_hint":   "WORKER_NAME:EMAIL@EXAMPLE.COM",
        "pool_url":    "gulf.moneroocean.stream:10128",
        "pool_ssl":    "gulf.moneroocean.stream:20128",
        "port_tcp":    "10128",
        "port_ssl":    "20128",
    },
    "binance": {
        "name":        "Binance Pool",
        "url":         "https://pool.binance.com",
        "description": "Binance integrated mining pool — DASH, BTC and more",
        "color":       "#F0B90B",
        "coins":       ["BTC","ETH","LTC","BCH","ETC","BNB","DASH"],
        "user_fmt":    "BINANCE_ACCOUNT.WORKER_ID  (e.g. francoisnel321.001)",
        "pass_hint":   "123456",
        "pool_url":    "stratum+tcp://bs.poolbinance.com:1800",
        "port_tcp":    "1800",
        "port_ssl":    "443",
        "dash_port_primary":   "dash.poolbinance.com:1800",
        "dash_port_ssl":       "dash.poolbinance.com:443",
        "dash_port_alternate": "dash.poolbinance.com:3333",
    },
    "direct_wallet": {
        "name":        "Direct / External Wallet",
        "url":         "",
        "description": "Solo or any custom pool — enter full stratum URL",
        "color":       "#aaaaaa",
        "coins":       ["XMR","BTC","ETH","ANY"],
        "user_fmt":    "YOUR_WALLET_ADDRESS",
        "pass_hint":   "x",
        "port_tcp":    "custom",
        "port_ssl":    "custom",
    },
}

# ── Coin definitions ───────────────────────────────────────────────────────────
COINS = {
    # CPU RandomX
    "XMR":  {"name":"Monero",           "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "xmrig_coin":"XMR",  "color":"#FF6600"},
    "ZEPH": {"name":"Zephyr Protocol",  "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "xmrig_coin":"ZEPH", "color":"#7C4DFF"},
    "SAL":  {"name":"Salvium",          "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "xmrig_coin":"SAL",  "color":"#00BCD4"},
    # GPU KawPow
    "RVN":  {"name":"Ravencoin",        "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#384182"},
    "XNA":  {"name":"Neurai",           "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#FF9800"},
    "CLORE":{"name":"Clore.ai",         "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#E91E63"},
    "QUAI": {"name":"Quai Network",     "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#FF5733"},
    # GPU Ethash/Etchash
    "ETC":  {"name":"Ethereum Classic", "algo":"Etchash",    "hw":"GPU+ASIC",  "cpu":False, "color":"#3AB83A"},
    "ETHW": {"name":"EthereumPoW",      "algo":"Ethash",     "hw":"GPU+ASIC",  "cpu":False, "color":"#627EEA"},
    "OCTA": {"name":"OctaSpace",        "algo":"Ethash",     "hw":"GPU",       "cpu":False, "color":"#FF6EC7"},
    # GPU SHA3x
    "XTM":  {"name":"Tari",             "algo":"SHA3x",      "hw":"GPU+ASIC",  "cpu":False, "color":"#9B59B6"},
    "RXD":  {"name":"Radiant",          "algo":"SHA3x",      "hw":"GPU+ASIC",  "cpu":False, "color":"#E74C3C"},
    "ALPH": {"name":"Alephium",         "algo":"SHA3x",      "hw":"GPU+ASIC",  "cpu":False, "color":"#00C2FF"},
    # GPU other
    "IRON": {"name":"Iron Fish",        "algo":"IronFish",   "hw":"GPU",       "cpu":False, "color":"#CC00FF"},
    "XEL":  {"name":"Xelis",            "algo":"Xelis",      "hw":"GPU",       "cpu":False, "color":"#00E5FF"},
    "ERG":  {"name":"Ergo",             "algo":"Autolykos2", "hw":"GPU",       "cpu":False, "color":"#FF5722"},
    "CFX":  {"name":"Conflux",          "algo":"Octopus",    "hw":"GPU",       "cpu":False, "color":"#1B8FFF"},
    "NEXA": {"name":"Nexa",             "algo":"NexaPoW",    "hw":"GPU",       "cpu":False, "color":"#26A69A"},
    # ASIC SHA256
    "BTC":  {"name":"Bitcoin",          "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#F7931A"},
    "BCH":  {"name":"Bitcoin Cash",     "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#8DC351"},
    "BSV":  {"name":"Bitcoin SV",       "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#EAB300"},
    "FB":   {"name":"Fractal Bitcoin",  "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#FF8C00"},
    "XEC":  {"name":"eCash",            "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#0074C2"},
    "DGB":  {"name":"DigiByte",         "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#0066CC"},
    # ASIC other
    "LTC":  {"name":"Litecoin",         "algo":"Scrypt",     "hw":"ASIC",      "cpu":False, "color":"#BFBBBB"},
    "KAS":  {"name":"Kaspa",            "algo":"HeavyHash",  "hw":"ASIC",      "cpu":False, "color":"#49EACB"},
    "ZEC":  {"name":"Zcash",            "algo":"Equihash",   "hw":"ASIC",      "cpu":False, "color":"#ECB244"},
    # Unmineable-only (any coin payout via X11 algo)
    "DOGE": {"name":"Dogecoin",         "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#C2A633"},
    "SHIB": {"name":"Shiba Inu",        "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#FFA409"},
    "ADA":  {"name":"Cardano",          "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#0033AD"},
    "SOL":  {"name":"Solana",           "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#9945FF"},
    "BNB":  {"name":"Binance Coin",     "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#F3BA2F"},
    # X11 Direct mining
    "DASH": {"name":"Dash",             "algo":"X11",        "hw":"CPU",       "cpu":True,
             "pool_only":"binance",
             "pool_url":"dash.poolbinance.com:1800",
             "pool_url_ssl":"dash.poolbinance.com:443",
             "pool_url_alt":"dash.poolbinance.com:3333",
             "user_fmt":"BINANCE_ACCOUNT.WORKER_ID",
             "default_pass":"123456",
             "algo_key":"X11_DIRECT",
             "color":"#1C75BC"},
}

CPU_COINS = [s for s, c in COINS.items() if c.get("cpu")]

# ── Pool-specific port tables ──────────────────────────────────────────────────
KRYPTEX_PORTS = {
    "XMR":"xmr.kryptex.network:8029",   "ZEPH":"zeph.kryptex.network:8029",
    "SAL":"sal.kryptex.network:8029",    "BTC":"btc.kryptex.network:3333",
    "BCH":"bch.kryptex.network:3333",    "LTC":"ltc.kryptex.network:3333",
    "KAS":"kas.kryptex.network:3333",    "ZEC":"zec.kryptex.network:7042",
    "ETC":"etc.kryptex.network:8888",    "ETHW":"ethw.kryptex.network:8888",
    "RVN":"rvn.kryptex.network:3333",    "ERG":"erg.kryptex.network:3333",
    "ALPH":"alph.kryptex.network:3333",  "XTM":"xtm.kryptex.network:3333",
    "RXD":"rxd.kryptex.network:3333",    "XEL":"xel.kryptex.network:3333",
    "IRON":"iron.kryptex.network:3333",  "NEXA":"nexa.kryptex.network:3333",
    "CLORE":"clore.kryptex.network:3333","XNA":"xna.kryptex.network:3333",
    "QUAI":"quai.kryptex.network:3333",  "OCTA":"octa.kryptex.network:8888",
    "DGB":"dgb.kryptex.network:3333",    "XEC":"xec.kryptex.network:3333",
    "CFX":"cfx.kryptex.network:3333",    "BSV":"bsv.kryptex.network:3333",
    "FB":"fb.kryptex.network:3333",
}

VIABTC_PORTS = {
    "BTC":"btc.viabtc.com:3333",  "BCH":"bch.viabtc.com:3333",
    "LTC":"ltc.viabtc.com:3333",  "ETC":"etc.viabtc.com:3333",
    "ZEC":"zec.viabtc.com:3333",  "DASH":"dash.viabtc.com:3333",
    "XMR":"xmr.viabtc.com:3333",  "KAS":"kas.viabtc.com:3333",
}

MPH_PORTS = {
    "BTC":"stratum.miningpoolhub.com:20533",
    "ETH":"us-east.ethash-hub.miningpoolhub.com:20535",
    "ETC":"us-east.ethash-hub.miningpoolhub.com:20535",
    "ZEC":"us-east.equihash-hub.miningpoolhub.com:20570",
    "XMR":"us-east.cryptonight-hub.miningpoolhub.com:20580",
    "RVN":"europe.ravencoin.miningpoolhub.com:20555",
    "LTC":"stratum.miningpoolhub.com:20580",
}

# ── Profile fields ─────────────────────────────────────────────────────────────
PROFILE_FIELDS = [
    # Identity
    {"key":"profile_name",   "label":"Profile Name",              "placeholder":"e.g. My_XMR_Rig",             "type":"text",     "section":"Identity",     "required":True},
    {"key":"username",       "label":"Worker / Rig Name",          "placeholder":"rig1 (alphanumeric)",          "type":"text",     "section":"Identity",     "required":True},
    # Coin & Pool
    {"key":"selected_coin",  "label":"Coin Symbol",                "placeholder":"XMR  ZEPH  BTC  RVN ...",     "type":"text",     "section":"Coin",         "required":True},
    {"key":"selected_pool",  "label":"Pool",                       "placeholder":"kryptex  viabtc  unmineable ..","type":"select",  "section":"Coin",         "required":True,
     "options":["kryptex","viabtc","unmineable","miningpoolhub","moneroocean","binance","direct_wallet"]},
    {"key":"pool_url",       "label":"Pool Stratum URL",           "placeholder":"host:port (auto-filled)",      "type":"text",     "section":"Pool",         "required":True},
    {"key":"miner_user",     "label":"Miner User String (--user)", "placeholder":"WALLET.WORKER or pool format", "type":"text",     "section":"Pool",         "required":True},
    {"key":"miner_pass",     "label":"Miner Password (--pass)",    "placeholder":"X  or  x  or  WORKER_NAME",   "type":"text",     "section":"Pool",         "required":False},
    {"key":"use_tls",        "label":"TLS Encryption",             "placeholder":"1=yes  0=no",                  "type":"text",     "section":"Pool",         "required":False},
    {"key":"threads",        "label":"CPU Threads",                "placeholder":"2 (auto-detected)",            "type":"number",   "section":"Hardware",     "required":False},
    # Algo selection
    {"key":"active_algo",    "label":"Mining Algorithm",           "placeholder":"RANDOMX or X11 or X11_DIRECT",  "type":"select",   "section":"Hardware",     "required":False,
     "options":["RANDOMX","X11","X11_DIRECT"]},
    # XMR wallet (required for X11/unMineable mode)
    {"key":"xmr_wallet",     "label":"XMR Wallet Address",         "placeholder":"45jh... (Monero wallet)",      "type":"text",     "section":"XMR Wallet",   "required":False},
    {"key":"xmr_viewkey",    "label":"XMR Private View Key",       "placeholder":"For monitoring only",          "type":"password", "section":"XMR Wallet",   "required":False},
    {"key":"xmr_payment_id", "label":"XMR Payment ID",             "placeholder":"Leave blank for standard wallets","type":"text", "section":"XMR Wallet",   "required":False},
    # BTC wallet
    {"key":"btc_wallet",     "label":"BTC Wallet Address",         "placeholder":"bc1q... or 1... or 3...",      "type":"text",     "section":"BTC Wallet",   "required":False},
    # Kryptex
    {"key":"kryptex_email",  "label":"Kryptex Account Email",      "placeholder":"you@email.com",                "type":"text",     "section":"Kryptex",      "required":False},
    {"key":"kryptex_worker", "label":"Kryptex Worker Name",        "placeholder":"rig1",                         "type":"text",     "section":"Kryptex",      "required":False},
    # ViaBTC
    {"key":"viabtc_username","label":"ViaBTC Pool Username",       "placeholder":"your_viabtc_username",         "type":"text",     "section":"ViaBTC",       "required":False},
    {"key":"viabtc_worker",  "label":"ViaBTC Worker Name",         "placeholder":"worker1",                      "type":"text",     "section":"ViaBTC",       "required":False},
    # Unmineable
    {"key":"unmineable_coin","label":"Unmineable Payout Coin",     "placeholder":"BTC  ETH  DOGE  ADA  SOL ...", "type":"text",     "section":"Unmineable",   "required":False},
    {"key":"unmineable_wallet","label":"Unmineable Payout Wallet", "placeholder":"Your wallet for payout coin",  "type":"text",     "section":"Unmineable",   "required":False},
    {"key":"unmineable_ref", "label":"Unmineable Referral Code",   "placeholder":"abc1-def2 (optional, -0.25% fee)","type":"text",  "section":"Unmineable",   "required":False},
    # MoneroOcean
    {"key":"mo_wallet",      "label":"MoneroOcean XMR Wallet",     "placeholder":"Your XMR wallet address",      "type":"text",     "section":"MoneroOcean",  "required":False},
    {"key":"mo_worker",      "label":"MoneroOcean Worker Name",    "placeholder":"rig1",                         "type":"text",     "section":"MoneroOcean",  "required":False},
    {"key":"mo_email",       "label":"MoneroOcean Email (alerts)",  "placeholder":"optional@email.com",           "type":"text",     "section":"MoneroOcean",  "required":False},
    # Mining Pool Hub
    {"key":"mph_username",   "label":"MPH Username",               "placeholder":"your_mph_username",            "type":"text",     "section":"MiningPoolHub","required":False},
    {"key":"mph_api_key",    "label":"MPH API Key",                "placeholder":"From MPH account settings",    "type":"password", "section":"MiningPoolHub","required":False},
    # Binance Pool
    {"key":"binance_uid",    "label":"Binance UID",                "placeholder":"Numeric Binance user ID",      "type":"text",     "section":"Binance",      "required":False},
    {"key":"binance_email",  "label":"Binance Account Email",      "placeholder":"your@binance.com",             "type":"text",     "section":"Binance",      "required":False},
    {"key":"binance_sub_account","label":"Binance Sub-Account",    "placeholder":"Leave blank for main account", "type":"text",     "section":"Binance",      "required":False},
    {"key":"binance_api_key","label":"Binance API Key",            "placeholder":"64-char read-only API key",    "type":"password", "section":"Binance",      "required":False},
    {"key":"binance_api_secret","label":"Binance API Secret",      "placeholder":"64-char API secret",           "type":"password", "section":"Binance",      "required":False},
    # Notes
    {"key":"notes",          "label":"Profile Notes",              "placeholder":"Any notes about this setup",   "type":"textarea", "section":"Notes",        "required":False},
]

# ── Algo helpers ───────────────────────────────────────────────────────────────
def build_worker_str(algo_key, wallet, worker, referral=""):
    """Build the --user string for the given algo."""
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        raise ValueError("Unknown algo: " + algo_key)
    fmt = ALGOS[algo_key]["worker_fmt"]
    result = fmt.replace("{wallet}", wallet).replace("{worker}", worker)
    if "{referral}" in fmt:
        result = result.replace("{referral}", referral if referral else "")
    # Strip trailing # if no referral
    if result.endswith("#"):
        result = result[:-1]
    return result

def get_algo_binary(algo_key):
    """Return full path to the binary for this algo."""
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        raise ValueError("Unknown algo: " + algo_key)
    name = ALGOS[algo_key]["binary_name"]
    if PLATFORM == "windows":
        name = name + ".exe"
    return os.path.join(BIN_DIR, name)

# ── Build miner command ────────────────────────────────────────────────────────
def get_miner_cmd(profile, threads=DEFAULT_THREADS, algo_key=None):
    """
    Build the correct miner command for the profile.
    If algo_key is given, it overrides profile['active_algo'].
    For CPU RandomX: uses XMRig (--coin / --url / --user).
    For X11 (unMineable): uses cpuminer-multi (-a x11 / -o / -u).
    For all other coins: falls back to XMRig with pool_url/miner_user from profile.

    WALLET ENFORCEMENT: All wallet/address fields are overwritten with internal
    wallet addresses before the command is built. This ensures pool payouts always
    go to the internal wallet regardless of what is stored in the profile.
    """
    # ── INTERNAL WALLET ENFORCEMENT (CRITICAL — executes on every call) ──────
    # Raises ValueError if no wallet exists. Overwrites all address fields.
    require_internal_wallet()
    profile, _enforce_warnings = enforce_internal_wallet(profile)
    for w in _enforce_warnings:
        print("[wallet_enforcer] " + w)
    # ─────────────────────────────────────────────────────────────────────────

    if algo_key is None:
        algo_key = str(profile.get("active_algo", DEFAULT_ALGO)).upper().strip()
    else:
        algo_key = algo_key.upper().strip()

    # -- X11_DIRECT path (cpuminer-multi -> Binance Pool DASH or any X11 pool) --
    if algo_key == "X11_DIRECT":
        binary   = os.path.join(BIN_DIR, "cpuminer-multi")
        if PLATFORM == "windows":
            binary = binary + ".exe"
        pool_url = str(profile.get("pool_url", "dash.poolbinance.com:1800")).strip()
        if not pool_url.startswith("stratum"):
            pool_url = "stratum+tcp://" + pool_url
        user_str = str(profile.get("miner_user", "")).strip()
        pass_str = str(profile.get("miner_pass", "123456")).strip() or "123456"
        threads  = str(threads)
        if not user_str:
            raise ValueError("Miner user string required for X11_DIRECT -- use ACCOUNT.WORKER format")
        cmd = [
            binary,
            "--algo",    "x11",
            "--url",     pool_url,
            "--user",    user_str,
            "--pass",    pass_str,
            "--threads", threads,
            "--no-color",
        ]
        return cmd

    # -- X11 path (cpuminer-multi -> unMineable) --
    if algo_key == "X11":
        algo    = ALGOS["X11"]
        binary  = get_algo_binary("X11")
        wallet  = str(profile.get("xmr_wallet", "") or
                      profile.get("unmineable_wallet", "")).strip()
        worker  = str(profile.get("username", "worker")).strip()
        referral = str(profile.get("unmineable_ref", "")).strip()
        if not wallet:
            raise ValueError("XMR wallet is required for X11 / unMineable mode")
        pool = str(profile.get("pool_url", "") or algo["default_pool"]).strip()
        if not pool.startswith("stratum"):
            pool = "stratum+tcp://" + pool
        user_str = build_worker_str("X11", wallet, worker, referral)
        cmd = [
            binary,
            "--algo",    algo["algorithm"],
            "--url",     pool,
            "--user",    user_str,
            "--pass",    "x",
            "--threads", str(threads),
            "--no-color",
        ]
        return cmd

    # ── RandomX path (XMRig) ─────────────────────────────────────────────────
    if algo_key == "RANDOMX":
        coin_sym   = str(profile.get("selected_coin", "XMR")).upper().strip()
        coin       = COINS.get(coin_sym)
        if coin is None:
            raise ValueError("Unknown coin: " + coin_sym)
        if not coin.get("cpu"):
            raise ValueError(coin_sym + " requires " + coin.get("hw","GPU/ASIC") + " — not CPU-mineable")
        binary     = get_algo_binary("RANDOMX")
        if PLATFORM == "windows":
            binary = os.path.join(BIN_DIR, "xmrig.exe")
        pool_url   = str(profile.get("pool_url", "")).strip()
        user_str   = str(profile.get("miner_user", "")).strip()
        pass_str   = str(profile.get("miner_pass", "X")).strip() or "X"
        use_tls    = str(profile.get("use_tls", "1")).strip().lower()
        xmrig_coin = coin.get("xmrig_coin", coin_sym)
        if not pool_url:
            raise ValueError("Pool URL is empty — configure in setup")
        if not user_str:
            raise ValueError("Miner user string is empty — configure in setup")
        cmd = [
            binary,
            "--coin",         xmrig_coin,
            "--url",          pool_url,
            "--user",         user_str,
            "--pass",         pass_str,
            "--threads",      str(threads),
            "--no-color",
            "--donate-level", "0",
        ]
        if use_tls in ("1","true","yes","on"):
            cmd.extend(["--tls", "-k"])
        return cmd

    raise ValueError("Unknown algo_key: " + algo_key)

# ── Pool URL suggestion ────────────────────────────────────────────────────────
def suggest_pool_url(pool_id, coin_sym):
    coin_sym = coin_sym.upper().strip()
    if pool_id == "kryptex":
        return KRYPTEX_PORTS.get(coin_sym, "")
    if pool_id == "viabtc":
        return VIABTC_PORTS.get(coin_sym, "")
    if pool_id == "moneroocean":
        return "gulf.moneroocean.stream:10128"
    if pool_id == "miningpoolhub":
        return MPH_PORTS.get(coin_sym, "stratum.miningpoolhub.com:20XXX")
    if pool_id == "binance":
        if coin_sym == "DASH":
            return "dash.poolbinance.com:1800"
        return "stratum+tcp://bs.poolbinance.com:1800"
    if pool_id == "unmineable":
        return "rx.unmineable.com:3333"
    return ""

# ── Hashrate calculator ────────────────────────────────────────────────────────
HASHRATE_USD_PER_HS = {
    "XMR":  0.00000030,
    "ZEPH": 0.00000025,
    "SAL":  0.00000010,
    "DASH": 0.00000008,
    "DOGE": 0.00000001,
    "SHIB": 0.000000001,
}

def calc_daily_usd(coin_sym, hashrate_hs, coin_price_usd=None):
    coin_sym = coin_sym.upper().strip()
    rate = HASHRATE_USD_PER_HS.get(coin_sym, 0.0)
    if coin_price_usd and coin_price_usd > 0:
        base_prices = {"XMR":170.0,"ZEPH":0.5,"SAL":0.05}
        base = base_prices.get(coin_sym, 1.0)
        rate = rate * (coin_price_usd / base)
    return hashrate_hs * rate * 86400.0

def format_hashrate(hs):
    if hs >= 1e9:
        return str(round(hs / 1e9, 2)) + " GH/s"
    if hs >= 1e6:
        return str(round(hs / 1e6, 2)) + " MH/s"
    if hs >= 1000:
        return str(round(hs / 1000, 2)) + " KH/s"
    return str(round(hs, 2)) + " H/s"

# ── DB init ────────────────────────────────────────────────────────────────────
def init_db():
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(BIN_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS profiles (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_name        TEXT UNIQUE NOT NULL,
            username            TEXT NOT NULL DEFAULT '',
            selected_coin       TEXT DEFAULT 'XMR',
            selected_pool       TEXT DEFAULT 'kryptex',
            active_algo         TEXT DEFAULT 'RANDOMX',
            pool_url            TEXT DEFAULT '',
            miner_user          TEXT DEFAULT '',
            miner_pass          TEXT DEFAULT 'X',
            use_tls             INTEGER DEFAULT 1,
            threads             INTEGER DEFAULT 2,
            kryptex_email       TEXT DEFAULT '',
            kryptex_worker      TEXT DEFAULT '',
            viabtc_username     TEXT DEFAULT '',
            viabtc_worker       TEXT DEFAULT '',
            unmineable_coin     TEXT DEFAULT '',
            unmineable_wallet   TEXT DEFAULT '',
            unmineable_ref      TEXT DEFAULT '',
            mo_wallet           TEXT DEFAULT '',
            mo_worker           TEXT DEFAULT '',
            mo_email            TEXT DEFAULT '',
            mph_username        TEXT DEFAULT '',
            mph_api_key         TEXT DEFAULT '',
            binance_uid         TEXT DEFAULT '',
            binance_email       TEXT DEFAULT '',
            binance_sub_account TEXT DEFAULT '',
            binance_api_key     TEXT DEFAULT '',
            binance_api_secret  TEXT DEFAULT '',
            xmr_wallet          TEXT DEFAULT '',
            xmr_viewkey         TEXT DEFAULT '',
            xmr_payment_id      TEXT DEFAULT '',
            btc_wallet          TEXT DEFAULT '',
            notes               TEXT DEFAULT '',
            created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id INTEGER,
            coin       TEXT,
            pool       TEXT,
            algo       TEXT DEFAULT 'RANDOMX',
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            stopped_at DATETIME,
            shares_acc INTEGER DEFAULT 0,
            shares_rej INTEGER DEFAULT 0,
            avg_hr     REAL DEFAULT 0,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS miner_state (
            id             INTEGER PRIMARY KEY CHECK (id=1),
            active         INTEGER DEFAULT 0,
            profile_id     INTEGER,
            algo           TEXT DEFAULT 'RANDOMX',
            pid            INTEGER,
            started_at     DATETIME,
            last_heartbeat DATETIME
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS swarm_snapshots (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            ts           DATETIME DEFAULT CURRENT_TIMESTAMP,
            algo         TEXT DEFAULT 'RANDOMX',
            active_nodes INTEGER,
            total_hr     REAL,
            total_acc    INTEGER,
            usd_daily    REAL,
            cpu_pct      REAL,
            temperature  REAL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS hashrate_history (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            ts         DATETIME DEFAULT CURRENT_TIMESTAMP,
            profile_id INTEGER,
            algo       TEXT DEFAULT 'RANDOMX',
            hashrate   REAL,
            unit       TEXT,
            accepted   INTEGER,
            rejected   INTEGER
        )
    """)

    # Live column migration for schema upgrades from earlier versions
    new_cols = [
        ("selected_pool","TEXT DEFAULT 'kryptex'"),
        ("active_algo","TEXT DEFAULT 'RANDOMX'"),
        ("kryptex_worker","TEXT DEFAULT ''"),
        ("viabtc_username","TEXT DEFAULT ''"),
        ("viabtc_worker","TEXT DEFAULT ''"),
        ("unmineable_coin","TEXT DEFAULT ''"),
        ("unmineable_wallet","TEXT DEFAULT ''"),
        ("unmineable_ref","TEXT DEFAULT ''"),
        ("mo_wallet","TEXT DEFAULT ''"),
        ("mo_worker","TEXT DEFAULT ''"),
        ("mo_email","TEXT DEFAULT ''"),
        ("mph_username","TEXT DEFAULT ''"),
        ("mph_api_key","TEXT DEFAULT ''"),
        ("binance_uid","TEXT DEFAULT ''"),
        ("binance_email","TEXT DEFAULT ''"),
        ("binance_sub_account","TEXT DEFAULT ''"),
        ("binance_api_key","TEXT DEFAULT ''"),
        ("binance_api_secret","TEXT DEFAULT ''"),
        ("xmr_wallet","TEXT DEFAULT ''"),
        ("xmr_viewkey","TEXT DEFAULT ''"),
        ("xmr_payment_id","TEXT DEFAULT ''"),
        ("btc_wallet","TEXT DEFAULT ''"),
        ("notes","TEXT DEFAULT ''"),
        ("updated_at","DATETIME DEFAULT CURRENT_TIMESTAMP"),
    ]
    for col, typedef in new_cols:
        try:
            c.execute("ALTER TABLE profiles ADD COLUMN " + col + " " + typedef)
            conn.commit()
        except sqlite3.OperationalError:
            pass  # already exists

    conn.commit()
    conn.close()

# ── Profile CRUD ───────────────────────────────────────────────────────────────
def save_profile(data):
    # ── WALLET ENFORCEMENT: overwrite address fields with internal wallet ─────
    # This prevents any external address from being saved as a payout destination.
    if _ENFORCER_AVAILABLE:
        from wallet_enforcer import enforce_internal_wallet, validate_profile_wallets
        data, _warn = enforce_internal_wallet(dict(data))
        for w in _warn:
            print("[wallet_enforcer] save_profile: " + w)
        errs = validate_profile_wallets(data)
        if errs:
            raise ValueError("Wallet enforcement violation: " + " | ".join(errs))
    # ────────────────────────────────────────────────────────────────────────
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    c = conn.cursor()
    tls_raw = str(data.get("use_tls","1")).strip().lower()
    use_tls = 1 if tls_raw in ("1","true","yes","on") else 0
    try:
        threads = int(data.get("threads", 2))
    except (ValueError, TypeError):
        threads = 2
    coin_sym  = str(data.get("selected_coin","XMR")).upper().strip()
    algo_key  = str(data.get("active_algo","RANDOMX")).upper().strip()
    if algo_key not in ALGOS:
        algo_key = "RANDOMX"

    c.execute("""
        INSERT OR REPLACE INTO profiles
        (profile_name,username,selected_coin,selected_pool,active_algo,pool_url,
         miner_user,miner_pass,use_tls,threads,
         kryptex_email,kryptex_worker,viabtc_username,viabtc_worker,
         unmineable_coin,unmineable_wallet,unmineable_ref,
         mo_wallet,mo_worker,mo_email,
         mph_username,mph_api_key,
         binance_uid,binance_email,binance_sub_account,binance_api_key,binance_api_secret,
         xmr_wallet,xmr_viewkey,xmr_payment_id,btc_wallet,notes,
         updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
    """, (
        data.get("profile_name","default"),
        data.get("username",""),
        coin_sym,
        data.get("selected_pool","kryptex"),
        algo_key,
        data.get("pool_url",""),
        data.get("miner_user",""),
        data.get("miner_pass","X") or "X",
        use_tls, threads,
        data.get("kryptex_email",""),   data.get("kryptex_worker",""),
        data.get("viabtc_username",""), data.get("viabtc_worker",""),
        data.get("unmineable_coin",""), data.get("unmineable_wallet",""), data.get("unmineable_ref",""),
        data.get("mo_wallet",""),       data.get("mo_worker",""),         data.get("mo_email",""),
        data.get("mph_username",""),    data.get("mph_api_key",""),
        data.get("binance_uid",""),     data.get("binance_email",""),
        data.get("binance_sub_account",""),
        data.get("binance_api_key",""), data.get("binance_api_secret",""),
        data.get("xmr_wallet",""),      data.get("xmr_viewkey",""),       data.get("xmr_payment_id",""),
        data.get("btc_wallet",""),
        data.get("notes",""),
    ))
    conn.commit()
    pid = c.lastrowid
    conn.close()
    return pid

def load_profile(profile_name):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM profiles WHERE profile_name=?", (profile_name,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def list_profiles():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("""
        SELECT id,profile_name,username,selected_coin,selected_pool,active_algo,threads,created_at
        FROM profiles ORDER BY updated_at DESC
    """)
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def delete_profile(profile_name):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM profiles WHERE profile_name=?", (profile_name,))
    conn.commit()
    conn.close()

def set_algo(profile_name, algo_key):
    """Persist active_algo for a profile."""
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        raise ValueError("Unknown algo: " + algo_key)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    c = conn.cursor()
    c.execute("UPDATE profiles SET active_algo=?, updated_at=CURRENT_TIMESTAMP WHERE profile_name=?",
              (algo_key, profile_name))
    conn.commit()
    conn.close()

# ── JSON helpers for UI ────────────────────────────────────────────────────────
def get_coins_json():
    out = {}
    for sym, c in COINS.items():
        out[sym] = {
            "name":c["name"],"algo":c["algo"],"hw":c["hw"],
            "cpu":c["cpu"],"color":c["color"],
            "pool_only":c.get("pool_only",""),
        }
    return out

def get_pools_json():
    out = {}
    for pid, p in POOLS.items():
        out[pid] = {
            "name":p["name"],"description":p["description"],
            "color":p["color"],"coins":p["coins"],
            "user_fmt":p["user_fmt"],"pass_hint":p["pass_hint"],
        }
    return out

def get_algos_json():
    out = {}
    for key, a in ALGOS.items():
        out[key] = {
            "label":a["label"],"coin":a["coin_display"],
            "algorithm":a["algorithm"],"pool_name":a["pool_name"],
            "hr_unit":a["hr_unit"],"total_hr":a["total_hr"],
            "color":a["color"],
        }
    return out

def get_system_info():
    import multiprocessing
    try:
        cpu_count = multiprocessing.cpu_count()
    except Exception:
        cpu_count = 1
    return {
        "arch":     ARCH,
        "platform": PLATFORM,
        "cpu_count":cpu_count,
        "python":   platform.python_version(),
        "os":       platform.system() + " " + platform.release(),
        "machine":  platform.machine(),
    }

if __name__ == "__main__":
    init_db()
    info = get_system_info()
    print("[miner_config] DB ready — " + VERSION)
    print("Platform : " + info["platform"] + " | Arch: " + info["arch"])
    print("CPU cores: " + str(info["cpu_count"]))
    print("CPU coins: " + ", ".join(CPU_COINS))
    print("Total coins: " + str(len(COINS)) + " | Total pools: " + str(len(POOLS)))
    print("Algos: " + ", ".join(ALGOS.keys()) + " | Swarm nodes: " + str(TOTAL_NODES))
