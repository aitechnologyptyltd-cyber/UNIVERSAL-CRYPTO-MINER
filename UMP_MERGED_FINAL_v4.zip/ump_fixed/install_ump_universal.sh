#!/bin/bash
# =============================================================================
#  install_ump_universal.sh
#  Universal Miner Pro ULTIMATE v4.2 EXTENDED -- Universal Installer
#  NEW: Hardware detection | GPU miners | Profit switching | 60+ coins
#  Supports: Userland Ubuntu armv7l | aarch64 | Linux x86_64 | Termux
# =============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

log_ok()   { echo -e "${GREEN}  [OK]  $1${NC}"; }
log_warn() { echo -e "${YELLOW}  [WARN] $1${NC}"; }
log_err()  { echo -e "${RED}  [ERR] $1${NC}"; }
log_info() { echo -e "${CYAN}  [-->] $1${NC}"; }
log_step() { echo -e "\n${BOLD}${CYAN}=== STEP $1: $2 ===${NC}"; }

echo -e "${CYAN}"
echo "============================================================"
echo "   UMP UNIVERSAL INSTALLER v4.2 EXTENDED"
echo "   Hardware Detect | GPU Support | Profit Switching"
echo "   60+ Coins | 9 Pools | 40-Node Swarm"
echo "============================================================"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"
LOG_DIR="$SCRIPT_DIR/logs"
TMP_DIR="/tmp/ump_universal_$$"
BUILD_LOG="$SCRIPT_DIR/install.log"
HW_PROFILE="$SCRIPT_DIR/ump_hw_profile.json"
ERRORS=0
PY_BIN="python3"

mkdir -p "$BIN_DIR" "$LOG_DIR" "$TMP_DIR"
echo "UMP Universal Install started: $(date)" > "$BUILD_LOG"

# =============================================================================
# STEP 1 -- DETECT PLATFORM AND ARCHITECTURE
# =============================================================================
log_step "1/12" "Detecting platform and architecture"

ARCH="$(uname -m)"
PLATFORM="linux"
PKG_MGR="apt"
IS_TERMUX=0
IS_USERLAND=0

if [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=1
    PLATFORM="termux"
    PKG_MGR="pkg"
fi

if [ "$IS_TERMUX" -eq 0 ]; then
    if grep -qi "userland" /proc/version 2>/dev/null; then
        IS_USERLAND=1
        PLATFORM="userland_ubuntu"
    fi
fi

CPU_COUNT="$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null || echo 2)"
BUILD_JOBS="$(( CPU_COUNT > 1 ? CPU_COUNT - 1 : 1 ))"

log_ok "Platform   : $PLATFORM"
log_ok "Arch       : $ARCH"
log_ok "CPU Cores  : $CPU_COUNT (build jobs: $BUILD_JOBS)"
log_ok "Build log  : $BUILD_LOG"

# =============================================================================
# STEP 2 -- SYSTEM PACKAGES (apt or pkg)
# =============================================================================
log_step "2/12" "Installing system packages"

# Core build tools needed for everything
APT_CORE="build-essential git wget curl \
    libssl-dev libuv1-dev libffi-dev \
    automake autoconf libtool pkg-config \
    libjansson-dev libcurl4-openssl-dev \
    libgmp-dev \
    python3 python3-pip python3-dev \
    screen unzip"

# libhwloc only on 64-bit (not available / causes issues on armv7l)
APT_HWLOC=""
if [ "$ARCH" != "armv7l" ] && [ "$ARCH" != "armv7" ]; then
    APT_HWLOC="libhwloc-dev"
fi

# OpenCL for GPU mining (x86_64 only)
APT_OPENCL=""
if [ "$ARCH" = "x86_64" ]; then
    APT_OPENCL="ocl-icd-opencl-dev opencl-headers clinfo"
fi

PKG_CORE="python git wget curl openssl automake autoconf libtool \
    pkg-config libgmp screen unzip"

if [ "$PKG_MGR" = "apt" ]; then
    log_info "Running apt-get update..."
    apt-get update -y >> "$BUILD_LOG" 2>&1 || log_warn "apt-get update had warnings"

    ALL_APT="$APT_CORE $APT_HWLOC $APT_OPENCL"
    for pkg in $ALL_APT; do
        log_info "Installing: $pkg"
        apt-get install -y --no-install-recommends "$pkg" >> "$BUILD_LOG" 2>&1 \
            && log_ok "$pkg" \
            || log_warn "$pkg not available -- skipping"
    done

elif [ "$PKG_MGR" = "pkg" ]; then
    log_info "Running pkg update..."
    pkg update -y >> "$BUILD_LOG" 2>&1 || true
    for pkg in $PKG_CORE; do
        log_info "Installing: $pkg"
        pkg install -y "$pkg" >> "$BUILD_LOG" 2>&1 \
            && log_ok "$pkg" \
            || log_warn "$pkg not available -- skipping"
    done
fi

# =============================================================================
# STEP 3 -- CMAKE (build from source if missing or version < 3.15)
# =============================================================================
log_step "3/12" "Checking cmake version"

CMAKE_NEEDED_MAJOR=3
CMAKE_NEEDED_MINOR=15
CMAKE_BUILD_VERSION="3.28.3"
NEED_CMAKE=0

if command -v cmake > /dev/null 2>&1; then
    CMAKE_RAW="$(cmake --version 2>/dev/null | head -1)"
    CMAKE_VER="$(echo "$CMAKE_RAW" | grep -o '[0-9][0-9]*\.[0-9][0-9]*' | head -1)"
    CMAKE_MAJ="$(echo "$CMAKE_VER" | cut -d. -f1)"
    CMAKE_MIN="$(echo "$CMAKE_VER" | cut -d. -f2)"
    if [ -z "$CMAKE_MAJ" ]; then
        CMAKE_MAJ=0; CMAKE_MIN=0
    fi
    if [ "$CMAKE_MAJ" -lt "$CMAKE_NEEDED_MAJOR" ]; then
        NEED_CMAKE=1
    elif [ "$CMAKE_MAJ" -eq "$CMAKE_NEEDED_MAJOR" ] && [ "$CMAKE_MIN" -lt "$CMAKE_NEEDED_MINOR" ]; then
        NEED_CMAKE=1
    fi
    if [ "$NEED_CMAKE" -eq 1 ]; then
        log_warn "cmake $CMAKE_VER is too old (need >= ${CMAKE_NEEDED_MAJOR}.${CMAKE_NEEDED_MINOR})"
    else
        log_ok "cmake $CMAKE_VER OK"
    fi
else
    log_warn "cmake not found"
    NEED_CMAKE=1
fi

if [ "$NEED_CMAKE" -eq 1 ]; then
    log_info "Building cmake $CMAKE_BUILD_VERSION from source..."
    CMAKE_SRCDIR="$TMP_DIR/cmake_src"
    mkdir -p "$CMAKE_SRCDIR"
    CMAKE_TAR="cmake-${CMAKE_BUILD_VERSION}.tar.gz"
    CMAKE_URL="https://github.com/Kitware/CMake/releases/download/v${CMAKE_BUILD_VERSION}/${CMAKE_TAR}"

    log_info "Downloading cmake source (approx 10MB)..."
    if command -v wget > /dev/null 2>&1; then
        wget -q --show-progress -O "$CMAKE_SRCDIR/$CMAKE_TAR" "$CMAKE_URL" >> "$BUILD_LOG" 2>&1
    else
        curl -L --progress-bar -o "$CMAKE_SRCDIR/$CMAKE_TAR" "$CMAKE_URL" >> "$BUILD_LOG" 2>&1
    fi

    if [ -f "$CMAKE_SRCDIR/$CMAKE_TAR" ] && [ -s "$CMAKE_SRCDIR/$CMAKE_TAR" ]; then
        cd "$CMAKE_SRCDIR"
        tar -xzf "$CMAKE_TAR" >> "$BUILD_LOG" 2>&1
        cd "cmake-${CMAKE_BUILD_VERSION}"
        log_info "Bootstrapping cmake (takes 10-40 min on ARM -- please wait)..."
        ./bootstrap --prefix=/usr/local --parallel="$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
        make -j"$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
        make install >> "$BUILD_LOG" 2>&1
        if command -v cmake > /dev/null 2>&1; then
            log_ok "cmake $(cmake --version | head -1) installed"
        else
            log_err "cmake build failed -- see $BUILD_LOG"
            ERRORS=$((ERRORS + 1))
        fi
        cd "$SCRIPT_DIR"
    else
        log_err "Failed to download cmake source from $CMAKE_URL"
        ERRORS=$((ERRORS + 1))
    fi
fi

# =============================================================================
# STEP 4 -- PYTHON PACKAGES
# =============================================================================
log_step "4/12" "Installing Python packages"

PIP_PKGS="flask requests psutil apscheduler cryptography"

for pkg in $PIP_PKGS; do
    log_info "pip install: $pkg"
    "$PY_BIN" -m pip install "$pkg" \
        --break-system-packages --quiet >> "$BUILD_LOG" 2>&1 \
        && log_ok "$pkg" \
        || log_warn "$pkg had pip warnings"
done

# =============================================================================
# STEP 5 -- RUN HARDWARE DETECTION
# =============================================================================
log_step "5/12" "Running hardware detection"

if [ -f "$SCRIPT_DIR/ump_hardware_detect.py" ]; then
    "$PY_BIN" "$SCRIPT_DIR/ump_hardware_detect.py" 2>&1 | tee -a "$BUILD_LOG"
    if [ -f "$HW_PROFILE" ]; then
        log_ok "Hardware profile saved: $HW_PROFILE"
        # Read capability from profile
        HW_CAPABILITY="$(python3 -c "
import json
try:
    d = json.load(open('$HW_PROFILE'))
    print(d.get('mining_capability','CPU_ONLY'))
except:
    print('CPU_ONLY')
" 2>/dev/null)"
        log_ok "Mining capability: $HW_CAPABILITY"
    else
        log_warn "Hardware profile not saved -- defaulting to CPU_ONLY"
        HW_CAPABILITY="CPU_ONLY"
    fi
else
    log_warn "ump_hardware_detect.py not found -- defaulting to CPU_ONLY"
    HW_CAPABILITY="CPU_ONLY"
fi

# =============================================================================
# STEP 6 -- BUILD XMRIG FROM SOURCE
# =============================================================================
log_step "6/12" "Building XMRig (RandomX CPU miner) from source"

XMRIG_DEST="$BIN_DIR/xmrig"
XMRIG_SRCDIR="$TMP_DIR/xmrig_src"
XMRIG_BUILDDIR="$XMRIG_SRCDIR/build"
XMRIG_REPO="https://github.com/xmrig/xmrig.git"

if [ -f "$XMRIG_DEST" ]; then
    log_ok "XMRig already installed at $XMRIG_DEST"
else
    log_info "Cloning XMRig source..."
    git clone --depth=1 "$XMRIG_REPO" "$XMRIG_SRCDIR" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_err "Failed to clone XMRig from $XMRIG_REPO"
        ERRORS=$((ERRORS + 1))
    else
        mkdir -p "$XMRIG_BUILDDIR"
        cd "$XMRIG_BUILDDIR"

        # Architecture-specific cmake flags
        CMAKE_XMRIG="-DCMAKE_BUILD_TYPE=Release -DXMRIG_DONATE_LEVEL=0"
        if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
            CMAKE_XMRIG="$CMAKE_XMRIG -DWITH_HWLOC=OFF -DWITH_ASM=OFF -DWITH_AVX=OFF"
            log_info "armv7l flags applied: HWLOC=OFF ASM=OFF AVX=OFF"
        elif [ "$ARCH" = "aarch64" ]; then
            CMAKE_XMRIG="$CMAKE_XMRIG -DWITH_HWLOC=OFF"
            log_info "aarch64 flags applied: HWLOC=OFF"
        fi

        log_info "Running cmake for XMRig..."
        cmake .. $CMAKE_XMRIG >> "$BUILD_LOG" 2>&1
        if [ $? -ne 0 ]; then
            log_err "XMRig cmake configure failed"
            ERRORS=$((ERRORS + 1))
        else
            log_info "Compiling XMRig (5-30 min on ARM)..."
            make -j"$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
            if [ -f "$XMRIG_BUILDDIR/xmrig" ]; then
                cp "$XMRIG_BUILDDIR/xmrig" "$XMRIG_DEST"
                chmod +x "$XMRIG_DEST"
                log_ok "XMRig built: $XMRIG_DEST"
            else
                log_warn "Source build failed -- falling back to pre-built binary"
                XMRIG_VER="6.22.0"
                if [ "$ARCH" = "aarch64" ]; then
                    XMRIG_TAG="linux-static-aarch64"
                elif [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
                    XMRIG_TAG="linux-static-armv7"
                else
                    XMRIG_TAG="linux-static-x64"
                fi
                XMRIG_FILE="xmrig-${XMRIG_VER}-${XMRIG_TAG}.tar.gz"
                XMRIG_URL="https://github.com/xmrig/xmrig/releases/download/v${XMRIG_VER}/${XMRIG_FILE}"
                log_info "Downloading pre-built XMRig: $XMRIG_FILE"
                wget -q -O "$TMP_DIR/$XMRIG_FILE" "$XMRIG_URL" >> "$BUILD_LOG" 2>&1 \
                    || curl -L -o "$TMP_DIR/$XMRIG_FILE" "$XMRIG_URL" >> "$BUILD_LOG" 2>&1
                if [ -f "$TMP_DIR/$XMRIG_FILE" ] && [ -s "$TMP_DIR/$XMRIG_FILE" ]; then
                    tar -xzf "$TMP_DIR/$XMRIG_FILE" -C "$TMP_DIR" >> "$BUILD_LOG" 2>&1
                    FOUND="$(find "$TMP_DIR" -name 'xmrig' -type f | grep -v src | head -1)"
                    if [ -n "$FOUND" ]; then
                        cp "$FOUND" "$XMRIG_DEST"
                        chmod +x "$XMRIG_DEST"
                        log_ok "Pre-built XMRig installed: $XMRIG_DEST"
                    else
                        log_err "XMRig binary not found in archive"
                        ERRORS=$((ERRORS + 1))
                    fi
                else
                    log_err "Failed to download pre-built XMRig"
                    ERRORS=$((ERRORS + 1))
                fi
            fi
        fi
        cd "$SCRIPT_DIR"
    fi
fi

# =============================================================================
# STEP 7 -- BUILD CPUMINER-MULTI FROM SOURCE
# =============================================================================
log_step "7/12" "Building cpuminer-multi (X11/multi-algo) from source"

CPUMINER_DEST="$BIN_DIR/cpuminer-multi"
CPUMINER_SRCDIR="$TMP_DIR/cpuminer_src"
CPUMINER_REPO="https://github.com/tpruvot/cpuminer-multi.git"

if [ -f "$CPUMINER_DEST" ]; then
    log_ok "cpuminer-multi already installed at $CPUMINER_DEST"
else
    log_info "Cloning cpuminer-multi source..."
    git clone --depth=1 "$CPUMINER_REPO" "$CPUMINER_SRCDIR" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_err "Failed to clone cpuminer-multi"
        ERRORS=$((ERRORS + 1))
    else
        cd "$CPUMINER_SRCDIR"
        log_info "Running autogen.sh..."
        if [ -f "./autogen.sh" ]; then
            ./autogen.sh >> "$BUILD_LOG" 2>&1 \
                || autoreconf --install >> "$BUILD_LOG" 2>&1 \
                || log_warn "autogen had warnings -- continuing"
        else
            autoreconf --install >> "$BUILD_LOG" 2>&1 || true
        fi

        CPUMINER_CONF="--with-crypto --with-curl"
        if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ] || [ "$ARCH" = "aarch64" ]; then
            CPUMINER_CONF="$CPUMINER_CONF --disable-assembly"
            log_info "ARM configure flags: --disable-assembly"
        fi

        log_info "Running configure..."
        ./configure $CPUMINER_CONF >> "$BUILD_LOG" 2>&1
        if [ $? -ne 0 ]; then
            log_err "cpuminer-multi configure failed"
            ERRORS=$((ERRORS + 1))
        else
            log_info "Compiling cpuminer-multi..."
            make -j"$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
            if [ -f "$CPUMINER_SRCDIR/cpuminer" ]; then
                cp "$CPUMINER_SRCDIR/cpuminer" "$CPUMINER_DEST"
                chmod +x "$CPUMINER_DEST"
                log_ok "cpuminer-multi built: $CPUMINER_DEST"
            else
                log_err "cpuminer-multi binary not found after build"
                ERRORS=$((ERRORS + 1))
            fi
        fi
        cd "$SCRIPT_DIR"
    fi
fi

# =============================================================================
# STEP 8 -- GPU MINERS (x86_64 only, skip on ARM)
# =============================================================================
log_step "8/12" "GPU miners"

if [ "$ARCH" = "x86_64" ] && [ "$HW_CAPABILITY" != "CPU_ONLY" ]; then
    log_info "x86_64 + GPU detected -- installing GPU miners"

    LOLMINER_VER="1.88"
    LOLMINER_FILE="lolMiner_v${LOLMINER_VER}_Lin64.tar.gz"
    LOLMINER_URL="https://github.com/Lolliedieb/lolMiner-releases/releases/download/${LOLMINER_VER}/${LOLMINER_FILE}"
    LOLMINER_DEST="$BIN_DIR/lolminer"

    if [ -f "$LOLMINER_DEST" ]; then
        log_ok "lolMiner already installed"
    else
        log_info "Downloading lolMiner $LOLMINER_VER..."
        wget -q -O "$TMP_DIR/$LOLMINER_FILE" "$LOLMINER_URL" >> "$BUILD_LOG" 2>&1 \
            || curl -L -o "$TMP_DIR/$LOLMINER_FILE" "$LOLMINER_URL" >> "$BUILD_LOG" 2>&1
        if [ -f "$TMP_DIR/$LOLMINER_FILE" ] && [ -s "$TMP_DIR/$LOLMINER_FILE" ]; then
            mkdir -p "$TMP_DIR/lolminer_extracted"
            tar -xzf "$TMP_DIR/$LOLMINER_FILE" -C "$TMP_DIR/lolminer_extracted" >> "$BUILD_LOG" 2>&1
            FOUND="$(find "$TMP_DIR/lolminer_extracted" -name 'lolMiner' -type f | head -1)"
            if [ -n "$FOUND" ]; then
                cp "$FOUND" "$LOLMINER_DEST"
                chmod +x "$LOLMINER_DEST"
                log_ok "lolMiner installed: $LOLMINER_DEST"
            else
                log_warn "lolMiner binary not found in archive"
            fi
        else
            log_warn "lolMiner download failed -- skipping"
        fi
    fi

    TREX_VER="0.26.8"
    TREX_FILE="t-rex-${TREX_VER}-linux.tar.gz"
    TREX_URL="https://github.com/trexminer/T-Rex/releases/download/${TREX_VER}/${TREX_FILE}"
    TREX_DEST="$BIN_DIR/t-rex"

    if [ -f "$TREX_DEST" ]; then
        log_ok "T-Rex already installed"
    else
        log_info "Downloading T-Rex $TREX_VER..."
        wget -q -O "$TMP_DIR/$TREX_FILE" "$TREX_URL" >> "$BUILD_LOG" 2>&1 \
            || curl -L -o "$TMP_DIR/$TREX_FILE" "$TREX_URL" >> "$BUILD_LOG" 2>&1
        if [ -f "$TMP_DIR/$TREX_FILE" ] && [ -s "$TMP_DIR/$TREX_FILE" ]; then
            mkdir -p "$TMP_DIR/trex_extracted"
            tar -xzf "$TMP_DIR/$TREX_FILE" -C "$TMP_DIR/trex_extracted" >> "$BUILD_LOG" 2>&1
            FOUND="$(find "$TMP_DIR/trex_extracted" -name 't-rex' -type f | head -1)"
            if [ -n "$FOUND" ]; then
                cp "$FOUND" "$TREX_DEST"
                chmod +x "$TREX_DEST"
                log_ok "T-Rex installed: $TREX_DEST"
            else
                log_warn "T-Rex binary not found in archive"
            fi
        else
            log_warn "T-Rex download failed -- skipping"
        fi
    fi

    TRM_VER="0.10.21"
    TRM_FILE="teamredminer-v${TRM_VER}-linux.tar.gz"
    TRM_URL="https://github.com/todxx/teamredminer/releases/download/v${TRM_VER}/${TRM_FILE}"
    TRM_DEST="$BIN_DIR/teamredminer"

    if [ -f "$TRM_DEST" ]; then
        log_ok "TeamRedMiner already installed"
    else
        log_info "Downloading TeamRedMiner $TRM_VER..."
        wget -q -O "$TMP_DIR/$TRM_FILE" "$TRM_URL" >> "$BUILD_LOG" 2>&1 \
            || curl -L -o "$TMP_DIR/$TRM_FILE" "$TRM_URL" >> "$BUILD_LOG" 2>&1
        if [ -f "$TMP_DIR/$TRM_FILE" ] && [ -s "$TMP_DIR/$TRM_FILE" ]; then
            mkdir -p "$TMP_DIR/trm_extracted"
            tar -xzf "$TMP_DIR/$TRM_FILE" -C "$TMP_DIR/trm_extracted" >> "$BUILD_LOG" 2>&1
            FOUND="$(find "$TMP_DIR/trm_extracted" -name 'teamredminer' -type f | head -1)"
            if [ -n "$FOUND" ]; then
                cp "$FOUND" "$TRM_DEST"
                chmod +x "$TRM_DEST"
                log_ok "TeamRedMiner installed: $TRM_DEST"
            else
                log_warn "TeamRedMiner binary not found in archive"
            fi
        else
            log_warn "TeamRedMiner download failed -- skipping"
        fi
    fi

else
    if [ "$ARCH" != "x86_64" ]; then
        log_info "ARM architecture ($ARCH) -- GPU miners not available -- skipping"
    else
        log_info "CPU_ONLY capability -- GPU miners skipped"
    fi
fi

# =============================================================================
# STEP 9 -- INIT DATABASE
# =============================================================================
log_step "9/12" "Initialising SQLite database"

if "$PY_BIN" -c "from miner_config import init_db; init_db(); print('DB OK')" 2>/dev/null; then
    log_ok "SQLite database initialised"
else
    log_warn "DB init skipped -- will initialise on first Flask start"
fi

# =============================================================================
# STEP 10 -- WRITE START SCRIPTS
# =============================================================================
log_step "10/12" "Writing start scripts"

cat > "$SCRIPT_DIR/start.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "[UMP] Starting Universal Miner Pro ULTIMATE v4.2..."
echo "[UMP] Dashboard: http://localhost:8080"
python3 universal_miner.py
EOF
chmod +x "$SCRIPT_DIR/start.sh"
log_ok "start.sh"

cat > "$SCRIPT_DIR/start_screen.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
SESSION="ump_miner"
if command -v screen > /dev/null 2>&1; then
    screen -dmS "$SESSION" python3 universal_miner.py
    echo "[UMP] Running in screen session: $SESSION"
    echo "[UMP] Reattach: screen -r $SESSION"
    echo "[UMP] Dashboard: http://localhost:8080"
else
    echo "[UMP] screen not installed -- running in foreground"
    python3 universal_miner.py
fi
EOF
chmod +x "$SCRIPT_DIR/start_screen.sh"
log_ok "start_screen.sh"

cat > "$SCRIPT_DIR/detect.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "[UMP] Running hardware detection..."
python3 ump_hardware_detect.py
EOF
chmod +x "$SCRIPT_DIR/detect.sh"
log_ok "detect.sh"

# =============================================================================
# STEP 11 -- VERIFY ALL BINARIES
# =============================================================================
log_step "11/12" "Verifying installed binaries"

log_info "Contents of bin/:"
for f in xmrig cpuminer-multi lolminer t-rex teamredminer; do
    FPATH="$BIN_DIR/$f"
    if [ -f "$FPATH" ]; then
        FSIZE="$(du -sh "$FPATH" 2>/dev/null | cut -f1)"
        log_ok "$f  ($FSIZE)"
    else
        log_info "$f  -- not installed (not required for $HW_CAPABILITY)"
    fi
done

# =============================================================================
# STEP 12 -- CLEANUP AND SUMMARY
# =============================================================================
log_step "12/12" "Cleanup and summary"

rm -rf "$TMP_DIR"

# Evaluate status into variables before printing (avoid nested subshell quoting)
if [ -f "$BIN_DIR/xmrig" ]; then
    S_XMRIG="${GREEN}READY${NC}"
else
    S_XMRIG="${RED}MISSING${NC}"
fi

if [ -f "$BIN_DIR/cpuminer-multi" ]; then
    S_CPUMINER="${GREEN}READY${NC}"
else
    S_CPUMINER="${YELLOW}NOT BUILT${NC}"
fi

if [ -f "$BIN_DIR/lolminer" ]; then
    S_LOL="${GREEN}READY${NC}"
else
    S_LOL="${YELLOW}N/A${NC}"
fi

if [ -f "$BIN_DIR/t-rex" ]; then
    S_TREX="${GREEN}READY${NC}"
else
    S_TREX="${YELLOW}N/A${NC}"
fi

if [ "$ERRORS" -eq 0 ]; then
    S_ERRORS="${GREEN}0${NC}"
else
    S_ERRORS="${RED}$ERRORS${NC}"
fi

echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "${BOLD}  INSTALL SUMMARY${NC}"
echo -e "${CYAN}============================================================${NC}"
echo -e "  Platform    : ${GREEN}$PLATFORM${NC}"
echo -e "  Arch        : ${GREEN}$ARCH${NC}"
echo -e "  CPU Cores   : ${GREEN}$CPU_COUNT${NC}"
echo -e "  Capability  : ${GREEN}$HW_CAPABILITY${NC}"
echo -e "  xmrig       : $(echo -e $S_XMRIG)"
echo -e "  cpuminer    : $(echo -e $S_CPUMINER)"
echo -e "  lolminer    : $(echo -e $S_LOL)"
echo -e "  t-rex       : $(echo -e $S_TREX)"
echo -e "  Errors      : $(echo -e $S_ERRORS)"
echo ""
if [ "$ERRORS" -eq 0 ]; then
    echo -e "  ${GREEN}${BOLD}Installation complete!${NC}"
    echo ""
    echo -e "  ${BOLD}Start dashboard:${NC}"
    echo -e "    ${CYAN}./start.sh${NC}           (foreground)"
    echo -e "    ${CYAN}./start_screen.sh${NC}    (background)"
    echo ""
    echo -e "  ${BOLD}Dashboard URL:${NC}"
    echo -e "    ${CYAN}http://localhost:8080${NC}"
    echo ""
    echo -e "  ${BOLD}First time -- setup your profile:${NC}"
    echo -e "    ${CYAN}http://localhost:8080/setup${NC}"
else
    echo -e "  ${YELLOW}Completed with $ERRORS issue(s) -- check $BUILD_LOG${NC}"
fi
echo -e "${CYAN}============================================================${NC}"
