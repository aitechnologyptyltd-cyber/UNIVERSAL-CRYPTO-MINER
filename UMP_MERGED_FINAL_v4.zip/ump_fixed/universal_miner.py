# universal_miner.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Flask app — port 8080 — Multi-Pool | Multi-Coin | Multi-Arch | Dual-Algo Swarm
# armv7l / aarch64 / x86_64 / macOS / Windows compatible
# no f-strings — no walrus — Python 3.6+ safe

import os
import json
import time
import threading
import sqlite3
from datetime import datetime
from flask import (
    Flask, render_template, request, redirect,
    url_for, jsonify, Response, session, flash
)

from miner_config import (
    COINS, CPU_COINS, PROFILE_FIELDS, POOLS, ALGOS, DEFAULT_ALGO,
    DB_PATH, VERSION, TOTAL_NODES,
    init_db, save_profile, load_profile, list_profiles, delete_profile,
    get_coins_json, get_pools_json, get_algos_json, get_system_info,
    suggest_pool_url, calc_daily_usd, format_hashrate, set_algo,
    ARCH, PLATFORM
)
from miner_manager import (
    start_miner, stop_miner, get_stats, is_running,
    auto_resume, get_log_tail, get_hashrate_history, switch_algo
)
from miner_swarm import register_with_app, get_engine

# ── Optional modules (graceful degradation if missing) ────────
try:
    from wallet_api import register_wallet
    _HAS_WALLET = True
except ImportError as e:
    print("[UMP] wallet_api not available: " + str(e))
    _HAS_WALLET = False

try:
    from wallet_validator import get_cached_result, start_background_validation
    _HAS_VALIDATOR = True
except ImportError as e:
    print("[UMP] wallet_validator not available: " + str(e))
    _HAS_VALIDATOR = False

try:
    from ump_hardware_detect import get_capability_profile
    _HAS_HARDWARE = True
except ImportError:
    _HAS_HARDWARE = False

try:
    from ump_profit_switcher import start_profit_switcher
    _HAS_PROFIT = True
except ImportError:
    _HAS_PROFIT = False

# ── App init ──────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.urandom(24)

init_db()
SYS_INFO = get_system_info()

# ── Register blueprints ───────────────────────────────────────
register_with_app(app)
print("[UMP] Swarm blueprint registered")

if _HAS_WALLET:
    register_wallet(app)
    print("[UMP] Wallet blueprint registered at /wallet/")

# ── Start background services ─────────────────────────────────
if _HAS_VALIDATOR:
    start_background_validation()
    print("[UMP] Validator started")

if _HAS_PROFIT:
    try:
        start_profit_switcher(app)
        print("[UMP] Profit switcher started")
    except Exception as e:
        print("[UMP] Profit switcher error: " + str(e))

print("[UMP] " + VERSION + " starting on " + SYS_INFO["platform"] + "/" + SYS_INFO["arch"])
print("[UMP] Swarm nodes: " + str(TOTAL_NODES) + " | Algos: " + ", ".join(ALGOS.keys()))
print("[UMP] Dashboard → http://0.0.0.0:8080")

# ── Helpers ───────────────────────────────────────────────────
def _has_profiles():
    try:
        return len(list_profiles()) > 0
    except Exception:
        return False

def _get_active_profile():
    pname = session.get("profile_name")
    if pname:
        p = load_profile(pname)
        if p:
            return p
    profiles = list_profiles()
    if profiles:
        p = load_profile(profiles[0]["profile_name"])
        if p:
            session["profile_name"] = p["profile_name"]
            return p
    return None

def _fmt_uptime(seconds):
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return str(h) + "h " + str(m) + "m " + str(s) + "s"

def _get_sections():
    sections = {}
    for f in PROFILE_FIELDS:
        sec = f["section"]
        if sec not in sections:
            sections[sec] = []
        sections[sec].append(f)
    return sections

# ── SSE stream ────────────────────────────────────────────────
def _sse_stream():
    while True:
        try:
            stats  = get_stats()
            swarm  = get_engine().get_snapshot()
            stats["uptime_str"]      = _fmt_uptime(stats.get("uptime_sec", 0))
            stats["is_alive"]        = is_running()
            stats["arch"]            = ARCH
            stats["platform"]        = PLATFORM
            stats["swarm_active"]    = swarm.get("swarm_active", False)
            stats["swarm_nodes"]     = swarm.get("active_nodes", 0)
            stats["swarm_hr"]        = swarm.get("total_hashrate", 0.0)
            stats["swarm_hr_unit"]   = swarm.get("hr_unit", "H/s")
            stats["swarm_earnings"]  = swarm.get("earnings_usd", 0.0)
            stats["xmr_price"]       = swarm.get("xmr_price", 0.0)
            stats["cpu_pct"]         = swarm.get("cpu_pct", stats.get("cpu_pct", 0.0))
            stats["temperature"]     = swarm.get("temperature", stats.get("temp"))
            yield "data: " + json.dumps(stats) + "\n\n"
        except Exception as e:
            yield "data: " + json.dumps({"error": str(e)}) + "\n\n"
        time.sleep(2)

# ── Main routes ───────────────────────────────────────────────
@app.route("/")
def index():
    if not _has_profiles():
        return redirect(url_for("setup"))
    profile = _get_active_profile()
    if not profile:
        return redirect(url_for("setup"))
    stats     = get_stats()
    profiles  = list_profiles()
    pool_id   = profile.get("selected_pool", "kryptex")
    pool_info = POOLS.get(pool_id, {})
    algo_key  = str(profile.get("active_algo", DEFAULT_ALGO)).upper()
    return render_template(
        "dashboard.html",
        profile     = profile,
        stats       = stats,
        profiles    = profiles,
        uptime      = _fmt_uptime(stats.get("uptime_sec", 0)),
        sys_info    = SYS_INFO,
        pool_info   = pool_info,
        algos       = ALGOS,
        algos_json  = json.dumps(get_algos_json()),
        active_algo = algo_key,
        total_nodes = TOTAL_NODES,
        version     = VERSION,
        has_wallet  = _HAS_WALLET,
    )

@app.route("/setup", methods=["GET"])
def setup():
    profiles     = list_profiles()
    sections     = _get_sections()
    coins_json   = json.dumps(get_coins_json())
    pools_json   = json.dumps(get_pools_json())
    edit_profile = None
    edit_name    = request.args.get("edit", "")
    if edit_name:
        edit_profile = load_profile(edit_name)
    return render_template(
        "setup.html",
        sections     = sections,
        profiles     = profiles,
        coins_json   = coins_json,
        pools_json   = pools_json,
        cpu_coins    = CPU_COINS,
        sys_info     = SYS_INFO,
        edit_profile = edit_profile,
        version      = VERSION,
        pool_ids     = list(POOLS.keys()),
        algos        = ALGOS,
    )

@app.route("/setup", methods=["POST"])
def setup_post():
    data  = {}
    pname = request.form.get("profile_name", "").strip()
    if not pname:
        uname = request.form.get("username", "user").strip()
        pname = uname + "_" + str(int(time.time()))
    data["profile_name"] = pname

    for f in PROFILE_FIELDS:
        data[f["key"]] = request.form.get(f["key"], "").strip()

    try:
        data["threads"] = int(request.form.get("threads", SYS_INFO.get("cpu_count", 2)))
    except (ValueError, TypeError):
        data["threads"] = 2

    algo_raw = request.form.get("active_algo", DEFAULT_ALGO).strip().upper()
    data["active_algo"] = algo_raw if algo_raw in ALGOS else DEFAULT_ALGO

    missing = [f["label"] for f in PROFILE_FIELDS
               if f.get("required") and not data.get(f["key"])]
    if missing:
        flash("Required fields missing: " + ", ".join(missing), "error")
        return redirect(url_for("setup"))

    try:
        save_profile(data)
        session["profile_name"] = pname
        flash("Profile saved: " + pname, "success")
    except Exception as e:
        flash("Save error: " + str(e), "error")
        return redirect(url_for("setup"))
    return redirect(url_for("index"))

@app.route("/profiles")
def profiles_page():
    return render_template(
        "profiles.html",
        profiles = list_profiles(),
        sys_info = SYS_INFO,
        version  = VERSION,
    )

@app.route("/profiles/switch", methods=["POST"])
def profile_switch():
    pname = request.form.get("profile_name", "").strip()
    if not pname or not load_profile(pname):
        return jsonify({"ok": False, "error": "Not found"}), 404
    if is_running():
        stop_miner()
    session["profile_name"] = pname
    return jsonify({"ok": True, "profile_name": pname})

@app.route("/profiles/delete", methods=["POST"])
def profile_delete():
    pname = request.form.get("profile_name", "").strip()
    try:
        delete_profile(pname)
        if session.get("profile_name") == pname:
            session.pop("profile_name", None)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/profiles/export/<profile_name>")
def profile_export(profile_name):
    p = load_profile(profile_name)
    if not p:
        return jsonify({"error": "Not found"}), 404
    safe = {k: v for k, v in p.items()
            if k not in ("binance_api_key", "binance_api_secret",
                         "mph_api_key", "xmr_viewkey")}
    return jsonify(safe)

# ── Mining controls ───────────────────────────────────────────
@app.route("/mine/start", methods=["POST"])
def mine_start():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    try:
        threads = int(request.form.get("threads", profile.get("threads", 2)))
    except (ValueError, TypeError):
        threads = 2
    algo_key = request.form.get("algo", profile.get("active_algo", DEFAULT_ALGO)).upper()
    ok, err  = start_miner(profile["profile_name"], threads=threads, algo_key=algo_key)
    if ok:
        return jsonify({
            "ok":      True,
            "coin":    profile.get("selected_coin", "XMR"),
            "pool":    profile.get("selected_pool", "kryptex"),
            "algo":    algo_key,
            "threads": threads,
        })
    return jsonify({"ok": False, "error": err}), 500

@app.route("/mine/stop", methods=["POST"])
def mine_stop():
    ok, err = stop_miner()
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": err}), 400

@app.route("/mine/switch_algo", methods=["POST"])
def mine_switch_algo():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    algo_key = request.form.get("algo", "").strip().upper()
    if not algo_key:
        data = request.get_json(silent=True) or {}
        algo_key = str(data.get("algo", "")).strip().upper()
    if algo_key not in ALGOS:
        return jsonify({"ok": False, "error": "Unknown algo: " + algo_key}), 400
    try:
        threads = int(request.form.get("threads", profile.get("threads", 2)))
    except (ValueError, TypeError):
        threads = 2
    ok, err = switch_algo(profile["profile_name"], algo_key, threads=threads)
    if ok:
        algo_info = ALGOS[algo_key]
        return jsonify({
            "ok":         True,
            "algo":       algo_key,
            "algo_label": algo_info["label"],
            "pool_name":  algo_info["pool_name"],
            "hr_unit":    algo_info["hr_unit"],
            "color":      algo_info["color"],
        })
    return jsonify({"ok": False, "error": err}), 500

# ── Swarm controls ────────────────────────────────────────────
@app.route("/swarm/start", methods=["POST"])
def swarm_start_route():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    try:
        threads = int(request.form.get("threads", 1))
    except (ValueError, TypeError):
        threads = 1
    algo_key = request.form.get("algo", profile.get("active_algo", DEFAULT_ALGO)).upper()
    ok, err  = get_engine().start_swarm(profile["profile_name"],
                                        threads=threads, algo_key=algo_key)
    if ok:
        return jsonify({"ok": True, "total_nodes": TOTAL_NODES, "algo": algo_key})
    return jsonify({"ok": False, "error": err}), 500

@app.route("/swarm/stop", methods=["POST"])
def swarm_stop_route():
    ok, err = get_engine().stop_swarm()
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": err}), 400

# ── SSE + Stats API ───────────────────────────────────────────
@app.route("/stream")
def stream():
    return Response(
        _sse_stream(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

@app.route("/api/stats")
def api_stats():
    stats = get_stats()
    stats["uptime_str"] = _fmt_uptime(stats.get("uptime_sec", 0))
    stats["is_alive"]   = is_running()
    return jsonify(stats)

@app.route("/api/log")
def api_log():
    lines    = int(request.args.get("lines", 80))
    algo_key = request.args.get("algo", None)
    return jsonify(get_log_tail(lines=lines, algo_key=algo_key))

@app.route("/api/hashrate_history")
def api_hashrate_history():
    profile = _get_active_profile()
    if not profile:
        return jsonify([])
    limit = int(request.args.get("limit", 120))
    return jsonify(get_hashrate_history(profile["profile_name"], limit=limit))

@app.route("/api/profiles")
def api_profiles():
    return jsonify(list_profiles())

@app.route("/api/coins")
def api_coins():
    return jsonify(get_coins_json())

@app.route("/api/pools")
def api_pools():
    return jsonify(get_pools_json())

@app.route("/api/algos")
def api_algos():
    return jsonify(get_algos_json())

@app.route("/api/suggest_pool_url")
def api_suggest_pool_url():
    pool_id  = request.args.get("pool", "kryptex")
    coin_sym = request.args.get("coin", "XMR")
    url = suggest_pool_url(pool_id, coin_sym)
    return jsonify({"url": url, "pool": pool_id, "coin": coin_sym})

@app.route("/api/hashrate_calc")
def api_hashrate_calc():
    try:
        hr_raw = float(request.args.get("hr", 0))
        unit   = request.args.get("unit", "H/s")
        coin   = request.args.get("coin", "XMR").upper()
        price  = float(request.args.get("price", 0))
        mult   = {"H/s": 1, "KH/s": 1e3, "MH/s": 1e6, "GH/s": 1e9}.get(unit, 1)
        hr_hs  = hr_raw * mult
        daily  = calc_daily_usd(coin, hr_hs,
                                coin_price_usd=price if price > 0 else None)
        return jsonify({
            "hashrate_hs":  hr_hs,
            "hashrate_fmt": format_hashrate(hr_hs),
            "daily_usd":    round(daily, 4),
            "weekly_usd":   round(daily * 7, 4),
            "monthly_usd":  round(daily * 30, 2),
            "yearly_usd":   round(daily * 365, 2),
            "coin":         coin,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route("/api/sysinfo")
def api_sysinfo():
    return jsonify(get_system_info())

@app.route("/api/sessions")
def api_sessions():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT s.id, s.started_at, s.stopped_at, s.coin, s.pool, s.algo,
                   s.shares_acc, s.shares_rej, s.avg_hr, p.profile_name
            FROM sessions s
            LEFT JOIN profiles p ON s.profile_id = p.id
            ORDER BY s.started_at DESC LIMIT 30
        """)
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Validator API ─────────────────────────────────────────────
@app.route("/api/validate")
def api_validate():
    if not _HAS_VALIDATOR:
        return jsonify({"ok": True, "errors": [], "warnings": [],
                        "all": [], "checked": 0,
                        "summary": "Validator not installed"})
    force = request.args.get("refresh", "0") in ("1", "true", "yes")
    try:
        res = get_cached_result(force=force)
        return jsonify(res.to_dict())
    except Exception as e:
        return jsonify({"ok": False, "errors": [], "warnings": [],
                        "all": [], "checked": 0,
                        "summary": "Validator error: " + str(e)})

# ── Hardware API ──────────────────────────────────────────────
@app.route("/api/hardware")
def api_hardware():
    if not _HAS_HARDWARE:
        return jsonify(SYS_INFO)
    try:
        return jsonify(get_capability_profile())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Health check ──────────────────────────────────────────────
@app.route("/health")
def health():
    swarm = get_engine().get_snapshot()
    return jsonify({
        "status":       "ok",
        "version":      VERSION,
        "arch":         ARCH,
        "platform":     PLATFORM,
        "mining":       is_running(),
        "swarm_active": swarm.get("swarm_active", False),
        "swarm_nodes":  swarm.get("active_nodes", 0),
        "profiles":     len(list_profiles()),
        "algos":        list(ALGOS.keys()),
        "has_wallet":   _HAS_WALLET,
        "has_validator":_HAS_VALIDATOR,
        "timestamp":    datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
    })

# ── Entry point ───────────────────────────────────────────────
if __name__ == "__main__":
    t = threading.Thread(target=auto_resume, daemon=True)
    t.start()
    app.run(
        host="0.0.0.0", port=8080,
        debug=False, threaded=True, use_reloader=False,
    )
