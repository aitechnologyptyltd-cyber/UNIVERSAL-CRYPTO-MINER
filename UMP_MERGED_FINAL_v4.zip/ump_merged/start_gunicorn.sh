#!/bin/bash
# =============================================================================
#  start_gunicorn.sh -- UMP ULTIMATE v4.2
#  Production WSGI server using Gunicorn + gthread workers.
#  Eliminates the "development server" warning.
#  Handles SSE correctly via thread-based workers.
# =============================================================================
cd "$(dirname "$0")"

LOG_DIR="logs"
PID_FILE="ump.pid"
GUNICORN_LOG="$LOG_DIR/gunicorn_error.log"

mkdir -p "$LOG_DIR"

# ---------------------------------------------------------------------------
# Check gunicorn is installed
# ---------------------------------------------------------------------------
if ! command -v gunicorn > /dev/null 2>&1; then
    echo "[UMP] Gunicorn not found -- installing..."
    pip3 install gunicorn --break-system-packages --quiet \
        || pip install gunicorn --break-system-packages --quiet
    if ! command -v gunicorn > /dev/null 2>&1; then
        # Try finding it in local bin paths
        GUNICORN_BIN="$(python3 -m site --user-base 2>/dev/null)/bin/gunicorn"
        if [ ! -f "$GUNICORN_BIN" ]; then
            echo "[UMP] ERROR: Could not install gunicorn."
            echo "[UMP] Run manually: pip3 install gunicorn --break-system-packages"
            echo "[UMP] Falling back to development server..."
            bash start.sh
            exit 0
        fi
        export PATH="$PATH:$(python3 -m site --user-base 2>/dev/null)/bin"
    fi
    echo "[UMP] Gunicorn installed OK"
fi

# ---------------------------------------------------------------------------
# Stop any existing instance
# ---------------------------------------------------------------------------
if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[UMP] Stopping previous instance (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null
        sleep 2
    fi
    rm -f "$PID_FILE"
fi

# ---------------------------------------------------------------------------
# Detect CPU count for thread tuning
# ---------------------------------------------------------------------------
CPU_COUNT="$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null || echo 4)"
THREADS="$CPU_COUNT"
if [ "$THREADS" -gt 8 ]; then
    THREADS=8
fi

echo "[UMP] ============================================"
echo "[UMP]  Universal Miner Pro ULTIMATE v4.2"
echo "[UMP]  Production WSGI Server (Gunicorn)"
echo "[UMP] ============================================"
echo "[UMP]  CPU cores  : $CPU_COUNT"
echo "[UMP]  Workers    : 1 (gthread)"
echo "[UMP]  Threads    : $THREADS"
echo "[UMP]  Port       : 8080"
echo "[UMP]  Dashboard  : http://localhost:8080"
echo "[UMP]  Error log  : $GUNICORN_LOG"
echo "[UMP]  PID file   : $PID_FILE"
echo "[UMP] ============================================"

# ---------------------------------------------------------------------------
# Launch Gunicorn in background via nohup
# ---------------------------------------------------------------------------
nohup gunicorn \
    --config gunicorn_config.py \
    --worker-class gthread \
    --workers 1 \
    --threads "$THREADS" \
    --bind 0.0.0.0:8080 \
    --timeout 0 \
    --graceful-timeout 10 \
    --keepalive 5 \
    --pid "$PID_FILE" \
    --access-logfile "$LOG_DIR/gunicorn_access.log" \
    --error-logfile "$GUNICORN_LOG" \
    --log-level info \
    --name ump_miner \
    wsgi:app >> "$LOG_DIR/ump.log" 2>&1 &

GUNICORN_PID=$!
echo $GUNICORN_PID > "$PID_FILE"

# ---------------------------------------------------------------------------
# Verify startup
# ---------------------------------------------------------------------------
sleep 2
if kill -0 "$GUNICORN_PID" 2>/dev/null; then
    echo "[UMP] Gunicorn running -- PID $GUNICORN_PID"
    echo "[UMP] Open:  http://localhost:8080"
    echo "[UMP] Stop:  bash stop.sh"
    echo "[UMP] Logs:  tail -f $LOG_DIR/ump.log"
    echo "[UMP] Errors: tail -f $GUNICORN_LOG"
else
    echo "[UMP] ERROR: Gunicorn failed to start"
    echo "[UMP] Last log lines:"
    tail -20 "$GUNICORN_LOG" 2>/dev/null || tail -20 "$LOG_DIR/ump.log" 2>/dev/null
    echo ""
    echo "[UMP] Falling back to development server..."
    bash start.sh
fi
