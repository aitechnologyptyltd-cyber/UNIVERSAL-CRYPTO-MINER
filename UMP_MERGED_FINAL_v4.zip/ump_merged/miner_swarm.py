# miner_swarm.py — Universal Miner Pro ULTIMATE EDITION v4.0
# SwarmEngine : price feed | hardware monitor | snapshot history | node aggregator
# SwarmNode   : real XMRig / cpuminer-multi subprocess per node (up to 40)
# ZIP1 real spawning + ZIP3 clean OOP + ZIP2 dual-algo — merged
# armv7l / aarch64 / x86_64 / macOS / Windows safe — no f-strings, no walrus

import os
import re
import time
import json
import signal
import sqlite3
import threading
import subprocess
from datetime import datetime

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

try:
    import psutil as _psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False

from flask import Blueprint, jsonify, request as flask_req
from miner_config import (
    DB_PATH, LOG_DIR, BIN_DIR, PLATFORM, ARCH, VERSION,
    ALGOS, DEFAULT_ALGO, TOTAL_NODES, COINS,
    get_miner_cmd, load_profile, calc_daily_usd, get_algo_binary
)

# ── Stagger constants ──────────────────────────────────────
STAGGER_SEC  = 0.25   # seconds between node starts
NODE_THREADS = 1      # threads per swarm node

# ─────────────────────────────────────────────────────────────────────────────
# SwarmNode — one real miner subprocess
# ─────────────────────────────────────────────────────────────────────────────
class SwarmNode:
    """
    Spawns and manages a single XMRig or cpuminer-multi subprocess.
    Reports parsed stats back to SwarmEngine via update_node() callback.
    """

    def __init__(self, node_id, profile, threads, algo_key, on_update):
        self.node_id   = node_id
        self.profile   = profile
        self.threads   = threads
        self.algo_key  = algo_key.upper()
        self.on_update = on_update    # callable(node_id, **stats)
        self._proc     = None
        self._stop_evt = threading.Event()
        self._thread   = None
        self.hashrate  = 0.0
        self.hr_unit   = ALGOS.get(self.algo_key, {}).get("hr_unit", "H/s")
        self.accepted  = 0
        self.rejected  = 0
        self.alive     = False
        self.error     = None

    # ── Parsers ───────────────────────────────────────────
    def _parse(self, line):
        """Dispatch to correct parser based on algo."""
        if self.algo_key == "RANDOMX":
            return self._parse_xmrig(line)
        return self._parse_cpuminer(line)

    def _parse_xmrig(self, line):
        p = {}
        m = re.search(
            r"speed\s+\S+\s+([\d.]+)\s+[\d.n/a]+\s+[\d.n/a]+\s+(H/s|KH/s|MH/s|GH/s)",
            line)
        if m:
            try:
                p["hashrate"]  = float(m.group(1))
                p["hr_unit"]   = m.group(2)
            except Exception:
                pass
        m2 = re.search(r"accepted\s*\((\d+)/(\d+)\)", line)
        if m2:
            p["accepted"] = int(m2.group(1))
            p["rejected"] = int(m2.group(2))
        return p

    def _parse_cpuminer(self, line):
        p = {}
        m = re.search(r"[Tt]otal:\s*([\d.]+)\s*(GH/s|MH/s|kH/s|KH/s|H/s)", line)
        if m:
            val  = float(m.group(1))
            unit = m.group(2)
            ul   = unit.lower()
            if ul == "gh/s":
                val *= 1000.0;  unit = "MH/s"
            elif ul in ("kh/s",):
                val /= 1000.0;  unit = "MH/s"
            elif ul == "h/s":
                val /= 1e6;     unit = "MH/s"
            p["hashrate"] = round(val, 6)
            p["hr_unit"]  = unit
        m2 = re.search(r"accepted:\s*(\d+)/(\d+)", line)
        if m2:
            acc = int(m2.group(1))
            tot = int(m2.group(2))
            p["accepted"] = acc
            p["rejected"] = max(0, tot - acc)
        return p

    # ── Main run loop ─────────────────────────────────────
    def _run(self):
        try:
            cmd = get_miner_cmd(self.profile, threads=self.threads, algo_key=self.algo_key)
        except Exception as e:
            self.error = "CMD build failed: " + str(e)
            self.alive = False
            return

        binary = cmd[0]
        if not os.path.exists(binary):
            self.error = "Binary missing: " + binary
            self.alive = False
            return
        if not os.access(binary, os.X_OK):
            try:
                os.chmod(binary, 0o755)
            except Exception:
                pass

        log_dir = os.path.join(LOG_DIR, "swarm")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(
            log_dir,
            "node_" + str(self.node_id).zfill(3) + "_" + self.algo_key.lower() + ".log"
        )

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
            )
        except OSError as e:
            self.error = "Launch failed: " + str(e)
            self.alive = False
            return

        self.alive = True
        self.on_update(self.node_id,
                       hashrate=0.0, hr_unit=self.hr_unit,
                       accepted=0,   rejected=0, alive=True)

        try:
            with open(log_path, "a") as lf:
                for raw in iter(self._proc.stdout.readline, b""):
                    if self._stop_evt.is_set() or self._proc.poll() is not None:
                        break
                    try:
                        line = raw.decode("utf-8", errors="replace").rstrip()
                    except Exception:
                        line = str(raw)
                    lf.write(line + "\n")
                    lf.flush()
                    p = self._parse(line)
                    if p:
                        if "hashrate" in p:
                            self.hashrate = p["hashrate"]
                            self.hr_unit  = p.get("hr_unit", self.hr_unit)
                        if "accepted" in p:
                            self.accepted = p["accepted"]
                        if "rejected" in p:
                            self.rejected = p["rejected"]
                        self.on_update(self.node_id,
                                       hashrate=self.hashrate,
                                       hr_unit=self.hr_unit,
                                       accepted=self.accepted,
                                       rejected=self.rejected,
                                       alive=True)
        except Exception as e:
            self.error = str(e)

        self.alive = False
        self.on_update(self.node_id, hashrate=0.0, hr_unit=self.hr_unit,
                       accepted=self.accepted, rejected=self.rejected, alive=False)

    def start(self, delay=0.0):
        """Start after optional stagger delay."""
        def _delayed():
            if delay > 0:
                time.sleep(delay)
            if not self._stop_evt.is_set():
                self._run()
        self._thread = threading.Thread(target=_delayed, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_evt.set()
        if self._proc:
            try:
                if PLATFORM == "windows":
                    self._proc.terminate()
                else:
                    self._proc.send_signal(signal.SIGTERM)
                self._proc.wait(timeout=6)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
        self.alive = False


# ─────────────────────────────────────────────────────────────────────────────
# SwarmEngine — orchestrator, aggregator, price/HW monitor
# ─────────────────────────────────────────────────────────────────────────────
class SwarmEngine:
    _instance      = None
    _instance_lock = threading.Lock()

    def __init__(self):
        self.shared = {
            "swarm_active":    False,
            "active_nodes":    0,
            "total_hashrate":  0.0,
            "hr_unit":         "H/s",
            "total_accepted":  0,
            "total_rejected":  0,
            "xmr_price":       0.0,
            "btc_price":       0.0,
            "eth_price":       0.0,
            "zeph_price":      0.0,
            "earnings_usd":    0.0,
            "temperature":     None,
            "cpu_pct":         0.0,
            "mem_pct":         0.0,
            "nodes":           [],
            "price_updated":   None,
            "hw_updated":      None,
            "algo":            DEFAULT_ALGO,
            "total_nodes_cfg": TOTAL_NODES,
        }
        self._lock        = threading.Lock()
        self._bg_stop     = threading.Event()  # stops background price/hw threads
        self._price_thread = None
        self._hw_thread    = None
        self._snap_thread  = None

        # Swarm-specific state
        self._swarm_nodes  = {}          # node_id -> SwarmNode
        self._nodes_lock   = threading.Lock()
        self._swarm_stop   = threading.Event()
        self._running      = False
        self._profile_name = None
        self._algo         = DEFAULT_ALGO

    # ── Singleton ──────────────────────────────────────────
    @classmethod
    def get_instance(cls):
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
                cls._instance._start_background()
        return cls._instance

    # ── Background tasks (always running) ─────────────────
    def _start_background(self):
        self._bg_stop.clear()
        self._price_thread = threading.Thread(target=self._price_loop, daemon=True)
        self._hw_thread    = threading.Thread(target=self._hw_loop,    daemon=True)
        self._snap_thread  = threading.Thread(target=self._snap_loop,  daemon=True)
        self._price_thread.start()
        self._hw_thread.start()
        self._snap_thread.start()
        # immediate first fetch
        threading.Thread(target=self._fetch_prices, daemon=True).start()

    def _price_loop(self):
        while not self._bg_stop.is_set():
            self._fetch_prices()
            self._bg_stop.wait(120)

    def _fetch_prices(self):
        if not _HAS_REQUESTS:
            return
        try:
            url    = "https://api.coingecko.com/api/v3/simple/price"
            params = {"ids":"monero,bitcoin,ethereum,zephyr-protocol","vs_currencies":"usd"}
            resp   = _requests.get(url, params=params, timeout=12)
            if resp.status_code == 200:
                data = resp.json()
                with self._lock:
                    self.shared["xmr_price"]     = data.get("monero",           {}).get("usd", 0.0)
                    self.shared["btc_price"]     = data.get("bitcoin",          {}).get("usd", 0.0)
                    self.shared["eth_price"]     = data.get("ethereum",         {}).get("usd", 0.0)
                    self.shared["zeph_price"]    = data.get("zephyr-protocol",  {}).get("usd", 0.0)
                    self.shared["price_updated"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                self._rebuild_shared()
        except Exception:
            pass

    def _hw_loop(self):
        while not self._bg_stop.is_set():
            self._read_hw()
            self._bg_stop.wait(5)

    def _read_hw(self):
        if not _HAS_PSUTIL:
            return
        try:
            cpu_pct = _psutil.cpu_percent(interval=None)
            mem     = _psutil.virtual_memory()
            temp    = None
            try:
                temps = _psutil.sensors_temperatures()
                if temps:
                    for name, entries in temps.items():
                        for e in entries:
                            if e.current and e.current > 0:
                                temp = round(e.current, 1)
                                break
                        if temp:
                            break
            except Exception:
                pass
            if temp is None:
                for zone in ["/sys/class/thermal/thermal_zone0/temp",
                             "/sys/class/thermal/thermal_zone1/temp"]:
                    try:
                        with open(zone) as f:
                            raw = int(f.read().strip())
                            temp = round(raw / 1000.0, 1)
                            break
                    except Exception:
                        pass
            with self._lock:
                self.shared["cpu_pct"]     = round(cpu_pct, 1)
                self.shared["mem_pct"]     = round(mem.percent, 1)
                self.shared["temperature"] = temp
                self.shared["hw_updated"]  = datetime.utcnow().strftime("%H:%M:%S")
        except Exception:
            pass

    def _snap_loop(self):
        while not self._bg_stop.is_set():
            self._bg_stop.wait(60)
            self._save_snapshot()

    def _save_snapshot(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.execute("PRAGMA journal_mode=WAL")
            c = conn.cursor()
            with self._lock:
                s = self.shared
            c.execute("""
                INSERT INTO swarm_snapshots
                (algo, active_nodes, total_hr, total_acc, usd_daily, cpu_pct, temperature)
                VALUES (?,?,?,?,?,?,?)
            """, (
                s.get("algo",          DEFAULT_ALGO),
                s.get("active_nodes",  0),
                s.get("total_hashrate",0.0),
                s.get("total_accepted",0),
                s.get("earnings_usd",  0.0),
                s.get("cpu_pct",       0.0),
                s.get("temperature"),
            ))
            conn.commit()
            conn.close()
        except Exception:
            pass

    # ── Node registration (external / API-registered nodes) ──
    def register_node(self, node_id, worker_name, coin="XMR"):
        with self._nodes_lock:
            if node_id not in self._swarm_nodes:
                # external node — track as dict only
                pass
        # Store in shared nodes list for _rebuild_shared
        with self._lock:
            existing = [n for n in self.shared.get("nodes",[]) if n.get("node_id") != node_id]
            existing.append({
                "node_id": node_id, "worker": worker_name, "coin": coin,
                "hashrate": 0.0, "hr_unit": "H/s",
                "accepted": 0, "rejected": 0,
                "last_seen": datetime.utcnow().isoformat(), "alive": True,
            })
            self.shared["nodes"] = existing
        self._rebuild_shared()

    def update_node(self, node_id, hashrate=None, hr_unit=None,
                    accepted=None, rejected=None, coin=None, alive=None):
        """Called by SwarmNodes and external API callers."""
        with self._lock:
            nodes = self.shared.get("nodes", [])
            found = False
            for n in nodes:
                if n.get("node_id") == node_id:
                    if hashrate  is not None: n["hashrate"]  = float(hashrate)
                    if hr_unit   is not None: n["hr_unit"]   = hr_unit
                    if accepted  is not None: n["accepted"]  = int(accepted)
                    if rejected  is not None: n["rejected"]  = int(rejected)
                    if coin      is not None: n["coin"]      = coin
                    if alive     is not None: n["alive"]     = bool(alive)
                    n["last_seen"] = datetime.utcnow().isoformat()
                    found = True
                    break
            if not found:
                self.shared["nodes"].append({
                    "node_id":  node_id,
                    "worker":   str(node_id),
                    "coin":     coin or "XMR",
                    "hashrate": float(hashrate or 0),
                    "hr_unit":  hr_unit or "H/s",
                    "accepted": int(accepted or 0),
                    "rejected": int(rejected or 0),
                    "last_seen": datetime.utcnow().isoformat(),
                    "alive":    alive if alive is not None else True,
                })
        self._rebuild_shared()

    def deregister_node(self, node_id):
        with self._lock:
            for n in self.shared.get("nodes", []):
                if n.get("node_id") == node_id:
                    n["alive"] = False
        self._rebuild_shared()

    def _rebuild_shared(self):
        with self._lock:
            alive = [n for n in self.shared.get("nodes", []) if n.get("alive")]
        total_hr  = 0.0
        total_acc = 0
        total_rej = 0
        for n in alive:
            hr   = n.get("hashrate", 0.0)
            unit = n.get("hr_unit", "H/s")
            mult = {"H/s":1.0,"KH/s":1e3,"MH/s":1e6,"GH/s":1e9}.get(unit, 1.0)
            total_hr  += hr * mult
            total_acc += n.get("accepted", 0)
            total_rej += n.get("rejected", 0)
        # Convert to best-fit unit
        if total_hr >= 1e9:
            hr_disp = total_hr / 1e9; unit_disp = "GH/s"
        elif total_hr >= 1e6:
            hr_disp = total_hr / 1e6; unit_disp = "MH/s"
        elif total_hr >= 1e3:
            hr_disp = total_hr / 1e3; unit_disp = "KH/s"
        else:
            hr_disp = total_hr; unit_disp = "H/s"
        with self._lock:
            self.shared["active_nodes"]    = len(alive)
            self.shared["swarm_active"]    = len(alive) > 0
            self.shared["total_hashrate"]  = round(hr_disp, 4)
            self.shared["hr_unit"]         = unit_disp
            self.shared["total_accepted"]  = total_acc
            self.shared["total_rejected"]  = total_rej
            self.shared["nodes"]           = list(alive)
            xmr_price = self.shared.get("xmr_price", 0.0)
            if total_hr > 0 and xmr_price > 0:
                rate = 0.0000003 * (xmr_price / 170.0)
                self.shared["earnings_usd"] = round(total_hr * rate * 86400.0, 4)

    # ── Real swarm: start / stop ───────────────────────────
    def start_swarm(self, profile_name, threads=NODE_THREADS, algo_key=None):
        """
        Spawn TOTAL_NODES real miner subprocesses with stagger delays.
        Each node reports parsed hashrate back via update_node().
        """
        if self._running:
            return False, "Swarm already running"

        profile = load_profile(profile_name)
        if not profile:
            return False, "Profile not found: " + profile_name

        if algo_key is None:
            algo_key = str(profile.get("active_algo", DEFAULT_ALGO)).upper().strip()
        else:
            algo_key = algo_key.upper().strip()

        if algo_key not in ALGOS:
            return False, "Unknown algo: " + algo_key

        # Validate binary exists
        try:
            binary = get_algo_binary(algo_key)
        except Exception as e:
            return False, str(e)
        if not os.path.exists(binary):
            return False, "Binary not found: " + binary + " — run installer first"

        self._algo         = algo_key
        self._profile_name = profile_name
        self._swarm_stop.clear()
        self._running      = True

        # Reset node list
        with self._lock:
            self.shared["nodes"]        = []
            self.shared["algo"]         = algo_key
            self.shared["active_nodes"] = 0
            self.shared["swarm_active"] = False

        with self._nodes_lock:
            self._swarm_nodes = {}

        # Spawn all nodes with stagger
        for i in range(1, TOTAL_NODES + 1):
            node = SwarmNode(
                node_id   = i,
                profile   = profile,
                threads   = threads,
                algo_key  = algo_key,
                on_update = self._on_node_update,
            )
            with self._nodes_lock:
                self._swarm_nodes[i] = node
            delay = (i - 1) * STAGGER_SEC
            node.start(delay=delay)

        print("[miner_swarm] Started " + str(TOTAL_NODES) + " nodes (" + algo_key + ")")
        return True, None

    def _on_node_update(self, node_id, hashrate=0.0, hr_unit="H/s",
                        accepted=0, rejected=0, alive=True):
        """Callback used by SwarmNode instances."""
        self.update_node(node_id,
                         hashrate=hashrate, hr_unit=hr_unit,
                         accepted=accepted, rejected=rejected,
                         alive=alive)

    def stop_swarm(self):
        if not self._running:
            return False, "Swarm not running"
        self._swarm_stop.set()
        self._running = False

        with self._nodes_lock:
            nodes = list(self._swarm_nodes.values())

        for node in nodes:
            try:
                node.stop()
            except Exception:
                pass

        with self._nodes_lock:
            self._swarm_nodes = {}

        with self._lock:
            self.shared["nodes"]        = []
            self.shared["active_nodes"] = 0
            self.shared["swarm_active"] = False
            self.shared["total_hashrate"] = 0.0

        print("[miner_swarm] Swarm stopped")
        return True, None

    def is_swarm_running(self):
        return self._running

    def get_snapshot(self):
        with self._lock:
            return dict(self.shared)


# ── Public singleton accessor ──────────────────────────────
def get_engine():
    return SwarmEngine.get_instance()


# ── Flask Blueprint ────────────────────────────────────────
swarm_bp = Blueprint("swarm", __name__)

@swarm_bp.route("/api/swarm/status")
def swarm_status():
    return jsonify(get_engine().get_snapshot())

@swarm_bp.route("/api/swarm/prices")
def swarm_prices():
    s = get_engine().get_snapshot()
    return jsonify({
        "xmr":     s.get("xmr_price",  0.0),
        "btc":     s.get("btc_price",  0.0),
        "eth":     s.get("eth_price",  0.0),
        "zeph":    s.get("zeph_price", 0.0),
        "updated": s.get("price_updated"),
    })

@swarm_bp.route("/api/swarm/hardware")
def swarm_hardware():
    s = get_engine().get_snapshot()
    return jsonify({
        "cpu_pct":    s.get("cpu_pct",    0.0),
        "mem_pct":    s.get("mem_pct",    0.0),
        "temperature":s.get("temperature"),
        "updated":    s.get("hw_updated"),
        "platform":   PLATFORM,
        "arch":       ARCH,
        "psutil":     _HAS_PSUTIL,
    })

@swarm_bp.route("/api/swarm/nodes")
def swarm_nodes():
    return jsonify(get_engine().shared.get("nodes", []))

@swarm_bp.route("/api/swarm/start", methods=["POST"])
def swarm_start():
    data     = flask_req.get_json(silent=True) or {}
    pname    = data.get("profile_name", flask_req.form.get("profile_name",""))
    threads  = int(data.get("threads",  flask_req.form.get("threads", NODE_THREADS)))
    algo_key = data.get("algo",         flask_req.form.get("algo", None))
    if not pname:
        return jsonify({"ok":False,"error":"profile_name required"}), 400
    ok, err = get_engine().start_swarm(pname, threads=threads, algo_key=algo_key)
    if ok:
        s = get_engine().get_snapshot()
        return jsonify({
            "ok":          True,
            "algo":        s.get("algo", DEFAULT_ALGO),
            "total_nodes": TOTAL_NODES,
            "hr_unit":     s.get("hr_unit","H/s"),
        })
    return jsonify({"ok":False,"error":err}), 500

@swarm_bp.route("/api/swarm/stop", methods=["POST"])
def swarm_stop():
    ok, err = get_engine().stop_swarm()
    if ok:
        return jsonify({"ok":True})
    return jsonify({"ok":False,"error":err}), 400

@swarm_bp.route("/api/swarm/register", methods=["POST"])
def swarm_register_node():
    data    = flask_req.get_json(silent=True) or {}
    node_id = data.get("node_id", "ext_" + str(int(time.time())))
    worker  = data.get("worker",  "unknown")
    coin    = data.get("coin",    "XMR")
    get_engine().register_node(node_id, worker, coin)
    return jsonify({"ok":True,"node_id":node_id})

@swarm_bp.route("/api/swarm/update", methods=["POST"])
def swarm_update_node():
    data    = flask_req.get_json(silent=True) or {}
    node_id = data.get("node_id")
    if not node_id:
        return jsonify({"ok":False,"error":"node_id required"}), 400
    get_engine().update_node(
        node_id,
        hashrate = data.get("hashrate"),
        hr_unit  = data.get("hr_unit"),
        accepted = data.get("accepted"),
        rejected = data.get("rejected"),
        coin     = data.get("coin"),
    )
    return jsonify({"ok":True})

@swarm_bp.route("/api/swarm/snapshot_history")
def swarm_snapshot_history():
    limit = int(flask_req.args.get("limit", 60))
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT ts, algo, active_nodes, total_hr, total_acc,
                   usd_daily, cpu_pct, temperature
            FROM swarm_snapshots
            ORDER BY ts DESC LIMIT ?
        """, (limit,))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return jsonify(list(reversed(rows)))
    except Exception as e:
        return jsonify({"error":str(e)}), 500


def register_with_app(flask_app):
    eng = get_engine()
    flask_app.register_blueprint(swarm_bp)
    return eng
