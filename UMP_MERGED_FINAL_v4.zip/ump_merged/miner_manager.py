# miner_manager.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Manages master miner subprocess — XMRig (RandomX) | cpuminer-multi (X11)
# armv7l / aarch64 / x86_64 / macOS / Windows safe — no f-strings, no walrus

import os
import re
import time
import signal
import sqlite3
import threading
import subprocess
from datetime import datetime

from miner_config import (
    DB_PATH, LOG_DIR, BIN_DIR, PLATFORM, ALGOS, DEFAULT_ALGO,
    get_miner_cmd, load_profile, init_db, DEFAULT_THREADS, COINS,
    calc_daily_usd, format_hashrate, set_algo
)

# ── Global state ───────────────────────────────────────────
_proc        = None
_proc_lock   = threading.Lock()
_stats_lock  = threading.Lock()
_stats = {
    "running":       False,
    "algo":          DEFAULT_ALGO,
    "coin":          "",
    "pool":          "",
    "hashrate":      0.0,
    "hashrate_unit": "H/s",
    "hashrate_fmt":  "0 H/s",
    "accepted":      0,
    "rejected":      0,
    "uptime_sec":    0,
    "started_at":    None,
    "profile_name":  None,
    "pid":           None,
    "error":         None,
    "daily_usd":     0.0,
    "efficiency":    0.0,
    "temp":          None,
    "cpu_pct":       0.0,
}
_heartbeat_stop   = threading.Event()
_log_thread       = None
_heartbeat_thread = None
_session_id       = None

# ── Output parsers ─────────────────────────────────────────
def _parse_xmrig(line):
    """Parser for XMRig (RandomX) output."""
    parsed = {}
    # hashrate: "speed 10s/60s/15m  123.4  124.5  125.0 H/s"
    m = re.search(
        r"speed\s+\S+\s+([\d.]+)\s+[\d.n/a]+\s+[\d.n/a]+\s+(H/s|KH/s|MH/s|GH/s)",
        line
    )
    if m:
        try:
            parsed["hashrate"]      = float(m.group(1))
            parsed["hashrate_unit"] = m.group(2)
        except Exception:
            pass
    # accepted shares: "accepted (12/0)"
    m2 = re.search(r"accepted\s*\((\d+)/(\d+)\)", line)
    if m2:
        parsed["accepted"] = int(m2.group(1))
        parsed["rejected"] = int(m2.group(2))
    # temperature
    m3 = re.search(r"temp[erature]*\s*[:\s]*([\d.]+)\s*[°C]?", line, re.IGNORECASE)
    if m3:
        try:
            parsed["temp"] = float(m3.group(1))
        except Exception:
            pass
    return parsed

def _parse_cpuminer(line):
    """Parser for cpuminer-multi (X11) output. Normalises to MH/s."""
    parsed = {}
    # "Total: 1.23 MH/s" or "total: 890.5 kH/s"
    m = re.search(r"[Tt]otal:\s*([\d.]+)\s*(GH/s|MH/s|kH/s|KH/s|H/s)", line)
    if m:
        val  = float(m.group(1))
        unit = m.group(2)
        ul   = unit.lower()
        if ul == "gh/s":
            val *= 1000.0;  unit = "MH/s"
        elif ul in ("kh/s","KH/s"):
            val /= 1000.0;  unit = "MH/s"
        elif ul == "h/s":
            val /= 1e6;     unit = "MH/s"
        parsed["hashrate"]      = round(val, 6)
        parsed["hashrate_unit"] = unit
    # "accepted: 3/5"  → accepted=3 rejected=5-3=2
    m2 = re.search(r"accepted:\s*(\d+)/(\d+)", line)
    if m2:
        acc = int(m2.group(1))
        tot = int(m2.group(2))
        parsed["accepted"] = acc
        parsed["rejected"] = max(0, tot - acc)
    return parsed

# ── Log reader thread ──────────────────────────────────────
def _read_output(proc, log_path, algo_key):
    """Reads subprocess stdout, writes to log, parses stats."""
    parser = _parse_xmrig if algo_key == "RANDOMX" else _parse_cpuminer
    try:
        with open(log_path, "a") as lf:
            for raw in iter(proc.stdout.readline, b""):
                if proc.poll() is not None:
                    break
                try:
                    line = raw.decode("utf-8", errors="replace").rstrip()
                except Exception:
                    line = str(raw)
                lf.write(line + "\n")
                lf.flush()
                parsed = parser(line)
                if parsed:
                    with _stats_lock:
                        _stats.update(parsed)
                        hr   = _stats["hashrate"]
                        unit = _stats["hashrate_unit"]
                        mult = {"H/s":1,"KH/s":1e3,"MH/s":1e6,"GH/s":1e9}.get(unit, 1)
                        hr_hs = hr * mult
                        _stats["hashrate_fmt"] = format_hashrate(hr_hs)
                        acc   = _stats["accepted"]
                        rej   = _stats["rejected"]
                        total = acc + rej
                        _stats["efficiency"] = round(100.0 * acc / total, 1) if total > 0 else 100.0
                        _stats["daily_usd"]  = round(calc_daily_usd(
                            _stats.get("coin","XMR"), hr_hs), 4)
    except Exception as e:
        with _stats_lock:
            _stats["error"] = str(e)

# ── Heartbeat loop ─────────────────────────────────────────
def _heartbeat_loop():
    while not _heartbeat_stop.is_set():
        try:
            _save_state()
            with _stats_lock:
                if _stats["started_at"] and _stats["running"]:
                    try:
                        started = datetime.strptime(_stats["started_at"], "%Y-%m-%d %H:%M:%S")
                        _stats["uptime_sec"] = int((datetime.utcnow() - started).total_seconds())
                    except Exception:
                        pass
                # detect silent process death
                with _proc_lock:
                    if _proc and _proc.poll() is not None:
                        _stats["running"] = False
                        _stats["error"]   = "Miner process exited (code " + str(_proc.returncode) + ")"
        except Exception:
            pass
        time.sleep(3)

def _save_state():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        with _stats_lock:
            active     = 1 if _stats["running"] else 0
            pid        = _stats.get("pid")
            started    = _stats.get("started_at")
            algo       = _stats.get("algo", DEFAULT_ALGO)
            profile_id = None
            if _stats.get("profile_name"):
                row = c.execute(
                    "SELECT id FROM profiles WHERE profile_name=?",
                    (_stats["profile_name"],)
                ).fetchone()
                if row:
                    profile_id = row[0]
        c.execute("""
            INSERT OR REPLACE INTO miner_state
            (id, active, profile_id, algo, pid, started_at, last_heartbeat)
            VALUES (1, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (active, profile_id, algo, pid, started))
        conn.commit()
        conn.close()
    except Exception:
        pass

def _save_hashrate_snapshot():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        with _stats_lock:
            pname = _stats.get("profile_name")
            hr    = _stats.get("hashrate", 0)
            unit  = _stats.get("hashrate_unit", "H/s")
            acc   = _stats.get("accepted", 0)
            rej   = _stats.get("rejected", 0)
            algo  = _stats.get("algo", DEFAULT_ALGO)
        profile_id = None
        if pname:
            row = c.execute("SELECT id FROM profiles WHERE profile_name=?", (pname,)).fetchone()
            if row:
                profile_id = row[0]
        c.execute("""
            INSERT INTO hashrate_history (profile_id, algo, hashrate, unit, accepted, rejected)
            VALUES (?,?,?,?,?,?)
        """, (profile_id, algo, hr, unit, acc, rej))
        conn.commit()
        conn.close()
    except Exception:
        pass

# ── Start miner ────────────────────────────────────────────
def start_miner(profile_name, threads=None, algo_key=None):
    global _proc, _log_thread, _heartbeat_thread, _session_id

    profile = load_profile(profile_name)
    if not profile:
        return False, "Profile not found: " + profile_name

    if algo_key is None:
        algo_key = str(profile.get("active_algo", DEFAULT_ALGO)).upper().strip()
    else:
        algo_key = algo_key.upper().strip()

    if algo_key not in ALGOS:
        return False, "Unknown algo: " + algo_key

    try:
        t = int(threads or profile.get("threads", DEFAULT_THREADS))
    except (ValueError, TypeError):
        t = DEFAULT_THREADS

    try:
        cmd = get_miner_cmd(profile, threads=t, algo_key=algo_key)
    except ValueError as e:
        return False, str(e)

    with _proc_lock:
        if _proc and _proc.poll() is None:
            return False, "Already running (PID " + str(_proc.pid) + ")"

        # Per-profile, per-algo log file
        log_name = profile_name.replace(" ","_") + "_" + algo_key.lower() + "_xmrig.log"
        log_path = os.path.join(LOG_DIR, log_name)
        os.makedirs(LOG_DIR, exist_ok=True)
        os.makedirs(BIN_DIR, exist_ok=True)

        binary = cmd[0]
        if not os.path.exists(binary):
            return False, "Binary not found: " + binary + " — run install script first"
        if not os.access(binary, os.X_OK):
            os.chmod(binary, 0o755)

        try:
            _proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
            )
        except OSError as e:
            return False, "Failed to start miner: " + str(e)

        now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        algo_info = ALGOS[algo_key]
        with _stats_lock:
            _stats.update({
                "running":      True,
                "algo":         algo_key,
                "coin":         str(profile.get("selected_coin","XMR")).upper(),
                "pool":         str(profile.get("selected_pool","kryptex")),
                "hashrate":     0.0,
                "hashrate_unit":algo_info["hr_unit"],
                "hashrate_fmt": "0 " + algo_info["hr_unit"],
                "accepted":     0,
                "rejected":     0,
                "uptime_sec":   0,
                "started_at":   now_str,
                "profile_name": profile_name,
                "pid":          _proc.pid,
                "error":        None,
                "daily_usd":    0.0,
                "efficiency":   100.0,
            })

    # Record session
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        row = c.execute("SELECT id FROM profiles WHERE profile_name=?", (profile_name,)).fetchone()
        pid = row[0] if row else None
        c.execute("""
            INSERT INTO sessions (profile_id, coin, pool, algo, started_at)
            VALUES (?,?,?,?,?)
        """, (pid,
              str(profile.get("selected_coin","XMR")).upper(),
              str(profile.get("selected_pool","kryptex")),
              algo_key, now_str))
        conn.commit()
        _session_id = c.lastrowid
        conn.close()
    except Exception:
        pass

    _heartbeat_stop.clear()

    _log_thread = threading.Thread(
        target=_read_output, args=(_proc, log_path, algo_key), daemon=True)
    _log_thread.start()

    _heartbeat_thread = threading.Thread(target=_heartbeat_loop, daemon=True)
    _heartbeat_thread.start()

    # Snapshot thread — every 30 s
    def _snapshot_loop():
        while not _heartbeat_stop.is_set():
            time.sleep(30)
            _save_hashrate_snapshot()
    threading.Thread(target=_snapshot_loop, daemon=True).start()

    return True, None

# ── Stop miner ─────────────────────────────────────────────
def stop_miner():
    global _proc
    _heartbeat_stop.set()

    with _proc_lock:
        if not _proc:
            return False, "Not running"
        if _proc.poll() is not None:
            _proc = None
            with _stats_lock:
                _stats["running"] = False
            return False, "Already stopped"
        try:
            if PLATFORM == "windows":
                _proc.terminate()
            else:
                _proc.send_signal(signal.SIGTERM)
            _proc.wait(timeout=8)
        except Exception:
            try:
                _proc.kill()
            except Exception:
                pass
        _proc = None

    stopped_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    with _stats_lock:
        _stats["running"] = False
        _stats["pid"]     = None

    # Finalise session record
    try:
        if _session_id:
            conn = sqlite3.connect(DB_PATH)
            conn.execute("PRAGMA journal_mode=WAL")
            c = conn.cursor()
            with _stats_lock:
                acc  = _stats.get("accepted", 0)
                rej  = _stats.get("rejected", 0)
                hr   = _stats.get("hashrate", 0)
            c.execute("""
                UPDATE sessions SET stopped_at=?, shares_acc=?, shares_rej=?, avg_hr=?
                WHERE id=?
            """, (stopped_at, acc, rej, hr, _session_id))
            conn.commit()
            conn.close()
    except Exception:
        pass

    _save_state()
    return True, None

# ── Switch algo (stop → persist → restart) ────────────────
def switch_algo(profile_name, algo_key, threads=None):
    """
    Atomically switch the mining algorithm:
      1. Stop the current miner (if running).
      2. Persist the new algo to the profile DB record.
      3. Restart with the new algo.
    Returns (ok, error_string).
    """
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        return False, "Unknown algo: " + algo_key

    was_running = is_running()

    if was_running:
        ok, err = stop_miner()
        if not ok and err not in ("Not running", "Already stopped"):
            return False, "Stop failed: " + str(err)
        time.sleep(1)  # brief settle

    # Persist new algo
    try:
        set_algo(profile_name, algo_key)
    except Exception as e:
        return False, "DB update failed: " + str(e)

    if was_running:
        return start_miner(profile_name, threads=threads, algo_key=algo_key)

    return True, None

# ── Status helpers ─────────────────────────────────────────
def is_running():
    with _proc_lock:
        if _proc and _proc.poll() is None:
            return True
    return False

def get_stats():
    with _stats_lock:
        s = dict(_stats)
    s["is_alive"] = is_running()
    return s

# ── Log tail ───────────────────────────────────────────────
def get_log_tail(lines=80, algo_key=None):
    """Return last N lines from the most recent log for the active profile."""
    with _stats_lock:
        pname  = _stats.get("profile_name", "")
        a_key  = _stats.get("algo", DEFAULT_ALGO) if algo_key is None else algo_key.upper()
    if not pname:
        return []
    log_name = pname.replace(" ","_") + "_" + a_key.lower() + "_xmrig.log"
    log_path = os.path.join(LOG_DIR, log_name)
    if not os.path.exists(log_path):
        return []
    try:
        with open(log_path, "r", errors="replace") as f:
            all_lines = f.readlines()
        return [l.rstrip() for l in all_lines[-lines:]]
    except Exception:
        return []

# ── Hashrate history ───────────────────────────────────────
def get_hashrate_history(profile_name, limit=120):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT h.ts, h.hashrate, h.unit, h.accepted, h.rejected, h.algo
            FROM hashrate_history h
            JOIN profiles p ON h.profile_id=p.id
            WHERE p.profile_name=?
            ORDER BY h.ts DESC LIMIT ?
        """, (profile_name, limit))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return list(reversed(rows))
    except Exception:
        return []

# ── Auto-resume on startup ─────────────────────────────────
def auto_resume():
    time.sleep(2)
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT ms.*, p.profile_name, p.active_algo
            FROM miner_state ms
            LEFT JOIN profiles p ON ms.profile_id=p.id
            WHERE ms.id=1 AND ms.active=1
        """)
        row = c.fetchone()
        conn.close()
        if row and row["profile_name"]:
            algo = row["algo"] or row["active_algo"] or DEFAULT_ALGO
            print("[miner_manager] Auto-resuming: " + row["profile_name"] + " (" + algo + ")")
            start_miner(row["profile_name"], algo_key=algo)
    except Exception as e:
        print("[miner_manager] Auto-resume error: " + str(e))

init_db()
