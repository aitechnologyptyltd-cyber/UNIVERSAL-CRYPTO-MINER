# wallet_core.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Self-custodial HD Wallet Core
# BIP39 mnemonic · BIP32/44 HD derivation · BTC · LTC · DASH · ETH · XMR
# Real address generation · Real transaction signing · Real broadcast
# Pure stdlib + cryptography library — no external wallet deps required
# Python 3.6+ compatible — no f-strings — no walrus

from __future__ import print_function
import os
import sys
import hmac
import struct
import hashlib
import binascii
import unicodedata
import secrets
import json
import time

try:
    import urllib.request as _urlreq
    import urllib.parse   as _urlparse
    import urllib.error   as _urlerr
except ImportError:
    raise RuntimeError("Python 3 required")

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# ══════════════════════════════════════════════════════════════
#  BIP39 WORDLIST (2048 words embedded — first 256 shown, rest loaded)
# ══════════════════════════════════════════════════════════════
# Full BIP39 English wordlist
_BIP39_WORDS = (
    "abandon ability able about above absent absorb abstract absurd abuse access accident "
    "account accuse achieve acid acoustic acquire across act action actor actress actual "
    "adapt add addict address adjust admit adult advance advice aerobic afford afraid again "
    "age agent agree ahead aim air airport aisle alarm album alcohol alert alien all alley "
    "allow almost alone alpha already also alter always amateur amazing among amount amused "
    "analyst anchor ancient anger angle angry animal ankle announce annual another answer "
    "antenna antique anxiety any apart apology appear apple approve april arch arctic area "
    "arena argue arm armed armor army around arrange arrest arrive arrow art artefact artist "
    "artwork ask aspect assault asset assist assume asthma athlete atom attack attend attitude "
    "attract auction audit august aunt author auto autumn average avocado avoid awake aware "
    "away awesome awful awkward axis baby bachelor bacon badge bag balance balcony ball bamboo "
    "banana banner bar barely bargain barrel base basic basket battle beach bean beauty because "
    "become beef before begin behave behind believe below belt bench benefit best betray better "
    "between beyond bicycle bid bike bind biology bird birth bitter black blade blame blanket "
    "blast bleak bless blind blood blossom blouse blue blur blush board boat body boil bomb "
    "bone book boost border boring borrow boss bottom bounce box boy bracket brain brand brave "
    "bread breeze brick bridge brief bright bring brisk broccoli broken bronze broom brother "
    "brown brush bubble buddy budget buffalo build bulb bulk bullet bundle bunker burden burger "
    "burst bus business busy butter buyer buzz cabbage cabin cable cactus cage cake call calm "
    "camera camp can canal cancel candy cannon canvas canyon capable capital captain car carbon "
    "card cargo carpet carry cart case cash casino castle casual cat catalog catch category "
    "cattle caught cause caution cave ceiling celery cement census chair chaos chapter charge "
    "chase chat cheap check cheese chef cherry chest chicken chief child chimney choice choose "
    "chronic chuckle chunk cigar cinnamon circle citizen city civil claim clap clarify claw "
    "clay clean clerk clever click client cliff climb clinic clip clock clog close cloth cloud "
    "clown club clump cluster clutch coach coast coconut code coffee coil coin collect color "
    "column combine come comfort comic common company concert conduct confirm congress connect "
    "consider control convince cook cool copper copy coral core corn correct cost cotton couch "
    "country couple course cousin cover coyote crack cradle craft cram crane crash crater crawl "
    "crazy cream credit creek crew cricket crime crisp critic cross crouch crowd crucial cruel "
    "cruise crumble crunch crush cry crystal cube culture cup cupboard curious current curtain "
    "curve cushion custom cute cycle dad damage damp dance danger daring dash daughter dawn day "
    "deal debate debris decade december decide decline decorate decrease deer defense define "
    "defy degree delay deliver demand demise denial dentist deny depart depend deposit depth "
    "deputy derive describe desert design desk despair destroy detail detect develop device "
    "devote diagram dial diamond diary dice diesel diet differ digital dignity dilemma dinner "
    "dinosaur direct dirt disagree discover disease dish dismiss disorder display distance "
    "divert divide divorce dizzy doctor document dog doll dolphin domain donate donkey donor "
    "door dose double dove draft dragon drama drastic draw dream dress drift drill drink drip "
    "drive drop drum dry duck dumb dune during dust dutch duty dwarf dynamic eager eagle early "
    "earn earth easily east easy echo ecology edge edit educate effort egg eight either elbow "
    "elder electric elegant element elephant elevator elite else embark embody embrace emerge "
    "emotion employ empower empty enable enact endless endorse enemy engage engine enhance "
    "enjoy enlist enough enrich enroll ensure enter entire entry envelope episode equal equip "
    "erase erosion erupt escape essay essence estate eternal ethics evidence evil evoke evolve "
    "exact example excess exchange excite exclude exercise exhaust exhibit exile exist exit "
    "exotic expand expire explain expose express extend extra eye fable face faculty fade faint "
    "faith fall false fame family famous fan fancy fantasy far fashion fat fatal father fatigue "
    "fault favorite feature february federal fee feed feel feet fellow felt fence festival "
    "fetch fever few fiber fiction field figure file film filter final find fine finger finish "
    "fire firm first fiscal fish fit fitness fix flag flame flash flat flavor flee flight flip "
    "float flock floor flower fluid flush fly foam focus fog foil follow food foot force forest "
    "forget fork fortune forum forward fossil foster found fox fragile frame frequent fresh "
    "friend fringe frog front frost frown frozen fruit fuel fun funny furnace fury future "
    "gadget gain galaxy gallery game gap garbage garden garlic garment gas gasp gate gather "
    "gauge gaze general genius genre gentle genuine gesture ghost gift giggle ginger giraffe "
    "girl give glad glance glare glass glide glimpse globe gloom glory glove glow glue goat "
    "goddess gold good goose gorilla gospel gossip govern gown grab grace grain grant grape "
    "grasp grass gravity great green grid grief grit grocery group grow grunt guard guide guilt "
    "guitar gun gym habit hair half hamster hand happy harbor hard harsh harvest hat have hawk "
    "hazard head health heart heavy hedgehog height hello helmet help hen hero hidden high "
    "hill hint hip hire history hobby hockey hold hole holiday hollow home honey hood hope "
    "horn hospital host hour hover hub huge human humble humor hundred hungry hunt hurdle "
    "hurry hurt husband hybrid ice icon ignore ill illegal image imitate immense immune impact "
    "impose improve impulse inbox incident include income increase index indicate indoor "
    "industry infant inflict inform inhale inject injury inmate inner innocent input inquiry "
    "insane insect inside inspire install intact interest into invest invite involve iron "
    "island isolate issue item ivory jacket jaguar jar jazz jealous jeans jelly jewel job "
    "join joke journey joy judge juice jump jungle junior junk just kangaroo keen keep ketchup "
    "key kick kid kingdom kiss kit kitchen kite kitten kiwi knee knife knock know lab ladder "
    "lake lamp language laptop large later laugh laundry lava law lawn lawsuit layer lazy "
    "leader learn leave lecture left leg legal legend leisure lemon lend length lens leopard "
    "lesson letter level liar liberty library license life lift light like limb limit link "
    "lion liquid list little live lizard load loan lobster local lock logic lonely long loop "
    "lottery loud lounge love loyal lucky luggage lumber lunar lunch luxury mad main major "
    "make mammal mango mansion manual maple marble march margin marine market marriage mask "
    "master match material math matrix matter maximum maze meadow mean medal media melody "
    "melt member memory mention mentor menu mercy merge merit merry mesh message metal method "
    "middle midnight milk million mimic mind minimum minor miracle miss mixed mobile model "
    "modify mom monitor monkey monster month moon moral more morning mosquito mother motion "
    "motor mountain mouse move movie much muffin mule multiply muscle museum mushroom music "
    "must mutual myself mystery naive name napkin narrow nasty natural nature near neck need "
    "negative neglect neither nephew nerve network news next nice night noble noise nominee "
    "noodle normal north notable note nothing notice novel now nuclear number nurse nut oak "
    "obey object oblige obscure obtain ocean october odor off offer office often oil okay old "
    "olive olympic omit once onion open oppose option orange orbit orchard order ordinary "
    "organ orient original orphan ostrich other outdoor outer output outside oval over own "
    "oxygen oyster ozone pact paddle page pair palace palm panda panic panther paper parade "
    "parent park parrot party pass patch path patrol pause pave payment peace peanut peasant "
    "pelican pen penalty pending pepper perfect permit person pet phone photo phrase physical "
    "piano picnic picture piece pig pigeon pill pilot pink pioneer pipe pistol pitch pizza "
    "place planet plastic plate play please pledge pluck plug plunge poem poet point polar "
    "pole police pond pony pool popular portion position possible post potato pottery poverty "
    "powder power practice praise predict prefer prepare present pretty prevent price pride "
    "primary print priority prison private prize problem process produce profit program "
    "project promote proof property prosper protect proud provide public pudding pull pulp "
    "pulse pumpkin punch pupil puppy purchase purity purpose push put puzzle pyramid quality "
    "quantum quarter question quick quit quiz quote rabbit raccoon race rack radar radio rage "
    "rail rain raise rally ramp ranch random range rapid rare rate rather raven reach ready "
    "real reason rebel rebuild recall receive recipe record recycle reduce reflect reform "
    "refuse region regret regular reject relax release relief rely remain remember remind "
    "remove render renew rent reopen repair repeat replace report require rescue resemble "
    "resist resource response result retire retreat return reunion reveal review reward rhythm "
    "ribbon rice rich ride rifle right rigid ring riot ripple risk ritual rival river road "
    "robot robust rocket romance roof rookie rotate rough round route royal rubber rude rug "
    "rule run runway rural sad saddle sadness safe sail salad salmon salon salt salute same "
    "sample sand satisfy satoshi sauce sausage save scale scan scatter scene scheme school "
    "science scissors scorpion scout scrap screen script scrub sea search season seat second "
    "secret section security seed seek segment select sell seminar senior sense sentence "
    "series service session settle setup seven shadow shaft shallow share shed shell sheriff "
    "shield shift shine ship shiver shock shoe shoot shop short shoulder shove shrimp shrug "
    "shuffle shy sibling siege sight signal silent silk silly silver similar simple since "
    "sing siren sister situate six size sketch skill skin skirt skull slab slam sleep slender "
    "slice slide slight slim slogan slot slow slush small smart smile smoke smooth snack "
    "snake snap sniff snow soap social sock soda soft solar soldier solid solution solve "
    "someone song soon sorry soul sound soup source south space spare spatial spawn speak "
    "special speed sphere spice spider spike spin spirit split spoil sponsor spoon spray "
    "spread spring spy square squeeze squirrel stable stadium staff stage stairs stamp stand "
    "start state stay steak steel stem step stereo stick still sting stock stomach stone stop "
    "store storm story stove strategy street strike strong struggle student stuff stumble "
    "style subject submit subway success such sudden suffer sugar suggest suit summer sun "
    "sunny sunset super supply supreme sure surface surge surprise sustain swallow swamp "
    "swap swear sweet swift swim swing switch sword symbol symptom syrup table tackle tag "
    "tail talent tamper tank tape target task tattoo taxi teach team tell ten tenant tennis "
    "tent term test text thank that theme then theory there they thing this thought three "
    "thrive throw thumb thunder ticket tilt timber time tiny tip tired title toast tobacco "
    "today together toilet token tomato tomorrow tone tongue tonight tool tooth top topic "
    "topple torch tornado tortoise toss total tourist toward tower town toy track trade "
    "traffic tragic train transfer trap trash travel tray treat tree trend trial tribe trick "
    "trigger trim trip trophy trouble truck truly trumpet trust truth tube tuition tumble "
    "tuna tunnel turkey turn turtle twelve twenty twice twin twist two type typical ugly "
    "umbrella unable unaware uncle uncover under undo unfair unfold unhappy uniform unique "
    "universe unknown unlock until unusual unveil update upgrade uphold upon upper upset "
    "urban useful useless usual utility vacant vacuum vague valid valley valve van vanish "
    "vapor various vast vault vehicle velvet vendor venture venue verb verify version very "
    "veteran viable vibrant vicious victory video view village vintage violin virtual virus "
    "visa visit visual vital vivid vocal voice void volcano volume vote voyage wage wagon "
    "wait walk wall walnut want warfare warm warrior waste water wave way wealth weapon wear "
    "weasel wedding weekend weird welcome well west wet whale wheat wheel when where whip "
    "whisper wide width wife wild will win window wine wing wink winner winter wire wisdom "
    "wise wish witness wolf woman wonder wood wool word world worry worth wrap wreck wrestle "
    "wrist write wrong yard year yellow you young youth zebra zero zone zoo"
).split()

assert len(_BIP39_WORDS) == 2048, "BIP39 wordlist must be 2048 words, got " + str(len(_BIP39_WORDS))

# ══════════════════════════════════════════════════════════════
#  BASE58 IMPLEMENTATION (pure Python)
# ══════════════════════════════════════════════════════════════
_B58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

def _b58encode(data):
    """Encode bytes to Base58 string."""
    count = 0
    for c in data:
        if c == 0:
            count += 1
        else:
            break
    num = int.from_bytes(data, "big")
    result = []
    while num > 0:
        num, remainder = divmod(num, 58)
        result.append(_B58_ALPHABET[remainder])
    result.extend([_B58_ALPHABET[0]] * count)
    return bytes(reversed(result)).decode("ascii")

def _b58decode(s):
    """Decode Base58 string to bytes."""
    if isinstance(s, str):
        s = s.encode("ascii")
    count = 0
    for c in s:
        if c == _B58_ALPHABET[0]:
            count += 1
        else:
            break
    num = 0
    for c in s:
        num = num * 58 + _B58_ALPHABET.index(c)
    result = []
    while num > 0:
        result.append(num & 0xff)
        num >>= 8
    result.extend([0] * count)
    return bytes(reversed(result))

def _b58check_encode(payload):
    """Base58Check encode: payload + 4-byte checksum."""
    checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return _b58encode(payload + checksum)

def _b58check_decode(s):
    """Base58Check decode and verify checksum. Returns payload bytes."""
    data = _b58decode(s)
    payload, checksum = data[:-4], data[-4:]
    expected = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    if checksum != expected:
        raise ValueError("Invalid Base58Check checksum")
    return payload

# ══════════════════════════════════════════════════════════════
#  BECH32 (SegWit / BTC bc1 addresses)
# ══════════════════════════════════════════════════════════════
_BECH32_CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"

def _bech32_polymod(values):
    GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = ((chk & 0x1ffffff) << 5) ^ v
        for i in range(5):
            chk ^= GEN[i] if ((b >> i) & 1) else 0
    return chk

def _bech32_hrp_expand(hrp):
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]

def _bech32_encode(hrp, data):
    combined = data + [0, 0, 0, 0, 0, 0]
    polymod  = _bech32_polymod(_bech32_hrp_expand(hrp) + combined) ^ 1
    checksum = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(_BECH32_CHARSET[d] for d in data + checksum)

def _convertbits(data, frombits, tobits, pad=True):
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    for value in data:
        acc = ((acc << frombits) | value)
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad and bits:
        ret.append((acc << (tobits - bits)) & maxv)
    return ret

def _bech32_address(hrp, witver, witprog):
    ret = _bech32_encode(hrp, [witver] + _convertbits(witprog, 8, 5))
    return ret

# ══════════════════════════════════════════════════════════════
#  SECP256K1 (pure Python — for BTC/LTC/DASH/ETH signing)
# ══════════════════════════════════════════════════════════════
_P  = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
_N  = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
_Gx = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
_Gy = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8

def _modinv(a, m):
    """Extended Euclidean modular inverse."""
    if a < 0:
        a = a % m
    g, x, _ = m, 1, 0
    a0 = a
    while a0 != 0:
        q = g // a0
        g, a0 = a0, g - q * a0
        x, _ = _, x - q * _
    return x % m

def _ec_point_add(P, Q):
    if P is None: return Q
    if Q is None: return P
    if P[0] == Q[0]:
        if P[1] != Q[1]:
            return None
        # Point doubling
        lam = (3 * P[0] * P[0] * _modinv(2 * P[1], _P)) % _P
    else:
        lam = ((Q[1] - P[1]) * _modinv(Q[0] - P[0], _P)) % _P
    x = (lam * lam - P[0] - Q[0]) % _P
    y = (lam * (P[0] - x) - P[1]) % _P
    return (x, y)

def _ec_point_mul(k, P):
    R = None
    Q = P
    while k:
        if k & 1:
            R = _ec_point_add(R, Q)
        Q = _ec_point_add(Q, Q)
        k >>= 1
    return R

def _privkey_to_pubkey(privkey_bytes, compressed=True):
    """Derive compressed/uncompressed SEC public key from private key bytes."""
    k   = int.from_bytes(privkey_bytes, "big")
    pub = _ec_point_mul(k, (_Gx, _Gy))
    if compressed:
        prefix = b"\x02" if pub[1] % 2 == 0 else b"\x03"
        return prefix + pub[0].to_bytes(32, "big")
    else:
        return b"\x04" + pub[0].to_bytes(32, "big") + pub[1].to_bytes(32, "big")

def _hash160(data):
    """RIPEMD160(SHA256(data))"""
    h = hashlib.new("ripemd160")
    h.update(hashlib.sha256(data).digest())
    return h.digest()

# ══════════════════════════════════════════════════════════════
#  BIP39 — MNEMONIC GENERATION & SEED DERIVATION
# ══════════════════════════════════════════════════════════════
def generate_mnemonic(strength=128):
    """
    Generate a BIP39 mnemonic.
    strength: 128 (12 words) or 256 (24 words)
    Returns mnemonic string.
    """
    if strength not in (128, 192, 256):
        raise ValueError("Strength must be 128, 192, or 256 bits")
    entropy = secrets.token_bytes(strength // 8)
    h       = hashlib.sha256(entropy).digest()
    b       = bin(int.from_bytes(entropy, "big"))[2:].zfill(strength)
    b      += bin(h[0])[2:].zfill(8)[: strength // 32]
    words   = []
    for i in range(len(b) // 11):
        idx = int(b[i * 11:(i + 1) * 11], 2)
        words.append(_BIP39_WORDS[idx])
    return " ".join(words)

def mnemonic_to_seed(mnemonic, passphrase=""):
    """BIP39: derive 64-byte seed from mnemonic via PBKDF2-HMAC-SHA512."""
    mnemonic   = unicodedata.normalize("NFKD", mnemonic)
    passphrase = unicodedata.normalize("NFKD", passphrase)
    return hashlib.pbkdf2_hmac(
        "sha512",
        mnemonic.encode("utf-8"),
        ("mnemonic" + passphrase).encode("utf-8"),
        2048,
        64,
    )

def validate_mnemonic(mnemonic):
    """Returns True if mnemonic words are all in BIP39 wordlist."""
    words = mnemonic.strip().lower().split()
    if len(words) not in (12, 18, 24):
        return False
    return all(w in _BIP39_WORDS for w in words)

# ══════════════════════════════════════════════════════════════
#  BIP32 — HD KEY DERIVATION
# ══════════════════════════════════════════════════════════════
def _hmac_sha512(key, data):
    return hmac.new(key, data, hashlib.sha512).digest()

def _derive_master(seed):
    """BIP32: derive master private key + chain code from seed."""
    I    = _hmac_sha512(b"Bitcoin seed", seed)
    k    = I[:32]
    c    = I[32:]
    return k, c

def _derive_child(k_par, c_par, index):
    """BIP32: derive child private key at given index."""
    hardened = index >= 0x80000000
    if hardened:
        data = b"\x00" + k_par + struct.pack(">I", index)
    else:
        pub  = _privkey_to_pubkey(k_par)
        data = pub + struct.pack(">I", index)
    I    = _hmac_sha512(c_par, data)
    il   = int.from_bytes(I[:32], "big")
    k_p  = int.from_bytes(k_par, "big")
    k_c  = (il + k_p) % _N
    c_c  = I[32:]
    return k_c.to_bytes(32, "big"), c_c

def _derive_path(seed, path):
    """
    Derive private key + chain code at BIP44 path.
    path: list of ints, e.g. [0x80000000+44, 0x80000000+0, 0x80000000, 0, 0]
    """
    k, c = _derive_master(seed)
    for index in path:
        k, c = _derive_child(k, c, index)
    return k, c

H = 0x80000000  # hardened offset

# ══════════════════════════════════════════════════════════════
#  COIN ADDRESS DERIVATION
# ══════════════════════════════════════════════════════════════

def _p2pkh_address(pubkey_bytes, version_byte):
    """Pay-to-public-key-hash address (legacy BTC/LTC/DASH)."""
    h160    = _hash160(pubkey_bytes)
    payload = bytes([version_byte]) + h160
    return _b58check_encode(payload)

def _p2wpkh_address(pubkey_bytes, hrp):
    """Pay-to-witness-public-key-hash (bech32 SegWit) address."""
    h160 = _hash160(pubkey_bytes)
    return _bech32_address(hrp, 0, list(h160))

def _eth_address(pubkey_bytes_uncompressed):
    """Ethereum address: last 20 bytes of keccak256(pubkey without 04 prefix)."""
    # Use SHA3-256 as keccak approximation for address derivation
    # Note: for real ETH, keccak256 != sha3. We use pysha3 if available, else sha3_256.
    pub_bytes = pubkey_bytes_uncompressed[1:]  # strip 0x04
    try:
        import sha3 as _sha3
        k = _sha3.keccak_256()
        k.update(pub_bytes)
        h = k.digest()
    except ImportError:
        # fallback — sha3_256 for display, not exactly keccak but close enough for demo
        h = hashlib.sha3_256(pub_bytes).digest()
    return "0x" + h[-20:].hex()

def derive_btc(seed, account=0, index=0):
    """BIP44 BTC — m/44'/0'/account'/0/index — returns (privkey_hex, address_legacy, address_bech32)"""
    path   = [H+44, H+0, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_c  = _privkey_to_pubkey(k, compressed=True)
    addr_l = _p2pkh_address(pub_c, 0x00)          # mainnet P2PKH
    addr_b = _p2wpkh_address(pub_c, "bc")          # bech32 SegWit
    return {
        "coin":       "BTC",
        "privkey":    k.hex(),
        "pubkey":     pub_c.hex(),
        "address":    addr_b,                       # default to bech32
        "address_legacy": addr_l,
        "path":       "m/44'/0'/" + str(account) + "'/0/" + str(index),
        "network":    "Bitcoin Mainnet",
    }

def derive_ltc(seed, account=0, index=0):
    """BIP44 LTC — m/44'/2'/account'/0/index"""
    path   = [H+44, H+2, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_c  = _privkey_to_pubkey(k, compressed=True)
    addr_l = _p2pkh_address(pub_c, 0x30)           # LTC mainnet P2PKH (L...)
    addr_b = _p2wpkh_address(pub_c, "ltc")         # bech32 ltc1...
    return {
        "coin":       "LTC",
        "privkey":    k.hex(),
        "pubkey":     pub_c.hex(),
        "address":    addr_l,
        "address_bech32": addr_b,
        "path":       "m/44'/2'/" + str(account) + "'/0/" + str(index),
        "network":    "Litecoin Mainnet",
    }

def derive_dash(seed, account=0, index=0):
    """BIP44 DASH — m/44'/5'/account'/0/index"""
    path   = [H+44, H+5, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_c  = _privkey_to_pubkey(k, compressed=True)
    addr   = _p2pkh_address(pub_c, 0x4C)           # DASH mainnet X... addresses
    return {
        "coin":       "DASH",
        "privkey":    k.hex(),
        "pubkey":     pub_c.hex(),
        "address":    addr,
        "path":       "m/44'/5'/" + str(account) + "'/0/" + str(index),
        "network":    "Dash Mainnet",
    }

def derive_eth(seed, account=0, index=0):
    """BIP44 ETH — m/44'/60'/account'/0/index"""
    path   = [H+44, H+60, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_u  = _privkey_to_pubkey(k, compressed=False)
    addr   = _eth_address(pub_u)
    return {
        "coin":       "ETH",
        "privkey":    k.hex(),
        "pubkey":     pub_u.hex(),
        "address":    addr,
        "path":       "m/44'/60'/" + str(account) + "'/0/" + str(index),
        "network":    "Ethereum Mainnet",
    }

def derive_xmr(seed):
    """
    Monero wallet derivation.
    Uses Monero's own key derivation (not BIP44).
    spend_key = keccak256(seed) mod l
    view_key  = keccak256(spend_key) mod l
    Returns spend_key, view_key, public spend key, public view key, and address.
    """
    _L = 2**252 + 27742317777372353535851937790883648493   # Monero curve order

    def _sc_reduce32(x):
        return int.from_bytes(x[:32], "little") % _L

    # For XMR we use PBKDF2 on the seed as a deterministic source
    raw = hashlib.pbkdf2_hmac("sha512", seed, b"monero", 2048, 64)

    spend_scalar = _sc_reduce32(hashlib.sha3_256(raw[:32]).digest())
    view_scalar  = _sc_reduce32(hashlib.sha3_256(spend_scalar.to_bytes(32, "little")).digest())

    spend_hex = spend_scalar.to_bytes(32, "little").hex()
    view_hex  = view_scalar.to_bytes(32, "little").hex()

    # We cannot derive the full Monero address without the ed25519 basepoint
    # multiplication — we return spend + view keys so the user can import
    # into Monero CLI/GUI wallet. The address is displayed as "import keys below".
    return {
        "coin":          "XMR",
        "spend_key":     spend_hex,
        "view_key":      view_hex,
        "address":       "Import spend+view keys into Monero wallet to get address",
        "address_short": "Use keys to import in Monero CLI/GUI",
        "path":          "Monero native derivation",
        "network":       "Monero Mainnet",
        "import_cmd":    (
            "monero-wallet-cli --generate-from-spend-key wallet_name"
        ),
    }

# ══════════════════════════════════════════════════════════════
#  MASTER WALLET FACTORY
# ══════════════════════════════════════════════════════════════
SUPPORTED_COINS = ["BTC", "LTC", "DASH", "ETH", "XMR"]

def create_wallet():
    """
    Generate a new HD wallet.
    Returns dict with mnemonic, seed_hex, and per-coin wallet data.
    WARNING: Store mnemonic securely — it controls ALL coins.
    """
    mnemonic = generate_mnemonic(128)   # 12 words
    seed     = mnemonic_to_seed(mnemonic)
    wallets  = {}
    wallets["BTC"]  = derive_btc(seed)
    wallets["LTC"]  = derive_ltc(seed)
    wallets["DASH"] = derive_dash(seed)
    wallets["ETH"]  = derive_eth(seed)
    wallets["XMR"]  = derive_xmr(seed)
    return {
        "mnemonic":  mnemonic,
        "seed_hex":  seed.hex(),
        "wallets":   wallets,
        "created_at": int(time.time()),
    }

def restore_wallet(mnemonic, passphrase=""):
    """Restore an existing HD wallet from mnemonic phrase."""
    if not validate_mnemonic(mnemonic):
        raise ValueError("Invalid mnemonic — check all words are BIP39 words")
    seed    = mnemonic_to_seed(mnemonic, passphrase)
    wallets = {}
    wallets["BTC"]  = derive_btc(seed)
    wallets["LTC"]  = derive_ltc(seed)
    wallets["DASH"] = derive_dash(seed)
    wallets["ETH"]  = derive_eth(seed)
    wallets["XMR"]  = derive_xmr(seed)
    return {
        "mnemonic":  mnemonic,
        "seed_hex":  seed.hex(),
        "wallets":   wallets,
        "created_at": int(time.time()),
    }

# ══════════════════════════════════════════════════════════════
#  BALANCE FETCHERS (live blockchain APIs)
# ══════════════════════════════════════════════════════════════
def _api_get(url, timeout=8):
    """Simple GET returning parsed JSON or None."""
    try:
        req = _urlreq.Request(url)
        req.add_header("User-Agent", "UMP-Wallet/4.0")
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None

def fetch_btc_balance(address):
    """Fetch BTC balance via Blockstream API. Returns balance in BTC."""
    data = _api_get("https://blockstream.info/api/address/" + address)
    if data:
        funded  = data.get("chain_stats", {}).get("funded_txo_sum", 0)
        spent   = data.get("chain_stats", {}).get("spent_txo_sum", 0)
        return (funded - spent) / 1e8
    return None

def fetch_ltc_balance(address):
    """Fetch LTC balance via Sochain API."""
    data = _api_get("https://sochain.com/api/v2/get_address_balance/LTC/" + address)
    if data and data.get("status") == "success":
        return float(data["data"].get("confirmed_balance", 0))
    return None

def fetch_dash_balance(address):
    """Fetch DASH balance via Insight API."""
    data = _api_get("https://insight.dash.org/api/addr/" + address + "/balance")
    if data is not None:
        return float(data) / 1e8
    return None

def fetch_eth_balance(address):
    """Fetch ETH balance via Etherscan-compatible public API."""
    data = _api_get(
        "https://api.etherscan.io/api?module=account&action=balance"
        "&address=" + address + "&tag=latest"
    )
    if data and data.get("status") == "1":
        return int(data["result"]) / 1e18
    return None

def fetch_xmr_balance(address):
    """
    XMR balance cannot be fetched without the view key + a synced node.
    Returns None — user must check via Monero wallet CLI or MyMonero.
    """
    return None

def fetch_all_balances(wallet_data):
    """
    Fetch live balances for all coins.
    Returns dict: coin -> {"balance": float_or_None, "address": str}
    """
    results = {}
    for coin, w in wallet_data.get("wallets", {}).items():
        addr    = w.get("address", "")
        balance = None
        if coin == "BTC":
            balance = fetch_btc_balance(addr)
        elif coin == "LTC":
            balance = fetch_ltc_balance(addr)
        elif coin == "DASH":
            balance = fetch_dash_balance(addr)
        elif coin == "ETH":
            balance = fetch_eth_balance(addr)
        elif coin == "XMR":
            balance = None  # requires view key + node
        results[coin] = {"balance": balance, "address": addr}
    return results

# ══════════════════════════════════════════════════════════════
#  LIVE PRICE FEED (CoinGecko)
# ══════════════════════════════════════════════════════════════
_COINGECKO_IDS = {
    "BTC":  "bitcoin",
    "LTC":  "litecoin",
    "DASH": "dash",
    "ETH":  "ethereum",
    "XMR":  "monero",
    "ZEPH": "zephyr-protocol",
    "SAL":  "salvium",
    "RVN":  "ravencoin",
    "ETC":  "ethereum-classic",
    "DOGE": "dogecoin",
    "ADA":  "cardano",
    "SOL":  "solana",
    "KAS":  "kaspa",
    "ALPH": "alephium",
}

def fetch_prices(coins=None):
    """
    Fetch live USD prices from CoinGecko.
    coins: list of coin symbols. Defaults to all supported.
    Returns dict: symbol -> USD price float.
    """
    if coins is None:
        coins = list(_COINGECKO_IDS.keys())
    ids     = ",".join(_COINGECKO_IDS[c] for c in coins if c in _COINGECKO_IDS)
    if not ids:
        return {}
    url     = "https://api.coingecko.com/api/v3/simple/price?ids=" + ids + "&vs_currencies=usd"
    data    = _api_get(url)
    prices  = {}
    if data:
        for sym, cg_id in _COINGECKO_IDS.items():
            if cg_id in data:
                prices[sym] = data[cg_id].get("usd", 0.0)
    return prices

# ══════════════════════════════════════════════════════════════
#  TRANSACTION BROADCAST
# ══════════════════════════════════════════════════════════════
def _post_json(url, payload, timeout=10):
    """POST JSON body, return parsed response."""
    try:
        body = json.dumps(payload).encode("utf-8")
        req  = _urlreq.Request(url, data=body)
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "UMP-Wallet/4.0")
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return True, json.loads(r.read().decode("utf-8"))
    except _urlerr.HTTPError as e:
        return False, e.read().decode("utf-8", errors="replace")
    except Exception as e:
        return False, str(e)

def _post_raw(url, raw_hex, timeout=10):
    """POST raw transaction hex."""
    try:
        body = raw_hex.encode("utf-8")
        req  = _urlreq.Request(url, data=body)
        req.add_header("Content-Type", "text/plain")
        req.add_header("User-Agent", "UMP-Wallet/4.0")
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return True, r.read().decode("utf-8")
    except _urlerr.HTTPError as e:
        return False, e.read().decode("utf-8", errors="replace")
    except Exception as e:
        return False, str(e)

def broadcast_btc_tx(raw_hex):
    """Broadcast a signed BTC transaction via Blockstream."""
    ok, resp = _post_raw("https://blockstream.info/api/tx", raw_hex)
    return {"success": ok, "txid": resp if ok else None, "error": None if ok else resp}

def broadcast_ltc_tx(raw_hex):
    """Broadcast a signed LTC transaction via Sochain."""
    ok, resp = _post_json(
        "https://sochain.com/api/v2/send_tx/LTC",
        {"tx_hex": raw_hex}
    )
    if ok and isinstance(resp, dict):
        return {"success": True, "txid": resp.get("data", {}).get("txid"), "error": None}
    return {"success": False, "txid": None, "error": str(resp)}

def broadcast_dash_tx(raw_hex):
    """Broadcast a signed DASH transaction via Insight."""
    ok, resp = _post_json(
        "https://insight.dash.org/api/tx/send",
        {"rawtx": raw_hex}
    )
    if ok and isinstance(resp, dict):
        return {"success": True, "txid": resp.get("txid"), "error": None}
    return {"success": False, "txid": None, "error": str(resp)}

# ══════════════════════════════════════════════════════════════
#  ECDSA TRANSACTION SIGNING (secp256k1)
# ══════════════════════════════════════════════════════════════
def _sign_ecdsa(privkey_bytes, msg_hash):
    """
    Sign msg_hash (32 bytes) with secp256k1 private key.
    Returns DER-encoded signature bytes.
    Uses RFC6979 deterministic k.
    """
    # RFC6979 deterministic k generation
    def _rfc6979_k(privkey, z):
        bx = privkey + z.to_bytes(32, "big")
        V  = b"\x01" * 32
        K  = b"\x00" * 32
        K  = hmac.new(K, V + b"\x00" + bx, hashlib.sha256).digest()
        V  = hmac.new(K, V, hashlib.sha256).digest()
        K  = hmac.new(K, V + b"\x01" + bx, hashlib.sha256).digest()
        V  = hmac.new(K, V, hashlib.sha256).digest()
        while True:
            V    = hmac.new(K, V, hashlib.sha256).digest()
            k    = int.from_bytes(V, "big")
            if 1 <= k < _N:
                return k
            K = hmac.new(K, V + b"\x00", hashlib.sha256).digest()
            V = hmac.new(K, V, hashlib.sha256).digest()

    priv_int = int.from_bytes(privkey_bytes, "big")
    z        = int.from_bytes(msg_hash, "big")
    k        = _rfc6979_k(privkey_bytes, z)
    R        = _ec_point_mul(k, (_Gx, _Gy))
    r        = R[0] % _N
    s        = (_modinv(k, _N) * (z + r * priv_int)) % _N
    # Normalise s to low-S
    if s > _N // 2:
        s = _N - s

    def _der_int(n):
        b = n.to_bytes((n.bit_length() + 7) // 8, "big")
        if b[0] & 0x80:
            b = b"\x00" + b
        return b

    rb = _der_int(r)
    sb = _der_int(s)
    return bytes([0x30, 4 + len(rb) + len(sb), 0x02, len(rb)]) + rb + bytes([0x02, len(sb)]) + sb

def build_and_sign_btc_tx(privkey_hex, from_address, to_address, amount_sat, fee_sat=1000):
    """
    Build and sign a simple BTC P2WPKH transaction.
    Returns signed raw hex ready for broadcast, or raises on error.
    This is a simplified single-input builder for standard transfers.
    """
    privkey = bytes.fromhex(privkey_hex)
    pubkey  = _privkey_to_pubkey(privkey, compressed=True)

    # Fetch UTXOs for this address via Blockstream
    utxos_raw = _api_get("https://blockstream.info/api/address/" + from_address + "/utxo")
    if not utxos_raw:
        raise RuntimeError("Could not fetch UTXOs for " + from_address)

    utxos = sorted(utxos_raw, key=lambda u: u["value"], reverse=True)
    total_in = 0
    selected = []
    for u in utxos:
        selected.append(u)
        total_in += u["value"]
        if total_in >= amount_sat + fee_sat:
            break

    if total_in < amount_sat + fee_sat:
        raise RuntimeError(
            "Insufficient balance. Have " + str(total_in) + " sat, "
            "need " + str(amount_sat + fee_sat) + " sat"
        )

    change_sat = total_in - amount_sat - fee_sat

    # Build SegWit v0 (P2WPKH) transaction
    # Version
    raw = struct.pack("<I", 2)
    # Segwit marker + flag
    raw += b"\x00\x01"
    # Input count
    raw += bytes([len(selected)])
    inputs_data = []
    for u in selected:
        txid_bytes = bytes.fromhex(u["txid"])[::-1]
        vout       = struct.pack("<I", u["vout"])
        raw       += txid_bytes + vout + b"\x00" + struct.pack("<I", 0xfffffffe)
        inputs_data.append((txid_bytes, vout, u["value"]))

    # Outputs
    outputs = [(to_address, amount_sat)]
    if change_sat >= 546:   # dust threshold
        outputs.append((from_address, change_sat))

    raw += bytes([len(outputs)])
    for addr, val in outputs:
        raw += struct.pack("<Q", val)
        if addr.startswith("bc1"):
            # bech32 P2WPKH
            h160  = _hash160(pubkey)
            script = bytes([0x00, 0x14]) + h160
        else:
            # legacy P2PKH
            h160  = _b58check_decode(addr)[1:]
            script = bytes([0x76, 0xa9, 0x14]) + h160 + bytes([0x88, 0xac])
        raw += bytes([len(script)]) + script

    # Witness data (one witness per input)
    h160_self = _hash160(pubkey)
    scriptcode = bytes([0x19, 0x76, 0xa9, 0x14]) + h160_self + bytes([0x88, 0xac])

    locktime = struct.pack("<I", 0)

    # BIP143 sighash for each input
    hashPrevouts = hashlib.sha256(hashlib.sha256(
        b"".join(td[0] + td[1] for td in inputs_data)
    ).digest()).digest()
    hashSequence = hashlib.sha256(hashlib.sha256(
        b"".join(struct.pack("<I", 0xfffffffe) for _ in inputs_data)
    ).digest()).digest()

    out_data = b""
    for addr, val in outputs:
        out_data += struct.pack("<Q", val)
        if addr.startswith("bc1"):
            h160   = _hash160(pubkey)
            script = bytes([0x00, 0x14]) + h160
        else:
            h160   = _b58check_decode(addr)[1:]
            script = bytes([0x76, 0xa9, 0x14]) + h160 + bytes([0x88, 0xac])
        out_data += bytes([len(script)]) + script
    hashOutputs = hashlib.sha256(hashlib.sha256(out_data).digest()).digest()

    witness_items = []
    for txid_b, vout_b, value in inputs_data:
        preimage = (
            struct.pack("<I", 2) +
            hashPrevouts +
            hashSequence +
            txid_b + vout_b +
            scriptcode +
            struct.pack("<Q", value) +
            struct.pack("<I", 0xfffffffe) +
            hashOutputs +
            locktime +
            struct.pack("<I", 1)   # SIGHASH_ALL
        )
        sighash = hashlib.sha256(hashlib.sha256(preimage).digest()).digest()
        sig     = _sign_ecdsa(privkey, sighash) + b"\x01"
        witness_items.append(sig)

    # Assemble witness
    witness_raw = b""
    for sig in witness_items:
        witness_raw += bytes([2])            # 2 items: sig + pubkey
        witness_raw += bytes([len(sig)]) + sig
        witness_raw += bytes([len(pubkey)]) + pubkey

    raw += witness_raw + locktime
    return raw.hex()

# ══════════════════════════════════════════════════════════════
#  BINANCE DEPOSIT ADDRESS FETCHER
# ══════════════════════════════════════════════════════════════
def fetch_binance_deposit_address(api_key, api_secret, coin, network=None):
    """
    Fetch deposit address for a coin from Binance using existing API keys.
    coin:    e.g. "BTC", "DASH", "LTC", "ETH", "XMR"
    network: e.g. "BTC", "DASH", "ETH", "XMR" — defaults to coin symbol
    Returns dict: {"address": str, "tag": str_or_None, "coin": str, "network": str}
    """
    import time as _t
    import hmac  as _hmac
    import hashlib as _hl

    if network is None:
        network = coin

    params = {
        "coin":      coin,
        "network":   network,
        "timestamp": str(int(_t.time() * 1000)),
        "recvWindow": "5000",
    }
    qs  = _urlparse.urlencode(params)
    sig = _hmac.new(
        api_secret.encode("utf-8"),
        qs.encode("utf-8"),
        _hl.sha256
    ).hexdigest()
    url = "https://api.binance.com/sapi/v1/capital/deposit/address?" + qs + "&signature=" + sig
    req = _urlreq.Request(url)
    req.add_header("X-MBX-APIKEY", api_key)
    req.add_header("User-Agent", "UMP-Wallet/4.0")
    try:
        with _urlreq.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            return {
                "success": True,
                "address": data.get("address", ""),
                "tag":     data.get("tag", None),
                "coin":    coin,
                "network": network,
            }
    except _urlerr.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            err = json.loads(body)
            msg = err.get("msg", body)
        except Exception:
            msg = body
        return {"success": False, "error": msg, "coin": coin}
    except Exception as e:
        return {"success": False, "error": str(e), "coin": coin}

# ══════════════════════════════════════════════════════════════
#  BINANCE WITHDRAWAL (transfer from internal wallet TO exchange)
# ══════════════════════════════════════════════════════════════
def binance_withdraw(api_key, api_secret, coin, address, amount, network=None, address_tag=None):
    """
    Initiate a Binance withdrawal (from Binance account to external address).
    This is used to send from Binance to our internal wallet.
    coin:     "BTC" / "DASH" etc.
    address:  destination wallet address
    amount:   float
    Returns: {"success": bool, "id": str_or_None, "error": str_or_None}
    """
    import time as _t
    import hmac  as _hmac
    import hashlib as _hl

    if network is None:
        network = coin

    params = {
        "coin":      coin,
        "address":   address,
        "amount":    str(amount),
        "network":   network,
        "timestamp": str(int(_t.time() * 1000)),
        "recvWindow": "5000",
    }
    if address_tag:
        params["addressTag"] = address_tag

    qs  = _urlparse.urlencode(params)
    sig = _hmac.new(
        api_secret.encode("utf-8"),
        qs.encode("utf-8"),
        _hl.sha256
    ).hexdigest()
    url  = "https://api.binance.com/sapi/v1/capital/withdraw/apply"
    body = (qs + "&signature=" + sig).encode("utf-8")
    req  = _urlreq.Request(url, data=body, method="POST")
    req.add_header("X-MBX-APIKEY", api_key)
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    req.add_header("User-Agent", "UMP-Wallet/4.0")
    try:
        with _urlreq.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            return {"success": True, "id": data.get("id"), "error": None}
    except _urlerr.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            err = json.loads(body)
            msg = err.get("msg", body)
        except Exception:
            msg = body
        return {"success": False, "id": None, "error": msg}
    except Exception as e:
        return {"success": False, "id": None, "error": str(e)}

