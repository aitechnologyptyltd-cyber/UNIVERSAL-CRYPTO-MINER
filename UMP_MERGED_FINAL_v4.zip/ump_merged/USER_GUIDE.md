# Universal Miner Pro — Ultimate Edition v4.0
## Complete User Guide

---

## Overview

Universal Miner Pro is a self-contained, Flask-based mining management dashboard.
It auto-detects your device architecture and OS, installs required packages, and
provides a browser UI to configure and run CPU/GPU/ASIC mining across multiple pools.

**Supported Platforms**
| Platform       | Arch          | Notes                          |
|----------------|---------------|--------------------------------|
| Android/Termux | armv7l        | CPU mining only (RandomX)      |
| Android/Termux | aarch64       | CPU mining only (RandomX)      |
| Linux Desktop  | x86_64        | CPU + GPU (place GPU binary)   |
| Linux Server   | x86_64/arm64  | CPU mining, headless-friendly  |
| macOS          | x86_64/M-chip | CPU mining, Homebrew required  |
| Windows        | x86_64        | CPU mining, WSL or native      |
| Raspberry Pi   | armv7l/arm64  | CPU mining (low hashrate)      |

---

## Quick Start

### 1. Install

```bash
# Linux / Android / macOS
chmod +x install_universal_miner.sh
./install_universal_miner.sh
```

The installer will:
- Detect your OS, architecture, and CPU core count
- Install system build tools (cmake, git, gcc, openssl, libuv)
- Install Python packages (flask, requests, apscheduler, psutil)
- Build XMRig from source for your architecture
- Write `start.sh`, `start_screen.sh`, `stop.sh`, `status.sh`

### 2. Start Dashboard

```bash
./start.sh               # Foreground (see logs directly)
./start_screen.sh        # Background (screen session)
```

Then open in your browser:
```
http://localhost:8080
http://YOUR_IP:8080      # from another device on same network
```

### 3. Create a Profile

Go to **Setup** → fill in all required fields → **Save Profile**.

### 4. Start Mining

On the Dashboard, select your profile and click **▶ START MINING**.

---

## Supported Pools

### Kryptex Pool (`kryptex`)
- **URL:** https://pool.kryptex.com
- **Auto-converts** mined coins to BTC
- **User format:** `YOUR_KRYPTEX_EMAIL.WORKER_NAME`
- **Password:** `X`
- **CPU coins:** XMR, ZEPH, SAL
- **GPU coins:** ETC, ETHW, RVN, ERG, ALPH, XTM, RXD, XEL, IRON, NEXA, CLORE, XNA, QUAI, OCTA, CFX
- **ASIC coins:** BTC, BCH, BSV, FB, XEC, DGB, LTC, KAS, ZEC

### ViaBTC (`viabtc`)
- **URL:** https://viabtc.com
- **PPS+ payout**, established since 2016
- **User format:** `YOUR_VIABTC_USERNAME.WORKER_NAME`
- **Password:** `123`
- **Coins:** BTC, BCH, LTC, ETH, ETC, ZEC, DASH, XMR, KAS

### Unmineable (`unmineable`)
- **URL:** https://unmineable.com
- Mine with CPU (RandomX) → receive payout in **any coin** (BTC, ETH, DOGE, ADA, SOL, SHIB, 100+)
- **User format:** `COIN:YOUR_WALLET_ADDRESS#REF_CODE`
- **Password:** `WORKER_NAME`
- **Pool URL:** `rx.unmineable.com:3333`

### Mining Pool Hub (`miningpoolhub`)
- **URL:** https://miningpoolhub.com
- Auto-switching multi-algo pool
- **User format:** `YOUR_MPH_USERNAME.WORKER_NAME`
- **Password:** `x`
- Register at miningpoolhub.com → create API key in account settings

### MoneroOcean (`moneroocean`)
- **URL:** https://moneroocean.stream
- Auto-switches RandomX algorithms for max XMR profit
- **No registration needed** — use XMR wallet as username
- **Pool URL:** `gulf.moneroocean.stream:10128` (SSL: `:20128`)
- **User:** `YOUR_XMR_WALLET_ADDRESS`
- **Password:** `WORKER_NAME:your@email.com`

### Binance Pool (`binance`)
- **URL:** https://pool.binance.com
- Integrated with Binance exchange account
- **Pool URL:** `stratum+tcp://bs.poolbinance.com:1800`
- **User format:** `BINANCE_USERNAME.WORKER_NAME`
- **Password:** `x`

### Direct Wallet (`direct_wallet`)
- Enter any custom stratum URL
- Mine directly to an external wallet address
- Supports any pool not listed above

---

## Profile System

Each profile stores a **complete mining template**:
- Coin, pool, stratum URL, miner user/pass, TLS
- All pool credentials (Kryptex, ViaBTC, Unmineable, MPH, MoneroOcean, Binance)
- External wallet addresses (XMR, BTC)
- Thread count

**Multi-user:** Create one profile per user/rig/coin setup.
**Switch instantly** from the Dashboard dropdown without restarting.
**Export** profiles as JSON for backup.

---

## Hardware Setup

### CPU Mining (all platforms)
Supported coins: **XMR, ZEPH, SAL** (RandomX algorithm)
- XMRig is built from source during install
- Set thread count in Hardware tab (leave 1-2 cores free)
- On armv7l: max 2 threads recommended

### GPU Mining (x86_64 Linux/Windows)
Place the GPU miner binary in the `bin/` directory:

| GPU Brand | Recommended Miner | Algorithms                          |
|-----------|-------------------|-------------------------------------|
| NVIDIA    | T-Rex             | KawPow (RVN, CLORE, XNA), Octopus  |
| NVIDIA    | lolMiner          | Ethash (ETC), Equihash (ZEC)       |
| AMD       | TeamRedMiner      | KawPow, Ethash, Autolykos2 (ERG)   |
| Both      | GMiner            | Equihash, BeamHash, Octopus        |

GPU miner binary must be named `lolminer`, `t-rex`, `teamredminer`, or `gminer`
and placed in `bin/`. GPU mining requires separate manual configuration via the
miner's own config file — the dashboard tracks CPU mining via XMRig only.

### ASIC Mining
ASICs connect directly to pool stratum — no binary needed on this machine.
- Configure pool URL + user/pass on the ASIC's web interface
- Use this dashboard to track wallet balances and session history only

---

## Hashrate Calculator

The built-in calculator estimates earnings:
- Input your hashrate and unit (H/s, KH/s, MH/s, GH/s)
- Select coin
- Optionally enter live coin price for accurate estimates
- See Daily / Weekly / Monthly / Yearly projections

Live coin prices are fetched automatically from CoinGecko every 2 minutes
(requires internet connection — estimates are shown even without prices).

---

## XMRig Pool URL Reference

| Coin | Kryptex URL                        | Algorithm  |
|------|------------------------------------|------------|
| XMR  | xmr.kryptex.network:8029           | RandomX    |
| ZEPH | zeph.kryptex.network:8029          | RandomX    |
| SAL  | sal.kryptex.network:8029           | RandomX    |
| BTC  | btc.kryptex.network:3333           | SHA256     |
| LTC  | ltc.kryptex.network:3333           | Scrypt     |
| KAS  | kas.kryptex.network:3333           | HeavyHash  |
| ZEC  | zec.kryptex.network:7042           | Equihash   |
| ETC  | etc.kryptex.network:8888           | Etchash    |
| RVN  | rvn.kryptex.network:3333           | KawPow     |
| ERG  | erg.kryptex.network:3333           | Autolykos2 |
| ALPH | alph.kryptex.network:3333          | SHA3x      |

**MoneroOcean:**
- TCP: `gulf.moneroocean.stream:10128`
- SSL: `gulf.moneroocean.stream:20128`

**Unmineable (RandomX):**
- TCP: `rx.unmineable.com:3333`
- SSL: `rx.unmineable.com:443`

---

## Android / Termux Notes

```bash
# Install Termux from F-Droid (not Play Store)
# Then:
pkg update && pkg install git python
git clone <your-repo> ump_ultimate
cd ump_ultimate
chmod +x install_universal_miner.sh
./install_universal_miner.sh
./start_screen.sh
# Access from phone browser: http://localhost:8080
# Access from PC on same WiFi: http://PHONE_IP:8080
```

- armv7l: XMRig build takes 15-25 min. Keep screen on.
- Use `screen -r ump_miner` to reattach if disconnected.
- Keep phone plugged in — mining drains battery fast.
- Recommended: 1 thread on weak phones, 2-3 on flagship.

---

## File Structure

```
ump_ultimate/
├── universal_miner.py      ← Flask app entry point
├── miner_config.py         ← Coins, pools, DB, profile CRUD
├── miner_manager.py        ← XMRig subprocess + stats parser
├── miner_swarm.py          ← Multi-node aggregation + price feed
├── miner.db                ← SQLite database (auto-created)
├── install_universal_miner.sh
├── start.sh
├── start_screen.sh
├── stop.sh
├── status.sh
├── requirements.txt
├── bin/
│   ├── xmrig               ← Built by installer
│   └── README.txt
├── logs/
│   └── PROFILE_xmrig.log   ← Auto-created per profile
└── templates/
    ├── dashboard.html
    ├── setup.html
    └── profiles.html
```

---

## API Endpoints

| Method | URL                        | Description                    |
|--------|----------------------------|--------------------------------|
| GET    | /                          | Dashboard                      |
| GET    | /setup                     | Setup wizard                   |
| GET    | /profiles                  | Profile manager                |
| POST   | /mine/start                | Start mining (form: threads)   |
| POST   | /mine/stop                 | Stop mining                    |
| GET    | /api/stats                 | Live miner stats (JSON)        |
| GET    | /api/log?lines=80          | Last N log lines               |
| GET    | /api/profiles              | List all profiles              |
| GET    | /api/coins                 | Coin registry                  |
| GET    | /api/pools                 | Pool registry                  |
| GET    | /api/suggest_pool_url      | Auto pool URL for coin+pool    |
| GET    | /api/hashrate_calc         | Earnings calculator            |
| GET    | /api/sysinfo               | Platform/arch detection        |
| GET    | /api/swarm/status          | Swarm + prices + hardware      |
| GET    | /api/swarm/prices          | Live coin prices               |
| GET    | /api/swarm/hardware        | CPU%, memory%, temperature     |
| GET    | /api/sessions              | Mining session history         |
| GET    | /stream                    | SSE live stats stream          |
| GET    | /health                    | Health check JSON              |

---

## Troubleshooting

**Dashboard not loading:**
```bash
./status.sh             # Check if running
python3 universal_miner.py   # Run in foreground to see errors
```

**XMRig not found:**
```bash
ls bin/xmrig            # Should exist after install
./install_universal_miner.sh   # Re-run installer
```

**"Pool URL empty" error:**
- Go to Setup → Pool tab → click AUTO-FILL or enter manually
- Verify coin is selected first

**Build failed on armv7l:**
- Ensure at least 1 GB free RAM and 500 MB free disk
- Check `build.log` for cmake/compiler errors
- Try: `apt-get install -y libuv1-dev libssl-dev`

**Port 8080 in use:**
- Edit `universal_miner.py` → change `port=8080` to `port=5002`

---

## Security Notes

- All credentials stored locally in `miner.db` (SQLite) — never sent externally
- Use read-only API keys for Binance/MPH — never enter trading keys
- XMR view key allows balance monitoring only — never enter spend key
- Run on trusted local network only — no authentication on the dashboard by default
- Add nginx + basic auth if exposing to internet
