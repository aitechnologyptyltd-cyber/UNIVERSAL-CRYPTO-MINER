"""
gunicorn_config.py
UMP ULTIMATE v4.2 -- Gunicorn production configuration.
Tuned for armv7l / aarch64 Userland Ubuntu with SSE support.
"""
import multiprocessing
import os

# ---------------------------------------------------------------------------
# Server socket
# ---------------------------------------------------------------------------
bind            = "0.0.0.0:8080"
backlog         = 64

# ---------------------------------------------------------------------------
# Worker model
# gthread = thread-based workers -- REQUIRED for SSE long-lived connections.
# sync workers would block on every /stream connection.
# ---------------------------------------------------------------------------
worker_class    = "gthread"

# 1 worker process keeps RAM usage low on armv7l (3.6 GB total).
# All concurrency comes from threads.
workers         = 1

# Threads per worker.
# armv7l 8-core: 4 threads handles dashboard + SSE + API simultaneously.
# Increase to 8 on aarch64 or x86_64.
threads         = 4

# ---------------------------------------------------------------------------
# Timeouts
# ---------------------------------------------------------------------------
# SSE stream connections are long-lived -- must NOT timeout.
# Set to 0 = no timeout for worker silence.
timeout         = 0

# How long Gunicorn waits for workers to finish on graceful restart.
graceful_timeout = 10

# Keep-alive for non-SSE HTTP connections (seconds).
keepalive       = 5

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
_log_dir = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(_log_dir, exist_ok=True)

accesslog       = os.path.join(_log_dir, "gunicorn_access.log")
errorlog        = os.path.join(_log_dir, "gunicorn_error.log")
loglevel        = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s'

# ---------------------------------------------------------------------------
# Process naming
# ---------------------------------------------------------------------------
proc_name       = "ump_miner"
default_proc_name = "ump_miner"

# ---------------------------------------------------------------------------
# PID file
# ---------------------------------------------------------------------------
pidfile         = os.path.join(os.path.dirname(__file__), "ump.pid")

# ---------------------------------------------------------------------------
# Preload -- load app code before forking workers.
# Saves RAM on multi-worker setups; fine with workers=1 too.
# ---------------------------------------------------------------------------
preload_app     = True
