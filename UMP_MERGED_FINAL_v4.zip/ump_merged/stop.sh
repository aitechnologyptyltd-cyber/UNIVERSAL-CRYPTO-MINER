#!/bin/bash
# =============================================================================
#  stop.sh -- UMP ULTIMATE v4.2
#  Gracefully stops whichever server is running (Flask dev or Gunicorn).
# =============================================================================
cd "$(dirname "$0")"

PID_FILE="ump.pid"
STOPPED=0

# ---------------------------------------------------------------------------
# Method 1: PID file
# ---------------------------------------------------------------------------
if [ -f "$PID_FILE" ]; then
    PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        echo "[UMP] Stopping UMP (PID $PID)..."
        kill -TERM "$PID" 2>/dev/null
        sleep 2
        if kill -0 "$PID" 2>/dev/null; then
            echo "[UMP] Process still alive -- sending SIGKILL..."
            kill -KILL "$PID" 2>/dev/null
            sleep 1
        fi
        if ! kill -0 "$PID" 2>/dev/null; then
            echo "[UMP] Stopped."
            STOPPED=1
        else
            echo "[UMP] WARNING: Could not stop PID $PID"
        fi
    else
        echo "[UMP] PID $PID not running -- cleaning up PID file"
        STOPPED=1
    fi
    rm -f "$PID_FILE"
fi

# ---------------------------------------------------------------------------
# Method 2: pkill fallback (catches orphan processes)
# ---------------------------------------------------------------------------
if pkill -f "gunicorn.*wsgi:app" 2>/dev/null; then
    echo "[UMP] Stopped gunicorn workers"
    STOPPED=1
fi
if pkill -f "python3 universal_miner.py" 2>/dev/null; then
    echo "[UMP] Stopped Flask dev server"
    STOPPED=1
fi

if [ "$STOPPED" -eq 1 ]; then
    echo "[UMP] UMP ULTIMATE stopped."
else
    echo "[UMP] No running UMP instance found."
fi
