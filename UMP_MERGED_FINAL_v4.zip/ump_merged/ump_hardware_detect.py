"""
ump_hardware_detect.py
Universal Miner Pro ULTIMATE - Hardware Detection Engine
Detects CPU, GPU, platform, arch, memory, and mining capability.
Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import platform
import subprocess
import json
import re
import struct
import shutil

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------
CAPABILITY_CPU_ONLY   = "CPU_ONLY"
CAPABILITY_GPU_ONLY   = "GPU_ONLY"
CAPABILITY_CPU_GPU    = "CPU_GPU"

PLATFORM_TERMUX       = "termux"
PLATFORM_USERLAND     = "userland_ubuntu"
PLATFORM_LINUX        = "linux"
PLATFORM_MACOS        = "macos"
PLATFORM_WINDOWS      = "windows"

ARCH_ARMV7L           = "armv7l"
ARCH_AARCH64          = "aarch64"
ARCH_X86_64           = "x86_64"
ARCH_X86              = "x86"


# ---------------------------------------------------------------------------
# PLATFORM DETECTION
# ---------------------------------------------------------------------------

def detect_platform():
    """
    Returns one of: termux, userland_ubuntu, linux, macos, windows.
    Checks filesystem markers for Termux and Userland before falling back
    to platform.system().
    """
    # Termux marker
    if os.path.isdir("/data/data/com.termux"):
        return PLATFORM_TERMUX

    # Userland Ubuntu: /proc/version contains "userland" or runs inside proot
    proc_version = ""
    try:
        with open("/proc/version", "r") as fh:
            proc_version = fh.read().lower()
    except Exception:
        pass
    if "userland" in proc_version:
        return PLATFORM_USERLAND

    # Check for proot (common Userland marker)
    try:
        result = subprocess.run(
            ["cat", "/proc/1/cmdline"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        cmdline = result.stdout.decode("utf-8", errors="ignore").lower()
        if "proot" in cmdline or "userland" in cmdline:
            return PLATFORM_USERLAND
    except Exception:
        pass

    # Check /etc/os-release for Ubuntu inside Userland
    try:
        with open("/etc/os-release", "r") as fh:
            os_release = fh.read().lower()
        # Running on an Android device but not Termux? Likely Userland.
        if "ubuntu" in os_release or "debian" in os_release:
            # Check if we are on ARM without a desktop GPU
            if platform.machine().lower() in ("armv7l", "aarch64", "arm"):
                # Try to confirm via Android prop
                if _is_android():
                    return PLATFORM_USERLAND
    except Exception:
        pass

    sys_name = platform.system().lower()
    if sys_name == "linux":
        return PLATFORM_LINUX
    elif sys_name == "darwin":
        return PLATFORM_MACOS
    elif sys_name == "windows":
        return PLATFORM_WINDOWS
    return PLATFORM_LINUX


def _is_android():
    """Return True if running on an Android device (any container)."""
    # Check for Android-specific paths
    android_markers = [
        "/system/build.prop",
        "/system/app",
        "/data/data",
        "/proc/sys/kernel/osrelease",
    ]
    for path in android_markers[:2]:
        if os.path.exists(path):
            return True
    try:
        result = subprocess.run(
            ["getprop", "ro.product.model"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        if result.returncode == 0 and result.stdout.strip():
            return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# CPU DETECTION
# ---------------------------------------------------------------------------

def detect_cpu_arch():
    """Returns normalised CPU architecture string."""
    machine = platform.machine().lower()
    mapping = {
        "armv7l": ARCH_ARMV7L,
        "armv7":  ARCH_ARMV7L,
        "arm":    ARCH_ARMV7L,
        "aarch64": ARCH_AARCH64,
        "arm64":   ARCH_AARCH64,
        "x86_64":  ARCH_X86_64,
        "amd64":   ARCH_X86_64,
        "i386":    ARCH_X86,
        "i686":    ARCH_X86,
    }
    return mapping.get(machine, machine)


def detect_cpu_features():
    """
    Returns dict of CPU capability flags:
    aes_ni, avx, avx2, avx512, sse4_2, neon (ARM), huge_pages
    """
    features = {
        "aes_ni":    False,
        "avx":       False,
        "avx2":      False,
        "avx512":    False,
        "sse4_2":    False,
        "neon":      False,
        "huge_pages": False,
    }

    # Linux /proc/cpuinfo
    try:
        with open("/proc/cpuinfo", "r") as fh:
            cpuinfo = fh.read().lower()
        flags_line = ""
        for line in cpuinfo.splitlines():
            if line.startswith("flags") or line.startswith("features"):
                flags_line = line
                break
        features["aes_ni"]  = "aes"   in flags_line
        features["avx"]     = " avx " in flags_line or flags_line.endswith("avx")
        features["avx2"]    = "avx2"  in flags_line
        features["avx512"]  = "avx512" in flags_line
        features["sse4_2"]  = "sse4_2" in flags_line or "sse4.2" in flags_line
        features["neon"]    = "neon"  in flags_line or "asimd" in flags_line
    except Exception:
        pass

    # Check huge pages support
    try:
        with open("/proc/meminfo", "r") as fh:
            meminfo = fh.read()
        if "HugePages_Total" in meminfo:
            features["huge_pages"] = True
    except Exception:
        pass

    return features


def detect_cpu_info():
    """Returns dict with model_name, cores, threads, freq_mhz."""
    info = {
        "model_name": "Unknown CPU",
        "cores":      1,
        "threads":    1,
        "freq_mhz":   0,
    }

    try:
        import psutil
        info["cores"]   = psutil.cpu_count(logical=False) or 1
        info["threads"] = psutil.cpu_count(logical=True)  or 1
        freq = psutil.cpu_freq()
        if freq:
            info["freq_mhz"] = int(freq.max or freq.current or 0)
    except Exception:
        try:
            info["cores"]   = os.cpu_count() or 1
            info["threads"] = os.cpu_count() or 1
        except Exception:
            pass

    try:
        with open("/proc/cpuinfo", "r") as fh:
            for line in fh:
                if "model name" in line.lower() or "hardware" in line.lower():
                    info["model_name"] = line.split(":")[1].strip()
                    break
    except Exception:
        info["model_name"] = platform.processor() or "Unknown CPU"

    return info


# ---------------------------------------------------------------------------
# GPU DETECTION
# ---------------------------------------------------------------------------

def detect_nvidia_gpu():
    """
    Returns list of dicts [{name, vram_mb, driver_version, cuda_version}]
    Empty list if no NVIDIA GPU found.
    """
    gpus = []
    # Try nvidia-smi first
    nvidia_smi = shutil.which("nvidia-smi")
    if nvidia_smi:
        try:
            result = subprocess.run(
                [nvidia_smi,
                 "--query-gpu=name,memory.total,driver_version",
                 "--format=csv,noheader,nounits"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            if result.returncode == 0:
                for line in result.stdout.decode("utf-8").strip().splitlines():
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 3:
                        gpus.append({
                            "name":           parts[0],
                            "vram_mb":        int(parts[1]) if parts[1].isdigit() else 0,
                            "driver_version": parts[2],
                            "cuda_version":   _get_cuda_version(),
                            "vendor":         "nvidia",
                        })
        except Exception:
            pass

    # Fallback: check /proc/driver/nvidia/gpus
    if not gpus and os.path.isdir("/proc/driver/nvidia/gpus"):
        try:
            gpu_dirs = os.listdir("/proc/driver/nvidia/gpus")
            for gd in gpu_dirs:
                info_path = os.path.join("/proc/driver/nvidia/gpus", gd, "information")
                if os.path.isfile(info_path):
                    with open(info_path, "r") as fh:
                        content = fh.read()
                    name = "NVIDIA GPU"
                    for line in content.splitlines():
                        if "Model" in line:
                            name = line.split(":")[1].strip()
                    gpus.append({
                        "name":           name,
                        "vram_mb":        0,
                        "driver_version": "unknown",
                        "cuda_version":   _get_cuda_version(),
                        "vendor":         "nvidia",
                    })
        except Exception:
            pass

    return gpus


def detect_amd_gpu():
    """
    Returns list of dicts [{name, vram_mb, driver}]
    Empty list if no AMD GPU found.
    """
    gpus = []

    # Try rocm-smi
    rocm_smi = shutil.which("rocm-smi")
    if rocm_smi:
        try:
            result = subprocess.run(
                [rocm_smi, "--showproductname"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            if result.returncode == 0:
                output = result.stdout.decode("utf-8")
                for line in output.splitlines():
                    if "GPU" in line and ":" in line:
                        name = line.split(":")[1].strip()
                        gpus.append({
                            "name":   name,
                            "vram_mb": _get_amd_vram(name),
                            "driver": "ROCm",
                            "vendor": "amd",
                        })
        except Exception:
            pass

    # Fallback: lspci
    if not gpus:
        gpus.extend(_detect_gpu_via_lspci("amd"))

    # Fallback: /sys/class/drm
    if not gpus:
        gpus.extend(_detect_amd_via_sysfs())

    return gpus


def detect_intel_gpu():
    """Returns list of Intel GPU dicts. Mostly integrated graphics."""
    gpus = []
    gpus.extend(_detect_gpu_via_lspci("intel"))
    return gpus


def _detect_gpu_via_lspci(vendor):
    """Use lspci to detect GPU by vendor string."""
    gpus = []
    lspci = shutil.which("lspci")
    if not lspci:
        return gpus
    try:
        result = subprocess.run(
            [lspci],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10
        )
        output = result.stdout.decode("utf-8", errors="ignore").lower()
        for line in output.splitlines():
            if vendor.lower() in line and ("vga" in line or "3d" in line or "display" in line):
                name = line.split(":")[-1].strip().title()
                gpus.append({
                    "name":   name,
                    "vram_mb": 0,
                    "driver": "unknown",
                    "vendor": vendor,
                })
    except Exception:
        pass
    return gpus


def _detect_amd_via_sysfs():
    """Check /sys/class/drm for amdgpu devices."""
    gpus = []
    drm_path = "/sys/class/drm"
    if not os.path.isdir(drm_path):
        return gpus
    try:
        for entry in os.listdir(drm_path):
            vendor_path = os.path.join(drm_path, entry, "device", "vendor")
            if os.path.isfile(vendor_path):
                with open(vendor_path, "r") as fh:
                    vendor_id = fh.read().strip().lower()
                # AMD vendor IDs: 0x1002
                if "0x1002" in vendor_id:
                    gpus.append({
                        "name":   "AMD GPU (" + entry + ")",
                        "vram_mb": 0,
                        "driver": "amdgpu",
                        "vendor": "amd",
                    })
    except Exception:
        pass
    return gpus


def _get_cuda_version():
    """Try to read CUDA version from nvcc or cuda lib."""
    nvcc = shutil.which("nvcc")
    if nvcc:
        try:
            result = subprocess.run(
                [nvcc, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            output = result.stdout.decode("utf-8")
            match = re.search(r"release (\d+\.\d+)", output)
            if match:
                return match.group(1)
        except Exception:
            pass
    # Check for libcuda
    for path in ["/usr/local/cuda/version.txt", "/usr/local/cuda/version.json"]:
        if os.path.isfile(path):
            try:
                with open(path, "r") as fh:
                    content = fh.read()
                match = re.search(r"(\d+\.\d+)", content)
                if match:
                    return match.group(1)
            except Exception:
                pass
    return "not_found"


def _get_amd_vram(gpu_name):
    """Try to estimate AMD VRAM from GPU name string."""
    vram_map = {
        "rx 580": 8192, "rx 590": 8192, "rx 5700": 8192,
        "rx 6600": 8192, "rx 6700": 12288, "rx 6800": 16384,
        "rx 6900": 16384, "rx 7900": 24576,
        "vega 56": 8192, "vega 64": 8192,
    }
    name_lower = gpu_name.lower()
    for key, vram in vram_map.items():
        if key in name_lower:
            return vram
    return 0


def detect_opencl():
    """Return True if OpenCL runtime is available."""
    try:
        import pyopencl
        platforms = pyopencl.get_platforms()
        return len(platforms) > 0
    except Exception:
        pass
    # Check for libOpenCL
    for lib in ["/usr/lib/libOpenCL.so", "/usr/lib/x86_64-linux-gnu/libOpenCL.so.1"]:
        if os.path.isfile(lib):
            return True
    return False


# ---------------------------------------------------------------------------
# MEMORY DETECTION
# ---------------------------------------------------------------------------

def detect_ram():
    """Returns dict with total_mb, available_mb."""
    info = {"total_mb": 0, "available_mb": 0}
    try:
        import psutil
        mem = psutil.virtual_memory()
        info["total_mb"]     = int(mem.total / (1024 * 1024))
        info["available_mb"] = int(mem.available / (1024 * 1024))
        return info
    except Exception:
        pass
    try:
        with open("/proc/meminfo", "r") as fh:
            for line in fh:
                if "MemTotal" in line:
                    info["total_mb"] = int(line.split()[1]) // 1024
                if "MemAvailable" in line:
                    info["available_mb"] = int(line.split()[1]) // 1024
    except Exception:
        pass
    return info


# ---------------------------------------------------------------------------
# CAPABILITY PROFILING
# ---------------------------------------------------------------------------

def build_capability_profile():
    """
    Master function. Returns a full capability dict covering:
    platform, arch, cpu, ram, gpu, opencl, mining_capability.
    """
    plat  = detect_platform()
    arch  = detect_cpu_arch()
    cpu   = detect_cpu_info()
    feats = detect_cpu_features()
    ram   = detect_ram()

    nvidia_gpus = detect_nvidia_gpu()
    amd_gpus    = detect_amd_gpu()
    intel_gpus  = detect_intel_gpu()
    has_opencl  = detect_opencl()

    all_gpus     = nvidia_gpus + amd_gpus + intel_gpus
    has_real_gpu = len(nvidia_gpus) > 0 or len(amd_gpus) > 0

    # Determine mining capability tier
    if has_real_gpu and arch in (ARCH_X86_64,):
        if feats.get("aes_ni") or feats.get("avx"):
            capability = CAPABILITY_CPU_GPU
        else:
            capability = CAPABILITY_GPU_ONLY
    elif has_real_gpu:
        capability = CAPABILITY_GPU_ONLY
    else:
        capability = CAPABILITY_CPU_ONLY

    # CPU mining suitability score (1-10)
    cpu_score = _score_cpu_mining(arch, feats, cpu, ram)

    # GPU mining suitability
    gpu_score = _score_gpu_mining(nvidia_gpus, amd_gpus)

    profile = {
        "platform":           plat,
        "arch":               arch,
        "is_android":         _is_android(),
        "python_version":     sys.version.split()[0],
        "cpu": {
            "model":          cpu["model_name"],
            "cores":          cpu["cores"],
            "threads":        cpu["threads"],
            "freq_mhz":       cpu["freq_mhz"],
            "features":       feats,
            "mining_score":   cpu_score,
        },
        "ram": ram,
        "gpu": {
            "nvidia":         nvidia_gpus,
            "amd":            amd_gpus,
            "intel":          intel_gpus,
            "opencl":         has_opencl,
            "mining_score":   gpu_score,
        },
        "mining_capability":  capability,
        "recommended_miners": _recommend_miners(
            capability, arch, plat, nvidia_gpus, amd_gpus, feats
        ),
        "install_packages":   _required_packages(
            capability, arch, plat, nvidia_gpus, amd_gpus
        ),
    }

    return profile


def _score_cpu_mining(arch, feats, cpu, ram):
    """Return 1-10 CPU mining suitability score."""
    score = 1
    if arch == ARCH_X86_64:
        score += 3
        if feats.get("avx2"):  score += 2
        if feats.get("aes_ni"): score += 1
        if feats.get("avx512"): score += 1
    elif arch == ARCH_AARCH64:
        score += 2
        if feats.get("neon"):  score += 1
    elif arch == ARCH_ARMV7L:
        score += 0

    cores = cpu.get("cores", 1)
    if cores >= 16: score += 2
    elif cores >= 8: score += 1

    total_mb = ram.get("total_mb", 0)
    if total_mb >= 8192:  score += 1
    elif total_mb >= 4096: score += 0

    return min(score, 10)


def _score_gpu_mining(nvidia_gpus, amd_gpus):
    """Return 1-10 GPU mining suitability score."""
    if not nvidia_gpus and not amd_gpus:
        return 0
    score = 5
    for gpu in nvidia_gpus:
        vram = gpu.get("vram_mb", 0)
        if vram >= 8192:   score += 3
        elif vram >= 4096: score += 1
    for gpu in amd_gpus:
        vram = gpu.get("vram_mb", 0)
        if vram >= 8192:   score += 3
        elif vram >= 4096: score += 1
    return min(score, 10)


def _recommend_miners(capability, arch, plat, nvidia_gpus, amd_gpus, feats):
    """
    Returns list of miner binary names recommended for this system.
    """
    miners = []

    # CPU miners — always include for CPU_ONLY and CPU_GPU
    if capability in (CAPABILITY_CPU_ONLY, CAPABILITY_CPU_GPU):
        miners.append("xmrig")          # RandomX / MoneroV / Zephyr
        miners.append("cpuminer-multi") # X11 + many algos via unMineable

        if arch == ARCH_X86_64 and feats.get("avx2"):
            miners.append("xmrig-mo")  # MoneroOcean algo-switching build

    # NVIDIA GPU miners
    if nvidia_gpus:
        miners.append("lolminer")       # ETHash, Beam, Flux, Kaspa
        miners.append("t-rex")          # KAWPOW, Octopus, MTP
        miners.append("nbminer")        # Octopus, Ethash, Kaspa
        miners.append("gminer")         # ZHash, Cuckatoo, BeamV3

    # AMD GPU miners
    if amd_gpus:
        miners.append("lolminer")       # also covers AMD
        miners.append("teamredminer")   # Ethash, KAWPOW, Autolykos

    return list(set(miners))  # deduplicate


def _required_packages(capability, arch, plat, nvidia_gpus, amd_gpus):
    """
    Returns dict of packages needed per install manager.
    Keys: apt, pip, pkg (termux), source_builds
    """
    apt_pkgs  = [
        "build-essential", "cmake", "git", "wget", "curl",
        "libssl-dev", "libhwloc-dev", "libuv1-dev",
        "automake", "autoconf", "libtool", "pkg-config",
        "libjansson-dev", "libcurl4-openssl-dev",
        "python3", "python3-pip",
    ]
    pip_pkgs  = [
        "flask", "requests", "psutil", "apscheduler",
    ]
    pkg_pkgs  = [  # Termux
        "python", "git", "cmake", "clang", "make",
        "openssl", "curl", "wget", "autoconf", "automake",
        "libtool", "pkg-config",
    ]
    source_builds = ["xmrig", "cpuminer-multi"]

    if arch == ARCH_ARMV7L:
        # 32-bit ARM: remove packages that require 64-bit
        apt_pkgs = [p for p in apt_pkgs if p not in ("libhwloc-dev",)]
        apt_pkgs.append("libhwloc-dev")  # try anyway; installer will skip if fail

    if capability in (CAPABILITY_GPU_ONLY, CAPABILITY_CPU_GPU):
        if nvidia_gpus:
            apt_pkgs.extend([
                "nvidia-cuda-toolkit", "nvidia-driver-latest",
                "ocl-icd-opencl-dev", "opencl-headers",
            ])
            source_builds.append("xmrig-cuda")
        if amd_gpus:
            apt_pkgs.extend([
                "ocl-icd-opencl-dev", "opencl-headers",
                "mesa-opencl-icd",
            ])

    return {
        "apt":           apt_pkgs,
        "pip":           pip_pkgs,
        "pkg":           pkg_pkgs,
        "source_builds": source_builds,
    }


# ---------------------------------------------------------------------------
# HUMAN-READABLE REPORT
# ---------------------------------------------------------------------------

def print_capability_report(profile):
    """Print a formatted hardware capability report to stdout."""
    cap   = profile["mining_capability"]
    cpu   = profile["cpu"]
    ram   = profile["ram"]
    gpus  = profile["gpu"]

    print("=" * 60)
    print("  UMP UNIVERSAL - HARDWARE CAPABILITY REPORT")
    print("=" * 60)
    print("Platform   : " + profile["platform"])
    print("Arch       : " + profile["arch"])
    print("Python     : " + profile["python_version"])
    print("")
    print("CPU        : " + cpu["model"])
    print("Cores/Thrd : " + str(cpu["cores"]) + " / " + str(cpu["threads"]))
    print("CPU Score  : " + str(cpu["mining_score"]) + " / 10")
    feats = cpu["features"]
    feat_str = []
    for k, v in feats.items():
        if v:
            feat_str.append(k)
    print("CPU Flags  : " + (", ".join(feat_str) or "none detected"))
    print("")
    print("RAM Total  : " + str(ram["total_mb"]) + " MB")
    print("RAM Free   : " + str(ram["available_mb"]) + " MB")
    print("")
    if gpus["nvidia"]:
        for g in gpus["nvidia"]:
            print("NVIDIA GPU : " + g["name"] + " (" + str(g["vram_mb"]) + " MB VRAM)")
    if gpus["amd"]:
        for g in gpus["amd"]:
            print("AMD GPU    : " + g["name"])
    if not gpus["nvidia"] and not gpus["amd"]:
        print("GPU        : None detected")
    print("GPU Score  : " + str(gpus["mining_score"]) + " / 10")
    print("OpenCL     : " + str(gpus["opencl"]))
    print("")
    print("CAPABILITY : " + cap)
    print("MINERS     : " + ", ".join(profile["recommended_miners"]))
    print("=" * 60)


# ---------------------------------------------------------------------------
# SAVE / LOAD PROFILE
# ---------------------------------------------------------------------------

def save_profile(profile, path="ump_hw_profile.json"):
    """Save capability profile to JSON file."""
    with open(path, "w") as fh:
        json.dump(profile, fh, indent=2)
    print("[hw_detect] Profile saved to " + path)


def load_profile(path="ump_hw_profile.json"):
    """Load previously saved capability profile."""
    if not os.path.isfile(path):
        return None
    with open(path, "r") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# MAIN (standalone run)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    profile = build_capability_profile()
    print_capability_report(profile)
    save_profile(profile)
    print(json.dumps(profile, indent=2))
