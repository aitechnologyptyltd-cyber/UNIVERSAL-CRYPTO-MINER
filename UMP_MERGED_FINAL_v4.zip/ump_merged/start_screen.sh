#!/bin/bash
# =============================================================================
#  start_screen.sh -- UMP ULTIMATE v4.2
#  Runs Gunicorn inside a screen session so you can detach safely.
# =============================================================================
cd "$(dirname "$0")"
SESSION="ump_miner"

if ! command -v screen > /dev/null 2>&1; then
    echo "[UMP] screen not installed -- installing..."
    apt-get install -y screen 2>/dev/null || pkg install screen 2>/dev/null
fi

if screen -list 2>/dev/null | grep -q "$SESSION"; then
    echo "[UMP] Session '$SESSION' already running."
    echo "[UMP] Reattach: screen -r $SESSION"
else
    screen -dmS "$SESSION" bash start_gunicorn.sh
    sleep 2
    echo "[UMP] Started in screen session: $SESSION"
    echo "[UMP] Reattach : screen -r $SESSION"
    echo "[UMP] Detach   : Ctrl+A then D"
    echo "[UMP] Dashboard: http://localhost:8080"
fi
