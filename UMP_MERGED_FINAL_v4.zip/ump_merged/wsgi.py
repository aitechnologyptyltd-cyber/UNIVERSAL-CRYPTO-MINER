"""
wsgi.py
UMP ULTIMATE v4.2 -- Production WSGI entry point for Gunicorn.
Usage:
    gunicorn --config gunicorn_config.py wsgi:app
"""
import threading
from universal_miner import app, auto_resume

# Start the auto-resume daemon when Gunicorn loads this module
_resume_thread = threading.Thread(target=auto_resume, daemon=True)
_resume_thread.start()

# 'app' is the Flask WSGI application exported to Gunicorn
__all__ = ["app"]
