#!/bin/bash
# =============================================================================
#  install_universal_miner.sh
#  Universal Miner Pro ULTIMATE v4.1
#  Installs all deps, builds XMRig + cpuminer-multi from source
#  Supports: Userland Ubuntu armv7l | aarch64 | Linux x86_64 | Termux
# =============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

log_ok()   { echo -e "${GREEN}  [OK]  $1${NC}"; }
log_warn() { echo -e "${YELLOW}  [WARN] $1${NC}"; }
log_err()  { echo -e "${RED}  [ERR] $1${NC}"; }
log_info() { echo -e "${CYAN}  [-->] $1${NC}"; }
log_step() { echo -e "\n${BOLD}${CYAN}=== STEP $1: $2 ===${NC}"; }

echo -e "${CYAN}"
echo "============================================================"
echo "   UNIVERSAL MINER PRO ULTIMATE v4.1 -- INSTALLER"
echo "   Multi-Arch | Multi-Pool | Multi-Coin | Dual-Algo"
echo "   Kryptex | ViaBTC | unMineable | MoneroOcean | Binance"
echo "============================================================"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"
LOG_DIR="$SCRIPT_DIR/logs"
TMP_DIR="/tmp/ump_build_$$"
BUILD_LOG="$SCRIPT_DIR/build.log"
ERRORS=0

mkdir -p "$BIN_DIR" "$LOG_DIR" "$TMP_DIR"
echo "Install started: $(date)" > "$BUILD_LOG"

# =============================================================================
# STEP 1 -- DETECT PLATFORM AND ARCHITECTURE
# =============================================================================
log_step "1/9" "Detecting platform and architecture"

ARCH="$(uname -m)"
OS_TYPE="$(uname -s)"
PLATFORM="linux"
PKG_MGR="apt"
IS_TERMUX=0
IS_USERLAND=0
PY_BIN="python3"

# Termux check
if [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=1
    PLATFORM="termux"
    PKG_MGR="pkg"
fi

# Userland Ubuntu check
if [ "$IS_TERMUX" -eq 0 ]; then
    if grep -qi "userland" /proc/version 2>/dev/null; then
        IS_USERLAND=1
        PLATFORM="userland_ubuntu"
    fi
fi

# CPU core count
CPU_COUNT="$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null || echo 2)"
REC_THREADS="$(( CPU_COUNT > 1 ? CPU_COUNT - 1 : 1 ))"

# GPU type (informational only — CPU miner)
GPU_TYPE="None (CPU miner)"

log_ok "Platform  : $PLATFORM"
log_ok "Arch      : $ARCH"
log_ok "CPU Cores : $CPU_COUNT  (recommended threads: $REC_THREADS)"
log_ok "Build log : $BUILD_LOG"

# =============================================================================
# STEP 2 -- SYSTEM PACKAGES
# =============================================================================
log_step "2/9" "Installing system packages"

APT_PKGS="build-essential git wget curl libssl-dev libuv1-dev \
    automake autoconf libtool pkg-config \
    libjansson-dev libcurl4-openssl-dev \
    python3 python3-pip python3-dev \
    libgmp-dev screen"

# Add libhwloc only on 64-bit
if [ "$ARCH" != "armv7l" ] && [ "$ARCH" != "armv7" ]; then
    APT_PKGS="$APT_PKGS libhwloc-dev"
fi

PKG_PKGS="python git wget curl openssl automake autoconf libtool \
    pkg-config screen"

if [ "$PKG_MGR" = "apt" ]; then
    log_info "Running apt-get update..."
    apt-get update -y >> "$BUILD_LOG" 2>&1 || log_warn "apt-get update had warnings"
    for pkg in $APT_PKGS; do
        log_info "apt-get install: $pkg"
        apt-get install -y --no-install-recommends "$pkg" >> "$BUILD_LOG" 2>&1 \
            && log_ok "$pkg" \
            || log_warn "$pkg skipped (not available)"
    done
elif [ "$PKG_MGR" = "pkg" ]; then
    log_info "Running pkg update..."
    pkg update -y >> "$BUILD_LOG" 2>&1 || true
    for pkg in $PKG_PKGS; do
        log_info "pkg install: $pkg"
        pkg install -y "$pkg" >> "$BUILD_LOG" 2>&1 \
            && log_ok "$pkg" \
            || log_warn "$pkg skipped"
    done
fi

# =============================================================================
# STEP 3 -- CMAKE (from source if system cmake is missing or too old)
# =============================================================================
log_step "3/9" "Checking / installing cmake"

CMAKE_MIN_VERSION="3.15"
CMAKE_INSTALL_VERSION="3.28.3"
NEED_CMAKE=0

if command -v cmake > /dev/null 2>&1; then
    CMAKE_VER="$(cmake --version 2>/dev/null | head -1 | grep -o '[0-9]*\.[0-9]*' | head -1)"
    CMAKE_MAJOR="$(echo "$CMAKE_VER" | cut -d. -f1)"
    CMAKE_MINOR="$(echo "$CMAKE_VER" | cut -d. -f2)"
    if [ "${CMAKE_MAJOR:-0}" -lt 3 ] || { [ "${CMAKE_MAJOR:-0}" -eq 3 ] && [ "${CMAKE_MINOR:-0}" -lt 15 ]; }; then
        log_warn "cmake $CMAKE_VER is too old (need >= $CMAKE_MIN_VERSION) -- building from source"
        NEED_CMAKE=1
    else
        log_ok "cmake $CMAKE_VER found -- OK"
    fi
else
    log_warn "cmake not found -- building from source"
    NEED_CMAKE=1
fi

if [ "$NEED_CMAKE" -eq 1 ]; then
    log_info "Building cmake $CMAKE_INSTALL_VERSION from source..."
    CMAKE_SRC="$TMP_DIR/cmake_src"
    mkdir -p "$CMAKE_SRC"
    CMAKE_TAR="cmake-${CMAKE_INSTALL_VERSION}.tar.gz"
    CMAKE_URL="https://github.com/Kitware/CMake/releases/download/v${CMAKE_INSTALL_VERSION}/${CMAKE_TAR}"
    log_info "Downloading cmake source..."
    wget -q -O "$CMAKE_SRC/$CMAKE_TAR" "$CMAKE_URL" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_warn "wget failed -- trying curl"
        curl -L -o "$CMAKE_SRC/$CMAKE_TAR" "$CMAKE_URL" >> "$BUILD_LOG" 2>&1
    fi
    if [ -f "$CMAKE_SRC/$CMAKE_TAR" ] && [ -s "$CMAKE_SRC/$CMAKE_TAR" ]; then
        cd "$CMAKE_SRC"
        tar -xzf "$CMAKE_TAR" >> "$BUILD_LOG" 2>&1
        cd "cmake-${CMAKE_INSTALL_VERSION}"
        log_info "Bootstrapping cmake (this takes several minutes on ARM)..."
        ./bootstrap --prefix=/usr/local >> "$BUILD_LOG" 2>&1
        make -j"$REC_THREADS" >> "$BUILD_LOG" 2>&1
        make install >> "$BUILD_LOG" 2>&1
        if command -v cmake > /dev/null 2>&1; then
            log_ok "cmake installed: $(cmake --version | head -1)"
        else
            log_err "cmake build failed -- check build.log"
            ERRORS=$((ERRORS + 1))
        fi
        cd "$SCRIPT_DIR"
    else
        log_err "Failed to download cmake source"
        ERRORS=$((ERRORS + 1))
    fi
fi

# =============================================================================
# STEP 4 -- PYTHON PACKAGES
# =============================================================================
log_step "4/9" "Installing Python packages"

PIP_PKGS="flask requests psutil apscheduler"

for pkg in $PIP_PKGS; do
    log_info "pip install: $pkg"
    "$PY_BIN" -m pip install "$pkg" --break-system-packages --quiet >> "$BUILD_LOG" 2>&1 \
        && log_ok "$pkg" \
        || log_warn "$pkg install had warnings"
done

# =============================================================================
# STEP 5 -- BUILD XMRIG FROM SOURCE
# =============================================================================
log_step "5/9" "Building XMRig from source"

XMRIG_DEST="$BIN_DIR/xmrig"
XMRIG_SRC="$TMP_DIR/xmrig_src"
XMRIG_REPO="https://github.com/xmrig/xmrig.git"
XMRIG_BUILD="$XMRIG_SRC/build"

if [ -f "$XMRIG_DEST" ]; then
    log_ok "XMRig already exists at $XMRIG_DEST -- skipping build"
else
    log_info "Cloning XMRig source..."
    git clone --depth=1 "$XMRIG_REPO" "$XMRIG_SRC" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_err "Failed to clone XMRig"
        ERRORS=$((ERRORS + 1))
    else
        mkdir -p "$XMRIG_BUILD"
        cd "$XMRIG_BUILD"

        # CMake flags per architecture
        CMAKE_FLAGS="-DCMAKE_BUILD_TYPE=Release"
        if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
            CMAKE_FLAGS="$CMAKE_FLAGS -DWITH_HWLOC=OFF -DWITH_ASM=OFF -DWITH_AVX=OFF"
            log_info "armv7l build flags: HWLOC=OFF ASM=OFF AVX=OFF"
        elif [ "$ARCH" = "aarch64" ]; then
            CMAKE_FLAGS="$CMAKE_FLAGS -DWITH_HWLOC=OFF"
            log_info "aarch64 build flags: HWLOC=OFF"
        fi

        log_info "Running cmake configure..."
        cmake .. $CMAKE_FLAGS >> "$BUILD_LOG" 2>&1
        if [ $? -ne 0 ]; then
            log_err "cmake configure failed -- check build.log"
            ERRORS=$((ERRORS + 1))
        else
            log_info "Building XMRig (this takes 5-30 min on ARM)..."
            make -j"$REC_THREADS" >> "$BUILD_LOG" 2>&1
            if [ -f "$XMRIG_BUILD/xmrig" ]; then
                cp "$XMRIG_BUILD/xmrig" "$XMRIG_DEST"
                chmod +x "$XMRIG_DEST"
                log_ok "XMRig built and installed: $XMRIG_DEST"
            else
                log_warn "Source build failed -- trying pre-built binary"
                # Fallback: download pre-built
                PREBUILT_VER="6.22.0"
                if [ "$ARCH" = "aarch64" ]; then
                    PREBUILT_TAG="linux-static-aarch64"
                elif [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
                    PREBUILT_TAG="linux-static-armv7"
                else
                    PREBUILT_TAG="linux-static-x64"
                fi
                PREBUILT_FILE="xmrig-${PREBUILT_VER}-${PREBUILT_TAG}.tar.gz"
                PREBUILT_URL="https://github.com/xmrig/xmrig/releases/download/v${PREBUILT_VER}/${PREBUILT_FILE}"
                log_info "Downloading pre-built XMRig: $PREBUILT_FILE"
                wget -q -O "$TMP_DIR/$PREBUILT_FILE" "$PREBUILT_URL" >> "$BUILD_LOG" 2>&1
                if [ $? -ne 0 ]; then
                    curl -L -o "$TMP_DIR/$PREBUILT_FILE" "$PREBUILT_URL" >> "$BUILD_LOG" 2>&1
                fi
                if [ -f "$TMP_DIR/$PREBUILT_FILE" ] && [ -s "$TMP_DIR/$PREBUILT_FILE" ]; then
                    tar -xzf "$TMP_DIR/$PREBUILT_FILE" -C "$TMP_DIR" >> "$BUILD_LOG" 2>&1
                    FOUND_BIN="$(find "$TMP_DIR" -name 'xmrig' -type f | head -1)"
                    if [ -n "$FOUND_BIN" ]; then
                        cp "$FOUND_BIN" "$XMRIG_DEST"
                        chmod +x "$XMRIG_DEST"
                        log_ok "Pre-built XMRig installed: $XMRIG_DEST"
                    else
                        log_err "Pre-built XMRig binary not found in archive"
                        ERRORS=$((ERRORS + 1))
                    fi
                else
                    log_err "Failed to download pre-built XMRig"
                    ERRORS=$((ERRORS + 1))
                fi
            fi
        fi
        cd "$SCRIPT_DIR"
    fi
fi

# =============================================================================
# STEP 6 -- BUILD CPUMINER-MULTI FROM SOURCE
# =============================================================================
log_step "6/9" "Building cpuminer-multi from source"

CPUMINER_DEST="$BIN_DIR/cpuminer-multi"
CPUMINER_SRC="$TMP_DIR/cpuminer_src"
CPUMINER_REPO="https://github.com/tpruvot/cpuminer-multi.git"

if [ -f "$CPUMINER_DEST" ]; then
    log_ok "cpuminer-multi already exists -- skipping build"
else
    log_info "Cloning cpuminer-multi source..."
    git clone --depth=1 "$CPUMINER_REPO" "$CPUMINER_SRC" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_err "Failed to clone cpuminer-multi"
        ERRORS=$((ERRORS + 1))
    else
        cd "$CPUMINER_SRC"
        log_info "Running autogen.sh..."
        ./autogen.sh >> "$BUILD_LOG" 2>&1 \
            || autoreconf --install >> "$BUILD_LOG" 2>&1 \
            || log_warn "autogen had warnings"

        CONF_FLAGS="--with-crypto --with-curl"
        if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
            CONF_FLAGS="$CONF_FLAGS --disable-assembly"
            log_info "armv7l configure flags: --disable-assembly"
        elif [ "$ARCH" = "aarch64" ]; then
            CONF_FLAGS="$CONF_FLAGS --disable-assembly"
            log_info "aarch64 configure flags: --disable-assembly"
        fi

        log_info "Running configure..."
        ./configure $CONF_FLAGS >> "$BUILD_LOG" 2>&1
        if [ $? -ne 0 ]; then
            log_err "cpuminer-multi configure failed -- check build.log"
            ERRORS=$((ERRORS + 1))
        else
            log_info "Building cpuminer-multi..."
            make -j"$REC_THREADS" >> "$BUILD_LOG" 2>&1
            if [ -f "$CPUMINER_SRC/cpuminer" ]; then
                cp "$CPUMINER_SRC/cpuminer" "$CPUMINER_DEST"
                chmod +x "$CPUMINER_DEST"
                log_ok "cpuminer-multi built and installed: $CPUMINER_DEST"
            else
                log_err "cpuminer-multi binary not found after build"
                ERRORS=$((ERRORS + 1))
            fi
        fi
        cd "$SCRIPT_DIR"
    fi
fi

# =============================================================================
# STEP 7 -- INIT DATABASE
# =============================================================================
log_step "7/9" "Initialising SQLite database"

if "$PY_BIN" -c "from miner_config import init_db; init_db(); print('DB OK')" 2>/dev/null; then
    log_ok "SQLite database initialised"
else
    log_warn "DB init skipped -- will init on first Flask start"
fi

# =============================================================================
# STEP 8 -- WRITE START SCRIPTS
# =============================================================================
log_step "8/9" "Writing start scripts"

cat > "$SCRIPT_DIR/start.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "[UMP] Starting Universal Miner Pro dashboard..."
echo "[UMP] Open browser: http://localhost:8080"
python3 universal_miner.py
EOF
chmod +x "$SCRIPT_DIR/start.sh"
log_ok "start.sh written"

cat > "$SCRIPT_DIR/start_screen.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
SESSION="ump_miner"
if command -v screen > /dev/null 2>&1; then
    screen -dmS "$SESSION" python3 universal_miner.py
    echo "[UMP] Started in screen session: $SESSION"
    echo "[UMP] Reattach with: screen -r $SESSION"
    echo "[UMP] Dashboard: http://localhost:8080"
else
    echo "[UMP] screen not installed -- running in foreground"
    python3 universal_miner.py
fi
EOF
chmod +x "$SCRIPT_DIR/start_screen.sh"
log_ok "start_screen.sh written"

# =============================================================================
# STEP 9 -- CLEANUP AND SUMMARY
# =============================================================================
log_step "9/9" "Cleanup and summary"

rm -rf "$TMP_DIR"

# Evaluate binary status into variables first (avoids nested subshell quoting)
if [ -f "$BIN_DIR/xmrig" ]; then
    XMRIG_STATUS="${GREEN}READY${NC}"
else
    XMRIG_STATUS="${RED}MISSING${NC}"
fi

if [ -f "$BIN_DIR/cpuminer-multi" ]; then
    CPUMINER_STATUS="${GREEN}READY${NC}"
else
    CPUMINER_STATUS="${YELLOW}NOT BUILT${NC}"
fi

if [ "$ERRORS" -eq 0 ]; then
    ERROR_STATUS="${GREEN}0${NC}"
else
    ERROR_STATUS="${RED}$ERRORS${NC}"
fi

echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "${BOLD}  INSTALL SUMMARY${NC}"
echo -e "${CYAN}============================================================${NC}"
echo -e "  Platform  : ${GREEN}$PLATFORM${NC}"
echo -e "  Arch      : ${GREEN}$ARCH${NC}"
echo -e "  CPU Cores : ${GREEN}$CPU_COUNT${NC} (recommended threads: ${GREEN}$REC_THREADS${NC})"
echo -e "  XMRig     : $(echo -e "$XMRIG_STATUS")"
echo -e "  cpuminer  : $(echo -e "$CPUMINER_STATUS")"
echo -e "  Errors    : $(echo -e "$ERROR_STATUS")"
echo ""

if [ "$ERRORS" -eq 0 ]; then
    echo -e "  ${GREEN}${BOLD}Installation complete!${NC}"
    echo ""
    echo -e "  ${BOLD}Start dashboard:${NC}"
    echo -e "    ${CYAN}./start.sh${NC}           (foreground)"
    echo -e "    ${CYAN}./start_screen.sh${NC}    (background)"
    echo ""
    echo -e "  ${BOLD}Open browser:${NC}"
    echo -e "    ${CYAN}http://localhost:8080${NC}"
    echo ""
    echo -e "  ${BOLD}First run -- configure pools at:${NC}"
    echo -e "    ${CYAN}http://localhost:8080/setup${NC}"
else
    echo -e "  ${YELLOW}Installation completed with $ERRORS issue(s).${NC}"
    echo -e "  Check: ${CYAN}$BUILD_LOG${NC}"
fi
echo -e "${CYAN}============================================================${NC}"
