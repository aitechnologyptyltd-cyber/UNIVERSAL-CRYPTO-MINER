# wallet_validator.py — Universal Miner Pro ULTIMATE EDITION v4.0
# ─────────────────────────────────────────────────────────────────
# Pre-flight validator for ALL supported mining pools.
# Validates wallet addresses, API keys, worker names, pool URLs,
# and live connectivity — for every profile in miner.db.
#
# NON-BLOCKING: never prevents the app from starting.
# Instead, results are exposed via /api/validate so the dashboard
# can display inline warnings.
#
# Run standalone:   python3 wallet_validator.py
# Import in app:    from wallet_validator import run_validation, ValidationResult

import re
import sys
import json
import hmac
import time
import hashlib
import sqlite3
import os
import threading

try:
    import urllib.request as _urlreq
    import urllib.parse   as _urlparse
    import urllib.error   as _urlerr
except ImportError:
    raise RuntimeError("Python 3 required")

# ══════════════════════════════════════════════════════════════════
#  COLOUR HELPERS
# ══════════════════════════════════════════════════════════════════
def _supports_color():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

_USE_COLOR = _supports_color()

def _c(code, t):
    return ("\033[" + code + "m" + t + "\033[0m") if _USE_COLOR else t

green  = lambda t: _c("92", t)
red    = lambda t: _c("91", t)
yellow = lambda t: _c("93", t)
cyan   = lambda t: _c("96", t)
bold   = lambda t: _c("1",  t)
dim    = lambda t: _c("2",  t)

SEP = dim("─" * 64)

# ══════════════════════════════════════════════════════════════════
#  CONSTANTS
# ══════════════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "miner.db")

# Regex patterns
RE = {
    # Binance / MPH API keys — 64 hex/alnum chars
    "binance_key":   re.compile(r'^[A-Za-z0-9]{64}$'),
    # XMR — starts with 4, 95 chars (standard) or 8x (subaddress)
    "xmr_std":       re.compile(r'^4[0-9A-Za-z]{94}$'),
    "xmr_sub":       re.compile(r'^8[0-9A-Za-z]{94}$'),
    # BTC legacy, SegWit, bech32
    "btc_legacy":    re.compile(r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$'),
    "btc_bech32":    re.compile(r'^bc1[a-zA-HJ-NP-Z0-9]{6,87}$'),
    # DASH P2PKH / P2SH
    "dash":          re.compile(r'^[X7][a-km-zA-HJ-NP-Z1-9]{33}$'),
    # LTC legacy / bech32
    "ltc_legacy":    re.compile(r'^[LM3][a-km-zA-HJ-NP-Z1-9]{25,34}$'),
    "ltc_bech32":    re.compile(r'^ltc1[a-zA-HJ-NP-Z0-9]{6,87}$'),
    # BCH cashaddr / legacy
    "bch_cashaddr":  re.compile(r'^(bitcoincash:)?[qp][a-z0-9]{41}$'),
    "bch_legacy":    re.compile(r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$'),
    # ZEC t-addr / z-addr
    "zec_t":         re.compile(r'^t[13][a-km-zA-HJ-NP-Z1-9]{33}$'),
    "zec_z":         re.compile(r'^zs[0-9a-z]{75}$'),
    # Generic pool stratum URL host:port
    "stratum_url":   re.compile(r'^[a-zA-Z0-9._-]+:\d{2,5}$'),
    # Worker name: alphanumeric + _ + -
    "worker":        re.compile(r'^[a-zA-Z0-9_\-]{1,32}$'),
    # Email
    "email":         re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$'),
    # Unmineable ref code  e.g. abc1-def2
    "unm_ref":       re.compile(r'^[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}$'),
    # Kryptex email-based username  OR wallet address
    "kryptex_user":  re.compile(r'^([^@\s]+@[^@\s]+\.[^@\s]+|[A-Za-z0-9_\-]{6,}|4[0-9A-Za-z]{94})$'),
}

BINANCE_API_BASE = "https://api.binance.com"
POOL_PING_URLS   = {
    "kryptex":      "https://pool.kryptex.com",
    "viabtc":       "https://viabtc.com",
    "unmineable":   "https://unmineable.com",
    "miningpoolhub":"https://miningpoolhub.com",
    "moneroocean":  "https://moneroocean.stream",
    "binance":      "https://pool.binance.com",
}

# ══════════════════════════════════════════════════════════════════
#  DATA CLASS
# ══════════════════════════════════════════════════════════════════
class Issue(object):
    WARN  = "warning"
    ERROR = "error"
    INFO  = "info"

    def __init__(self, level, field, message, profile=None):
        self.level   = level    # "warning" | "error" | "info"
        self.field   = field    # field name / check name
        self.message = message
        self.profile = profile  # profile_name or None

    def to_dict(self):
        return {
            "level":   self.level,
            "field":   self.field,
            "message": self.message,
            "profile": self.profile,
        }

    def __repr__(self):
        return "[{level}] {f}: {m}".format(
            level=self.level.upper(), f=self.field, m=self.message)


class ValidationResult(object):
    def __init__(self):
        self.issues   = []   # list of Issue
        self.ok       = True # False if any ERROR-level issue
        self.checked  = 0    # profiles checked

    def add(self, level, field, message, profile=None):
        self.issues.append(Issue(level, field, message, profile))
        if level == Issue.ERROR:
            self.ok = False

    def errors(self):
        return [i for i in self.issues if i.level == Issue.ERROR]

    def warnings(self):
        return [i for i in self.issues if i.level == Issue.WARN]

    def to_dict(self):
        return {
            "ok":       self.ok,
            "checked":  self.checked,
            "errors":   [i.to_dict() for i in self.errors()],
            "warnings": [i.to_dict() for i in self.warnings()],
            "all":      [i.to_dict() for i in self.issues],
            "summary":  (
                "All checks passed." if self.ok and not self.warnings()
                else ("{e} error(s), {w} warning(s)".format(
                    e=len(self.errors()), w=len(self.warnings())))
            ),
        }


# ══════════════════════════════════════════════════════════════════
#  DB HELPERS
# ══════════════════════════════════════════════════════════════════
def _load_profiles():
    if not os.path.exists(DB_PATH):
        return []
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM profiles ORDER BY updated_at DESC")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows
    except Exception as e:
        return []


# ══════════════════════════════════════════════════════════════════
#  NETWORK HELPERS
# ══════════════════════════════════════════════════════════════════
def _http_get(url, headers=None, timeout=8):
    """Returns (status_code, body_str).  status=0 on network error."""
    req = _urlreq.Request(url)
    req.add_header("User-Agent", "UMP-Validator/4.0")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return r.getcode(), r.read().decode("utf-8", errors="replace")
    except _urlerr.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return e.code, body
    except Exception as e:
        return 0, str(e)


def _binance_signed(endpoint, api_key, api_secret, params=None):
    """Signed Binance REST GET.  Returns (status, dict_or_str)."""
    if params is None:
        params = {}
    params["timestamp"]  = str(int(time.time() * 1000))
    params["recvWindow"] = "5000"
    qs  = _urlparse.urlencode(params)
    sig = hmac.new(api_secret.encode(), qs.encode(), hashlib.sha256).hexdigest()
    url = BINANCE_API_BASE + endpoint + "?" + qs + "&signature=" + sig
    status, body = _http_get(url, headers={"X-MBX-APIKEY": api_key})
    try:
        return status, json.loads(body)
    except Exception:
        return status, body


def _ping_url(url):
    """Returns (ok: bool, msg: str)."""
    status, body = _http_get(url, timeout=7)
    if status > 0 and status < 500:
        return True, "Reachable (HTTP " + str(status) + ")"
    if status == 0:
        return False, "Unreachable — " + str(body)[:80]
    return False, "HTTP " + str(status)


# ══════════════════════════════════════════════════════════════════
#  ADDRESS / KEY VALIDATORS (pure format checks)
# ══════════════════════════════════════════════════════════════════
def _chk(result, ok, level, field, ok_msg, fail_msg, profile):
    if ok:
        result.add(Issue.INFO, field, ok_msg, profile)
    else:
        result.add(level, field, fail_msg, profile)
    return ok


def validate_xmr(addr, result, profile):
    a = (addr or "").strip()
    if not a:
        result.add(Issue.ERROR, "xmr_wallet", "XMR wallet address is empty.", profile)
        return False
    ok = bool(RE["xmr_std"].match(a) or RE["xmr_sub"].match(a))
    return _chk(result, ok, Issue.ERROR, "xmr_wallet",
                "XMR address format OK (" + a[:8] + "…)",
                "Invalid XMR address. Must be 95 chars, starting with '4' or '8'.",
                profile)


def validate_btc(addr, result, profile):
    a = (addr or "").strip()
    if not a:
        return True  # BTC wallet optional for most pools
    ok = bool(RE["btc_legacy"].match(a) or RE["btc_bech32"].match(a))
    return _chk(result, ok, Issue.ERROR, "btc_wallet",
                "BTC address format OK (" + a[:8] + "…)",
                "Invalid BTC address. Expected 1…/3…/bc1… format.",
                profile)


def validate_dash(addr, result, profile):
    a = (addr or "").strip().split(".")[0]  # strip .worker suffix
    if not a:
        result.add(Issue.ERROR, "dash_wallet",
                   "DASH wallet/account is empty. Use BINANCE_ACCOUNT.WORKER format.", profile)
        return False
    ok = bool(RE["dash"].match(a))
    # Binance account (email prefix or numeric) is also acceptable
    if not ok and (RE["email"].match(a) or a.isdigit() or len(a) > 5):
        ok = True  # looks like a Binance account name
    return _chk(result, ok, Issue.ERROR, "dash_wallet",
                "DASH wallet/account OK (" + a[:8] + "…)",
                "Invalid DASH address. Expected 34-char address starting with X or 7, "
                "or a Binance account name.",
                profile)


def validate_ltc(addr, result, profile):
    a = (addr or "").strip()
    if not a:
        return True
    ok = bool(RE["ltc_legacy"].match(a) or RE["ltc_bech32"].match(a))
    return _chk(result, ok, Issue.ERROR, "ltc_wallet",
                "LTC address format OK (" + a[:8] + "…)",
                "Invalid LTC address. Expected L…/M…/3…/ltc1… format.",
                profile)


def validate_worker(name, result, profile, field="worker"):
    n = (name or "").strip()
    if not n:
        result.add(Issue.WARN, field, "Worker name is empty — using 'worker1' as default.", profile)
        return False
    ok = bool(RE["worker"].match(n))
    return _chk(result, ok, Issue.WARN, field,
                "Worker name OK: " + n,
                "Worker name '" + n + "' contains invalid characters. "
                "Use only letters, numbers, _ or - (max 32 chars).",
                profile)


def validate_pool_url(url, result, profile):
    u = (url or "").strip()
    if not u:
        result.add(Issue.ERROR, "pool_url", "Pool URL is empty.", profile)
        return False
    # strip stratum+tcp:// prefix for format check
    bare = u
    for prefix in ("stratum+tcp://", "stratum+ssl://", "stratum://"):
        if bare.startswith(prefix):
            bare = bare[len(prefix):]
            break
    ok = bool(RE["stratum_url"].match(bare))
    return _chk(result, ok, Issue.ERROR, "pool_url",
                "Pool URL format OK: " + u,
                "Pool URL '" + u + "' looks invalid. Expected host:port format.",
                profile)


def validate_email(addr, result, profile, field, required=False):
    a = (addr or "").strip()
    if not a:
        if required:
            result.add(Issue.ERROR, field, "Email address is required but empty.", profile)
            return False
        return True
    ok = bool(RE["email"].match(a))
    return _chk(result, ok, Issue.WARN, field,
                "Email format OK: " + a,
                "Email '" + a + "' looks invalid.",
                profile)


def validate_binance_key_format(key, secret, result, profile):
    k = (key or "").strip()
    s = (secret or "").strip()
    if not k:
        result.add(Issue.ERROR, "binance_api_key", "Binance API key is empty.", profile)
        return False
    if not s:
        result.add(Issue.ERROR, "binance_api_secret", "Binance API secret is empty.", profile)
        return False
    ok_k = bool(RE["binance_key"].match(k))
    ok_s = bool(RE["binance_key"].match(s))
    if not ok_k:
        result.add(Issue.ERROR, "binance_api_key",
                   "Binance API key must be exactly 64 alphanumeric characters.", profile)
        return False
    if not ok_s:
        result.add(Issue.ERROR, "binance_api_secret",
                   "Binance API secret must be exactly 64 alphanumeric characters.", profile)
        return False
    result.add(Issue.INFO, "binance_api_key", "API key/secret format OK.", profile)
    return True


# ══════════════════════════════════════════════════════════════════
#  LIVE CHECKS
# ══════════════════════════════════════════════════════════════════
def live_check_binance(api_key, api_secret, result, profile):
    """Hit /api/v3/account — verifies key works and checks permissions."""
    status, data = _binance_signed("/api/v3/account",
                                   api_key.strip(), api_secret.strip())
    if status == 200 and isinstance(data, dict):
        result.add(Issue.INFO, "binance_live_auth",
                   "Binance authentication successful. "
                   "Account type: " + str(data.get("accountType", "?")), profile)
        if data.get("canWithdraw"):
            result.add(Issue.WARN, "binance_api_key",
                       "SECURITY: API key has WITHDRAW permission. "
                       "For mining, regenerate with READ-ONLY permission only.", profile)
        return True
    if isinstance(data, dict):
        code = data.get("code", "")
        msg  = data.get("msg",  "Unknown error")
        if code == -2014:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Binance rejected API key format: " + msg, profile)
        elif code == -1022:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Binance signature invalid — check your API secret: " + msg, profile)
        elif code == -1021:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Timestamp mismatch — check your system clock: " + msg, profile)
        else:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Binance auth error " + str(code) + ": " + msg, profile)
    else:
        result.add(Issue.ERROR, "binance_live_auth",
                   "Unexpected Binance response (HTTP " + str(status) + "): " + str(data)[:80],
                   profile)
    return False


def live_check_mph(api_key, username, result, profile):
    """Validate MPH API key via public API endpoint."""
    if not api_key or not username:
        result.add(Issue.WARN, "mph_api_key",
                   "MPH API key or username is empty — cannot validate live.", profile)
        return False
    url = ("https://miningpoolhub.com/index.php?page=api&action=getuserbalance"
           "&api_key=" + _urlparse.quote(api_key.strip()) +
           "&id=" + _urlparse.quote(username.strip()))
    status, body = _http_get(url, timeout=8)
    if status == 200:
        try:
            d = json.loads(body)
            if "getuserbalance" in d:
                result.add(Issue.INFO, "mph_live_auth",
                           "MPH authentication successful.", profile)
                return True
        except Exception:
            pass
    if status == 0:
        result.add(Issue.WARN, "mph_live_auth",
                   "MPH unreachable — cannot validate. Check network.", profile)
    else:
        result.add(Issue.ERROR, "mph_live_auth",
                   "MPH API key invalid or username mismatch (HTTP " + str(status) + ").", profile)
    return False


def live_check_kryptex(email, worker, result, profile):
    """Kryptex doesn't expose a public account API — do a format check + ping."""
    ok = True
    if not email or not email.strip():
        result.add(Issue.ERROR, "kryptex_email",
                   "Kryptex email/account is empty.", profile)
        ok = False
    else:
        e = email.strip()
        if not (RE["email"].match(e) or len(e) >= 6):
            result.add(Issue.ERROR, "kryptex_email",
                       "Kryptex account '" + e + "' looks invalid.", profile)
            ok = False
        else:
            result.add(Issue.INFO, "kryptex_email",
                       "Kryptex account format OK: " + e, profile)
    validate_worker(worker, result, profile, "kryptex_worker")
    return ok


def live_check_viabtc(username, worker, result, profile):
    ok = True
    if not username or not username.strip():
        result.add(Issue.ERROR, "viabtc_username",
                   "ViaBTC username is empty.", profile)
        ok = False
    else:
        validate_worker(username.strip(), result, profile, "viabtc_username")
    validate_worker(worker, result, profile, "viabtc_worker")
    return ok


def live_check_unmineable(coin, wallet, ref, result, profile):
    ok = True
    if not coin or not coin.strip():
        result.add(Issue.ERROR, "unmineable_coin",
                   "Unmineable payout coin is not set.", profile)
        ok = False
    else:
        result.add(Issue.INFO, "unmineable_coin",
                   "Payout coin: " + coin.strip().upper(), profile)
    if not wallet or not wallet.strip():
        result.add(Issue.ERROR, "unmineable_wallet",
                   "Unmineable payout wallet address is empty.", profile)
        ok = False
    else:
        # Validate wallet format based on payout coin
        c = coin.strip().upper() if coin else ""
        w = wallet.strip()
        addr_ok = False
        if c in ("BTC", "BCH", "BSV"):
            addr_ok = bool(RE["btc_legacy"].match(w) or RE["btc_bech32"].match(w))
        elif c == "LTC":
            addr_ok = bool(RE["ltc_legacy"].match(w) or RE["ltc_bech32"].match(w))
        elif c == "XMR":
            addr_ok = bool(RE["xmr_std"].match(w) or RE["xmr_sub"].match(w))
        else:
            # Generic: just check it's non-trivial
            addr_ok = len(w) >= 20
        if addr_ok:
            result.add(Issue.INFO, "unmineable_wallet",
                       c + " wallet format OK (" + w[:8] + "…)", profile)
        else:
            result.add(Issue.ERROR, "unmineable_wallet",
                       "Wallet address for " + c + " looks invalid: " + w[:16] + "…", profile)
            ok = False
    # Referral code — optional but validate format if present
    if ref and ref.strip():
        r = ref.strip()
        if not RE["unm_ref"].match(r):
            result.add(Issue.WARN, "unmineable_ref",
                       "Referral code '" + r + "' format unexpected (expected xxxx-xxxx).", profile)
    return ok


def live_check_moneroocean(wallet, worker, email, result, profile):
    ok = validate_xmr(wallet, result, profile)
    validate_worker(worker, result, profile, "mo_worker")
    validate_email(email, result, profile, "mo_email", required=False)
    # MoneroOcean provides a public stats endpoint
    if wallet and len(wallet.strip()) == 95:
        url = "https://moneroocean.stream/api/miner/" + wallet.strip()[:20] + "/stats"
        status, body = _http_get(url, timeout=7)
        if status == 200:
            result.add(Issue.INFO, "moneroocean_live",
                       "MoneroOcean pool reachable and wallet accepted.", profile)
        elif status == 0:
            result.add(Issue.WARN, "moneroocean_live",
                       "MoneroOcean unreachable — check network.", profile)
        # 404 just means new/unknown wallet — not an error
    return ok


# ══════════════════════════════════════════════════════════════════
#  PER-POOL DISPATCHER
# ══════════════════════════════════════════════════════════════════
def _validate_profile(p, result):
    pname = p.get("profile_name", "unknown")
    pool  = (p.get("selected_pool") or "").strip().lower()
    coin  = (p.get("selected_coin") or "XMR").strip().upper()
    algo  = (p.get("active_algo")   or "RANDOMX").strip().upper()

    # Always validate common fields
    validate_pool_url(p.get("pool_url"), result, pname)
    validate_worker(p.get("username"), result, pname, "username")

    # XMR wallet — required for RandomX and X11 (unMineable)
    if algo in ("RANDOMX", "X11") or pool in ("kryptex", "moneroocean", "unmineable"):
        xmr = p.get("xmr_wallet") or p.get("mo_wallet") or ""
        if xmr:
            validate_xmr(xmr, result, pname)

    # BTC wallet — validate if provided
    if p.get("btc_wallet"):
        validate_btc(p.get("btc_wallet"), result, pname)

    # ── Pool-specific ──────────────────────────────────────────
    if pool == "binance" or algo == "X11_DIRECT" or coin == "DASH":
        # DASH miner_user is ACCOUNT.WORKER — validate both parts
        miner_user = (p.get("miner_user") or "").strip()
        if "." in miner_user:
            account, worker = miner_user.split(".", 1)
            validate_dash(account, result, pname)
            validate_worker(worker, result, pname, "binance_worker")
        else:
            validate_dash(miner_user, result, pname)
        # Binance API keys
        api_key    = (p.get("binance_api_key")    or "").strip()
        api_secret = (p.get("binance_api_secret") or "").strip()
        if api_key or api_secret:
            fmt_ok = validate_binance_key_format(api_key, api_secret, result, pname)
            if fmt_ok:
                live_check_binance(api_key, api_secret, result, pname)
        else:
            result.add(Issue.WARN, "binance_api_key",
                       "No Binance API key stored — live authentication skipped.", pname)
        validate_email(p.get("binance_email"), result, pname, "binance_email")

    elif pool == "kryptex":
        live_check_kryptex(
            p.get("kryptex_email") or p.get("username"),
            p.get("kryptex_worker") or p.get("username"),
            result, pname)

    elif pool == "viabtc":
        live_check_viabtc(
            p.get("viabtc_username") or p.get("username"),
            p.get("viabtc_worker")   or p.get("username"),
            result, pname)

    elif pool == "unmineable":
        live_check_unmineable(
            p.get("unmineable_coin"),
            p.get("unmineable_wallet") or p.get("xmr_wallet"),
            p.get("unmineable_ref"),
            result, pname)

    elif pool == "moneroocean":
        live_check_moneroocean(
            p.get("mo_wallet") or p.get("xmr_wallet"),
            p.get("mo_worker") or p.get("username"),
            p.get("mo_email"),
            result, pname)

    elif pool == "miningpoolhub":
        mph_user   = p.get("mph_username") or p.get("username") or ""
        mph_apikey = p.get("mph_api_key") or ""
        validate_worker(mph_user, result, pname, "mph_username")
        if mph_apikey:
            live_check_mph(mph_apikey, mph_user, result, pname)
        else:
            result.add(Issue.WARN, "mph_api_key",
                       "MPH API key not configured — live validation skipped.", pname)

    # RandomX / Kryptex XMR path — validate wallet in miner_user
    if algo == "RANDOMX" and pool not in ("binance",):
        miner_user = (p.get("miner_user") or "").strip()
        if miner_user:
            wallet_part = miner_user.split(".")[0]
            if RE["xmr_std"].match(wallet_part) or RE["xmr_sub"].match(wallet_part):
                result.add(Issue.INFO, "miner_user",
                           "XMR wallet in --user string looks valid.", pname)
            elif RE["email"].match(wallet_part):
                result.add(Issue.INFO, "miner_user",
                           "Kryptex email in --user string: " + wallet_part, pname)
            else:
                result.add(Issue.WARN, "miner_user",
                           "Could not recognise wallet format in --user string: '"
                           + wallet_part[:20] + "…'", pname)


# ══════════════════════════════════════════════════════════════════
#  NETWORK CONNECTIVITY SWEEP
# ══════════════════════════════════════════════════════════════════
def _check_pool_connectivity(pools_needed, result):
    for pool_id in pools_needed:
        url = POOL_PING_URLS.get(pool_id)
        if not url:
            continue
        ok, msg = _ping_url(url)
        if ok:
            result.add(Issue.INFO, "network_" + pool_id,
                       pool_id.capitalize() + " pool reachable: " + msg)
        else:
            result.add(Issue.ERROR, "network_" + pool_id,
                       pool_id.capitalize() + " pool UNREACHABLE — " + msg +
                       ". Mining will fail until connectivity is restored.")


# ══════════════════════════════════════════════════════════════════
#  MAIN RUNNER
# ══════════════════════════════════════════════════════════════════
def run_validation(profiles=None, verbose=True):
    """
    Run all pre-flight checks.
    Returns a ValidationResult — NEVER raises an exception.
    The miner is NOT blocked; callers decide what to do with the result.
    """
    result = ValidationResult()

    try:
        if profiles is None:
            profiles = _load_profiles()

        if not profiles:
            result.add(Issue.WARN, "profiles",
                       "No profiles found in miner.db. "
                       "Add a profile via the dashboard before mining.")
            return result

        result.checked = len(profiles)

        # Gather which pools are actually used
        pools_needed = set()
        for p in profiles:
            pid = (p.get("selected_pool") or "").strip().lower()
            if pid in POOL_PING_URLS:
                pools_needed.add(pid)

        # 1 — Connectivity
        _check_pool_connectivity(pools_needed, result)

        # 2 — Per-profile
        for p in profiles:
            try:
                _validate_profile(p, result)
            except Exception as e:
                result.add(Issue.WARN, "validator_error",
                           "Unexpected error validating profile '"
                           + str(p.get("profile_name", "?")) + "': " + str(e),
                           p.get("profile_name"))

    except Exception as e:
        result.add(Issue.WARN, "validator_crash",
                   "Validator encountered an unexpected error: " + str(e))

    return result


# ══════════════════════════════════════════════════════════════════
#  BACKGROUND RUNNER (called by Flask app on startup)
# ══════════════════════════════════════════════════════════════════
_cached_result   = None
_cached_lock     = threading.Lock()
_cached_at       = 0
CACHE_TTL        = 300  # re-validate every 5 minutes

def get_cached_result(force=False):
    """Thread-safe cached validation result for the Flask app."""
    global _cached_result, _cached_at
    with _cached_lock:
        if force or _cached_result is None or (time.time() - _cached_at) > CACHE_TTL:
            _cached_result = run_validation(verbose=False)
            _cached_at     = time.time()
        return _cached_result


def start_background_validation():
    """Kick off first validation in a background thread so Flask boot isn't delayed."""
    def _run():
        get_cached_result(force=True)
    t = threading.Thread(target=_run, daemon=True)
    t.start()


# ══════════════════════════════════════════════════════════════════
#  CLI PRETTY-PRINT
# ══════════════════════════════════════════════════════════════════
def _cli_print(result):
    print()
    print(bold(cyan("╔══════════════════════════════════════════════════════════════╗")))
    print(bold(cyan("║   Universal Miner Pro — Pre-Flight Validator v4.0            ║")))
    print(bold(cyan("║   Pools: Kryptex • ViaBTC • Unmineable • MPH • MO • Binance  ║")))
    print(bold(cyan("╚══════════════════════════════════════════════════════════════╝")))
    print()

    by_profile = {}
    network    = []
    for issue in result.issues:
        if issue.field.startswith("network_") or issue.profile is None:
            network.append(issue)
        else:
            by_profile.setdefault(issue.profile, []).append(issue)

    # Network section
    print(bold("[ NETWORK CONNECTIVITY ]"))
    print(SEP)
    for issue in network:
        if issue.level == Issue.INFO:
            print("  " + green("✔") + "  " + issue.message)
        elif issue.level == Issue.WARN:
            print("  " + yellow("⚠") + "  " + issue.message)
        else:
            print("  " + red("✘") + "  " + issue.message)
    print()

    # Per-profile sections
    for pname, issues in by_profile.items():
        errors   = [i for i in issues if i.level == Issue.ERROR]
        warnings = [i for i in issues if i.level == Issue.WARN]
        infos    = [i for i in issues if i.level == Issue.INFO]
        status   = (green("PASS") if not errors
                    else red("FAIL"))
        print(bold("[ PROFILE: " + pname + " ]") + "  " + status)
        print(SEP)
        for i in errors:
            print("  " + red("✘  ERROR   ") + bold(i.field) + ": " + i.message)
        for i in warnings:
            print("  " + yellow("⚠  WARN    ") + bold(i.field) + ": " + i.message)
        for i in infos:
            print("  " + green("✔  OK      ") + dim(i.field + ": " + i.message))
        print()

    # Summary
    print(bold("[ SUMMARY ]"))
    print(SEP)
    errs  = result.errors()
    warns = result.warnings()
    if result.ok and not warns:
        print(green("  ✔  ALL CHECKS PASSED — miner is clear to start.\n"))
    else:
        if errs:
            print(red("  ✘  " + str(len(errs)) + " error(s) found:\n"))
            for e in errs:
                print(red("     • [" + (e.profile or "global") + "] " + e.message))
            print()
        if warns:
            print(yellow("  ⚠  " + str(len(warns)) + " warning(s):\n"))
            for w in warns:
                print(yellow("     • [" + (w.profile or "global") + "] " + w.message))
            print()
        if errs:
            print(red(bold(
                "  ► Fix the errors above, then re-run:\n"
                "      python3 wallet_validator.py\n"
                "    The miner app has NOT been blocked — but payouts may fail\n"
                "    until configuration is corrected.\n"
            )))
    print(dim("  Profiles checked: " + str(result.checked)))
    print()


if __name__ == "__main__":
    res = run_validation()
    _cli_print(res)
    sys.exit(0 if res.ok else 1)
