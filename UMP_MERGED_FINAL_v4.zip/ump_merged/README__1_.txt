UMP ULTIMATE v4.2 -- Binaries Directory
========================================
Place compiled binaries here after running the installer.

xmrig            -- RandomX CPU miner (built from source by installer)
cpuminer-multi   -- X11 / GhostRider / multi-algo CPU miner (built from source)
lolminer         -- GPU miner: Ethash, Etchash, ALPH, KAS (x86_64 prebuilt)
t-rex            -- GPU miner NVIDIA: KawPow, Octopus (x86_64 prebuilt)
teamredminer     -- GPU miner AMD: Ethash, KawPow (x86_64 prebuilt)

Run installer to populate this directory:
  bash install_ump_universal.sh
