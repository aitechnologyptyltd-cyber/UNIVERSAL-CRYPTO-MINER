UMP ULTIMATE v4.2 -- Logs Directory
====================================
ump.log              -- Main application log (Flask / Gunicorn stdout)
gunicorn_access.log  -- HTTP access log (Gunicorn production mode)
gunicorn_error.log   -- Gunicorn error log
profit_switch.log    -- Profit switcher coin switch events
PROFILE_xmrig.log    -- XMRig output per profile
PROFILE_cpuminer.log -- cpuminer-multi output per profile
