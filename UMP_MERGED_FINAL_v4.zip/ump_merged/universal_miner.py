# universal_miner.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Flask app — port 8080 — Multi-Pool | Multi-Coin | Multi-Arch | Dual-Algo Swarm
# armv7l / aarch64 / x86_64 / macOS / Windows compatible
#
# ── FULLY WIRED — all modules registered ──────────────────────────────────────
#   miner_config       : DB init, profile CRUD, command builder, coin/pool/algo config
#   miner_manager      : master miner subprocess (XMRig / cpuminer-multi)
#   miner_swarm        : 40-node SwarmEngine blueprint (/api/swarm/*)
#   wallet_validator   : pre-flight config validator (/api/validate)
#   wallet_api         : HD wallet blueprint (/wallet/*)
#   wallet_db          : wallet SQLite keystore init
#   ump_hardware_detect: hardware capability detection (/api/hardware)
#   ump_miner_registry : extended coin/pool/binary registry (/api/registry/*)
#   ump_profit_switcher: profit-switching daemon + blueprint (/api/profit/*)

import os
import json
import time
import threading
import sqlite3
from datetime import datetime
from flask import (
    Flask, render_template, request, redirect,
    url_for, jsonify, Response, session, flash
)

# ── Core modules ───────────────────────────────────────────────────────────────
from miner_config import (
    COINS, CPU_COINS, PROFILE_FIELDS, POOLS, ALGOS, DEFAULT_ALGO,
    DB_PATH, VERSION, TOTAL_NODES,
    init_db, save_profile, load_profile, list_profiles, delete_profile,
    get_coins_json, get_pools_json, get_algos_json, get_system_info,
    suggest_pool_url, calc_daily_usd, format_hashrate, set_algo,
    ARCH, PLATFORM
)
from miner_manager import (
    start_miner, stop_miner, get_stats, is_running,
    auto_resume, get_log_tail, get_hashrate_history, switch_algo
)
from miner_swarm import register_with_app, get_engine

# ── Validator ─────────────────────────────────────────────────────────────────
from wallet_validator import get_cached_result, start_background_validation

# ── Wallet ────────────────────────────────────────────────────────────────────
from wallet_api import register_wallet
from wallet_db import init_wallet_db

# ── Hardware detect ───────────────────────────────────────────────────────────
try:
    from ump_hardware_detect import build_capability_profile
    _HAS_HW_DETECT = True
except ImportError:
    _HAS_HW_DETECT = False

# ── Miner registry ────────────────────────────────────────────────────────────
try:
    import ump_miner_registry as _registry
    _HAS_REGISTRY = True
except ImportError:
    _HAS_REGISTRY = False

# ── Profit switcher ───────────────────────────────────────────────────────────
try:
    from ump_profit_switcher import get_switcher, create_profit_blueprint
    _HAS_PROFIT = True
except ImportError:
    _HAS_PROFIT = False

# ══════════════════════════════════════════════════════════════════════════════
# APP INIT
# ══════════════════════════════════════════════════════════════════════════════
app = Flask(__name__)
app.secret_key = os.urandom(24)

# ── DB ─────────────────────────────────────────────────────────────────────
init_db()           # miner tables  (profiles, sessions, miner_state, etc.)
init_wallet_db()    # wallet tables (wallet_keystore, wallet_coins, etc.)

SYS_INFO = get_system_info()

# ── Background validator ───────────────────────────────────────────────────
start_background_validation()

# ── Swarm blueprint  /api/swarm/* ──────────────────────────────────────────
register_with_app(app)

# ── Wallet blueprint  /wallet/* ───────────────────────────────────────────
register_wallet(app)

# ── Hardware capability (detect once at startup, non-blocking) ────────────
_hw_profile    = {}
_hw_profile_lock = threading.Lock()

def _detect_hardware():
    global _hw_profile
    if not _HAS_HW_DETECT:
        return
    try:
        profile = build_capability_profile()
        with _hw_profile_lock:
            _hw_profile = profile
        print("[UMP] Hardware: " + profile.get("mining_capability", "unknown")
              + " | arch: " + profile.get("arch", "?")
              + " | CPU score: " + str(profile.get("cpu", {}).get("mining_score", "?")))
    except Exception as e:
        print("[UMP] Hardware detect error: " + str(e))

threading.Thread(target=_detect_hardware, daemon=True).start()

# ── Profit switcher  /api/profit/* ────────────────────────────────────────
_profit_switcher = None

def _init_profit_switcher():
    global _profit_switcher
    if not _HAS_PROFIT:
        print("[UMP] ump_profit_switcher not available — skipping")
        return

    # Wait for hardware detection to finish (max 15 s)
    for _ in range(30):
        with _hw_profile_lock:
            cap = _hw_profile.get("mining_capability")
        if cap:
            break
        time.sleep(0.5)

    with _hw_profile_lock:
        capability = _hw_profile.get("mining_capability", "CPU_ONLY")

    def _hashrate_provider():
        """Return current master miner hashrate in H/s."""
        s    = get_stats()
        hr   = s.get("hashrate", 0.0)
        unit = s.get("hashrate_unit", "H/s")
        mult = {"H/s": 1, "KH/s": 1e3, "MH/s": 1e6, "GH/s": 1e9}.get(unit, 1)
        return hr * mult

    def _coin_provider():
        """Return current coin being mined."""
        return get_stats().get("coin", "XMR")

    def _switch_callback(coin_sym, algo_key, pool_id):
        """
        Called by the profit switcher when a better coin is found.
        Switches the active profile's coin and algo, then restarts the miner.
        """
        profile = _get_active_profile()
        if not profile:
            return
        # Persist the new coin and algo into the profile
        profile["selected_coin"] = coin_sym
        profile["active_algo"]   = algo_key
        try:
            save_profile(profile)
        except Exception as e:
            print("[profit_switcher] save_profile error: " + str(e))
            return
        # Stop and restart with new settings
        if is_running():
            stop_miner()
            time.sleep(1)
        ok, err = start_miner(
            profile["profile_name"],
            threads=profile.get("threads", 2),
            algo_key=algo_key,
        )
        if ok:
            print("[profit_switcher] Switched to " + coin_sym + " (" + algo_key + ")")
        else:
            print("[profit_switcher] Restart failed after switch: " + str(err))

    try:
        _profit_switcher = get_switcher(
            capability          = capability,
            hashrate_provider   = _hashrate_provider,
            current_coin_provider = _coin_provider,
            switch_callback     = _switch_callback,
            db_path             = DB_PATH,
        )
        # Register the Flask blueprint
        bp = create_profit_blueprint(_profit_switcher)
        if bp:
            app.register_blueprint(bp)
        print("[UMP] Profit switcher started — capability: " + capability)
    except Exception as e:
        print("[UMP] Profit switcher init error: " + str(e))

threading.Thread(target=_init_profit_switcher, daemon=True).start()

# ── Startup log ───────────────────────────────────────────────────────────
print("[UMP] " + VERSION + " starting on " + SYS_INFO["platform"] + "/" + SYS_INFO["arch"])
print("[UMP] Swarm nodes: " + str(TOTAL_NODES) + " | Algos: " + ", ".join(ALGOS.keys()))
print("[UMP] Wallet blueprint registered at /wallet")
print("[UMP] Validator running in background")

# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _has_profiles():
    try:
        return len(list_profiles()) > 0
    except Exception:
        return False

def _get_active_profile():
    pname = session.get("profile_name")
    if pname:
        p = load_profile(pname)
        if p:
            return p
    profiles = list_profiles()
    if profiles:
        p = load_profile(profiles[0]["profile_name"])
        if p:
            session["profile_name"] = p["profile_name"]
            return p
    return None

def _fmt_uptime(seconds):
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return str(h) + "h " + str(m) + "m " + str(s) + "s"

def _get_sections():
    sections = {}
    for f in PROFILE_FIELDS:
        sec = f["section"]
        if sec not in sections:
            sections[sec] = []
        sections[sec].append(f)
    return sections

# ══════════════════════════════════════════════════════════════════════════════
# SSE STREAM
# ══════════════════════════════════════════════════════════════════════════════
def _sse_stream():
    while True:
        try:
            stats  = get_stats()
            swarm  = get_engine().get_snapshot()
            stats["uptime_str"]      = _fmt_uptime(stats.get("uptime_sec", 0))
            stats["is_alive"]        = is_running()
            stats["arch"]            = ARCH
            stats["platform"]        = PLATFORM
            stats["swarm_active"]    = swarm.get("swarm_active", False)
            stats["swarm_nodes"]     = swarm.get("active_nodes", 0)
            stats["swarm_hr"]        = swarm.get("total_hashrate", 0.0)
            stats["swarm_hr_unit"]   = swarm.get("hr_unit", "H/s")
            stats["swarm_earnings"]  = swarm.get("earnings_usd", 0.0)
            stats["xmr_price"]       = swarm.get("xmr_price", 0.0)
            stats["cpu_pct"]         = swarm.get("cpu_pct", stats.get("cpu_pct", 0.0))
            stats["temperature"]     = swarm.get("temperature", stats.get("temp"))
            # Inject profit switcher top coin if available
            if _profit_switcher:
                try:
                    ranking = _profit_switcher.get_ranking()
                    stats["best_coin"]     = ranking[0]["coin"]     if ranking else ""
                    stats["best_usd_day"]  = ranking[0]["usd_daily"] if ranking else 0.0
                except Exception:
                    pass
            yield "data: " + json.dumps(stats) + "\n\n"
        except Exception as e:
            yield "data: " + json.dumps({"error": str(e)}) + "\n\n"
        time.sleep(2)

# ══════════════════════════════════════════════════════════════════════════════
# MAIN ROUTES
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/")
def index():
    if not _has_profiles():
        return redirect(url_for("setup"))
    profile = _get_active_profile()
    if not profile:
        return redirect(url_for("setup"))
    stats     = get_stats()
    profiles  = list_profiles()
    pool_id   = profile.get("selected_pool", "kryptex")
    pool_info = POOLS.get(pool_id, {})
    algo_key  = str(profile.get("active_algo", DEFAULT_ALGO)).upper()
    return render_template(
        "dashboard.html",
        profile     = profile,
        stats       = stats,
        profiles    = profiles,
        uptime      = _fmt_uptime(stats.get("uptime_sec", 0)),
        sys_info    = SYS_INFO,
        pool_info   = pool_info,
        algos       = ALGOS,
        algos_json  = json.dumps(get_algos_json()),
        active_algo = algo_key,
        total_nodes = TOTAL_NODES,
        version     = VERSION,
    )

@app.route("/setup", methods=["GET"])
def setup():
    profiles     = list_profiles()
    sections     = _get_sections()
    coins_json   = json.dumps(get_coins_json())
    pools_json   = json.dumps(get_pools_json())
    edit_profile = None
    edit_name    = request.args.get("edit", "")
    if edit_name:
        edit_profile = load_profile(edit_name)
    return render_template(
        "setup.html",
        sections     = sections,
        profiles     = profiles,
        coins_json   = coins_json,
        pools_json   = pools_json,
        cpu_coins    = CPU_COINS,
        sys_info     = SYS_INFO,
        edit_profile = edit_profile,
        version      = VERSION,
        pool_ids     = list(POOLS.keys()),
        algos        = ALGOS,
    )

@app.route("/setup", methods=["POST"])
def setup_post():
    data  = {}
    pname = request.form.get("profile_name", "").strip()
    if not pname:
        uname = request.form.get("username", "user").strip()
        pname = uname + "_" + str(int(time.time()))
    data["profile_name"] = pname

    for f in PROFILE_FIELDS:
        data[f["key"]] = request.form.get(f["key"], "").strip()

    try:
        data["threads"] = int(request.form.get("threads", SYS_INFO.get("cpu_count", 2)))
    except (ValueError, TypeError):
        data["threads"] = 2

    algo_raw = request.form.get("active_algo", DEFAULT_ALGO).strip().upper()
    data["active_algo"] = algo_raw if algo_raw in ALGOS else DEFAULT_ALGO

    missing = [f["label"] for f in PROFILE_FIELDS
               if f.get("required") and not data.get(f["key"])]
    if missing:
        flash("Required fields missing: " + ", ".join(missing), "error")
        return redirect(url_for("setup"))

    try:
        save_profile(data)
        session["profile_name"] = pname
        flash("Profile saved: " + pname, "success")
    except Exception as e:
        flash("Save error: " + str(e), "error")
        return redirect(url_for("setup"))
    return redirect(url_for("index"))

@app.route("/profiles")
def profiles_page():
    return render_template(
        "profiles.html",
        profiles = list_profiles(),
        sys_info = SYS_INFO,
        version  = VERSION,
    )

@app.route("/profiles/switch", methods=["POST"])
def profile_switch():
    pname = request.form.get("profile_name", "").strip()
    if not pname or not load_profile(pname):
        return jsonify({"ok": False, "error": "Not found"}), 404
    if is_running():
        stop_miner()
    session["profile_name"] = pname
    return jsonify({"ok": True, "profile_name": pname})

@app.route("/profiles/delete", methods=["POST"])
def profile_delete():
    pname = request.form.get("profile_name", "").strip()
    try:
        delete_profile(pname)
        if session.get("profile_name") == pname:
            session.pop("profile_name", None)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/profiles/export/<profile_name>")
def profile_export(profile_name):
    p = load_profile(profile_name)
    if not p:
        return jsonify({"error": "Not found"}), 404
    safe = {k: v for k, v in p.items()
            if k not in ("binance_api_key", "binance_api_secret",
                         "mph_api_key", "xmr_viewkey")}
    return jsonify(safe)

# ══════════════════════════════════════════════════════════════════════════════
# MINING CONTROLS
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/mine/start", methods=["POST"])
def mine_start():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    try:
        threads = int(request.form.get("threads", profile.get("threads", 2)))
    except (ValueError, TypeError):
        threads = 2
    algo_key = request.form.get("algo", profile.get("active_algo", DEFAULT_ALGO)).upper()
    ok, err  = start_miner(profile["profile_name"], threads=threads, algo_key=algo_key)
    if ok:
        return jsonify({
            "ok":      True,
            "coin":    profile.get("selected_coin", "XMR"),
            "pool":    profile.get("selected_pool", "kryptex"),
            "algo":    algo_key,
            "threads": threads,
        })
    return jsonify({"ok": False, "error": err}), 500

@app.route("/mine/stop", methods=["POST"])
def mine_stop():
    ok, err = stop_miner()
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": err}), 400

@app.route("/mine/switch_algo", methods=["POST"])
def mine_switch_algo():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400

    algo_key = request.form.get("algo", "").strip().upper()
    if not algo_key:
        data = request.get_json(silent=True) or {}
        algo_key = str(data.get("algo", "")).strip().upper()
    if algo_key not in ALGOS:
        return jsonify({"ok": False, "error": "Unknown algo: " + algo_key}), 400

    try:
        threads = int(request.form.get("threads", profile.get("threads", 2)))
    except (ValueError, TypeError):
        threads = 2

    ok, err = switch_algo(profile["profile_name"], algo_key, threads=threads)
    if ok:
        algo_info = ALGOS[algo_key]
        return jsonify({
            "ok":         True,
            "algo":       algo_key,
            "algo_label": algo_info["label"],
            "pool_name":  algo_info["pool_name"],
            "hr_unit":    algo_info["hr_unit"],
            "color":      algo_info["color"],
        })
    return jsonify({"ok": False, "error": err}), 500

# ══════════════════════════════════════════════════════════════════════════════
# SWARM CONTROLS  (blueprint at /api/swarm/* handles most swarm routes)
# These top-level routes keep the dashboard UI working)
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/swarm/start", methods=["POST"])
def swarm_start_route():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    try:
        threads = int(request.form.get("threads", 1))
    except (ValueError, TypeError):
        threads = 1
    algo_key = request.form.get("algo", profile.get("active_algo", DEFAULT_ALGO)).upper()
    ok, err  = get_engine().start_swarm(profile["profile_name"], threads=threads, algo_key=algo_key)
    if ok:
        return jsonify({"ok": True, "total_nodes": TOTAL_NODES, "algo": algo_key})
    return jsonify({"ok": False, "error": err}), 500

@app.route("/swarm/stop", methods=["POST"])
def swarm_stop_route():
    ok, err = get_engine().stop_swarm()
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": err}), 400

# ══════════════════════════════════════════════════════════════════════════════
# SSE + CORE API
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/stream")
def stream():
    return Response(
        _sse_stream(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

@app.route("/api/stats")
def api_stats():
    stats = get_stats()
    stats["uptime_str"] = _fmt_uptime(stats.get("uptime_sec", 0))
    stats["is_alive"]   = is_running()
    return jsonify(stats)

@app.route("/api/log")
def api_log():
    lines    = int(request.args.get("lines", 80))
    algo_key = request.args.get("algo", None)
    return jsonify(get_log_tail(lines=lines, algo_key=algo_key))

@app.route("/api/hashrate_history")
def api_hashrate_history():
    profile = _get_active_profile()
    if not profile:
        return jsonify([])
    limit = int(request.args.get("limit", 120))
    return jsonify(get_hashrate_history(profile["profile_name"], limit=limit))

@app.route("/api/profiles")
def api_profiles():
    return jsonify(list_profiles())

@app.route("/api/coins")
def api_coins():
    return jsonify(get_coins_json())

@app.route("/api/pools")
def api_pools():
    return jsonify(get_pools_json())

@app.route("/api/algos")
def api_algos():
    return jsonify(get_algos_json())

@app.route("/api/suggest_pool_url")
def api_suggest_pool_url():
    pool_id  = request.args.get("pool", "kryptex")
    coin_sym = request.args.get("coin", "XMR")
    url = suggest_pool_url(pool_id, coin_sym)
    return jsonify({"url": url, "pool": pool_id, "coin": coin_sym})

@app.route("/api/hashrate_calc")
def api_hashrate_calc():
    try:
        hr_raw = float(request.args.get("hr", 0))
        unit   = request.args.get("unit", "H/s")
        coin   = request.args.get("coin", "XMR").upper()
        price  = float(request.args.get("price", 0))
        mult   = {"H/s": 1, "KH/s": 1e3, "MH/s": 1e6, "GH/s": 1e9}.get(unit, 1)
        hr_hs  = hr_raw * mult
        daily  = calc_daily_usd(coin, hr_hs, coin_price_usd=price if price > 0 else None)
        return jsonify({
            "hashrate_hs":  hr_hs,
            "hashrate_fmt": format_hashrate(hr_hs),
            "daily_usd":    round(daily, 4),
            "monthly_usd":  round(daily * 30, 2),
            "yearly_usd":   round(daily * 365, 2),
            "coin":         coin,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route("/api/sysinfo")
def api_sysinfo():
    return jsonify(get_system_info())

@app.route("/api/sessions")
def api_sessions():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT s.id, s.started_at, s.stopped_at, s.coin, s.pool, s.algo,
                   s.shares_acc, s.shares_rej, s.avg_hr, p.profile_name
            FROM sessions s
            LEFT JOIN profiles p ON s.profile_id=p.id
            ORDER BY s.started_at DESC LIMIT 30
        """)
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Validator ────────────────────────────────────────────────────────────────
@app.route("/api/validate")
def api_validate():
    force = request.args.get("refresh", "0") in ("1", "true", "yes")
    try:
        res = get_cached_result(force=force)
        return jsonify(res.to_dict())
    except Exception as e:
        return jsonify({
            "ok": False, "errors": [], "warnings": [],
            "all": [], "checked": 0,
            "summary": "Validator error: " + str(e),
        })

# ══════════════════════════════════════════════════════════════════════════════
# HARDWARE DETECT API  /api/hardware
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/api/hardware")
def api_hardware():
    """Return full hardware capability profile detected at startup."""
    with _hw_profile_lock:
        profile = dict(_hw_profile)
    if not profile:
        return jsonify({
            "available": False,
            "reason": "ump_hardware_detect not installed or still running",
        })
    profile["available"] = True
    return jsonify(profile)

@app.route("/api/hardware/capability")
def api_hardware_capability():
    """Return just the mining capability tier — used by profit switcher UI."""
    with _hw_profile_lock:
        cap  = _hw_profile.get("mining_capability", "CPU_ONLY")
        arch = _hw_profile.get("arch", ARCH)
    return jsonify({"mining_capability": cap, "arch": arch})

@app.route("/api/hardware/refresh", methods=["POST"])
def api_hardware_refresh():
    """Re-run hardware detection in the background."""
    threading.Thread(target=_detect_hardware, daemon=True).start()
    return jsonify({"ok": True, "message": "Hardware detection triggered"})

# ══════════════════════════════════════════════════════════════════════════════
# MINER REGISTRY API  /api/registry/*
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/api/registry/coins")
def api_registry_coins():
    """Extended coin list from ump_miner_registry."""
    if not _HAS_REGISTRY:
        return jsonify({"error": "ump_miner_registry not available"}), 503
    try:
        return jsonify(_registry.get_coins_json())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/registry/pools")
def api_registry_pools():
    """Extended pool list from ump_miner_registry."""
    if not _HAS_REGISTRY:
        return jsonify({"error": "ump_miner_registry not available"}), 503
    try:
        return jsonify(_registry.get_pools_json())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/registry/algos")
def api_registry_algos():
    """Extended algo list from ump_miner_registry."""
    if not _HAS_REGISTRY:
        return jsonify({"error": "ump_miner_registry not available"}), 503
    try:
        return jsonify(_registry.get_algos_json())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/registry/cpu_coins")
def api_registry_cpu_coins():
    """All CPU-minable coins from registry."""
    if not _HAS_REGISTRY:
        return jsonify({"error": "ump_miner_registry not available"}), 503
    try:
        return jsonify(_registry.get_cpu_coins())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/registry/gpu_coins")
def api_registry_gpu_coins():
    """All GPU-minable coins from registry."""
    if not _HAS_REGISTRY:
        return jsonify({"error": "ump_miner_registry not available"}), 503
    try:
        return jsonify(_registry.get_gpu_coins())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/registry/coins_for_capability")
def api_registry_coins_for_capability():
    """
    Return coins eligible for the detected (or specified) hardware capability.
    ?capability=CPU_ONLY | GPU_ONLY | CPU_GPU  (default: auto-detected)
    """
    if not _HAS_REGISTRY:
        return jsonify({"error": "ump_miner_registry not available"}), 503
    cap = request.args.get("capability", "").strip()
    if not cap:
        with _hw_profile_lock:
            cap = _hw_profile.get("mining_capability", "CPU_ONLY")
    try:
        return jsonify(_registry.get_coins_for_capability(cap))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ══════════════════════════════════════════════════════════════════════════════
# WALLET MINING CREDIT BRIDGE
# Lets the miner session logger notify the wallet of a new payout.
# Calls /wallet/api/record_mining internally — avoids an HTTP round-trip.
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/api/record_mining_credit", methods=["POST"])
def api_record_mining_credit():
    """
    Internal bridge: record a mining payout in the wallet ledger.
    Called by the miner or any external script after a pool payout is detected.

    POST JSON or form:
      wallet_name   : str  (wallet name in the keystore, default "default")
      coin          : str  (e.g. "XMR")
      amount        : float
      amount_usd    : float  (optional)
      session_id    : int    (optional, links to sessions table)
      profile_name  : str    (optional)
      pool          : str    (optional)
      algo          : str    (optional)
    """
    try:
        from wallet_db import record_mining_credit, wallet_exists
    except ImportError:
        return jsonify({"error": "wallet_db not available"}), 503

    data         = request.get_json(silent=True) or request.form
    wallet_name  = (data.get("wallet_name")  or "default").strip()
    coin         = (data.get("coin")         or "").upper().strip()
    profile_name = (data.get("profile_name") or "").strip()
    pool         = (data.get("pool")         or "").strip()
    algo         = (data.get("algo")         or "").strip()

    try:
        amount     = float(data.get("amount")     or 0)
        amount_usd = float(data.get("amount_usd") or 0)
        session_id = int(data.get("session_id")   or 0) or None
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid numeric values"}), 400

    if not coin or amount <= 0:
        return jsonify({"error": "coin and positive amount are required"}), 400

    if not wallet_exists(wallet_name):
        return jsonify({"success": True, "skipped": "wallet '" + wallet_name + "' not configured"})

    try:
        record_mining_credit(
            wallet_name, coin, amount, amount_usd,
            session_id, profile_name, pool, algo,
        )
        return jsonify({"success": True, "wallet": wallet_name, "coin": coin, "amount": amount})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ══════════════════════════════════════════════════════════════════════════════
# HEALTH + FULL STATUS
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/health")
def health():
    swarm = get_engine().get_snapshot()
    with _hw_profile_lock:
        cap = _hw_profile.get("mining_capability", "unknown")
    return jsonify({
        "status":            "ok",
        "version":           VERSION,
        "arch":              ARCH,
        "platform":          PLATFORM,
        "mining":            is_running(),
        "swarm_active":      swarm.get("swarm_active", False),
        "swarm_nodes":       swarm.get("active_nodes", 0),
        "profiles":          len(list_profiles()),
        "algos":             list(ALGOS.keys()),
        "hw_capability":     cap,
        "profit_switcher":   _profit_switcher is not None,
        "wallet_module":     True,
        "registry_module":   _HAS_REGISTRY,
        "hw_detect_module":  _HAS_HW_DETECT,
        "timestamp":         datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
    })

@app.route("/api/status/full")
def api_status_full():
    """
    Single endpoint that returns everything the dashboard could need —
    useful for external monitoring or a mobile app.
    """
    stats = get_stats()
    swarm = get_engine().get_snapshot()
    with _hw_profile_lock:
        hw = dict(_hw_profile)

    profit_status = {}
    if _profit_switcher:
        try:
            profit_status = _profit_switcher.get_status()
        except Exception:
            pass

    try:
        validate_result = get_cached_result().to_dict()
    except Exception:
        validate_result = {}

    return jsonify({
        "miner":   stats,
        "swarm":   swarm,
        "hardware": hw,
        "profit":  profit_status,
        "validate": validate_result,
        "version": VERSION,
        "ts":      datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
    })

# ══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT  (dev mode)
# Production: gunicorn --config gunicorn_config.py wsgi:app
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("[UMP] Dashboard → http://0.0.0.0:8080")
    print("[UMP] Wallet    → http://0.0.0.0:8080/wallet")
    t = threading.Thread(target=auto_resume, daemon=True)
    t.start()
    app.run(
        host="0.0.0.0", port=8080,
        debug=False, threaded=True, use_reloader=False,
    )
