"""
ump_universal_installer.py
Universal Miner Pro ULTIMATE - Universal Installer Engine
Reads hardware capability profile and installs all required
miners, binaries, dependencies, and build tools.

Supports: Userland Ubuntu, Termux, Linux x86_64/aarch64/armv7l
Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import subprocess
import shutil
import platform
import json
import time
import tarfile
import zipfile

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------
BIN_DIR          = "bin"
BUILD_DIR        = "/tmp/ump_build"
LOG_FILE         = "install.log"

XMRIG_REPO       = "https://github.com/xmrig/xmrig.git"
CPUMINER_REPO    = "https://github.com/tpruvot/cpuminer-multi.git"
LOLMINER_URL_BASE= "https://github.com/Lolliedieb/lolMiner-releases/releases/latest/download/"
TEAMRED_URL_BASE = "https://github.com/todxx/teamredminer/releases/latest/download/"
TREX_URL_BASE    = "https://github.com/trexminer/T-Rex/releases/latest/download/"

# Known stable release versions (fallback if latest lookup fails)
LOLMINER_VERSION = "1.88"
TREX_VERSION     = "0.26.8"
TEAMRED_VERSION  = "0.10.21"


# ---------------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------------
_log_fh = None

def _log(msg):
    """Write message to stdout and log file."""
    print("[installer] " + msg)
    global _log_fh
    if _log_fh is None:
        try:
            _log_fh = open(LOG_FILE, "a")
        except Exception:
            pass
    if _log_fh:
        try:
            _log_fh.write(msg + "\n")
            _log_fh.flush()
        except Exception:
            pass


def _run(cmd, check=True, timeout=600, env=None):
    """Run a shell command. Returns (returncode, stdout, stderr)."""
    _log("CMD: " + " ".join(cmd))
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            env=env,
        )
        out = result.stdout.decode("utf-8", errors="ignore").strip()
        err = result.stderr.decode("utf-8", errors="ignore").strip()
        if result.returncode != 0:
            _log("WARN: exit " + str(result.returncode) + " -- " + err[:200])
        return result.returncode, out, err
    except subprocess.TimeoutExpired:
        _log("ERROR: Command timed out: " + " ".join(cmd))
        return 1, "", "timeout"
    except Exception as e:
        _log("ERROR: " + str(e))
        return 1, "", str(e)


def _cmd_exists(cmd):
    return shutil.which(cmd) is not None


# ---------------------------------------------------------------------------
# PACKAGE MANAGERS
# ---------------------------------------------------------------------------

def install_apt_packages(packages, platform_name):
    """Install packages via apt-get (Linux/Userland Ubuntu)."""
    if not packages:
        return
    _log("--- Installing APT packages ---")

    # Update first
    _run(["apt-get", "update", "-y"], check=False)

    for pkg in packages:
        _log("APT install: " + pkg)
        rc, out, err = _run(
            ["apt-get", "install", "-y", "--no-install-recommends", pkg],
            check=False
        )
        if rc != 0:
            _log("SKIP " + pkg + " (not available or already installed)")


def install_pkg_packages(packages):
    """Install packages via Termux pkg."""
    if not packages:
        return
    _log("--- Installing Termux pkg packages ---")
    _run(["pkg", "update", "-y"], check=False)
    for pkg in packages:
        _log("PKG install: " + pkg)
        _run(["pkg", "install", "-y", pkg], check=False)


def install_pip_packages(packages):
    """Install Python packages via pip."""
    if not packages:
        return
    _log("--- Installing pip packages ---")
    pip_cmd = "pip3" if _cmd_exists("pip3") else "pip"
    for pkg in packages:
        _log("PIP install: " + pkg)
        _run(
            [pip_cmd, "install", pkg, "--break-system-packages", "--quiet"],
            check=False
        )


# ---------------------------------------------------------------------------
# BINARY DIRECTORY
# ---------------------------------------------------------------------------

def ensure_bin_dir():
    """Create bin/ directory if it does not exist."""
    if not os.path.isdir(BIN_DIR):
        os.makedirs(BIN_DIR)
        _log("Created " + BIN_DIR + "/ directory")


def ensure_build_dir():
    if not os.path.isdir(BUILD_DIR):
        os.makedirs(BUILD_DIR)


def _chmod_x(path):
    """Set executable permission."""
    try:
        os.chmod(path, 0o755)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# XMRIG BUILD FROM SOURCE
# ---------------------------------------------------------------------------

def build_xmrig(arch, platform_name):
    """Build XMRig from source. Returns True on success."""
    out_path = os.path.join(BIN_DIR, "xmrig")
    if os.path.isfile(out_path):
        _log("XMRig already exists at " + out_path + " -- skipping build")
        return True

    _log("=== Building XMRig from source ===")
    ensure_build_dir()
    src_dir = os.path.join(BUILD_DIR, "xmrig")

    # Clone
    if not os.path.isdir(src_dir):
        rc, _, _ = _run(["git", "clone", "--depth=1", XMRIG_REPO, src_dir])
        if rc != 0:
            _log("ERROR: Failed to clone XMRig")
            return False

    build_dir = os.path.join(src_dir, "build")
    if not os.path.isdir(build_dir):
        os.makedirs(build_dir)

    # CMake configure
    cmake_args = [
        "cmake", "..",
        "-DCMAKE_BUILD_TYPE=Release",
    ]

    # armv7l specific flags
    if arch == "armv7l":
        cmake_args += [
            "-DWITH_HWLOC=OFF",
            "-DWITH_ASM=OFF",
        ]
    elif arch == "aarch64":
        cmake_args += [
            "-DWITH_HWLOC=OFF",
        ]

    rc, _, _ = _run(cmake_args, check=False)
    # cmake must run from build dir
    old_dir = os.getcwd()
    os.chdir(build_dir)
    rc, _, _ = _run(cmake_args, check=False)
    if rc != 0:
        _log("ERROR: CMake configure failed")
        os.chdir(old_dir)
        return False

    # Make
    cores = str(max(1, (os.cpu_count() or 2) - 1))
    rc, _, _ = _run(["make", "-j" + cores], check=False)
    os.chdir(old_dir)

    if rc != 0:
        _log("ERROR: XMRig build failed. Check " + LOG_FILE)
        return False

    # Copy binary
    built_bin = os.path.join(build_dir, "xmrig")
    if os.path.isfile(built_bin):
        shutil.copy2(built_bin, out_path)
        _chmod_x(out_path)
        _log("XMRig built and installed to " + out_path)
        return True

    _log("ERROR: XMRig binary not found after build")
    return False


# ---------------------------------------------------------------------------
# CPUMINER-MULTI BUILD FROM SOURCE
# ---------------------------------------------------------------------------

def build_cpuminer(arch, platform_name):
    """Build cpuminer-multi from source. Returns True on success."""
    out_path = os.path.join(BIN_DIR, "cpuminer-multi")
    if os.path.isfile(out_path):
        _log("cpuminer-multi already exists -- skipping build")
        return True

    _log("=== Building cpuminer-multi from source ===")
    ensure_build_dir()
    src_dir = os.path.join(BUILD_DIR, "cpuminer-multi")

    if not os.path.isdir(src_dir):
        rc, _, _ = _run(["git", "clone", "--depth=1", CPUMINER_REPO, src_dir])
        if rc != 0:
            _log("ERROR: Failed to clone cpuminer-multi")
            return False

    old_dir = os.getcwd()
    os.chdir(src_dir)

    # autogen
    rc, _, _ = _run(["./autogen.sh"], check=False)
    if rc != 0:
        _log("WARN: autogen.sh failed -- trying autoreconf")
        _run(["autoreconf", "--install"], check=False)

    # configure flags
    configure_cmd = ["./configure", "--with-crypto", "--with-curl"]
    if arch == "armv7l":
        configure_cmd += ["--disable-assembly"]
    elif arch == "aarch64":
        configure_cmd += ["--disable-assembly"]

    rc, _, _ = _run(configure_cmd, check=False)
    if rc != 0:
        _log("ERROR: cpuminer-multi configure failed")
        os.chdir(old_dir)
        return False

    cores = str(max(1, (os.cpu_count() or 2) - 1))
    rc, _, _ = _run(["make", "-j" + cores], check=False)
    os.chdir(old_dir)

    if rc != 0:
        _log("ERROR: cpuminer-multi build failed")
        return False

    built_bin = os.path.join(src_dir, "cpuminer")
    if os.path.isfile(built_bin):
        shutil.copy2(built_bin, out_path)
        _chmod_x(out_path)
        _log("cpuminer-multi installed to " + out_path)
        return True

    _log("ERROR: cpuminer-multi binary not found after build")
    return False


# ---------------------------------------------------------------------------
# GPU MINERS — PRE-BUILT BINARIES
# ---------------------------------------------------------------------------

def _download_file(url, dest):
    """Download a file via curl or wget."""
    _log("Downloading " + url)
    if _cmd_exists("curl"):
        rc, _, _ = _run(["curl", "-L", "-o", dest, url, "--silent", "--show-error"])
    elif _cmd_exists("wget"):
        rc, _, _ = _run(["wget", "-O", dest, url, "-q"])
    else:
        _log("ERROR: Neither curl nor wget found")
        return False
    return rc == 0


def _extract_archive(archive_path, dest_dir):
    """Extract tar.gz or zip archive."""
    if archive_path.endswith(".zip"):
        try:
            with zipfile.ZipFile(archive_path, "r") as zh:
                zh.extractall(dest_dir)
            return True
        except Exception as e:
            _log("ERROR extracting zip: " + str(e))
            return False
    elif archive_path.endswith(".tar.gz") or archive_path.endswith(".tgz"):
        try:
            with tarfile.open(archive_path, "r:gz") as th:
                th.extractall(dest_dir)
            return True
        except Exception as e:
            _log("ERROR extracting tar.gz: " + str(e))
            return False
    return False


def install_lolminer(arch, has_nvidia, has_amd):
    """Download and install lolMiner for NVIDIA and/or AMD."""
    out_path = os.path.join(BIN_DIR, "lolminer")
    if os.path.isfile(out_path):
        _log("lolMiner already installed -- skipping")
        return True

    if arch not in ("x86_64",):
        _log("lolMiner: no pre-built binary for arch " + arch)
        return False

    _log("=== Installing lolMiner ===")
    ensure_build_dir()

    filename    = "lolMiner_v" + LOLMINER_VERSION + "_Lin64.tar.gz"
    url         = LOLMINER_URL_BASE + filename
    archive     = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "lolminer_extracted")

    if not _download_file(url, archive):
        _log("ERROR: Failed to download lolMiner")
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    # Find the binary inside extracted dir
    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if "lolminer" in fname.lower() and not fname.endswith(".sh"):
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("lolMiner installed to " + out_path)
                return True

    _log("ERROR: lolMiner binary not found in archive")
    return False


def install_trex(arch):
    """Download and install T-Rex miner (NVIDIA)."""
    out_path = os.path.join(BIN_DIR, "t-rex")
    if os.path.isfile(out_path):
        _log("T-Rex already installed -- skipping")
        return True

    if arch not in ("x86_64",):
        _log("T-Rex: no pre-built binary for arch " + arch)
        return False

    _log("=== Installing T-Rex miner ===")
    ensure_build_dir()

    filename    = "t-rex-" + TREX_VERSION + "-linux.tar.gz"
    url         = TREX_URL_BASE + filename
    archive     = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "trex_extracted")

    if not _download_file(url, archive):
        _log("ERROR: Failed to download T-Rex")
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if fname == "t-rex" or fname == "t-rex.exe":
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("T-Rex installed to " + out_path)
                return True

    _log("ERROR: T-Rex binary not found in archive")
    return False


def install_teamredminer(arch):
    """Download and install TeamRedMiner (AMD)."""
    out_path = os.path.join(BIN_DIR, "teamredminer")
    if os.path.isfile(out_path):
        _log("TeamRedMiner already installed -- skipping")
        return True

    if arch not in ("x86_64",):
        _log("TeamRedMiner: no pre-built binary for arch " + arch)
        return False

    _log("=== Installing TeamRedMiner ===")
    ensure_build_dir()

    filename    = "teamredminer-v" + TEAMRED_VERSION + "-linux.tar.gz"
    url         = TEAMRED_URL_BASE + filename
    archive     = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "trm_extracted")

    if not _download_file(url, archive):
        _log("ERROR: Failed to download TeamRedMiner")
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if "teamredminer" in fname.lower() and not fname.endswith(".sh"):
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("TeamRedMiner installed to " + out_path)
                return True

    _log("ERROR: TeamRedMiner binary not found in archive")
    return False


# ---------------------------------------------------------------------------
# OPENCL RUNTIME
# ---------------------------------------------------------------------------

def install_opencl_runtime(platform_name, has_nvidia, has_amd):
    """Install OpenCL runtime for GPU mining."""
    if platform_name in ("termux",):
        _log("OpenCL runtime: Termux does not support GPU mining -- skipping")
        return

    _log("=== Installing OpenCL runtime ===")
    opencl_pkgs = ["ocl-icd-opencl-dev", "opencl-headers", "clinfo"]

    if has_amd:
        opencl_pkgs.append("mesa-opencl-icd")
    if has_nvidia:
        # CUDA toolkit includes OpenCL
        opencl_pkgs.append("nvidia-cuda-toolkit")

    install_apt_packages(opencl_pkgs, platform_name)


# ---------------------------------------------------------------------------
# XMRIG PREBUILT FALLBACK (ARM)
# ---------------------------------------------------------------------------

def download_xmrig_prebuilt(arch):
    """Download pre-built XMRig for ARM if source build fails."""
    out_path = os.path.join(BIN_DIR, "xmrig")
    if os.path.isfile(out_path):
        return True

    _log("=== Downloading pre-built XMRig for " + arch + " ===")

    arch_map = {
        "aarch64": "linux-static-aarch64",
        "armv7l":  "linux-static-armv7",
        "x86_64":  "linux-static-x64",
    }
    arch_tag = arch_map.get(arch)
    if not arch_tag:
        _log("No pre-built binary known for arch: " + arch)
        return False

    # XMRig GitHub releases
    version  = "6.22.0"
    filename = "xmrig-" + version + "-" + arch_tag + ".tar.gz"
    url      = "https://github.com/xmrig/xmrig/releases/download/v" + version + "/" + filename
    archive  = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "xmrig_prebuilt")

    if not _download_file(url, archive):
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if fname == "xmrig":
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("XMRig pre-built installed to " + out_path)
                return True

    return False


# ---------------------------------------------------------------------------
# MASTER INSTALL FUNCTION
# ---------------------------------------------------------------------------

def run_full_install(capability_profile):
    """
    Master installer. Reads capability profile and installs everything needed.
    Returns dict of install results per component.
    """
    plat       = capability_profile.get("platform", "linux")
    arch       = capability_profile.get("arch", "x86_64")
    capability = capability_profile.get("mining_capability", "CPU_ONLY")
    gpu_info   = capability_profile.get("gpu", {})
    pkgs       = capability_profile.get("install_packages", {})
    recommended= capability_profile.get("recommended_miners", [])

    has_nvidia = len(gpu_info.get("nvidia", [])) > 0
    has_amd    = len(gpu_info.get("amd", [])) > 0

    results = {}

    _log("============================================")
    _log("  UMP UNIVERSAL INSTALLER")
    _log("  Platform : " + plat)
    _log("  Arch     : " + arch)
    _log("  Capability: " + capability)
    _log("============================================")

    ensure_bin_dir()

    # Step 1: System package dependencies
    if plat == "termux":
        _log("--- STEP 1: Termux pkg dependencies ---")
        install_pkg_packages(pkgs.get("pkg", []))
    else:
        _log("--- STEP 1: APT dependencies ---")
        install_apt_packages(pkgs.get("apt", []), plat)

    # Step 2: Python packages
    _log("--- STEP 2: Python pip packages ---")
    install_pip_packages(pkgs.get("pip", []))

    # Step 3: CPU miners
    if capability in ("CPU_ONLY", "CPU_GPU"):
        _log("--- STEP 3: CPU miner binaries ---")

        # Try source build, fallback to prebuilt
        xmrig_ok = build_xmrig(arch, plat)
        if not xmrig_ok:
            _log("Source build failed -- trying pre-built XMRig")
            xmrig_ok = download_xmrig_prebuilt(arch)
        results["xmrig"] = xmrig_ok

        cpuminer_ok = build_cpuminer(arch, plat)
        results["cpuminer-multi"] = cpuminer_ok

    # Step 4: GPU miners
    if capability in ("GPU_ONLY", "CPU_GPU"):
        _log("--- STEP 4: GPU miner binaries ---")

        install_opencl_runtime(plat, has_nvidia, has_amd)

        if has_nvidia or has_amd:
            lol_ok = install_lolminer(arch, has_nvidia, has_amd)
            results["lolminer"] = lol_ok

        if has_nvidia:
            trex_ok = install_trex(arch)
            results["t-rex"] = trex_ok

        if has_amd:
            trm_ok = install_teamredminer(arch)
            results["teamredminer"] = trm_ok

    # Step 5: Report
    _log("============================================")
    _log("  INSTALL COMPLETE")
    for component, ok in results.items():
        status = "OK" if ok else "FAILED/SKIPPED"
        _log("  " + component + " : " + status)

    # Verify bin/ contents
    _log("--- bin/ directory contents ---")
    if os.path.isdir(BIN_DIR):
        for fname in sorted(os.listdir(BIN_DIR)):
            fpath = os.path.join(BIN_DIR, fname)
            size  = os.path.getsize(fpath)
            _log("  " + fname + " (" + str(size // 1024) + " KB)")
    else:
        _log("  bin/ directory empty or missing")

    _log("============================================")
    return results


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import ump_hardware_detect as hw
    profile = hw.build_capability_profile()
    hw.print_capability_report(profile)
    hw.save_profile(profile)
    results = run_full_install(profile)
    print("Install results:", json.dumps(results, indent=2))
