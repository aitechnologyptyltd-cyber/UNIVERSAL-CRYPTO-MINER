#!/bin/bash
# =============================================================================
#  restart.sh -- UMP ULTIMATE v4.2
#  Stops then starts the production Gunicorn server.
# =============================================================================
cd "$(dirname "$0")"
echo "[UMP] Restarting UMP ULTIMATE..."
bash stop.sh
sleep 1
bash start_gunicorn.sh
