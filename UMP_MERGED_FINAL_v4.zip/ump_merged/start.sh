#!/bin/bash
# =============================================================================
#  start.sh -- UMP ULTIMATE v4.2
#  Runs the Flask dev server in the BACKGROUND via nohup.
#  Use start_gunicorn.sh for production (recommended).
# =============================================================================
cd "$(dirname "$0")"

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/ump.log"
PID_FILE="ump.pid"

mkdir -p "$LOG_DIR"

# Kill any existing instance
if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[UMP] Stopping previous instance (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null
        sleep 1
    fi
    rm -f "$PID_FILE"
fi

echo "[UMP] Starting Universal Miner Pro ULTIMATE v4.2..."
echo "[UMP] Dashboard: http://localhost:8080"
echo "[UMP] Log file : $LOG_FILE"
echo "[UMP] PID file : $PID_FILE"

nohup python3 universal_miner.py >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

sleep 1
if kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    echo "[UMP] Running -- PID $(cat "$PID_FILE")"
    echo "[UMP] Open:  http://localhost:8080"
    echo "[UMP] Stop:  bash stop.sh"
    echo "[UMP] Logs:  tail -f $LOG_FILE"
else
    echo "[UMP] ERROR: Process failed to start. Check $LOG_FILE"
fi
