# wallet_api.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Flask Blueprint — Internal HD Wallet API
# All routes for balances, addresses, transfers, broadcast, Binance integration
# Python 3.6+ compatible — no f-strings — no walrus

from __future__ import print_function
import os
import json
import time
import threading

from flask import Blueprint, request, jsonify, session, render_template

from wallet_core import (
    create_wallet, restore_wallet, validate_mnemonic,
    fetch_all_balances, fetch_prices,
    build_and_sign_btc_tx, broadcast_btc_tx,
    broadcast_ltc_tx, broadcast_dash_tx,
    fetch_binance_deposit_address, binance_withdraw,
    SUPPORTED_COINS,
)
from wallet_db import (
    init_wallet_db, save_wallet, load_wallet_addresses,
    load_privkey, load_mnemonic, list_wallets, wallet_exists, delete_wallet,
    cache_balance, get_cached_balances, cache_prices, get_cached_prices,
    record_transaction, update_tx_status, get_transactions,
    record_mining_credit, get_mining_credits, get_total_mined,
    save_address, get_address_book, delete_address,
    get_portfolio_summary,
)

wallet_bp = Blueprint("wallet", __name__, url_prefix="/wallet")

# ── Session key for active wallet ─────────────────────────────
WALLET_SESSION_KEY = "active_wallet"

def _active_wallet():
    return session.get(WALLET_SESSION_KEY, "default")

def _require_wallet(name=None):
    wname = name or _active_wallet()
    if not wallet_exists(wname):
        return None, jsonify({"error": "No wallet found. Create or restore a wallet first."}), 404
    return wname, None, None

def _get_binance_keys():
    """Pull Binance API key/secret from the active mining profile."""
    try:
        import sqlite3, os
        db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "miner.db")
        conn = sqlite3.connect(db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT binance_api_key, binance_api_secret
            FROM profiles
            WHERE binance_api_key != '' AND binance_api_secret != ''
            ORDER BY updated_at DESC LIMIT 1
        """)
        row = c.fetchone()
        conn.close()
        if row:
            return row["binance_api_key"], row["binance_api_secret"]
    except Exception:
        pass
    return None, None

# ── Background refresh thread ─────────────────────────────────
_refresh_lock   = threading.Lock()
_refresh_active = False

def _refresh_balances_background(wallet_name):
    """Fetch live balances and prices in a background thread, store in cache."""
    global _refresh_active
    with _refresh_lock:
        if _refresh_active:
            return
        _refresh_active = True
    try:
        addrs  = load_wallet_addresses(wallet_name)
        w_data = {"wallets": {}}
        for a in addrs:
            w_data["wallets"][a["coin"]] = {"address": a["address"]}

        balances = fetch_all_balances(w_data)
        prices   = fetch_prices(list(balances.keys()))
        cache_prices(prices)

        for coin, info in balances.items():
            price = prices.get(coin, 0.0)
            cache_balance(wallet_name, coin, info.get("balance"), price)
    except Exception as e:
        print("[wallet] Balance refresh error: " + str(e))
    finally:
        with _refresh_lock:
            _refresh_active = False

def trigger_refresh(wallet_name):
    t = threading.Thread(target=_refresh_balances_background,
                         args=(wallet_name,), daemon=True)
    t.start()

# ══════════════════════════════════════════════════════════════
#  WALLET MANAGEMENT ROUTES
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/", methods=["GET"])
def wallet_dashboard():
    """Serve the wallet UI page."""
    wallets = list_wallets()
    active  = _active_wallet()
    return render_template("wallet_ui.html",
                           wallets=wallets,
                           active_wallet=active)

@wallet_bp.route("/api/create", methods=["POST"])
def api_create_wallet():
    """
    POST /wallet/api/create
    Body: { wallet_name, password, confirm_password }
    Creates a new HD wallet, returns public data (NO private keys in response).
    """
    data     = request.get_json(silent=True) or request.form
    wname    = (data.get("wallet_name") or "default").strip()
    password = (data.get("password") or "").strip()
    confirm  = (data.get("confirm_password") or "").strip()

    if not wname:
        return jsonify({"error": "wallet_name is required"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400
    if password != confirm:
        return jsonify({"error": "Passwords do not match"}), 400
    if wallet_exists(wname):
        return jsonify({"error": "Wallet '" + wname + "' already exists"}), 409

    try:
        wallet_data = create_wallet()
        save_wallet(wname, wallet_data, password)
        session[WALLET_SESSION_KEY] = wname

        # Return mnemonic ONCE — user must write it down
        coins_public = {}
        for coin, w in wallet_data["wallets"].items():
            coins_public[coin] = {
                "address": w.get("address", ""),
                "address_legacy": w.get("address_legacy", ""),
                "network": w.get("network", ""),
                "path":    w.get("path", ""),
            }

        return jsonify({
            "success":      True,
            "wallet_name":  wname,
            "mnemonic":     wallet_data["mnemonic"],
            "mnemonic_warning": (
                "WRITE THIS DOWN NOW. This is the ONLY time it is shown. "
                "Anyone with this phrase controls all funds."
            ),
            "coins":        coins_public,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@wallet_bp.route("/api/restore", methods=["POST"])
def api_restore_wallet():
    """
    POST /wallet/api/restore
    Body: { wallet_name, mnemonic, password, confirm_password, passphrase? }
    Restore an existing HD wallet from mnemonic.
    """
    data       = request.get_json(silent=True) or request.form
    wname      = (data.get("wallet_name") or "restored").strip()
    mnemonic   = (data.get("mnemonic") or "").strip().lower()
    password   = (data.get("password") or "").strip()
    confirm    = (data.get("confirm_password") or "").strip()
    passphrase = (data.get("passphrase") or "").strip()

    if not mnemonic:
        return jsonify({"error": "Mnemonic is required"}), 400
    if not validate_mnemonic(mnemonic):
        return jsonify({"error": "Invalid mnemonic — check all words are valid BIP39 words"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400
    if password != confirm:
        return jsonify({"error": "Passwords do not match"}), 400
    if wallet_exists(wname):
        return jsonify({"error": "Wallet '" + wname + "' already exists. Use a different name."}), 409

    try:
        wallet_data = restore_wallet(mnemonic, passphrase)
        save_wallet(wname, wallet_data, password)
        session[WALLET_SESSION_KEY] = wname

        coins_public = {}
        for coin, w in wallet_data["wallets"].items():
            coins_public[coin] = {
                "address": w.get("address", ""),
                "network": w.get("network", ""),
            }

        return jsonify({
            "success":     True,
            "wallet_name": wname,
            "coins":       coins_public,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@wallet_bp.route("/api/select", methods=["POST"])
def api_select_wallet():
    """Switch active wallet."""
    data  = request.get_json(silent=True) or request.form
    wname = (data.get("wallet_name") or "").strip()
    if not wallet_exists(wname):
        return jsonify({"error": "Wallet not found"}), 404
    session[WALLET_SESSION_KEY] = wname
    return jsonify({"success": True, "active_wallet": wname})

@wallet_bp.route("/api/list", methods=["GET"])
def api_list_wallets():
    return jsonify({"wallets": list_wallets(), "active": _active_wallet()})

@wallet_bp.route("/api/delete", methods=["POST"])
def api_delete_wallet():
    data  = request.get_json(silent=True) or request.form
    wname = (data.get("wallet_name") or "").strip()
    if not wallet_exists(wname):
        return jsonify({"error": "Wallet not found"}), 404
    delete_wallet(wname)
    if session.get(WALLET_SESSION_KEY) == wname:
        session.pop(WALLET_SESSION_KEY, None)
    return jsonify({"success": True})

# ══════════════════════════════════════════════════════════════
#  PORTFOLIO & BALANCES
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/portfolio", methods=["GET"])
def api_portfolio():
    """
    GET /wallet/api/portfolio
    Returns full portfolio: balances + USD values + mining totals + prices.
    """
    wname = _active_wallet()
    if not wallet_exists(wname):
        return jsonify({"portfolio": None, "wallets": list_wallets()})

    portfolio = get_portfolio_summary(wname)
    return jsonify(portfolio)

@wallet_bp.route("/api/balances", methods=["GET"])
def api_balances():
    """
    GET /wallet/api/balances?refresh=1
    Returns cached balances. Pass refresh=1 to trigger live fetch.
    """
    wname   = _active_wallet()
    refresh = request.args.get("refresh", "0") in ("1", "true")

    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    if refresh:
        trigger_refresh(wname)
        time.sleep(0.1)  # brief yield so thread can start

    balances = get_cached_balances(wname)
    prices   = get_cached_prices()
    return jsonify({
        "wallet_name": wname,
        "balances":    balances,
        "prices":      prices,
        "refreshing":  refresh,
    })

@wallet_bp.route("/api/prices", methods=["GET"])
def api_prices():
    """GET /wallet/api/prices — live coin prices (CoinGecko, cached 2 min)."""
    prices = get_cached_prices()
    if not prices:
        prices = fetch_prices()
        if prices:
            cache_prices(prices)
    return jsonify({"prices": prices, "ts": int(time.time())})

# ══════════════════════════════════════════════════════════════
#  ADDRESSES
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/addresses", methods=["GET"])
def api_addresses():
    """GET /wallet/api/addresses — all coin addresses for active wallet."""
    wname = _active_wallet()
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404
    coins = load_wallet_addresses(wname)
    return jsonify({"wallet_name": wname, "coins": coins})

@wallet_bp.route("/api/address/<coin>", methods=["GET"])
def api_address(coin):
    """GET /wallet/api/address/BTC — receive address for specific coin."""
    coin  = coin.upper()
    wname = _active_wallet()
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404
    addrs = load_wallet_addresses(wname)
    for a in addrs:
        if a["coin"] == coin:
            return jsonify({"coin": coin, "address": a["address"],
                            "address_legacy": a.get("address_legacy", ""),
                            "network": a.get("network", "")})
    return jsonify({"error": "Coin not found: " + coin}), 404

# ══════════════════════════════════════════════════════════════
#  BINANCE DEPOSIT ADDRESS
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/binance_deposit/<coin>", methods=["GET"])
def api_binance_deposit(coin):
    """
    GET /wallet/api/binance_deposit/DASH
    Fetch Binance deposit address for a coin using saved API keys.
    This is the address to send mined funds TO Binance.
    """
    coin    = coin.upper()
    network = request.args.get("network", coin)
    api_key, api_secret = _get_binance_keys()

    if not api_key or not api_secret:
        return jsonify({
            "error": "No Binance API keys configured. Add them in Setup → Binance section."
        }), 400

    result = fetch_binance_deposit_address(api_key, api_secret, coin, network)
    if result.get("success"):
        # Auto-save to address book
        label = "Binance " + coin + " Deposit"
        save_address(label, coin, result["address"],
                     result.get("tag", ""), network, "binance")
    return jsonify(result)

# ══════════════════════════════════════════════════════════════
#  TRANSFER / WITHDRAW
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/transfer", methods=["POST"])
def api_transfer():
    """
    POST /wallet/api/transfer
    Send funds from internal wallet to external address or Binance.
    Body: {
        coin, to_address, amount, password,
        fee_sat (optional, BTC/LTC/DASH),
        note (optional)
    }
    Requires wallet password to decrypt private key.
    """
    data       = request.get_json(silent=True) or request.form
    coin       = (data.get("coin") or "").upper().strip()
    to_address = (data.get("to_address") or "").strip()
    password   = (data.get("password") or "").strip()
    note       = (data.get("note") or "").strip()
    wname      = _active_wallet()

    try:
        amount = float(data.get("amount") or 0)
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400

    try:
        fee_sat = int(data.get("fee_sat") or 1000)
    except (ValueError, TypeError):
        fee_sat = 1000

    if not coin:
        return jsonify({"error": "coin is required"}), 400
    if not to_address:
        return jsonify({"error": "to_address is required"}), 400
    if not password:
        return jsonify({"error": "password is required to decrypt private key"}), 400
    if amount <= 0:
        return jsonify({"error": "amount must be greater than zero"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    # Get from_address
    addrs     = load_wallet_addresses(wname)
    from_addr = None
    for a in addrs:
        if a["coin"] == coin:
            from_addr = a["address"]
            break
    if not from_addr:
        return jsonify({"error": "No " + coin + " wallet found"}), 404

    # Decrypt private key
    try:
        privkey_hex = load_privkey(wname, coin, password)
    except ValueError as e:
        return jsonify({"error": str(e)}), 401

    # Build, sign, broadcast
    try:
        if coin == "BTC":
            amount_sat = int(amount * 1e8)
            raw_hex    = build_and_sign_btc_tx(privkey_hex, from_addr, to_address,
                                               amount_sat, fee_sat)
            result     = broadcast_btc_tx(raw_hex)

        elif coin == "LTC":
            # LTC uses same UTXO model — simplified broadcast (user builds tx externally)
            # For full LTC signing we'd need UTXO fetch + same secp256k1 flow
            # Return the signed address data so user can use Electrum-LTC to sign
            result = {
                "success": False,
                "error":   (
                    "LTC on-chain signing requires UTXO fetch from Sochain. "
                    "Use Electrum-LTC with this private key to send: " +
                    privkey_hex[:8] + "...  OR transfer via Binance API below."
                ),
            }

        elif coin == "DASH":
            # DASH Insight UTXO broadcast
            # For a full implementation we'd need UTXO fetch from Insight
            # Return guidance for now — Binance transfer path is recommended
            result = {
                "success": False,
                "error":   (
                    "DASH direct broadcast requires Insight UTXO fetch. "
                    "Use 'Transfer to Exchange' to send DASH via Binance API, "
                    "or import private key into Dash Electrum."
                ),
            }

        elif coin == "ETH":
            # ETH requires nonce + gas price fetch — use Etherscan for this
            result = {
                "success": False,
                "error":   (
                    "ETH transfers require nonce + gas price. "
                    "Import private key into MetaMask or use Binance API transfer."
                ),
            }

        elif coin == "XMR":
            result = {
                "success": False,
                "error":   (
                    "XMR transactions require a running Monero daemon (monerod). "
                    "Import spend key into Monero CLI wallet to send funds."
                ),
            }
        else:
            result = {"success": False, "error": "Unsupported coin: " + coin}

    except Exception as e:
        return jsonify({"error": "Transaction failed: " + str(e)}), 500

    # Record in transaction history
    status = "broadcast" if result.get("success") else "failed"
    tx_id  = record_transaction(
        wname, coin, "send", "out",
        from_addr, to_address, amount, fee_sat / 1e8 if coin == "BTC" else 0,
        result.get("txid", ""), status, note, "manual"
    )

    return jsonify({
        "success":    result.get("success"),
        "txid":       result.get("txid"),
        "tx_id":      tx_id,
        "error":      result.get("error"),
        "from":       from_addr,
        "to":         to_address,
        "amount":     amount,
        "coin":       coin,
    })

@wallet_bp.route("/api/transfer_to_exchange", methods=["POST"])
def api_transfer_to_exchange():
    """
    POST /wallet/api/transfer_to_exchange
    Initiate a Binance withdrawal FROM Binance TO our internal wallet address,
    OR use Binance API to move funds from Binance account to external address.
    Body: {
        coin, amount, direction,
        network (optional),
        address_tag (optional, for XMR/XRP)
    }
    direction: 'to_internal' (Binance -> internal wallet)
               'to_external' (Binance -> any address)
    For direction='to_external': also pass { to_address }
    """
    data      = request.get_json(silent=True) or request.form
    coin      = (data.get("coin") or "").upper().strip()
    network   = (data.get("network") or coin).strip()
    direction = (data.get("direction") or "to_internal").strip()
    note      = (data.get("note") or "").strip()
    wname     = _active_wallet()

    try:
        amount = float(data.get("amount") or 0)
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400

    if not coin:
        return jsonify({"error": "coin is required"}), 400
    if amount <= 0:
        return jsonify({"error": "amount must be greater than zero"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    api_key, api_secret = _get_binance_keys()
    if not api_key or not api_secret:
        return jsonify({
            "error": "Binance API keys not configured. Add them in Setup → Binance."
        }), 400

    # Determine destination address
    if direction == "to_internal":
        # Find our internal wallet address for this coin
        addrs     = load_wallet_addresses(wname)
        to_addr   = None
        for a in addrs:
            if a["coin"] == coin:
                to_addr = a["address"]
                break
        if not to_addr:
            return jsonify({"error": "No internal " + coin + " wallet found"}), 404
        label = "Internal UMP Wallet"
    else:
        to_addr = (data.get("to_address") or "").strip()
        if not to_addr:
            return jsonify({"error": "to_address is required for external transfer"}), 400
        label = "External transfer"

    address_tag = (data.get("address_tag") or "").strip() or None

    result = binance_withdraw(api_key, api_secret, coin, to_addr, amount, network, address_tag)

    # Record transaction
    status = "pending" if result.get("success") else "failed"
    tx_id  = record_transaction(
        wname, coin, "transfer_to_exchange" if direction != "to_internal" else "transfer_from_exchange",
        "in" if direction == "to_internal" else "out",
        "Binance Account", to_addr, amount, 0,
        result.get("id", ""), status, note, "binance_transfer"
    )

    return jsonify({
        "success":    result.get("success"),
        "binance_id": result.get("id"),
        "tx_id":      tx_id,
        "error":      result.get("error"),
        "coin":       coin,
        "amount":     amount,
        "to_address": to_addr,
        "direction":  direction,
    })

# ══════════════════════════════════════════════════════════════
#  TRANSACTION HISTORY
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/transactions", methods=["GET"])
def api_transactions():
    """GET /wallet/api/transactions?coin=BTC&limit=50"""
    wname = _active_wallet()
    coin  = request.args.get("coin", "").upper() or None
    limit = int(request.args.get("limit", 100))
    txs   = get_transactions(wname, coin, limit)
    return jsonify({"transactions": txs, "wallet_name": wname})

@wallet_bp.route("/api/mining_credits", methods=["GET"])
def api_mining_credits():
    """GET /wallet/api/mining_credits — mining attribution history."""
    wname = _active_wallet()
    coin  = request.args.get("coin", "").upper() or None
    rows  = get_mining_credits(wname, coin)
    total = get_total_mined(wname)
    return jsonify({"credits": rows, "totals": total, "wallet_name": wname})

# ══════════════════════════════════════════════════════════════
#  ADDRESS BOOK
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/address_book", methods=["GET"])
def api_address_book():
    coin = request.args.get("coin", "").upper() or None
    return jsonify({"addresses": get_address_book(coin)})

@wallet_bp.route("/api/address_book/save", methods=["POST"])
def api_save_address():
    data    = request.get_json(silent=True) or request.form
    label   = (data.get("label") or "").strip()
    coin    = (data.get("coin") or "").upper().strip()
    address = (data.get("address") or "").strip()
    tag     = (data.get("address_tag") or "").strip()
    network = (data.get("network") or coin).strip()
    atype   = (data.get("type") or "external").strip()

    if not label or not coin or not address:
        return jsonify({"error": "label, coin, and address are required"}), 400

    save_address(label, coin, address, tag, network, atype)
    return jsonify({"success": True})

@wallet_bp.route("/api/address_book/delete", methods=["POST"])
def api_delete_address():
    data = request.get_json(silent=True) or request.form
    try:
        addr_id = int(data.get("id", 0))
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid id"}), 400
    delete_address(addr_id)
    return jsonify({"success": True})

# ══════════════════════════════════════════════════════════════
#  MINING CREDIT RECORD (called by miner_manager on session end)
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/record_mining", methods=["POST"])
def api_record_mining():
    """
    POST /wallet/api/record_mining
    Internal route called by miner manager to attribute mined funds to wallet.
    Body: { coin, amount, amount_usd, session_id, profile_name, pool, algo }
    """
    data         = request.get_json(silent=True) or request.form
    wname        = _active_wallet()
    coin         = (data.get("coin") or "").upper()
    profile_name = data.get("profile_name", "")
    pool         = data.get("pool", "")
    algo         = data.get("algo", "")

    try:
        amount     = float(data.get("amount") or 0)
        amount_usd = float(data.get("amount_usd") or 0)
        session_id = int(data.get("session_id") or 0) or None
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid numeric values"}), 400

    if not coin or amount <= 0:
        return jsonify({"error": "coin and positive amount required"}), 400
    if not wallet_exists(wname):
        return jsonify({"success": True, "skipped": "no wallet configured"})

    record_mining_credit(wname, coin, amount, amount_usd,
                         session_id, profile_name, pool, algo)
    return jsonify({"success": True})

# ══════════════════════════════════════════════════════════════
#  REVEAL KEYS (password required)
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/reveal_mnemonic", methods=["POST"])
def api_reveal_mnemonic():
    """
    POST /wallet/api/reveal_mnemonic
    Body: { password }
    Returns mnemonic phrase. Requires correct wallet password.
    """
    data     = request.get_json(silent=True) or request.form
    password = (data.get("password") or "").strip()
    wname    = _active_wallet()

    if not password:
        return jsonify({"error": "Password is required"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    try:
        mnemonic = load_mnemonic(wname, password)
        return jsonify({
            "success":  True,
            "mnemonic": mnemonic,
            "warning":  "Never share this phrase. Store it offline and securely.",
        })
    except ValueError:
        return jsonify({"error": "Wrong password"}), 401

@wallet_bp.route("/api/reveal_privkey", methods=["POST"])
def api_reveal_privkey():
    """
    POST /wallet/api/reveal_privkey
    Body: { coin, password }
    Returns private key hex. Requires correct wallet password.
    """
    data     = request.get_json(silent=True) or request.form
    coin     = (data.get("coin") or "").upper().strip()
    password = (data.get("password") or "").strip()
    wname    = _active_wallet()

    if not coin or not password:
        return jsonify({"error": "coin and password are required"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    try:
        key = load_privkey(wname, coin, password)
        return jsonify({
            "success":  True,
            "coin":     coin,
            "privkey":  key,
            "warning":  "Never share this key. Import into a wallet to use it.",
        })
    except ValueError:
        return jsonify({"error": "Wrong password"}), 401

# ══════════════════════════════════════════════════════════════
#  REGISTER WITH FLASK APP
# ══════════════════════════════════════════════════════════════

def register_wallet(app):
    """Call this from universal_miner.py to wire up the wallet."""
    init_wallet_db()
    app.register_blueprint(wallet_bp)
    print("[wallet] HD Wallet API registered at /wallet")

