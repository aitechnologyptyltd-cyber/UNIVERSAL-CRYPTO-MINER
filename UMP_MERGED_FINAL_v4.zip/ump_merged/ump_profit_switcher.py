"""
ump_profit_switcher.py
Universal Miner Pro ULTIMATE - Profit Switching Daemon
Polls CoinGecko + WhatToMine, scores all minable coins against
detected hardware, switches miner/coin/algo automatically.

Runs as APScheduler background job integrated into Flask app.
Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import time
import json
import logging
import threading
import sqlite3

try:
    import requests
    REQUESTS_OK = True
except ImportError:
    REQUESTS_OK = False

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    SCHEDULER_OK = True
except ImportError:
    SCHEDULER_OK = False

# ---------------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------------
log = logging.getLogger("ump_profit_switcher")
if not log.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(
        "[profit_switcher] %(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S"
    ))
    log.addHandler(handler)
    log.setLevel(logging.INFO)


# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------
DB_PATH             = "miner.db"
PRICE_CACHE_TTL     = 120      # seconds — how long CoinGecko prices are valid
SWITCH_INTERVAL_SEC = 300      # how often profit switcher re-evaluates (5 min)
MIN_SWITCH_GAIN_PCT = 5.0      # only switch if new coin earns >= 5% more
LOG_PATH            = "logs/profit_switch.log"

COINGECKO_IDS = {
    "XMR":   "monero",
    "ZEPH":  "zephyr-protocol",
    "SAL":   "salvium",
    "DOGE":  "dogecoin",
    "ADA":   "cardano",
    "SOL":   "solana",
    "BNB":   "binancecoin",
    "TRX":   "tron",
    "XRP":   "ripple",
    "MATIC": "matic-network",
    "DOT":   "polkadot",
    "LINK":  "chainlink",
    "AVAX":  "avalanche-2",
    "RVN":   "ravencoin",
    "ETC":   "ethereum-classic",
    "ERG":   "ergo",
    "KAS":   "kaspa",
    "ALPH":  "alephium",
    "BTC":   "bitcoin",
    "LTC":   "litecoin",
    "BCH":   "bitcoin-cash",
    "RTM":   "raptoreum",
    "WOW":   "wownero",
}

# WhatToMine endpoints for network difficulty data
WHATTOMINE_COINS = {
    "XMR":  "https://whattomine.com/coins/101.json",
    "ETC":  "https://whattomine.com/coins/162.json",
    "RVN":  "https://whattomine.com/coins/234.json",
    "ERG":  "https://whattomine.com/coins/340.json",
    "KAS":  "https://whattomine.com/coins/415.json",
}


# ---------------------------------------------------------------------------
# PRICE CACHE
# ---------------------------------------------------------------------------
_price_cache = {}        # {coin_sym: {"usd": float, "ts": float}}
_price_lock  = threading.Lock()


def _fetch_coingecko_prices(coin_syms):
    """
    Fetch USD prices for list of coin symbols from CoinGecko.
    Returns dict {coin_sym: usd_price}.
    """
    if not REQUESTS_OK:
        return {}

    # Build coingecko ID string
    ids = []
    sym_to_id = {}
    for sym in coin_syms:
        cg_id = COINGECKO_IDS.get(sym)
        if cg_id:
            ids.append(cg_id)
            sym_to_id[cg_id] = sym

    if not ids:
        return {}

    ids_str = ",".join(ids)
    url     = "https://api.coingecko.com/api/v3/simple/price"
    params  = {"ids": ids_str, "vs_currencies": "usd"}

    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code != 200:
            log.warning("CoinGecko returned HTTP " + str(resp.status_code))
            return {}
        data = resp.json()
        result = {}
        for cg_id, prices in data.items():
            sym = sym_to_id.get(cg_id)
            if sym and "usd" in prices:
                result[sym] = float(prices["usd"])
        return result
    except Exception as e:
        log.warning("CoinGecko fetch error: " + str(e))
        return {}


def get_price(coin_sym):
    """
    Return current USD price for coin, using cache if fresh.
    Returns 0.0 on failure.
    """
    now = time.time()
    with _price_lock:
        cached = _price_cache.get(coin_sym)
        if cached and (now - cached["ts"]) < PRICE_CACHE_TTL:
            return cached["usd"]

    # Fetch all at once to minimise API calls
    prices = _fetch_coingecko_prices(list(COINGECKO_IDS.keys()))
    ts_now = time.time()
    with _price_lock:
        for sym, usd in prices.items():
            _price_cache[sym] = {"usd": usd, "ts": ts_now}
        if coin_sym in prices:
            return prices[coin_sym]

    return 0.0


def refresh_all_prices():
    """Force-refresh all tracked coin prices."""
    prices = _fetch_coingecko_prices(list(COINGECKO_IDS.keys()))
    ts_now = time.time()
    with _price_lock:
        for sym, usd in prices.items():
            _price_cache[sym] = {"usd": usd, "ts": ts_now}
    log.info("Refreshed " + str(len(prices)) + " coin prices from CoinGecko")
    return prices


def get_all_cached_prices():
    """Return full price cache dict {sym: usd}."""
    with _price_lock:
        return {sym: v["usd"] for sym, v in _price_cache.items()}


# ---------------------------------------------------------------------------
# PROFITABILITY SCORING
# ---------------------------------------------------------------------------

def _to_hs(hashrate, unit):
    """Convert hashrate to raw H/s."""
    unit_lower = unit.lower()
    if unit_lower in ("gh/s", "ghs"):
        return hashrate * 1e9
    elif unit_lower in ("mh/s", "mhs"):
        return hashrate * 1e6
    elif unit_lower in ("kh/s", "khs"):
        return hashrate * 1e3
    return hashrate


def score_coin(coin_sym, hashrate_hs, capability, prices_dict):
    """
    Compute estimated daily USD for a coin given hardware hashrate.

    Returns dict:
    {
      coin:         str,
      algo_key:     str,
      usd_daily:    float,
      price_usd:    float,
      eligible:     bool,   (hardware can mine it)
      reason:       str,    (why eligible/ineligible)
    }
    """
    # Import here to avoid circular import at module load
    try:
        import ump_miner_registry as reg
    except ImportError:
        return {
            "coin": coin_sym, "algo_key": "", "usd_daily": 0.0,
            "price_usd": 0.0, "eligible": False,
            "reason": "ump_miner_registry not available",
        }

    coin_data = reg.COINS.get(coin_sym)
    if not coin_data:
        return {
            "coin": coin_sym, "algo_key": "", "usd_daily": 0.0,
            "price_usd": 0.0, "eligible": False, "reason": "Unknown coin",
        }

    coin_cap  = coin_data.get("capability", "")
    algo_key  = coin_data.get("algo_key", "")

    # Eligibility check
    eligible = False
    reason   = ""
    if capability == "CPU_ONLY":
        if coin_cap in (reg.CAP_CPU, reg.CAP_PROXIED):
            eligible = True
        else:
            reason = "Requires GPU"
    elif capability == "GPU_ONLY":
        if coin_cap == reg.CAP_GPU:
            eligible = True
        else:
            reason = "Requires CPU or ASIC"
    elif capability == "CPU_GPU":
        if coin_cap in (reg.CAP_CPU, reg.CAP_GPU, reg.CAP_PROXIED):
            eligible = True
        else:
            reason = "ASIC-only coin"
    else:
        eligible = coin_cap != reg.CAP_ASIC

    if not eligible:
        return {
            "coin": coin_sym, "algo_key": algo_key, "usd_daily": 0.0,
            "price_usd": 0.0, "eligible": False, "reason": reason,
        }

    # Get live price
    price_usd = prices_dict.get(coin_sym, 0.0)
    if price_usd == 0.0:
        price_usd = coin_data.get("base_price_usd", 0.0)

    daily_usd = reg.calc_daily_usd(coin_sym, hashrate_hs, price_usd)

    return {
        "coin":      coin_sym,
        "algo_key":  algo_key,
        "usd_daily": round(daily_usd, 6),
        "price_usd": price_usd,
        "eligible":  True,
        "reason":    "OK",
    }


def rank_coins(hashrate_hs, capability, prices_dict=None):
    """
    Score all coins and return sorted list (highest daily USD first).
    Only includes eligible coins.
    """
    if prices_dict is None:
        prices_dict = get_all_cached_prices()

    try:
        import ump_miner_registry as reg
        all_coins = list(reg.COINS.keys())
    except ImportError:
        log.error("Cannot import ump_miner_registry")
        return []

    scored = []
    for sym in all_coins:
        result = score_coin(sym, hashrate_hs, capability, prices_dict)
        if result["eligible"] and result["usd_daily"] > 0:
            scored.append(result)

    scored.sort(key=lambda x: x["usd_daily"], reverse=True)
    return scored


def get_best_coin(hashrate_hs, capability, current_coin=None, prices_dict=None):
    """
    Return the single best coin to mine.
    Applies MIN_SWITCH_GAIN_PCT to avoid constant switching.
    """
    ranking = rank_coins(hashrate_hs, capability, prices_dict)
    if not ranking:
        return None

    best = ranking[0]

    if current_coin and current_coin != best["coin"]:
        # Find current coin in ranking
        current_score = 0.0
        for entry in ranking:
            if entry["coin"] == current_coin:
                current_score = entry["usd_daily"]
                break
        # Only switch if improvement exceeds threshold
        if current_score > 0:
            gain_pct = (best["usd_daily"] - current_score) / current_score * 100.0
            if gain_pct < MIN_SWITCH_GAIN_PCT:
                log.info(
                    "Best coin " + best["coin"] +
                    " is only " + str(round(gain_pct, 1)) +
                    "% better than " + current_coin +
                    " -- keeping current"
                )
                # Return current coin entry
                for entry in ranking:
                    if entry["coin"] == current_coin:
                        return entry
                return best  # current not in ranking; switch anyway

    return best


# ---------------------------------------------------------------------------
# SWITCH LOG
# ---------------------------------------------------------------------------

def _ensure_log_dir():
    log_dir = os.path.dirname(LOG_PATH)
    if log_dir and not os.path.isdir(log_dir):
        os.makedirs(log_dir)


def _write_switch_log(from_coin, to_coin, from_usd, to_usd, reason):
    """Append switch event to log file."""
    _ensure_log_dir()
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_PATH, "a") as fh:
            fh.write(
                ts + " | SWITCH | " +
                from_coin + " -> " + to_coin +
                " | from_usd=" + str(round(from_usd, 6)) +
                " to_usd=" + str(round(to_usd, 6)) +
                " | " + reason + "\n"
            )
    except Exception as e:
        log.warning("Failed to write switch log: " + str(e))


def _record_switch_to_db(db_path, from_coin, to_coin, from_usd, to_usd, reason):
    """Record switch event in SQLite profit_switches table."""
    try:
        conn = sqlite3.connect(db_path, timeout=10)
        c    = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS profit_switches (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          TEXT    NOT NULL,
                from_coin   TEXT,
                to_coin     TEXT,
                from_usd    REAL,
                to_usd      REAL,
                reason      TEXT
            )
        """)
        c.execute(
            "INSERT INTO profit_switches (ts, from_coin, to_coin, from_usd, to_usd, reason) "
            "VALUES (datetime('now'), ?, ?, ?, ?, ?)",
            (from_coin, to_coin, from_usd, to_usd, reason)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning("DB switch log error: " + str(e))


# ---------------------------------------------------------------------------
# PROFIT SWITCHER ENGINE
# ---------------------------------------------------------------------------

class ProfitSwitcher(object):
    """
    Main profit switching engine.
    Integrate with Flask/miner_manager by passing callbacks.
    """

    def __init__(
        self,
        capability="CPU_ONLY",
        hashrate_provider=None,
        current_coin_provider=None,
        switch_callback=None,
        db_path=DB_PATH,
    ):
        """
        Parameters
        ----------
        capability          : str   Hardware capability string from ump_hardware_detect
        hashrate_provider   : callable  Returns current hashrate in H/s (float)
        current_coin_provider: callable Returns current mining coin symbol (str)
        switch_callback     : callable(coin_sym, algo_key, pool_id) — called to trigger switch
        db_path             : str   Path to SQLite DB
        """
        self.capability           = capability
        self._hashrate_provider   = hashrate_provider
        self._current_coin_provider = current_coin_provider
        self._switch_callback     = switch_callback
        self.db_path              = db_path

        self._scheduler   = None
        self._running     = False
        self._last_ranking= []
        self._last_check  = 0
        self._switch_count= 0
        self._lock        = threading.Lock()

        _ensure_log_dir()

    def start(self):
        """Start the profit switching scheduler."""
        if not SCHEDULER_OK:
            log.error("APScheduler not installed. Run: pip install apscheduler")
            return False

        if self._running:
            log.warning("Profit switcher already running")
            return True

        # Initial price fetch
        refresh_all_prices()

        self._scheduler = BackgroundScheduler(daemon=True)
        self._scheduler.add_job(
            self._evaluate,
            "interval",
            seconds=SWITCH_INTERVAL_SEC,
            id="profit_switcher",
            replace_existing=True,
        )
        self._scheduler.add_job(
            refresh_all_prices,
            "interval",
            seconds=PRICE_CACHE_TTL,
            id="price_refresh",
            replace_existing=True,
        )
        self._scheduler.start()
        self._running = True
        log.info("Profit switcher started. Evaluating every " +
                 str(SWITCH_INTERVAL_SEC) + "s")
        return True

    def stop(self):
        """Stop the scheduler."""
        if self._scheduler and self._running:
            try:
                self._scheduler.shutdown(wait=False)
            except Exception:
                pass
            self._running = False
            log.info("Profit switcher stopped")

    def _evaluate(self):
        """
        Core evaluation loop. Called by APScheduler.
        Scores all coins, decides whether to switch.
        """
        log.info("Evaluating profitability...")

        # Get current state
        hashrate_hs  = 0.0
        current_coin = "XMR"

        if self._hashrate_provider:
            try:
                hashrate_hs = float(self._hashrate_provider() or 0.0)
            except Exception:
                pass

        if self._current_coin_provider:
            try:
                current_coin = self._current_coin_provider() or "XMR"
            except Exception:
                pass

        if hashrate_hs <= 0.0:
            log.info("Hashrate is 0 -- skipping evaluation")
            return

        # Get fresh prices
        prices = get_all_cached_prices()
        if not prices:
            prices = refresh_all_prices()

        # Rank coins
        ranking = rank_coins(hashrate_hs, self.capability, prices)
        with self._lock:
            self._last_ranking = ranking
            self._last_check   = time.time()

        if not ranking:
            log.info("No eligible coins found in ranking")
            return

        best = get_best_coin(hashrate_hs, self.capability, current_coin, prices)
        if not best:
            return

        log.info(
            "Best: " + best["coin"] +
            " $" + str(best["usd_daily"]) + "/day" +
            " | Current: " + current_coin
        )

        # Switch if needed
        if best["coin"] != current_coin:
            self._do_switch(current_coin, best, prices, hashrate_hs)

    def _do_switch(self, from_coin, best_entry, prices, hashrate_hs):
        """Execute coin switch."""
        to_coin   = best_entry["coin"]
        algo_key  = best_entry["algo_key"]
        to_usd    = best_entry["usd_daily"]

        # Get from_usd for logging
        from_usd = 0.0
        for entry in self._last_ranking:
            if entry["coin"] == from_coin:
                from_usd = entry["usd_daily"]
                break

        reason = "profit_switch auto"
        log.info(
            "SWITCHING: " + from_coin + " -> " + to_coin +
            " (+" + str(round((to_usd - from_usd) / max(from_usd, 0.000001) * 100, 1)) + "%)"
        )

        # Best pool for this coin
        try:
            import ump_miner_registry as reg
            coin_data = reg.COINS.get(to_coin, {})
            best_pools = coin_data.get("best_pools", ["custom"])
            pool_id    = best_pools[0] if best_pools else "custom"
        except ImportError:
            pool_id = "custom"

        # Invoke switch callback (provided by Flask app)
        if self._switch_callback:
            try:
                self._switch_callback(to_coin, algo_key, pool_id)
            except Exception as e:
                log.error("Switch callback error: " + str(e))
                return

        # Log the switch
        _write_switch_log(from_coin, to_coin, from_usd, to_usd, reason)
        _record_switch_to_db(
            self.db_path, from_coin, to_coin, from_usd, to_usd, reason
        )
        self._switch_count += 1

    def force_evaluate(self):
        """Manually trigger evaluation (callable from Flask route)."""
        threading.Thread(target=self._evaluate, daemon=True).start()

    def get_status(self):
        """Return current switcher status dict for API."""
        with self._lock:
            return {
                "running":       self._running,
                "capability":    self.capability,
                "switch_count":  self._switch_count,
                "last_check":    self._last_check,
                "interval_sec":  SWITCH_INTERVAL_SEC,
                "min_gain_pct":  MIN_SWITCH_GAIN_PCT,
                "top_coins":     self._last_ranking[:10],
                "prices":        get_all_cached_prices(),
            }

    def get_ranking(self):
        """Return last computed ranking."""
        with self._lock:
            return list(self._last_ranking)

    def set_capability(self, capability):
        """Update hardware capability (e.g. after profile change)."""
        with self._lock:
            self.capability = capability

    def set_min_gain(self, pct):
        """Update minimum gain threshold for switching."""
        global MIN_SWITCH_GAIN_PCT
        MIN_SWITCH_GAIN_PCT = float(pct)

    def set_interval(self, seconds):
        """Update evaluation interval."""
        global SWITCH_INTERVAL_SEC
        SWITCH_INTERVAL_SEC = int(seconds)
        if self._scheduler and self._running:
            try:
                self._scheduler.reschedule_job(
                    "profit_switcher",
                    trigger="interval",
                    seconds=SWITCH_INTERVAL_SEC
                )
            except Exception:
                pass


# ---------------------------------------------------------------------------
# SINGLETON
# ---------------------------------------------------------------------------
_instance = None
_instance_lock = threading.Lock()


def get_switcher(
    capability="CPU_ONLY",
    hashrate_provider=None,
    current_coin_provider=None,
    switch_callback=None,
    db_path=DB_PATH,
):
    """
    Return singleton ProfitSwitcher instance.
    On first call, creates and starts the switcher.
    """
    global _instance
    with _instance_lock:
        if _instance is None:
            _instance = ProfitSwitcher(
                capability=capability,
                hashrate_provider=hashrate_provider,
                current_coin_provider=current_coin_provider,
                switch_callback=switch_callback,
                db_path=db_path,
            )
            _instance.start()
        return _instance


# ---------------------------------------------------------------------------
# FLASK BLUEPRINT (optional integration)
# ---------------------------------------------------------------------------

def create_profit_blueprint(switcher_instance):
    """
    Create a Flask Blueprint with profit switcher API endpoints.
    Register with: app.register_blueprint(create_profit_blueprint(switcher))
    """
    try:
        from flask import Blueprint, jsonify, request
    except ImportError:
        log.error("Flask not installed -- cannot create blueprint")
        return None

    bp = Blueprint("profit", __name__)

    @bp.route("/api/profit/status")
    def profit_status():
        return jsonify(switcher_instance.get_status())

    @bp.route("/api/profit/ranking")
    def profit_ranking():
        return jsonify({"ranking": switcher_instance.get_ranking()})

    @bp.route("/api/profit/prices")
    def profit_prices():
        return jsonify(get_all_cached_prices())

    @bp.route("/api/profit/evaluate", methods=["POST"])
    def profit_evaluate():
        switcher_instance.force_evaluate()
        return jsonify({"ok": True, "message": "Evaluation triggered"})

    @bp.route("/api/profit/settings", methods=["POST"])
    def profit_settings():
        data = request.get_json(force=True) or {}
        if "min_gain_pct" in data:
            switcher_instance.set_min_gain(float(data["min_gain_pct"]))
        if "interval_sec" in data:
            switcher_instance.set_interval(int(data["interval_sec"]))
        return jsonify({"ok": True})

    @bp.route("/api/profit/switch_log")
    def profit_switch_log():
        """Return last 50 lines of profit switch log."""
        lines = []
        if os.path.isfile(LOG_PATH):
            with open(LOG_PATH, "r") as fh:
                lines = fh.readlines()[-50:]
        return jsonify({"lines": [l.rstrip() for l in lines]})

    return bp


# ---------------------------------------------------------------------------
# MAIN (standalone test)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Test price fetch
    print("Fetching prices...")
    prices = refresh_all_prices()
    print("Prices:", json.dumps(prices, indent=2))

    # Test ranking with a hypothetical 500 H/s CPU
    print("\nRanking for CPU_ONLY @ 500 H/s:")
    ranking = rank_coins(500.0, "CPU_ONLY", prices)
    for i, entry in enumerate(ranking[:5]):
        print(
            str(i + 1) + ". " + entry["coin"] +
            " $" + str(entry["usd_daily"]) + "/day" +
            " (" + entry["algo_key"] + ")"
        )

    best = get_best_coin(500.0, "CPU_ONLY", "XMR", prices)
    if best:
        print("\nBest coin:", best["coin"], "@ $" + str(best["usd_daily"]) + "/day")
