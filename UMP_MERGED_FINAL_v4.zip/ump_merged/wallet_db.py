# wallet_db.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Encrypted Wallet Keystore · Balance Cache · TX History · Mining Attribution
# AES-256-GCM encryption for private keys and mnemonic
# Python 3.6+ compatible — no f-strings — no walrus

from __future__ import print_function
import os
import json
import time
import sqlite3
import hashlib
import secrets
import threading

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "miner.db")
_db_lock = threading.Lock()

# ══════════════════════════════════════════════════════════════
#  AES-256-GCM ENCRYPTION
# ══════════════════════════════════════════════════════════════
def _derive_key(password, salt):
    """Derive 32-byte AES key from password using PBKDF2-HMAC-SHA256."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200000, 32)

def encrypt(plaintext, password):
    """
    Encrypt plaintext string with AES-256-GCM.
    Returns hex string: salt(32) + nonce(12) + ciphertext+tag
    """
    salt      = secrets.token_bytes(32)
    nonce     = secrets.token_bytes(12)
    key       = _derive_key(password, salt)
    aesgcm    = AESGCM(key)
    ct        = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return (salt + nonce + ct).hex()

def decrypt(hex_blob, password):
    """
    Decrypt hex blob produced by encrypt().
    Returns plaintext string. Raises ValueError on wrong password.
    """
    raw    = bytes.fromhex(hex_blob)
    salt   = raw[:32]
    nonce  = raw[32:44]
    ct     = raw[44:]
    key    = _derive_key(password, salt)
    aesgcm = AESGCM(key)
    try:
        pt = aesgcm.decrypt(nonce, ct, None)
        return pt.decode("utf-8")
    except Exception:
        raise ValueError("Decryption failed — wrong password or corrupted data")

# ══════════════════════════════════════════════════════════════
#  DB SCHEMA INIT
# ══════════════════════════════════════════════════════════════
WALLET_TABLES = [
    # Master keystore — one row per wallet
    """
    CREATE TABLE IF NOT EXISTS wallet_keystore (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT UNIQUE NOT NULL,
        encrypted_mnemonic TEXT NOT NULL,
        salt_hint     TEXT DEFAULT '',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
    # Per-coin wallet records
    """
    CREATE TABLE IF NOT EXISTS wallet_coins (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        address       TEXT NOT NULL,
        address_legacy TEXT DEFAULT '',
        address_bech32 TEXT DEFAULT '',
        pubkey_hex    TEXT DEFAULT '',
        encrypted_privkey TEXT DEFAULT '',
        network       TEXT DEFAULT '',
        derivation_path TEXT DEFAULT '',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(wallet_name, coin)
    )
    """,
    # Balance cache — updated on-demand
    """
    CREATE TABLE IF NOT EXISTS wallet_balances (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        balance       REAL DEFAULT 0,
        balance_usd   REAL DEFAULT 0,
        last_fetched  DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(wallet_name, coin)
    )
    """,
    # Transaction history
    """
    CREATE TABLE IF NOT EXISTS wallet_transactions (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        tx_type       TEXT NOT NULL,
        direction     TEXT NOT NULL,
        from_address  TEXT DEFAULT '',
        to_address    TEXT DEFAULT '',
        amount        REAL DEFAULT 0,
        fee           REAL DEFAULT 0,
        txid          TEXT DEFAULT '',
        status        TEXT DEFAULT 'pending',
        note          TEXT DEFAULT '',
        source        TEXT DEFAULT 'manual',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        confirmed_at  DATETIME
    )
    """,
    # Mining attribution — links sessions to wallet credits
    """
    CREATE TABLE IF NOT EXISTS wallet_mining_credits (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        session_id    INTEGER,
        profile_name  TEXT DEFAULT '',
        pool          TEXT DEFAULT '',
        algo          TEXT DEFAULT '',
        amount        REAL DEFAULT 0,
        amount_usd    REAL DEFAULT 0,
        credited_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
    # Saved external addresses (exchanges, cold wallets)
    """
    CREATE TABLE IF NOT EXISTS wallet_address_book (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        label         TEXT NOT NULL,
        coin          TEXT NOT NULL,
        address       TEXT NOT NULL,
        address_tag   TEXT DEFAULT '',
        network       TEXT DEFAULT '',
        type          TEXT DEFAULT 'external',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(coin, address)
    )
    """,
    # Price cache
    """
    CREATE TABLE IF NOT EXISTS wallet_price_cache (
        coin          TEXT PRIMARY KEY,
        price_usd     REAL DEFAULT 0,
        fetched_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
]

def init_wallet_db():
    """Create all wallet tables if they don't exist."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        for sql in WALLET_TABLES:
            c.execute(sql)
        conn.commit()
        conn.close()

# ══════════════════════════════════════════════════════════════
#  WALLET KEYSTORE
# ══════════════════════════════════════════════════════════════
def save_wallet(wallet_name, wallet_data, password):
    """
    Store a new wallet securely.
    wallet_data: dict from wallet_core.create_wallet()
    password: encryption password chosen by user
    """
    mnemonic       = wallet_data["mnemonic"]
    enc_mnemonic   = encrypt(mnemonic, password)

    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c    = conn.cursor()

        c.execute("""
            INSERT OR REPLACE INTO wallet_keystore
            (wallet_name, encrypted_mnemonic, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        """, (wallet_name, enc_mnemonic))

        # Store per-coin records
        for coin, w in wallet_data["wallets"].items():
            priv_enc = encrypt(w.get("privkey", w.get("spend_key", "")), password)
            c.execute("""
                INSERT OR REPLACE INTO wallet_coins
                (wallet_name, coin, address, address_legacy, address_bech32,
                 pubkey_hex, encrypted_privkey, network, derivation_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                wallet_name,
                coin,
                w.get("address", ""),
                w.get("address_legacy", ""),
                w.get("address_bech32", ""),
                w.get("pubkey", ""),
                priv_enc,
                w.get("network", ""),
                w.get("path", ""),
            ))

        conn.commit()
        conn.close()

def load_wallet_addresses(wallet_name):
    """
    Load wallet coin records (public data only — no private keys).
    Returns list of coin dicts.
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT coin, address, address_legacy, address_bech32,
                   pubkey_hex, network, derivation_path
            FROM wallet_coins WHERE wallet_name=?
            ORDER BY coin
        """, (wallet_name,))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

def load_privkey(wallet_name, coin, password):
    """
    Load and decrypt private key for a specific coin.
    Returns hex string or raises ValueError on bad password.
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            SELECT encrypted_privkey FROM wallet_coins
            WHERE wallet_name=? AND coin=?
        """, (wallet_name, coin))
        row = c.fetchone()
        conn.close()
    if not row:
        raise ValueError("No wallet found for " + wallet_name + "/" + coin)
    return decrypt(row[0], password)

def load_mnemonic(wallet_name, password):
    """Load and decrypt the mnemonic phrase. Returns string."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("SELECT encrypted_mnemonic FROM wallet_keystore WHERE wallet_name=?",
                  (wallet_name,))
        row = c.fetchone()
        conn.close()
    if not row:
        raise ValueError("No wallet found: " + wallet_name)
    return decrypt(row[0], password)

def list_wallets():
    """Return list of wallet names."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("SELECT wallet_name, created_at FROM wallet_keystore ORDER BY created_at DESC")
        rows = [{"wallet_name": r[0], "created_at": r[1]} for r in c.fetchall()]
        conn.close()
        return rows

def wallet_exists(wallet_name):
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("SELECT 1 FROM wallet_keystore WHERE wallet_name=?", (wallet_name,))
        exists = c.fetchone() is not None
        conn.close()
        return exists

def delete_wallet(wallet_name):
    """Permanently delete wallet and all associated data."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        for table in ("wallet_keystore", "wallet_coins", "wallet_balances",
                      "wallet_transactions", "wallet_mining_credits"):
            c.execute("DELETE FROM " + table + " WHERE wallet_name=?", (wallet_name,))
        conn.commit()
        conn.close()

# ══════════════════════════════════════════════════════════════
#  BALANCE CACHE
# ══════════════════════════════════════════════════════════════
BALANCE_TTL = 120   # seconds before balance is considered stale

def cache_balance(wallet_name, coin, balance, price_usd=0.0):
    """Store fetched balance in cache."""
    balance_usd = (balance or 0) * price_usd
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO wallet_balances
            (wallet_name, coin, balance, balance_usd, last_fetched)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (wallet_name, coin, balance or 0, balance_usd))
        conn.commit()
        conn.close()

def get_cached_balances(wallet_name, max_age=BALANCE_TTL):
    """
    Return cached balances. Returns list of dicts.
    Entries older than max_age seconds are flagged as stale.
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        c.execute("""
            SELECT coin, balance, balance_usd,
                   CAST((julianday('now') - julianday(last_fetched)) * 86400 AS INTEGER)
                   AS age_seconds
            FROM wallet_balances
            WHERE wallet_name=?
            ORDER BY coin
        """, (wallet_name,))
        rows = []
        for r in c.fetchall():
            d = dict(r)
            d["stale"] = d["age_seconds"] > max_age
            rows.append(d)
        conn.close()
        return rows

# ══════════════════════════════════════════════════════════════
#  PRICE CACHE
# ══════════════════════════════════════════════════════════════
PRICE_TTL = 120   # seconds

def cache_prices(prices):
    """Store fetched prices dict {coin: usd_price}."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        for coin, price in prices.items():
            c.execute("""
                INSERT OR REPLACE INTO wallet_price_cache (coin, price_usd, fetched_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, (coin, price))
        conn.commit()
        conn.close()

def get_cached_prices(max_age=PRICE_TTL):
    """Return cached prices dict {coin: usd_price}. Returns empty dict if all stale."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            SELECT coin, price_usd,
                   CAST((julianday('now') - julianday(fetched_at)) * 86400 AS INTEGER)
                   AS age_seconds
            FROM wallet_price_cache
        """)
        prices = {}
        for row in c.fetchall():
            if row[2] <= max_age:
                prices[row[0]] = row[1]
        conn.close()
        return prices

# ══════════════════════════════════════════════════════════════
#  TRANSACTION HISTORY
# ══════════════════════════════════════════════════════════════
def record_transaction(wallet_name, coin, tx_type, direction,
                       from_addr, to_addr, amount, fee=0.0,
                       txid="", status="pending", note="", source="manual"):
    """
    Record a transaction in history.
    tx_type:   'send' | 'receive' | 'transfer_to_exchange' | 'transfer_from_exchange'
    direction: 'out' | 'in'
    source:    'manual' | 'mining' | 'binance_transfer'
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT INTO wallet_transactions
            (wallet_name, coin, tx_type, direction, from_address, to_address,
             amount, fee, txid, status, note, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (wallet_name, coin, tx_type, direction,
              from_addr, to_addr, amount, fee,
              txid, status, note, source))
        tx_id = c.lastrowid
        conn.commit()
        conn.close()
    return tx_id

def update_tx_status(tx_id, status, txid=None, confirmed_at=None):
    """Update transaction status (pending → confirmed / failed)."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        if txid and confirmed_at:
            c.execute("""
                UPDATE wallet_transactions
                SET status=?, txid=?, confirmed_at=?
                WHERE id=?
            """, (status, txid, confirmed_at, tx_id))
        elif txid:
            c.execute("UPDATE wallet_transactions SET status=?, txid=? WHERE id=?",
                      (status, txid, tx_id))
        else:
            c.execute("UPDATE wallet_transactions SET status=? WHERE id=?",
                      (status, tx_id))
        conn.commit()
        conn.close()

def get_transactions(wallet_name, coin=None, limit=100):
    """Return transaction history. Optionally filter by coin."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        if coin:
            c.execute("""
                SELECT * FROM wallet_transactions
                WHERE wallet_name=? AND coin=?
                ORDER BY created_at DESC LIMIT ?
            """, (wallet_name, coin, limit))
        else:
            c.execute("""
                SELECT * FROM wallet_transactions
                WHERE wallet_name=?
                ORDER BY created_at DESC LIMIT ?
            """, (wallet_name, limit))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

# ══════════════════════════════════════════════════════════════
#  MINING CREDITS
# ══════════════════════════════════════════════════════════════
def record_mining_credit(wallet_name, coin, amount, amount_usd=0.0,
                         session_id=None, profile_name="", pool="", algo=""):
    """Record a mining credit to the wallet (auto-called by miner manager)."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT INTO wallet_mining_credits
            (wallet_name, coin, session_id, profile_name, pool, algo, amount, amount_usd)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (wallet_name, coin, session_id, profile_name, pool, algo, amount, amount_usd))
        conn.commit()
        conn.close()

def get_mining_credits(wallet_name, coin=None, limit=200):
    """Return mining credit history."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        if coin:
            c.execute("""
                SELECT * FROM wallet_mining_credits
                WHERE wallet_name=? AND coin=?
                ORDER BY credited_at DESC LIMIT ?
            """, (wallet_name, coin, limit))
        else:
            c.execute("""
                SELECT * FROM wallet_mining_credits
                WHERE wallet_name=?
                ORDER BY credited_at DESC LIMIT ?
            """, (wallet_name, limit))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

def get_total_mined(wallet_name):
    """Return total amount mined per coin."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            SELECT coin, SUM(amount) as total, SUM(amount_usd) as total_usd
            FROM wallet_mining_credits WHERE wallet_name=?
            GROUP BY coin
        """, (wallet_name,))
        rows = {r[0]: {"total": r[1], "total_usd": r[2]} for r in c.fetchall()}
        conn.close()
        return rows

# ══════════════════════════════════════════════════════════════
#  ADDRESS BOOK
# ══════════════════════════════════════════════════════════════
def save_address(label, coin, address, address_tag="", network="", addr_type="external"):
    """Save an external address (exchange, cold wallet) to address book."""
    if network == "":
        network = coin
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO wallet_address_book
            (label, coin, address, address_tag, network, type)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (label, coin, address, address_tag, network, addr_type))
        conn.commit()
        conn.close()

def get_address_book(coin=None):
    """Return address book entries, optionally filtered by coin."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        if coin:
            c.execute("""
                SELECT * FROM wallet_address_book WHERE coin=?
                ORDER BY label
            """, (coin,))
        else:
            c.execute("SELECT * FROM wallet_address_book ORDER BY coin, label")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

def delete_address(addr_id):
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.cursor().execute("DELETE FROM wallet_address_book WHERE id=?", (addr_id,))
        conn.commit()
        conn.close()

# ══════════════════════════════════════════════════════════════
#  PORTFOLIO SUMMARY
# ══════════════════════════════════════════════════════════════
def get_portfolio_summary(wallet_name):
    """
    Return a full portfolio summary for the wallet.
    Joins balances + prices + mining credits.
    """
    balances = {b["coin"]: b for b in get_cached_balances(wallet_name)}
    mined    = get_total_mined(wallet_name)
    prices   = get_cached_prices()
    coins    = load_wallet_addresses(wallet_name)

    total_usd = 0.0
    summary   = []
    for c in coins:
        coin    = c["coin"]
        bal     = balances.get(coin, {})
        balance = bal.get("balance", 0.0) or 0.0
        price   = prices.get(coin, 0.0)
        val_usd = balance * price
        total_usd += val_usd
        summary.append({
            "coin":         coin,
            "address":      c["address"],
            "balance":      balance,
            "price_usd":    price,
            "value_usd":    val_usd,
            "total_mined":  mined.get(coin, {}).get("total", 0.0),
            "network":      c["network"],
            "stale":        bal.get("stale", True),
        })

    return {
        "wallet_name": wallet_name,
        "total_usd":   total_usd,
        "coins":       summary,
        "prices":      prices,
    }

