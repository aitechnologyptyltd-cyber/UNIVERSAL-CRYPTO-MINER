#!/usr/bin/env python3
"""
UMP CONSOLIDATED v5.2 -- One-shot extractor
Run from inside your UMP folder:
    python3 extract_ump.py

Expects these files in the same directory:
    all_python.py  all_shell.sh  all_html.html  all_text.txt
"""

import re, os, stat, sys

BASE = os.path.dirname(os.path.abspath(__file__))
ERRORS = []

def mkdir(path):
    os.makedirs(path, exist_ok=True)

def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content)
    print(f"  \u2713  {os.path.relpath(path, BASE)}")

def make_executable(path):
    s = os.stat(path)
    os.chmod(path, s.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

def require(filename):
    path = os.path.join(BASE, filename)
    if not os.path.exists(path):
        print(f"  [ERROR] Missing required file: {filename}")
        sys.exit(1)
    return path

# ── 1. PYTHON MODULES ────────────────────────────────────────────────────────
print("\n[1/5] Extracting Python modules...")
require('all_python.py')
with open(os.path.join(BASE, 'all_python.py'), 'r') as f:
    content = f.read()

parts = re.split(r'# =+\n# MODULE: (.+?)\n# =+\n', content)
written = 0
for i in range(1, len(parts), 2):
    name = parts[i].strip()
    code = parts[i+1] if i+1 < len(parts) else ''
    write(os.path.join(BASE, name), code)
    written += 1
print(f"  → {written} Python modules extracted")

# ── 2. SHELL SCRIPTS ─────────────────────────────────────────────────────────
print("\n[2/5] Extracting shell scripts...")
require('all_shell.sh')
with open(os.path.join(BASE, 'all_shell.sh'), 'r') as f:
    content = f.read()

parts = re.split(r'# =+\n# SCRIPT: (.+?)\n# =+\n', content)
written = 0
for i in range(1, len(parts), 2):
    name = parts[i].strip()
    code = parts[i+1] if i+1 < len(parts) else ''
    dest = os.path.join(BASE, name)
    write(dest, '#!/bin/bash\n' + code)
    make_executable(dest)
    written += 1
print(f"  → {written} shell scripts extracted and made executable")

# ── 3. HTML TEMPLATES ────────────────────────────────────────────────────────
print("\n[3/5] Extracting HTML templates...")
require('all_html.html')
templates_dir = os.path.join(BASE, 'templates')
mkdir(templates_dir)

with open(os.path.join(BASE, 'all_html.html'), 'r') as f:
    content = f.read()

pattern = r'<!-- ===== TEMPLATE: (.+?) ===== -->\s*<template[^>]*>(.*?)</template>'
matches = re.findall(pattern, content, re.DOTALL)

# Required templates — Flask will 500 without these
REQUIRED_TEMPLATES = ['dashboard.html', 'setup.html', 'profiles.html', 'wallet_ui.html']
written_names = []

for name, body in matches:
    name = name.strip()
    dest = os.path.join(templates_dir, name)
    write(dest, body.strip())
    written_names.append(name)

# Verify every required template was written
for t in REQUIRED_TEMPLATES:
    dest = os.path.join(templates_dir, t)
    if not os.path.exists(dest):
        print(f"  [ERROR] Required template not found in all_html.html: {t}")
        ERRORS.append(t)
    else:
        size = os.path.getsize(dest)
        if size < 500:
            print(f"  [WARN]  {t} is suspiciously small ({size} bytes) — may be corrupt")

# Also copy the unified standalone dashboard into templates as index fallback
unified = os.path.join(BASE, 'ump_unified_dashboard.html')
if os.path.exists(unified):
    import shutil
    shutil.copy(unified, os.path.join(templates_dir, 'ump_unified_dashboard.html'))
    print(f"  \u2713  templates/ump_unified_dashboard.html  (standalone copy)")

print(f"  → {len(written_names)} templates extracted to templates/")

# ── 4. TEXT FILES ────────────────────────────────────────────────────────────
print("\n[4/5] Extracting text files...")
require('all_text.txt')
with open(os.path.join(BASE, 'all_text.txt'), 'r') as f:
    content = f.read()

# Two formats present in consolidated file:
#   --- filename (description) ---   (with description)
#   --- filename ---                 (plain)
text_parts = re.split(r'---\s+(.+?)(?:\s+\(.*?\))?\s+---\n', content)
written = 0
for i in range(1, len(text_parts), 2):
    name = text_parts[i].strip()
    body = text_parts[i+1] if i+1 < len(text_parts) else ''
    if '.' in name and '/' not in name and '\\' not in name:
        write(os.path.join(BASE, name), body.strip() + '\n')
        written += 1
print(f"  → {written} text files extracted")

# ── 5. RUNTIME DIRECTORIES ───────────────────────────────────────────────────
print("\n[5/5] Creating runtime directories...")
for d in ['logs', 'bins', 'tmp']:
    path = os.path.join(BASE, d)
    mkdir(path)
    # Write a .gitkeep so the directory isn't ignored
    keep = os.path.join(path, '.gitkeep')
    if not os.path.exists(keep):
        open(keep, 'w').close()
    print(f"  \u2713  {d}/")

# ── FINAL VERIFICATION ───────────────────────────────────────────────────────
print("\n[VERIFY] Checking critical files...")
critical = [
    'universal_miner.py',
    'miner_config.py',
    'wallet_core.py',
    'wallet_api.py',
    'start.sh',
    'templates/dashboard.html',
    'templates/setup.html',
    'templates/profiles.html',
    'templates/wallet_ui.html',
]
ok = True
for f in critical:
    path = os.path.join(BASE, f)
    exists = os.path.exists(path)
    size   = os.path.getsize(path) if exists else 0
    mark   = '\u2713' if exists and size > 100 else '\u2717'
    status = f'{size:,} bytes' if exists else 'MISSING'
    print(f"  {mark}  {f:<40} {status}")
    if not exists or size < 100:
        ok = False

# ── DONE ─────────────────────────────────────────────────────────────────────
if ERRORS or not ok:
    print("\n\u26a0  Some files had issues (see above). Flask may not start correctly.")
else:
    print("""
\u256c\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u256c
\u2551  \u2713  Extraction complete!                         \u2551
\u2551                                                  \u2551
\u2551  Next:                                           \u2551
\u2551    pip install -r requirements.txt \\             \u2551
\u2551        --break-system-packages                   \u2551
\u2551    ./start.sh                                    \u2551
\u2551                                                  \u2551
\u2551  Dashboard: http://localhost:8080               \u2551
\u2551  Wallet:    http://localhost:8080/wallet         \u2551
\u2551  Setup:     http://localhost:8080/setup          \u2551
\u2551  Profiles:  http://localhost:8080/profiles       \u2551
\u256c\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u256c""")
