#!/usr/bin/env python3
"""
UMP CONSOLIDATED v5.2 — Bulletproof Extractor + Installer
==========================================================
Run from ANYWHERE:
    python3 extract_ump.py
    python3 /path/to/extract_ump.py

It auto-detects the directory containing the consolidated files
and extracts everything relative to that location.
"""

import re, os, stat, sys, subprocess, shutil

# ── Find the directory that contains our consolidated files ─────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# If consolidated files aren't next to this script, search common locations
REQUIRED_FILES = ['all_python.py', 'all_shell.sh', 'all_html.html', 'all_text.txt']

def find_base():
    candidates = [
        SCRIPT_DIR,
        os.getcwd(),
        os.path.join(os.getcwd(), 'UMP'),
        os.path.expanduser('~/UMP'),
        os.path.expanduser('~'),
    ]
    for c in candidates:
        if all(os.path.exists(os.path.join(c, f)) for f in REQUIRED_FILES):
            return c
    return None

BASE = find_base()
if BASE is None:
    print("ERROR: Cannot find consolidated files (all_python.py, all_shell.sh, etc.)")
    print("Make sure you extracted the ZIP and are running from that folder.")
    sys.exit(1)

if BASE != os.getcwd():
    print(f"[INFO] Working directory set to: {BASE}")
os.chdir(BASE)

ERRORS = []

def mkdir(path):
    os.makedirs(path, exist_ok=True)

def write(path, content):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content)
    rel = os.path.relpath(path, BASE)
    size = len(content.encode())
    print(f"  ✓  {rel:<45} ({size:,} bytes)")

def make_executable(path):
    s = os.stat(path)
    os.chmod(path, s.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

def read_file(name):
    with open(os.path.join(BASE, name), 'r', errors='replace') as f:
        return f.read()

# ─────────────────────────────────────────────────────────────────────────────
# 1. PYTHON MODULES
# ─────────────────────────────────────────────────────────────────────────────
print("\n[1/5] Extracting Python modules...")
content = read_file('all_python.py')
# Handles both single and double separator lines
parts = re.split(r'(?:# =+\n)+# MODULE: (.+?)\n(?:# =+\n)+', content)
written = 0
for i in range(1, len(parts), 2):
    name = parts[i].strip()
    code = parts[i+1] if i+1 < len(parts) else ''
    # Strip leading separator lines from code body
    code = re.sub(r'^(?:# =+\n)+', '', code)
    write(os.path.join(BASE, name), code)
    written += 1
if written == 0:
    ERRORS.append("No Python modules extracted — check all_python.py delimiter format")
    print(f"  [ERROR] No modules found. Expected '# MODULE: filename' delimiters.")
else:
    print(f"  → {written} Python modules extracted")

# ─────────────────────────────────────────────────────────────────────────────
# 2. SHELL SCRIPTS
# ─────────────────────────────────────────────────────────────────────────────
print("\n[2/5] Extracting shell scripts...")
content = read_file('all_shell.sh')
parts = re.split(r'(?:# =+\n)+# SCRIPT: (.+?)\n(?:# =+\n)+', content)
written = 0
for i in range(1, len(parts), 2):
    name = parts[i].strip()
    code = parts[i+1] if i+1 < len(parts) else ''
    code = re.sub(r'^(?:# =+\n)+', '', code)
    # Strip any duplicate #!/bin/bash lines then prepend one clean shebang
    code = re.sub(r'^#!/bin/bash\s*\n', '', code)
    code = '#!/bin/bash\n' + code
    dest = os.path.join(BASE, name)
    write(dest, code)
    make_executable(dest)
    written += 1
if written == 0:
    ERRORS.append("No shell scripts extracted")
else:
    print(f"  → {written} shell scripts extracted and made executable")

# ─────────────────────────────────────────────────────────────────────────────
# 3. PATCH start.sh — fix path and port to be always relative + port 8080
# ─────────────────────────────────────────────────────────────────────────────
print("\n  [PATCH] Rewriting start.sh to use dynamic paths...")
START = os.path.join(BASE, 'start.sh')
start_content = open(START).read()

# Replace any hardcoded absolute python3 invocation with a relative one
# and ensure port 8080 is used
fixed_start = '''#!/bin/bash
# start.sh — Universal Miner Pro ULTIMATE v5.2
# Always runs relative to its own directory regardless of where you call it from.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

LOG_DIR="$SCRIPT_DIR/logs"
LOG_FILE="$LOG_DIR/ump.log"
PID_FILE="$SCRIPT_DIR/ump.pid"

mkdir -p "$LOG_DIR"

# Verify universal_miner.py exists before trying to start
if [ ! -f "$SCRIPT_DIR/universal_miner.py" ]; then
    echo "[UMP] ERROR: universal_miner.py not found in $SCRIPT_DIR"
    echo "[UMP] Run:  python3 extract_ump.py  first to extract all files."
    exit 1
fi

# Kill any existing instance
if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[UMP] Stopping previous instance (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null
        sleep 1
    fi
    rm -f "$PID_FILE"
fi

echo "[UMP] Starting Universal Miner Pro ULTIMATE v5.2..."
echo "[UMP] Dashboard: http://localhost:8080"
echo "[UMP] Log file : $LOG_FILE"

nohup python3 "$SCRIPT_DIR/universal_miner.py" >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

sleep 2
if kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    echo "[UMP] Running — PID $(cat "$PID_FILE")"
    echo "[UMP] Open:  http://localhost:8080"
    echo "[UMP] Stop:  bash stop.sh"
    echo "[UMP] Logs:  tail -f $LOG_FILE"
else
    echo "[UMP] ERROR: Failed to start. Last log lines:"
    tail -5 "$LOG_FILE" 2>/dev/null
    exit 1
fi
'''
with open(START, 'w') as f:
    f.write(fixed_start)
make_executable(START)
print("  ✓  start.sh patched (dynamic path, port 8080, pre-flight check)")

# ─────────────────────────────────────────────────────────────────────────────
# 4. HTML TEMPLATES
# ─────────────────────────────────────────────────────────────────────────────
print("\n[3/5] Extracting HTML templates...")
templates_dir = os.path.join(BASE, 'templates')
mkdir(templates_dir)

content = read_file('all_html.html')
pattern = r'<!-- ===== TEMPLATE: (.+?) ===== -->\s*<template[^>]*>(.*?)</template>'
matches = re.findall(pattern, content, re.DOTALL)

REQUIRED_TEMPLATES = ['dashboard.html', 'setup.html', 'profiles.html', 'wallet_ui.html']
written_names = []

for name, body in matches:
    name = name.strip()
    dest = os.path.join(templates_dir, name)
    write(dest, body.strip())
    written_names.append(name)

for t in REQUIRED_TEMPLATES:
    dest = os.path.join(templates_dir, t)
    if not os.path.exists(dest):
        print(f"  [ERROR] Required template missing: {t}")
        ERRORS.append(f"Missing template: {t}")
    elif os.path.getsize(dest) < 500:
        print(f"  [WARN]  {t} is too small ({os.path.getsize(dest)} bytes)")

# Copy standalone unified dashboard into templates too
unified_src = os.path.join(BASE, 'ump_unified_dashboard.html')
if os.path.exists(unified_src):
    shutil.copy(unified_src, os.path.join(templates_dir, 'ump_unified_dashboard.html'))
    print(f"  ✓  templates/ump_unified_dashboard.html  (standalone copy)")

print(f"  → {len(written_names)} templates extracted to templates/")

# ─────────────────────────────────────────────────────────────────────────────
# 5. TEXT FILES (requirements.txt etc.)
# ─────────────────────────────────────────────────────────────────────────────
print("\n[4/5] Extracting text files...")
content = read_file('all_text.txt')
parts = re.split(r'---\s+([^\n/\\]+?)\s+(?:\([^)]*\)\s+)?---\n', content)
written = 0
for i in range(1, len(parts), 2):
    name = parts[i].strip()
    body = parts[i+1] if i+1 < len(parts) else ''
    if '.' in name and '/' not in name and '\\' not in name and len(name) < 60:
        write(os.path.join(BASE, name), body.strip() + '\n')
        written += 1
print(f"  → {written} text files extracted")

# ─────────────────────────────────────────────────────────────────────────────
# 6. RUNTIME DIRECTORIES
# ─────────────────────────────────────────────────────────────────────────────
print("\n[5/5] Creating runtime directories...")
for d in ['logs', 'bin', 'bins', 'tmp']:
    path = os.path.join(BASE, d)
    mkdir(path)
    keep = os.path.join(path, '.gitkeep')
    if not os.path.exists(keep):
        open(keep, 'w').close()
    print(f"  ✓  {d}/")

# ─────────────────────────────────────────────────────────────────────────────
# PATCH install_miner.sh — fix gcc/compiler issues and set -e abort behaviour
# ─────────────────────────────────────────────────────────────────────────────
print("\n  [PATCH] Hardening install_miner.sh...")
INST = os.path.join(BASE, 'install_miner.sh')
if os.path.exists(INST):
    inst = open(INST).read()
    # Remove "set -e" so a failed cpuminer build doesn't abort everything
    inst = inst.replace('\nset -e\n', '\n# set -e removed — build failures are handled per-step\n')
    # Ensure gcc and libc6-dev are in the apt install list (fixes "C compiler cannot create executables")
    inst = inst.replace(
        'build-essential \\',
        'build-essential gcc libc6-dev \\'
    )
    with open(INST, 'w') as f:
        f.write(inst)
    make_executable(INST)
    print("  ✓  install_miner.sh patched (removed set -e, added gcc/libc6-dev)")

# ─────────────────────────────────────────────────────────────────────────────
# VERIFY — check all critical files are present and non-empty
# ─────────────────────────────────────────────────────────────────────────────
print("\n[VERIFY] Checking critical files...")
critical = [
    ('universal_miner.py',          10_000),
    ('miner_config.py',             5_000),
    ('wallet_core.py',              10_000),
    ('wallet_api.py',               2_000),
    ('miner_swarm.py',              2_000),
    ('start.sh',                    200),
    ('stop.sh',                     100),
    ('requirements.txt',            20),
    ('templates/dashboard.html',    5_000),
    ('templates/setup.html',        5_000),
    ('templates/profiles.html',     2_000),
    ('templates/wallet_ui.html',    5_000),
]
all_ok = True
for fname, min_size in critical:
    path = os.path.join(BASE, fname)
    exists = os.path.exists(path)
    size   = os.path.getsize(path) if exists else 0
    ok     = exists and size >= min_size
    mark   = '✓' if ok else '✗'
    status = f'{size:,} bytes' if exists else 'MISSING'
    print(f"  {mark}  {fname:<42} {status}")
    if not ok:
        all_ok = False
        ERRORS.append(f"Bad file: {fname} ({status})")

# ─────────────────────────────────────────────────────────────────────────────
# WRITE setup_all.sh — one-shot master installer
# ─────────────────────────────────────────────────────────────────────────────
setup_all = '''#!/bin/bash
# setup_all.sh — One-shot UMP installer
# Run once after extracting the ZIP:
#   python3 extract_ump.py && bash setup_all.sh
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
echo "=================================================="
echo "  UMP v5.2 — Full Install"
echo "=================================================="
echo ""
echo "[1/3] Installing pip dependencies..."
pip3 install --break-system-packages -r requirements.txt 2>/dev/null || \
    pip3 install -r requirements.txt
echo "  ✓ pip done"
echo ""
echo "[2/3] Building miner binaries..."
bash install_miner.sh
echo "  ✓ binaries done"
echo ""
echo "[3/3] Launching dashboard..."
bash start.sh
echo ""
echo "Done. Open http://localhost:8080"
'''
write(os.path.join(BASE, 'setup_all.sh'), setup_all)
make_executable(os.path.join(BASE, 'setup_all.sh'))

# ─────────────────────────────────────────────────────────────────────────────
# FINAL SUMMARY
# ─────────────────────────────────────────────────────────────────────────────
if ERRORS:
    print(f"\n⚠  {len(ERRORS)} issue(s) found:")
    for e in ERRORS:
        print(f"   • {e}")
    print("\nFix the above before running ./start.sh")
else:
    print("""
╔══════════════════════════════════════════════════╗
║  ✓  Extraction complete — all files verified!   ║
║                                                  ║
║  QUICK START (pip + binaries + launch):          ║
║    bash setup_all.sh                             ║
║                                                  ║
║  OR step by step:                                ║
║    pip install -r requirements.txt \\             ║
║        --break-system-packages                   ║
║    bash install_miner.sh                         ║
║    bash start.sh                                 ║
║                                                  ║
║  Dashboard: http://localhost:8080                ║
║  Setup:     http://localhost:8080/setup          ║
║  Wallet:    http://localhost:8080/wallet         ║
╚══════════════════════════════════════════════════╝""")
