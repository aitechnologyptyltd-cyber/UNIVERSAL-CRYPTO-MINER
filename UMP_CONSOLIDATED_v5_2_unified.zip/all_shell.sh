#!/usr/bin/env bash
# =============================================================================
# UNIVERSAL MINER PRO - ALL SHELL SCRIPTS (CONSOLIDATED v5.2)
# Merged: all .sh files, largest/newest versions used
# install_universal_miner.sh: from ULTIMATE_v4_1_EXTENDED (21544 bytes, largest)
# install_ump_universal.sh: from UMP_MERGED_FINAL_v4 (23582 bytes, largest)
# install_miner.sh: Android-specific, from Android_Addition-1 (unique)
# All others from UMPV5.2
# =============================================================================


# =============================================================================
# SCRIPT: install_universal_miner.sh
# =============================================================================

#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  install_universal_miner.sh — Universal Miner Pro ULTIMATE EDITION v4.0
#  Auto-detects: Linux x86_64 | aarch64 | armv7l | macOS | Android/Termux
#  Installs:     System deps | Python | XMRig (from source)
#  Multi-pool:   Kryptex | ViaBTC | Unmineable | MPH | MoneroOcean | Binance
# ═══════════════════════════════════════════════════════════════════════════════

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'
YELLOW='\033[1;33m'; BOLD='\033[1m'; PURPLE='\033[0;35m'; NC='\033[0m'

log_ok()   { echo -e "${GREEN}  ✓ $1${NC}"; }
log_warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
log_err()  { echo -e "${RED}  ✗ $1${NC}"; }
log_info() { echo -e "${CYAN}  → $1${NC}"; }
log_step() { echo -e "\n${BOLD}${CYAN}[$1] $2${NC}"; }

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   ⛏  UNIVERSAL MINER PRO — ULTIMATE EDITION v4.0           ║"
echo "║      Multi-Arch | Multi-Pool | Multi-Coin | Dual-Algo      ║"
echo "║      Kryptex | ViaBTC | Unmineable | MPH | MoneroOcean      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"
LOG_DIR="$SCRIPT_DIR/logs"
TMP_DIR="/tmp/ump_$$"
BUILD_LOG="$SCRIPT_DIR/build.log"

mkdir -p "$BIN_DIR" "$LOG_DIR" "$TMP_DIR"
echo "Install started: $(date)" > "$BUILD_LOG"

# ═══════════════════════════════════════════════
# STEP 0 — Detect platform and architecture
# ═══════════════════════════════════════════════
log_step "0/8" "Detecting platform and architecture..."

ARCH=$(uname -m)
OS_TYPE=$(uname -s)
PLATFORM="unknown"
PKG_MGR="unknown"
IS_ANDROID=0
IS_TERMUX=0

# Detect OS
case "$OS_TYPE" in
    Linux*)
        PLATFORM="linux"
        # Check for Android
        if [ -f /proc/version ]; then
            grep -qi android /proc/version && IS_ANDROID=1
        fi
        if [ -d /data/data/com.termux ]; then
            IS_TERMUX=1
            PLATFORM="termux"
        fi
        # Detect package manager
        if command -v apt-get &>/dev/null; then     PKG_MGR="apt";
        elif command -v dnf    &>/dev/null; then    PKG_MGR="dnf";
        elif command -v yum    &>/dev/null; then    PKG_MGR="yum";
        elif command -v pacman &>/dev/null; then    PKG_MGR="pacman";
        elif command -v zypper &>/dev/null; then    PKG_MGR="zypper";
        elif command -v pkg    &>/dev/null; then    PKG_MGR="pkg";   # Termux
        fi
        ;;
    Darwin*)
        PLATFORM="macos"
        ARCH=$(uname -m)
        [ "$ARCH" = "arm64" ] && ARCH="aarch64_mac"
        PKG_MGR="brew"
        ;;
    MINGW*|CYGWIN*|MSYS*)
        PLATFORM="windows"
        PKG_MGR="choco"
        ;;
esac

# CPU count
CPU_COUNT=1
if command -v nproc &>/dev/null; then
    CPU_COUNT=$(nproc)
elif [ -f /proc/cpuinfo ]; then
    CPU_COUNT=$(grep -c processor /proc/cpuinfo 2>/dev/null || echo 1)
fi

# Determine recommended threads (leave 1 core free on small devices)
if [ "$CPU_COUNT" -le 2 ]; then
    REC_THREADS=1
elif [ "$CPU_COUNT" -le 4 ]; then
    REC_THREADS=$((CPU_COUNT - 1))
else
    REC_THREADS=$((CPU_COUNT - 2))
fi

echo ""
echo -e "  ${BOLD}Platform  :${NC} $PLATFORM ($OS_TYPE)"
echo -e "  ${BOLD}Arch      :${NC} $ARCH"
echo -e "  ${BOLD}Pkg Mgr   :${NC} $PKG_MGR"
echo -e "  ${BOLD}CPU cores :${NC} $CPU_COUNT  (recommended threads: $REC_THREADS)"
echo -e "  ${BOLD}Android   :${NC} $IS_ANDROID  |  Termux: $IS_TERMUX"
echo ""

# Architecture-specific cmake flags
CMAKE_FLAGS=""
LDFLAGS_EXTRA=""
case "$ARCH" in
    armv7l|armhf)
        CMAKE_FLAGS="-DCMAKE_C_FLAGS=-O2 -DCMAKE_CXX_FLAGS=-O2"
        log_info "armv7l: Using -O2 (safe for 32-bit ARM)"
        ;;
    aarch64)
        CMAKE_FLAGS="-DCMAKE_C_FLAGS=-O3 -DCMAKE_CXX_FLAGS=-O3"
        log_info "aarch64: Using -O3 (64-bit ARM)"
        ;;
    x86_64)
        CMAKE_FLAGS="-DCMAKE_C_FLAGS=-O3 -DCMAKE_CXX_FLAGS=-O3 -DCMAKE_C_FLAGS=-march=native"
        log_info "x86_64: Using -O3 -march=native"
        ;;
    aarch64_mac)
        CMAKE_FLAGS="-DCMAKE_C_FLAGS=-O3 -DCMAKE_CXX_FLAGS=-O3"
        log_info "Apple Silicon (M-series): Using -O3"
        ;;
esac

# ═══════════════════════════════════════════════
# STEP 1 — Internet check
# ═══════════════════════════════════════════════
log_step "1/8" "Checking internet connectivity..."
CURL_BIN=""
if command -v curl &>/dev/null; then
    CURL_BIN="curl"
elif command -v wget &>/dev/null; then
    CURL_BIN="wget"
fi

if [ -n "$CURL_BIN" ]; then
    if curl -s --max-time 10 https://github.com >/dev/null 2>&1 || \
       wget -q --timeout=10 -O /dev/null https://github.com 2>/dev/null; then
        log_ok "Internet reachable"
    else
        log_warn "Internet not reachable — some steps may fail"
    fi
else
    log_warn "curl/wget not found — installing curl first"
fi

# ═══════════════════════════════════════════════
# STEP 2 — System packages
# ═══════════════════════════════════════════════
log_step "2/8" "Installing system packages for $PKG_MGR ($ARCH)..."

install_apt() {
    apt-get update -qq 2>/dev/null || true
    apt-get install -y \
        build-essential cmake git curl wget \
        libuv1-dev libssl-dev libhwloc-dev \
        python3 python3-pip python3-venv \
        screen htop procps lsof \
        --no-install-recommends 2>&1 | grep -E "^(Get:|Inst|Err)" || true

    # libuv fallback
    dpkg -l libuv1-dev 2>/dev/null | grep -q "^ii" || {
        log_warn "libuv1-dev not found — trying libuv-dev"
        apt-get install -y libuv-dev --no-install-recommends 2>/dev/null || true
    }
    # libssl fallback for older Ubuntu
    dpkg -l libssl-dev 2>/dev/null | grep -q "^ii" || {
        apt-get install -y libssl1.0-dev 2>/dev/null || true
    }
}

install_dnf() {
    dnf install -y \
        gcc gcc-c++ cmake git curl wget \
        libuv-devel openssl-devel hwloc-devel \
        python3 python3-pip \
        screen htop procps 2>&1 | grep -E "^(Install|Error)" || true
}

install_pacman() {
    pacman -Sy --noconfirm \
        base-devel cmake git curl \
        libuv openssl hwloc \
        python python-pip \
        screen htop 2>&1 | grep -E "^(installing|error)" || true
}

install_pkg_termux() {
    pkg update -y 2>/dev/null || true
    pkg install -y \
        build-essential cmake git curl wget \
        libuv openssl \
        python 2>&1 | grep -E "^(Get:|Inst|Err)" || true
}

install_brew() {
    if ! command -v brew &>/dev/null; then
        log_warn "Homebrew not found — attempting install"
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" 2>/dev/null || true
    fi
    brew install cmake git openssl libuv hwloc python3 2>/dev/null || true
}

case "$PKG_MGR" in
    apt)     install_apt     ;;
    dnf|yum) install_dnf     ;;
    pacman)  install_pacman  ;;
    pkg)     install_pkg_termux ;;
    brew)    install_brew    ;;
    *)       log_warn "Unknown package manager — skipping system packages" ;;
esac

log_ok "System packages done"

# ═══════════════════════════════════════════════
# STEP 3 — Python packages
# ═══════════════════════════════════════════════
log_step "3/8" "Installing Python packages..."

PY_PKGS="flask requests apscheduler psutil"

# Try multiple pip invocation styles
install_python_pkgs() {
    local pkgs="$1"
    if command -v pip3 &>/dev/null; then
        pip3 install --break-system-packages --quiet $pkgs 2>/dev/null && return 0
        pip3 install --quiet $pkgs 2>/dev/null && return 0
    fi
    if command -v pip &>/dev/null; then
        pip install --break-system-packages --quiet $pkgs 2>/dev/null && return 0
        pip install --quiet $pkgs 2>/dev/null && return 0
    fi
    if command -v python3 &>/dev/null; then
        python3 -m pip install --break-system-packages --quiet $pkgs 2>/dev/null && return 0
        python3 -m pip install --quiet $pkgs 2>/dev/null && return 0
    fi
    return 1
}

if install_python_pkgs "$PY_PKGS"; then
    # Verify
    PY_BIN="python3"
    command -v python3 &>/dev/null || PY_BIN="python"
    if $PY_BIN -c "import flask, requests, apscheduler" 2>/dev/null; then
        log_ok "Python packages OK: flask requests apscheduler"
    else
        log_warn "Some Python packages may be missing — check manually"
    fi
    # psutil is optional
    $PY_BIN -c "import psutil" 2>/dev/null && log_ok "psutil OK (CPU temp monitoring)" || \
        log_warn "psutil not installed — temperature monitoring disabled"
else
    log_err "Python package install failed — check pip"
fi

# ═══════════════════════════════════════════════
# STEP 4 — Build XMRig from source
# ═══════════════════════════════════════════════
log_step "4/8" "Building XMRig (CPU miner — RandomX)..."

if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armhf" ]; then
    log_info "ARM 32-bit detected — this takes 15-25 min. Please wait..."
elif [ "$ARCH" = "aarch64" ]; then
    log_info "ARM 64-bit — build takes ~10-15 min..."
else
    log_info "x86_64/macOS — build takes ~5-10 min..."
fi

XMRIG_DIR="$TMP_DIR/xmrig"
XMRIG_OK=0

build_xmrig() {
    local url="$1"
    rm -rf "$XMRIG_DIR"
    log_info "Cloning XMRig from $url ..."
    git clone --depth=1 "$url" "$XMRIG_DIR" >> "$BUILD_LOG" 2>&1 || return 1
    cd "$XMRIG_DIR"
    mkdir -p build && cd build

    log_info "Running cmake..."
    cmake .. \
        -DWITH_HWLOC=OFF \
        -DWITH_OPENCL=OFF \
        -DWITH_CUDA=OFF \
        -DWITH_RANDOMX=ON \
        -DWITH_CN_LITE=ON \
        -DCMAKE_BUILD_TYPE=Release \
        $CMAKE_FLAGS \
        >> "$BUILD_LOG" 2>&1 || {
        log_warn "cmake attempt 1 failed — retrying minimal config"
        cmake .. \
            -DWITH_HWLOC=OFF \
            -DWITH_OPENCL=OFF \
            -DWITH_CUDA=OFF \
            -DCMAKE_BUILD_TYPE=Release \
            >> "$BUILD_LOG" 2>&1 || return 1
    }

    log_info "Compiling (make -j$CPU_COUNT) ..."
    make -j"$CPU_COUNT" >> "$BUILD_LOG" 2>&1 || {
        log_warn "Parallel build failed — retrying single-thread"
        make >> "$BUILD_LOG" 2>&1 || return 1
    }

    [ -f xmrig ] || return 1
    cp xmrig "$BIN_DIR/xmrig"
    chmod +x "$BIN_DIR/xmrig"
    log_ok "XMRig built → $BIN_DIR/xmrig"
    return 0
}

XMRIG_URLS=(
    "https://github.com/xmrig/xmrig.git"
    "https://github.com/xmrig/xmrig"
)

for url in "${XMRIG_URLS[@]}"; do
    build_xmrig "$url" && XMRIG_OK=1 && break
    log_warn "Failed with $url — trying next..."
done

if [ "$XMRIG_OK" -eq 0 ]; then
    log_warn "XMRig build failed — trying prebuilt binary for $ARCH"
    # Attempt prebuilt download
    case "$ARCH" in
        x86_64)
            PREBUILT_URL="https://github.com/xmrig/xmrig/releases/latest/download/xmrig-6.21.0-linux-static-x64.tar.gz"
            ;;
        aarch64)
            PREBUILT_URL="https://github.com/xmrig/xmrig/releases/latest/download/xmrig-6.21.0-linux-arm64.tar.gz"
            ;;
        armv7l|armhf)
            PREBUILT_URL="https://github.com/xmrig/xmrig/releases/latest/download/xmrig-6.21.0-linux-armv7.tar.gz"
            ;;
        *)
            PREBUILT_URL=""
            ;;
    esac

    if [ -n "$PREBUILT_URL" ]; then
        log_info "Downloading prebuilt from $PREBUILT_URL"
        TGZ="$TMP_DIR/xmrig_prebuilt.tar.gz"
        if curl -sL "$PREBUILT_URL" -o "$TGZ" 2>/dev/null || \
           wget -q "$PREBUILT_URL" -O "$TGZ" 2>/dev/null; then
            tar -xzf "$TGZ" -C "$TMP_DIR" >> "$BUILD_LOG" 2>&1
            PREBUILT_BIN=$(find "$TMP_DIR" -name "xmrig" -type f | head -1)
            if [ -n "$PREBUILT_BIN" ]; then
                cp "$PREBUILT_BIN" "$BIN_DIR/xmrig"
                chmod +x "$BIN_DIR/xmrig"
                log_ok "Prebuilt XMRig installed"
                XMRIG_OK=1
            fi
        fi
    fi

    if [ "$XMRIG_OK" -eq 0 ]; then
        log_err "XMRig install failed. Place xmrig binary in: $BIN_DIR/"
        log_err "See build log: $BUILD_LOG"
    fi
fi

# ═══════════════════════════════════════════════

# ═══════════════════════════════════════════════
# STEP 5 — Build cpuminer-multi (X11 / unMineable)
# ═══════════════════════════════════════════════
log_step "5/8" "Building cpuminer-multi (X11 algo — unMineable payout)..."

CPUMINER_OK=0
CPUMINER_DIR="$TMP_DIR/cpuminer"

build_cpuminer() {
    local url="$1"
    log_info "Cloning cpuminer-multi from $url ..."
    git clone --depth 1 "$url" "$CPUMINER_DIR" >> "$BUILD_LOG" 2>&1 || return 1
    cd "$CPUMINER_DIR" || return 1
    ./autogen.sh >> "$BUILD_LOG" 2>&1 || return 1
    CFLAGS_CPU=""
    case "$ARCH" in
        armv7*|armhf) CFLAGS_CPU="-mfpu=neon" ;;
        aarch64)      CFLAGS_CPU="-march=armv8-a+crypto" ;;
        x86_64)       CFLAGS_CPU="-march=native" ;;
    esac
    CFLAGS="$CFLAGS_CPU -O3" ./configure --with-curl >> "$BUILD_LOG" 2>&1 || return 1
    make -j"$CPU_COUNT" >> "$BUILD_LOG" 2>&1 || return 1
    [ -f cpuminer ] || return 1
    cp cpuminer "$BIN_DIR/cpuminer-multi"
    chmod +x "$BIN_DIR/cpuminer-multi"
    log_ok "cpuminer-multi built → $BIN_DIR/cpuminer-multi"
    return 0
}

# Deps: autoconf, automake, libcurl
if [ "$IS_TERMUX" -eq 1 ]; then
    pkg install -y autoconf automake curl 2>/dev/null || true
elif [ "$PKG_MGR" = "apt" ]; then
    apt-get install -y autoconf automake libcurl4-openssl-dev >> "$BUILD_LOG" 2>&1 || true
elif [ "$PKG_MGR" = "pacman" ]; then
    pacman -Sy --noconfirm autoconf automake curl >> "$BUILD_LOG" 2>&1 || true
elif [ "$PKG_MGR" = "brew" ]; then
    brew install autoconf automake curl >> "$BUILD_LOG" 2>&1 || true
fi

for url in     "https://github.com/tpruvot/cpuminer-multi.git"     "https://github.com/JayDDee/cpuminer-opt.git"; do
    build_cpuminer "$url" && CPUMINER_OK=1 && break
    rm -rf "$CPUMINER_DIR"
done

if [ "$CPUMINER_OK" -eq 0 ]; then
    log_warn "cpuminer-multi build failed — X11 algo disabled."
    log_warn "To enable: place 'cpuminer-multi' binary in: $BIN_DIR/"
fi

# STEP 5 — GPU miner detection (optional)
# ═══════════════════════════════════════════════
log_step "6/8" "GPU miner detection..."

GPU_DETECTED=0
GPU_TYPE="none"

# NVIDIA check
if command -v nvidia-smi &>/dev/null; then
    GPU_TYPE="nvidia"
    GPU_DETECTED=1
    GPU_INFO=$(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null | head -1)
    log_ok "NVIDIA GPU: $GPU_INFO"
    log_info "GPU mining available — lolMiner / T-Rex / GMiner can be placed in: $BIN_DIR/"
fi

# AMD check
if command -v rocm-smi &>/dev/null || lspci 2>/dev/null | grep -qi "amd\|radeon"; then
    GPU_TYPE="amd"
    GPU_DETECTED=1
    log_ok "AMD GPU detected"
    log_info "GPU mining available — lolMiner / TeamRedMiner can be placed in: $BIN_DIR/"
fi

if [ "$GPU_DETECTED" -eq 0 ]; then
    log_info "No discrete GPU detected — CPU mining only"
fi

# ═══════════════════════════════════════════════
# STEP 6 — Write auto-start scripts
# ═══════════════════════════════════════════════
log_step "7/8" "Writing startup scripts..."

# start.sh
cat > "$SCRIPT_DIR/start.sh" << 'STARTEOF'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
PY_BIN="python3"
command -v python3 &>/dev/null || PY_BIN="python"
echo "Starting Universal Miner Pro on http://0.0.0.0:5001"
$PY_BIN universal_miner.py
STARTEOF
chmod +x "$SCRIPT_DIR/start.sh"

# start_screen.sh (background via screen)
cat > "$SCRIPT_DIR/start_screen.sh" << 'SCREENEOF'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
PY_BIN="python3"
command -v python3 &>/dev/null || PY_BIN="python"
screen -dmS ump_miner $PY_BIN universal_miner.py
echo "Started in background (screen session: ump_miner)"
echo "Attach with: screen -r ump_miner"
echo "Dashboard: http://localhost:5001"
SCREENEOF
chmod +x "$SCRIPT_DIR/start_screen.sh"

# stop.sh
cat > "$SCRIPT_DIR/stop.sh" << 'STOPEOF'
#!/bin/bash
curl -s -X POST http://localhost:5001/mine/stop 2>/dev/null
screen -X -S ump_miner quit 2>/dev/null
echo "Stopped"
STOPEOF
chmod +x "$SCRIPT_DIR/stop.sh"

# status.sh
cat > "$SCRIPT_DIR/status.sh" << 'STATEOF'
#!/bin/bash
curl -s http://localhost:5001/health 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "Not running"
STATEOF
chmod +x "$SCRIPT_DIR/status.sh"

log_ok "start.sh | start_screen.sh | stop.sh | status.sh created"

# ═══════════════════════════════════════════════
# STEP 7 — Final verification + summary
# ═══════════════════════════════════════════════
log_step "8/8" "Final verification..."

ERRORS=0

# Python check
PY_BIN="python3"
command -v python3 &>/dev/null || PY_BIN="python"
if $PY_BIN -c "import flask" 2>/dev/null; then
    log_ok "Flask OK"
else
    log_err "Flask missing — run: pip3 install flask"
    ERRORS=$((ERRORS + 1))
fi

# XMRig binary
if [ -f "$BIN_DIR/xmrig" ] && [ -x "$BIN_DIR/xmrig" ]; then
    XMRIG_VER=$("$BIN_DIR/xmrig" --version 2>/dev/null | head -1)
    log_ok "XMRig: $XMRIG_VER"
else
    log_warn "XMRig binary not found — CPU mining disabled"
    ERRORS=$((ERRORS + 1))
fi

# DB init
if $PY_BIN -c "from miner_config import init_db; init_db(); print('DB OK')" 2>/dev/null; then
    log_ok "SQLite DB initialized"
else
    log_err "DB init failed — check miner_config.py"
    ERRORS=$((ERRORS + 1))
fi

# Cleanup
rm -rf "$TMP_DIR"

echo ""
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}  INSTALL SUMMARY${NC}"
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"
echo -e "  Platform  : ${GREEN}$PLATFORM${NC}"
echo -e "  Arch      : ${GREEN}$ARCH${NC}"
echo -e "  CPU Cores : ${GREEN}$CPU_COUNT${NC} (recommended threads: ${GREEN}$REC_THREADS${NC})"
echo -e "  GPU       : ${GREEN}$GPU_TYPE${NC}"
echo -e "  XMRig     : $([ -f "$BIN_DIR/xmrig" ] && echo "${GREEN}READY${NC}" || echo "${RED}MISSING${NC}")"
echo -e "  cpuminer  : $([ -f "$BIN_DIR/cpuminer-multi" ] && echo "${GREEN}READY (X11)${NC}" || echo "${YELLOW}NOT BUILT${NC}")"
echo -e "  Errors    : $([ "$ERRORS" -eq 0 ] && echo "${GREEN}0${NC}" || echo "${RED}$ERRORS${NC}")"
echo ""
if [ "$ERRORS" -eq 0 ]; then
    echo -e "  ${GREEN}${BOLD}✓ Installation complete!${NC}"
    echo ""
    echo -e "  ${BOLD}Start dashboard:${NC}"
    echo -e "    ${CYAN}./start.sh${NC}           (foreground)"
    echo -e "    ${CYAN}./start_screen.sh${NC}    (background)"
    echo ""
    echo -e "  ${BOLD}Open browser:${NC}"
    echo -e "    ${CYAN}http://localhost:5001${NC}"
    echo ""
    echo -e "  ${BOLD}Configure pools at:${NC}"
    echo -e "    ${CYAN}http://localhost:5001/setup${NC}"
else
    echo -e "  ${YELLOW}Installation completed with $ERRORS issue(s).${NC}"
    echo -e "  Check build log: ${CYAN}$BUILD_LOG${NC}"
fi
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"


# =============================================================================
# SCRIPT: install_ump_universal.sh
# =============================================================================

#!/bin/bash
# =============================================================================
#  install_ump_universal.sh
#  Universal Miner Pro ULTIMATE v4.2 EXTENDED -- Universal Installer
#  NEW: Hardware detection | GPU miners | Profit switching | 60+ coins
#  Supports: Userland Ubuntu armv7l | aarch64 | Linux x86_64 | Termux
# =============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

log_ok()   { echo -e "${GREEN}  [OK]  $1${NC}"; }
log_warn() { echo -e "${YELLOW}  [WARN] $1${NC}"; }
log_err()  { echo -e "${RED}  [ERR] $1${NC}"; }
log_info() { echo -e "${CYAN}  [-->] $1${NC}"; }
log_step() { echo -e "\n${BOLD}${CYAN}=== STEP $1: $2 ===${NC}"; }

echo -e "${CYAN}"
echo "============================================================"
echo "   UMP UNIVERSAL INSTALLER v4.2 EXTENDED"
echo "   Hardware Detect | GPU Support | Profit Switching"
echo "   60+ Coins | 9 Pools | 40-Node Swarm"
echo "============================================================"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"
LOG_DIR="$SCRIPT_DIR/logs"
TMP_DIR="/tmp/ump_universal_$$"
BUILD_LOG="$SCRIPT_DIR/install.log"
HW_PROFILE="$SCRIPT_DIR/ump_hw_profile.json"
ERRORS=0
PY_BIN="python3"

mkdir -p "$BIN_DIR" "$LOG_DIR" "$TMP_DIR"
echo "UMP Universal Install started: $(date)" > "$BUILD_LOG"

# =============================================================================
# STEP 1 -- DETECT PLATFORM AND ARCHITECTURE
# =============================================================================
log_step "1/12" "Detecting platform and architecture"

ARCH="$(uname -m)"
PLATFORM="linux"
PKG_MGR="apt"
IS_TERMUX=0
IS_USERLAND=0

if [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=1
    PLATFORM="termux"
    PKG_MGR="pkg"
fi

if [ "$IS_TERMUX" -eq 0 ]; then
    if grep -qi "userland" /proc/version 2>/dev/null; then
        IS_USERLAND=1
        PLATFORM="userland_ubuntu"
    fi
fi

CPU_COUNT="$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null || echo 2)"
BUILD_JOBS="$(( CPU_COUNT > 1 ? CPU_COUNT - 1 : 1 ))"

log_ok "Platform   : $PLATFORM"
log_ok "Arch       : $ARCH"
log_ok "CPU Cores  : $CPU_COUNT (build jobs: $BUILD_JOBS)"
log_ok "Build log  : $BUILD_LOG"

# =============================================================================
# STEP 2 -- SYSTEM PACKAGES (apt or pkg)
# =============================================================================
log_step "2/12" "Installing system packages"

# Core build tools needed for everything
APT_CORE="build-essential git wget curl \
    libssl-dev libuv1-dev libffi-dev \
    automake autoconf libtool pkg-config \
    libjansson-dev libcurl4-openssl-dev \
    libgmp-dev \
    python3 python3-pip python3-dev \
    screen unzip"

# libhwloc only on 64-bit (not available / causes issues on armv7l)
APT_HWLOC=""
if [ "$ARCH" != "armv7l" ] && [ "$ARCH" != "armv7" ]; then
    APT_HWLOC="libhwloc-dev"
fi

# OpenCL for GPU mining (x86_64 only)
APT_OPENCL=""
if [ "$ARCH" = "x86_64" ]; then
    APT_OPENCL="ocl-icd-opencl-dev opencl-headers clinfo"
fi

PKG_CORE="python git wget curl openssl automake autoconf libtool \
    pkg-config libgmp screen unzip"

if [ "$PKG_MGR" = "apt" ]; then
    log_info "Running apt-get update..."
    apt-get update -y >> "$BUILD_LOG" 2>&1 || log_warn "apt-get update had warnings"

    ALL_APT="$APT_CORE $APT_HWLOC $APT_OPENCL"
    for pkg in $ALL_APT; do
        log_info "Installing: $pkg"
        apt-get install -y --no-install-recommends "$pkg" >> "$BUILD_LOG" 2>&1 \
            && log_ok "$pkg" \
            || log_warn "$pkg not available -- skipping"
    done

elif [ "$PKG_MGR" = "pkg" ]; then
    log_info "Running pkg update..."
    pkg update -y >> "$BUILD_LOG" 2>&1 || true
    for pkg in $PKG_CORE; do
        log_info "Installing: $pkg"
        pkg install -y "$pkg" >> "$BUILD_LOG" 2>&1 \
            && log_ok "$pkg" \
            || log_warn "$pkg not available -- skipping"
    done
fi

# =============================================================================
# STEP 3 -- CMAKE (build from source if missing or version < 3.15)
# =============================================================================
log_step "3/12" "Checking cmake version"

CMAKE_NEEDED_MAJOR=3
CMAKE_NEEDED_MINOR=15
CMAKE_BUILD_VERSION="3.28.3"
NEED_CMAKE=0

if command -v cmake > /dev/null 2>&1; then
    CMAKE_RAW="$(cmake --version 2>/dev/null | head -1)"
    CMAKE_VER="$(echo "$CMAKE_RAW" | grep -o '[0-9][0-9]*\.[0-9][0-9]*' | head -1)"
    CMAKE_MAJ="$(echo "$CMAKE_VER" | cut -d. -f1)"
    CMAKE_MIN="$(echo "$CMAKE_VER" | cut -d. -f2)"
    if [ -z "$CMAKE_MAJ" ]; then
        CMAKE_MAJ=0; CMAKE_MIN=0
    fi
    if [ "$CMAKE_MAJ" -lt "$CMAKE_NEEDED_MAJOR" ]; then
        NEED_CMAKE=1
    elif [ "$CMAKE_MAJ" -eq "$CMAKE_NEEDED_MAJOR" ] && [ "$CMAKE_MIN" -lt "$CMAKE_NEEDED_MINOR" ]; then
        NEED_CMAKE=1
    fi
    if [ "$NEED_CMAKE" -eq 1 ]; then
        log_warn "cmake $CMAKE_VER is too old (need >= ${CMAKE_NEEDED_MAJOR}.${CMAKE_NEEDED_MINOR})"
    else
        log_ok "cmake $CMAKE_VER OK"
    fi
else
    log_warn "cmake not found"
    NEED_CMAKE=1
fi

if [ "$NEED_CMAKE" -eq 1 ]; then
    log_info "Building cmake $CMAKE_BUILD_VERSION from source..."
    CMAKE_SRCDIR="$TMP_DIR/cmake_src"
    mkdir -p "$CMAKE_SRCDIR"
    CMAKE_TAR="cmake-${CMAKE_BUILD_VERSION}.tar.gz"
    CMAKE_URL="https://github.com/Kitware/CMake/releases/download/v${CMAKE_BUILD_VERSION}/${CMAKE_TAR}"

    log_info "Downloading cmake source (approx 10MB)..."
    if command -v wget > /dev/null 2>&1; then
        wget -q --show-progress -O "$CMAKE_SRCDIR/$CMAKE_TAR" "$CMAKE_URL" >> "$BUILD_LOG" 2>&1
    else
        curl -L --progress-bar -o "$CMAKE_SRCDIR/$CMAKE_TAR" "$CMAKE_URL" >> "$BUILD_LOG" 2>&1
    fi

    if [ -f "$CMAKE_SRCDIR/$CMAKE_TAR" ] && [ -s "$CMAKE_SRCDIR/$CMAKE_TAR" ]; then
        cd "$CMAKE_SRCDIR"
        tar -xzf "$CMAKE_TAR" >> "$BUILD_LOG" 2>&1
        cd "cmake-${CMAKE_BUILD_VERSION}"
        log_info "Bootstrapping cmake (takes 10-40 min on ARM -- please wait)..."
        ./bootstrap --prefix=/usr/local --parallel="$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
        make -j"$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
        make install >> "$BUILD_LOG" 2>&1
        if command -v cmake > /dev/null 2>&1; then
            log_ok "cmake $(cmake --version | head -1) installed"
        else
            log_err "cmake build failed -- see $BUILD_LOG"
            ERRORS=$((ERRORS + 1))
        fi
        cd "$SCRIPT_DIR"
    else
        log_err "Failed to download cmake source from $CMAKE_URL"
        ERRORS=$((ERRORS + 1))
    fi
fi

# =============================================================================
# STEP 4 -- PYTHON PACKAGES
# =============================================================================
log_step "4/12" "Installing Python packages"

PIP_PKGS="flask requests psutil apscheduler cryptography"

for pkg in $PIP_PKGS; do
    log_info "pip install: $pkg"
    "$PY_BIN" -m pip install "$pkg" \
        --break-system-packages --quiet >> "$BUILD_LOG" 2>&1 \
        && log_ok "$pkg" \
        || log_warn "$pkg had pip warnings"
done

# =============================================================================
# STEP 5 -- RUN HARDWARE DETECTION
# =============================================================================
log_step "5/12" "Running hardware detection"

if [ -f "$SCRIPT_DIR/ump_hardware_detect.py" ]; then
    "$PY_BIN" "$SCRIPT_DIR/ump_hardware_detect.py" 2>&1 | tee -a "$BUILD_LOG"
    if [ -f "$HW_PROFILE" ]; then
        log_ok "Hardware profile saved: $HW_PROFILE"
        # Read capability from profile
        HW_CAPABILITY="$(python3 -c "
import json
try:
    d = json.load(open('$HW_PROFILE'))
    print(d.get('mining_capability','CPU_ONLY'))
except:
    print('CPU_ONLY')
" 2>/dev/null)"
        log_ok "Mining capability: $HW_CAPABILITY"
    else
        log_warn "Hardware profile not saved -- defaulting to CPU_ONLY"
        HW_CAPABILITY="CPU_ONLY"
    fi
else
    log_warn "ump_hardware_detect.py not found -- defaulting to CPU_ONLY"
    HW_CAPABILITY="CPU_ONLY"
fi

# =============================================================================
# STEP 6 -- BUILD XMRIG FROM SOURCE
# =============================================================================
log_step "6/12" "Building XMRig (RandomX CPU miner) from source"

XMRIG_DEST="$BIN_DIR/xmrig"
XMRIG_SRCDIR="$TMP_DIR/xmrig_src"
XMRIG_BUILDDIR="$XMRIG_SRCDIR/build"
XMRIG_REPO="https://github.com/xmrig/xmrig.git"

if [ -f "$XMRIG_DEST" ]; then
    log_ok "XMRig already installed at $XMRIG_DEST"
else
    log_info "Cloning XMRig source..."
    git clone --depth=1 "$XMRIG_REPO" "$XMRIG_SRCDIR" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_err "Failed to clone XMRig from $XMRIG_REPO"
        ERRORS=$((ERRORS + 1))
    else
        mkdir -p "$XMRIG_BUILDDIR"
        cd "$XMRIG_BUILDDIR"

        # Architecture-specific cmake flags
        CMAKE_XMRIG="-DCMAKE_BUILD_TYPE=Release -DXMRIG_DONATE_LEVEL=0"
        if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
            CMAKE_XMRIG="$CMAKE_XMRIG -DWITH_HWLOC=OFF -DWITH_ASM=OFF -DWITH_AVX=OFF"
            log_info "armv7l flags applied: HWLOC=OFF ASM=OFF AVX=OFF"
        elif [ "$ARCH" = "aarch64" ]; then
            CMAKE_XMRIG="$CMAKE_XMRIG -DWITH_HWLOC=OFF"
            log_info "aarch64 flags applied: HWLOC=OFF"
        fi

        log_info "Running cmake for XMRig..."
        cmake .. $CMAKE_XMRIG >> "$BUILD_LOG" 2>&1
        if [ $? -ne 0 ]; then
            log_err "XMRig cmake configure failed"
            ERRORS=$((ERRORS + 1))
        else
            log_info "Compiling XMRig (5-30 min on ARM)..."
            make -j"$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
            if [ -f "$XMRIG_BUILDDIR/xmrig" ]; then
                cp "$XMRIG_BUILDDIR/xmrig" "$XMRIG_DEST"
                chmod +x "$XMRIG_DEST"
                log_ok "XMRig built: $XMRIG_DEST"
            else
                log_warn "Source build failed -- falling back to pre-built binary"
                XMRIG_VER="6.22.0"
                if [ "$ARCH" = "aarch64" ]; then
                    XMRIG_TAG="linux-static-aarch64"
                elif [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ]; then
                    XMRIG_TAG="linux-static-armv7"
                else
                    XMRIG_TAG="linux-static-x64"
                fi
                XMRIG_FILE="xmrig-${XMRIG_VER}-${XMRIG_TAG}.tar.gz"
                XMRIG_URL="https://github.com/xmrig/xmrig/releases/download/v${XMRIG_VER}/${XMRIG_FILE}"
                log_info "Downloading pre-built XMRig: $XMRIG_FILE"
                wget -q -O "$TMP_DIR/$XMRIG_FILE" "$XMRIG_URL" >> "$BUILD_LOG" 2>&1 \
                    || curl -L -o "$TMP_DIR/$XMRIG_FILE" "$XMRIG_URL" >> "$BUILD_LOG" 2>&1
                if [ -f "$TMP_DIR/$XMRIG_FILE" ] && [ -s "$TMP_DIR/$XMRIG_FILE" ]; then
                    tar -xzf "$TMP_DIR/$XMRIG_FILE" -C "$TMP_DIR" >> "$BUILD_LOG" 2>&1
                    FOUND="$(find "$TMP_DIR" -name 'xmrig' -type f | grep -v src | head -1)"
                    if [ -n "$FOUND" ]; then
                        cp "$FOUND" "$XMRIG_DEST"
                        chmod +x "$XMRIG_DEST"
                        log_ok "Pre-built XMRig installed: $XMRIG_DEST"
                    else
                        log_err "XMRig binary not found in archive"
                        ERRORS=$((ERRORS + 1))
                    fi
                else
                    log_err "Failed to download pre-built XMRig"
                    ERRORS=$((ERRORS + 1))
                fi
            fi
        fi
        cd "$SCRIPT_DIR"
    fi
fi

# =============================================================================
# STEP 7 -- BUILD CPUMINER-MULTI FROM SOURCE
# =============================================================================
log_step "7/12" "Building cpuminer-multi (X11/multi-algo) from source"

CPUMINER_DEST="$BIN_DIR/cpuminer-multi"
CPUMINER_SRCDIR="$TMP_DIR/cpuminer_src"
CPUMINER_REPO="https://github.com/tpruvot/cpuminer-multi.git"

if [ -f "$CPUMINER_DEST" ]; then
    log_ok "cpuminer-multi already installed at $CPUMINER_DEST"
else
    log_info "Cloning cpuminer-multi source..."
    git clone --depth=1 "$CPUMINER_REPO" "$CPUMINER_SRCDIR" >> "$BUILD_LOG" 2>&1
    if [ $? -ne 0 ]; then
        log_err "Failed to clone cpuminer-multi"
        ERRORS=$((ERRORS + 1))
    else
        cd "$CPUMINER_SRCDIR"
        log_info "Running autogen.sh..."
        if [ -f "./autogen.sh" ]; then
            ./autogen.sh >> "$BUILD_LOG" 2>&1 \
                || autoreconf --install >> "$BUILD_LOG" 2>&1 \
                || log_warn "autogen had warnings -- continuing"
        else
            autoreconf --install >> "$BUILD_LOG" 2>&1 || true
        fi

        CPUMINER_CONF="--with-crypto --with-curl"
        if [ "$ARCH" = "armv7l" ] || [ "$ARCH" = "armv7" ] || [ "$ARCH" = "aarch64" ]; then
            CPUMINER_CONF="$CPUMINER_CONF --disable-assembly"
            log_info "ARM configure flags: --disable-assembly"
        fi

        log_info "Running configure..."
        ./configure $CPUMINER_CONF >> "$BUILD_LOG" 2>&1
        if [ $? -ne 0 ]; then
            log_err "cpuminer-multi configure failed"
            ERRORS=$((ERRORS + 1))
        else
            log_info "Compiling cpuminer-multi..."
            make -j"$BUILD_JOBS" >> "$BUILD_LOG" 2>&1
            if [ -f "$CPUMINER_SRCDIR/cpuminer" ]; then
                cp "$CPUMINER_SRCDIR/cpuminer" "$CPUMINER_DEST"
                chmod +x "$CPUMINER_DEST"
                log_ok "cpuminer-multi built: $CPUMINER_DEST"
            else
                log_err "cpuminer-multi binary not found after build"
                ERRORS=$((ERRORS + 1))
            fi
        fi
        cd "$SCRIPT_DIR"
    fi
fi

# =============================================================================
# STEP 8 -- GPU MINERS (x86_64 only, skip on ARM)
# =============================================================================
log_step "8/12" "GPU miners"

if [ "$ARCH" = "x86_64" ] && [ "$HW_CAPABILITY" != "CPU_ONLY" ]; then
    log_info "x86_64 + GPU detected -- installing GPU miners"

    LOLMINER_VER="1.88"
    LOLMINER_FILE="lolMiner_v${LOLMINER_VER}_Lin64.tar.gz"
    LOLMINER_URL="https://github.com/Lolliedieb/lolMiner-releases/releases/download/${LOLMINER_VER}/${LOLMINER_FILE}"
    LOLMINER_DEST="$BIN_DIR/lolminer"

    if [ -f "$LOLMINER_DEST" ]; then
        log_ok "lolMiner already installed"
    else
        log_info "Downloading lolMiner $LOLMINER_VER..."
        wget -q -O "$TMP_DIR/$LOLMINER_FILE" "$LOLMINER_URL" >> "$BUILD_LOG" 2>&1 \
            || curl -L -o "$TMP_DIR/$LOLMINER_FILE" "$LOLMINER_URL" >> "$BUILD_LOG" 2>&1
        if [ -f "$TMP_DIR/$LOLMINER_FILE" ] && [ -s "$TMP_DIR/$LOLMINER_FILE" ]; then
            mkdir -p "$TMP_DIR/lolminer_extracted"
            tar -xzf "$TMP_DIR/$LOLMINER_FILE" -C "$TMP_DIR/lolminer_extracted" >> "$BUILD_LOG" 2>&1
            FOUND="$(find "$TMP_DIR/lolminer_extracted" -name 'lolMiner' -type f | head -1)"
            if [ -n "$FOUND" ]; then
                cp "$FOUND" "$LOLMINER_DEST"
                chmod +x "$LOLMINER_DEST"
                log_ok "lolMiner installed: $LOLMINER_DEST"
            else
                log_warn "lolMiner binary not found in archive"
            fi
        else
            log_warn "lolMiner download failed -- skipping"
        fi
    fi

    TREX_VER="0.26.8"
    TREX_FILE="t-rex-${TREX_VER}-linux.tar.gz"
    TREX_URL="https://github.com/trexminer/T-Rex/releases/download/${TREX_VER}/${TREX_FILE}"
    TREX_DEST="$BIN_DIR/t-rex"

    if [ -f "$TREX_DEST" ]; then
        log_ok "T-Rex already installed"
    else
        log_info "Downloading T-Rex $TREX_VER..."
        wget -q -O "$TMP_DIR/$TREX_FILE" "$TREX_URL" >> "$BUILD_LOG" 2>&1 \
            || curl -L -o "$TMP_DIR/$TREX_FILE" "$TREX_URL" >> "$BUILD_LOG" 2>&1
        if [ -f "$TMP_DIR/$TREX_FILE" ] && [ -s "$TMP_DIR/$TREX_FILE" ]; then
            mkdir -p "$TMP_DIR/trex_extracted"
            tar -xzf "$TMP_DIR/$TREX_FILE" -C "$TMP_DIR/trex_extracted" >> "$BUILD_LOG" 2>&1
            FOUND="$(find "$TMP_DIR/trex_extracted" -name 't-rex' -type f | head -1)"
            if [ -n "$FOUND" ]; then
                cp "$FOUND" "$TREX_DEST"
                chmod +x "$TREX_DEST"
                log_ok "T-Rex installed: $TREX_DEST"
            else
                log_warn "T-Rex binary not found in archive"
            fi
        else
            log_warn "T-Rex download failed -- skipping"
        fi
    fi

    TRM_VER="0.10.21"
    TRM_FILE="teamredminer-v${TRM_VER}-linux.tar.gz"
    TRM_URL="https://github.com/todxx/teamredminer/releases/download/v${TRM_VER}/${TRM_FILE}"
    TRM_DEST="$BIN_DIR/teamredminer"

    if [ -f "$TRM_DEST" ]; then
        log_ok "TeamRedMiner already installed"
    else
        log_info "Downloading TeamRedMiner $TRM_VER..."
        wget -q -O "$TMP_DIR/$TRM_FILE" "$TRM_URL" >> "$BUILD_LOG" 2>&1 \
            || curl -L -o "$TMP_DIR/$TRM_FILE" "$TRM_URL" >> "$BUILD_LOG" 2>&1
        if [ -f "$TMP_DIR/$TRM_FILE" ] && [ -s "$TMP_DIR/$TRM_FILE" ]; then
            mkdir -p "$TMP_DIR/trm_extracted"
            tar -xzf "$TMP_DIR/$TRM_FILE" -C "$TMP_DIR/trm_extracted" >> "$BUILD_LOG" 2>&1
            FOUND="$(find "$TMP_DIR/trm_extracted" -name 'teamredminer' -type f | head -1)"
            if [ -n "$FOUND" ]; then
                cp "$FOUND" "$TRM_DEST"
                chmod +x "$TRM_DEST"
                log_ok "TeamRedMiner installed: $TRM_DEST"
            else
                log_warn "TeamRedMiner binary not found in archive"
            fi
        else
            log_warn "TeamRedMiner download failed -- skipping"
        fi
    fi

else
    if [ "$ARCH" != "x86_64" ]; then
        log_info "ARM architecture ($ARCH) -- GPU miners not available -- skipping"
    else
        log_info "CPU_ONLY capability -- GPU miners skipped"
    fi
fi

# =============================================================================
# STEP 9 -- INIT DATABASE
# =============================================================================
log_step "9/12" "Initialising SQLite database"

if "$PY_BIN" -c "from miner_config import init_db; init_db(); print('DB OK')" 2>/dev/null; then
    log_ok "SQLite database initialised"
else
    log_warn "DB init skipped -- will initialise on first Flask start"
fi

# =============================================================================
# STEP 10 -- WRITE START SCRIPTS
# =============================================================================
log_step "10/12" "Writing start scripts"

cat > "$SCRIPT_DIR/start.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
LOG_DIR="logs"
LOG_FILE="$LOG_DIR/ump.log"
PID_FILE="ump.pid"
mkdir -p "$LOG_DIR"
if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[UMP] Stopping previous instance (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null
        sleep 1
    fi
    rm -f "$PID_FILE"
fi
echo "[UMP] Starting Universal Miner Pro ULTIMATE v4.2..."
echo "[UMP] Dashboard: http://localhost:8080"
echo "[UMP] Log file : $LOG_FILE"
nohup python3 universal_miner.py >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"
sleep 1
if kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    echo "[UMP] Running -- PID $(cat "$PID_FILE")"
    echo "[UMP] Open:  http://localhost:8080"
    echo "[UMP] Stop:  bash stop.sh"
    echo "[UMP] Logs:  tail -f $LOG_FILE"
else
    echo "[UMP] ERROR: Failed to start. Check $LOG_FILE"
fi
EOF
chmod +x "$SCRIPT_DIR/start.sh"
log_ok "start.sh"

cat > "$SCRIPT_DIR/start_screen.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
SESSION="ump_miner"
if ! command -v screen > /dev/null 2>&1; then
    echo "[UMP] screen not installed -- installing..."
    apt-get install -y screen 2>/dev/null || pkg install screen 2>/dev/null
fi
if screen -list 2>/dev/null | grep -q "$SESSION"; then
    echo "[UMP] Session '$SESSION' already running."
    echo "[UMP] Reattach: screen -r $SESSION"
else
    screen -dmS "$SESSION" bash start.sh
    sleep 2
    echo "[UMP] Started in screen session: $SESSION"
    echo "[UMP] Reattach : screen -r $SESSION"
    echo "[UMP] Detach   : Ctrl+A then D"
    echo "[UMP] Dashboard: http://localhost:8080"
fi
EOF
chmod +x "$SCRIPT_DIR/start_screen.sh"
log_ok "start_screen.sh"

cat > "$SCRIPT_DIR/detect.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "[UMP] Running hardware detection..."
python3 ump_hardware_detect.py
EOF
chmod +x "$SCRIPT_DIR/detect.sh"
log_ok "detect.sh"

# =============================================================================
# STEP 11 -- VERIFY ALL BINARIES
# =============================================================================
log_step "11/12" "Verifying installed binaries"

log_info "Contents of bin/:"
for f in xmrig cpuminer-multi lolminer t-rex teamredminer; do
    FPATH="$BIN_DIR/$f"
    if [ -f "$FPATH" ]; then
        FSIZE="$(du -sh "$FPATH" 2>/dev/null | cut -f1)"
        log_ok "$f  ($FSIZE)"
    else
        log_info "$f  -- not installed (not required for $HW_CAPABILITY)"
    fi
done

# =============================================================================
# STEP 12 -- CLEANUP AND SUMMARY
# =============================================================================
log_step "12/12" "Cleanup and summary"

rm -rf "$TMP_DIR"

# Evaluate status into variables before printing (avoid nested subshell quoting)
if [ -f "$BIN_DIR/xmrig" ]; then
    S_XMRIG="${GREEN}READY${NC}"
else
    S_XMRIG="${RED}MISSING${NC}"
fi

if [ -f "$BIN_DIR/cpuminer-multi" ]; then
    S_CPUMINER="${GREEN}READY${NC}"
else
    S_CPUMINER="${YELLOW}NOT BUILT${NC}"
fi

if [ -f "$BIN_DIR/lolminer" ]; then
    S_LOL="${GREEN}READY${NC}"
else
    S_LOL="${YELLOW}N/A${NC}"
fi

if [ -f "$BIN_DIR/t-rex" ]; then
    S_TREX="${GREEN}READY${NC}"
else
    S_TREX="${YELLOW}N/A${NC}"
fi

if [ "$ERRORS" -eq 0 ]; then
    S_ERRORS="${GREEN}0${NC}"
else
    S_ERRORS="${RED}$ERRORS${NC}"
fi

echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "${BOLD}  INSTALL SUMMARY${NC}"
echo -e "${CYAN}============================================================${NC}"
echo -e "  Platform    : ${GREEN}$PLATFORM${NC}"
echo -e "  Arch        : ${GREEN}$ARCH${NC}"
echo -e "  CPU Cores   : ${GREEN}$CPU_COUNT${NC}"
echo -e "  Capability  : ${GREEN}$HW_CAPABILITY${NC}"
echo -e "  xmrig       : $(echo -e $S_XMRIG)"
echo -e "  cpuminer    : $(echo -e $S_CPUMINER)"
echo -e "  lolminer    : $(echo -e $S_LOL)"
echo -e "  t-rex       : $(echo -e $S_TREX)"
echo -e "  Errors      : $(echo -e $S_ERRORS)"
echo ""
if [ "$ERRORS" -eq 0 ]; then
    echo -e "  ${GREEN}${BOLD}Installation complete!${NC}"
    echo ""
    echo -e "  ${BOLD}Start dashboard:${NC}"
    echo -e "    ${CYAN}./start.sh${NC}           (foreground)"
    echo -e "    ${CYAN}./start_screen.sh${NC}    (background)"
    echo ""
    echo -e "  ${BOLD}Dashboard URL:${NC}"
    echo -e "    ${CYAN}http://localhost:8080${NC}"
    echo ""
    echo -e "  ${BOLD}First time -- setup your profile:${NC}"
    echo -e "    ${CYAN}http://localhost:8080/setup${NC}"
else
    echo -e "  ${YELLOW}Completed with $ERRORS issue(s) -- check $BUILD_LOG${NC}"
fi
echo -e "${CYAN}============================================================${NC}"


# =============================================================================
# SCRIPT: install_miner.sh
# =============================================================================

#!/bin/bash
# install_miner.sh — Universal Miner Pro
# Installs all dependencies and miner binaries on armv7l Userland Ubuntu
# Run as root: bash install_miner.sh

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════╗"
echo "║   UNIVERSAL MINER PRO — INSTALLER        ║"
echo "║   armv7l Userland Ubuntu Edition         ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"
mkdir -p "$BIN_DIR"
mkdir -p "$SCRIPT_DIR/logs"

# ── Step 1: System packages ───────────────────────────────
echo -e "${YELLOW}[1/6] Installing system packages...${NC}"
apt-get update -qq
apt-get install -y \
    python3 python3-pip python3-venv \
    git curl wget build-essential \
    libssl-dev libcurl4-openssl-dev \
    automake autoconf pkg-config \
    libjansson-dev libgmp-dev \
    screen htop procps \
    --no-install-recommends

echo -e "${GREEN}✓ System packages installed${NC}"

# ── Step 2: Python dependencies ───────────────────────────
echo -e "${YELLOW}[2/6] Installing Python dependencies...${NC}"
pip3 install --break-system-packages flask requests apscheduler 2>/dev/null || \
pip3 install flask requests apscheduler

echo -e "${GREEN}✓ Python packages installed${NC}"

# ── Step 3: cpuminer-multi (DASH X11 + KAS fallback) ──────
echo -e "${YELLOW}[3/6] Building cpuminer-multi (DASH/X11)...${NC}"
CPUMINER_DIR="/tmp/cpuminer-multi"
if [ -d "$CPUMINER_DIR" ]; then rm -rf "$CPUMINER_DIR"; fi
git clone --depth=1 https://github.com/tpruvot/cpuminer-multi.git "$CPUMINER_DIR"
cd "$CPUMINER_DIR"
./autogen.sh
./configure CFLAGS="-O2 -march=armv7-a -mfpu=neon" --disable-assembly
make -j2
cp cpuminer "$BIN_DIR/cpuminer-multi"
chmod +x "$BIN_DIR/cpuminer-multi"
cd "$SCRIPT_DIR"
echo -e "${GREEN}✓ cpuminer-multi built → $BIN_DIR/cpuminer-multi${NC}"

# ── Step 4: cpuminer-opt (KAS kHeavyHash) ─────────────────
echo -e "${YELLOW}[4/6] Building cpuminer-opt (KAS/kHeavyHash)...${NC}"
COPT_DIR="/tmp/cpuminer-opt"
if [ -d "$COPT_DIR" ]; then rm -rf "$COPT_DIR"; fi
git clone --depth=1 https://github.com/JayDDee/cpuminer-opt.git "$COPT_DIR"
cd "$COPT_DIR"
./build-linux-arm.sh 2>/dev/null || {
    ./autogen.sh 2>/dev/null || true
    ./configure CFLAGS="-O2 -march=armv7-a -mfpu=neon" \
        --disable-assembly --with-curl 2>/dev/null || \
    ./configure CFLAGS="-O2" --disable-assembly 2>/dev/null || true
    make -j2 2>/dev/null || true
}
if [ -f "cpuminer" ]; then
    cp cpuminer "$BIN_DIR/cpuminer-opt"
    chmod +x "$BIN_DIR/cpuminer-opt"
    echo -e "${GREEN}✓ cpuminer-opt built → $BIN_DIR/cpuminer-opt${NC}"
else
    echo -e "${YELLOW}⚠ cpuminer-opt build failed — copying cpuminer-multi as fallback for KAS${NC}"
    cp "$BIN_DIR/cpuminer-multi" "$BIN_DIR/cpuminer-opt"
fi
cd "$SCRIPT_DIR"

# ── Step 5: nheqminer (ZEC Equihash) ──────────────────────
echo -e "${YELLOW}[5/6] Building nheqminer (ZEC/Equihash)...${NC}"
NHEQ_DIR="/tmp/nheqminer"
if [ -d "$NHEQ_DIR" ]; then rm -rf "$NHEQ_DIR"; fi
git clone --depth=1 https://github.com/nicehash/nheqminer.git "$NHEQ_DIR" 2>/dev/null || {
    echo -e "${YELLOW}⚠ nheqminer clone failed — trying alternative...${NC}"
    git clone --depth=1 https://github.com/davidgfnet/nheqminer.git "$NHEQ_DIR" 2>/dev/null || true
}

NHEQ_BUILT=0
if [ -d "$NHEQ_DIR" ]; then
    cd "$NHEQ_DIR"
    # try cmake build
    apt-get install -y cmake libboost-all-dev --no-install-recommends 2>/dev/null || true
    mkdir -p build && cd build
    cmake .. -DUSE_CPU_XENONCAT=OFF -DUSE_CPU_TROMP=ON 2>/dev/null && \
    make -j2 2>/dev/null && NHEQ_BUILT=1 || true
    if [ $NHEQ_BUILT -eq 1 ] && [ -f "nheqminer" ]; then
        cp nheqminer "$BIN_DIR/nheqminer"
        chmod +x "$BIN_DIR/nheqminer"
    fi
    cd "$SCRIPT_DIR"
fi

if [ $NHEQ_BUILT -eq 0 ]; then
    echo -e "${YELLOW}⚠ nheqminer build failed — using cpuminer-multi as ZEC fallback${NC}"
    echo -e "${YELLOW}  ZEC will use cpuminer-multi with --algo=equihash${NC}"
    cp "$BIN_DIR/cpuminer-multi" "$BIN_DIR/nheqminer"
fi
echo -e "${GREEN}✓ ZEC miner ready → $BIN_DIR/nheqminer${NC}"

# ── Step 6: Launch script ──────────────────────────────────
echo -e "${YELLOW}[6/6] Creating launch script...${NC}"
cat > "$SCRIPT_DIR/start.sh" << 'LAUNCH'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
echo "[Universal Miner] Starting on http://0.0.0.0:5001 ..."
python3 universal_miner.py
LAUNCH
chmod +x "$SCRIPT_DIR/start.sh"

cat > "$SCRIPT_DIR/start_screen.sh" << 'SCREEN'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
screen -dmS miner bash -c "python3 universal_miner.py; exec bash"
echo "[Universal Miner] Running in screen session 'miner'"
echo "Attach with: screen -r miner"
echo "Detach with: Ctrl+A then D"
SCREEN
chmod +x "$SCRIPT_DIR/start_screen.sh"

# ── Done ───────────────────────────────────────────────────
echo ""
echo -e "${GREEN}"
echo "╔══════════════════════════════════════════╗"
echo "║   INSTALLATION COMPLETE                  ║"
echo "╠══════════════════════════════════════════╣"
echo "║                                          ║"
echo "║  To start:  bash start.sh                ║"
echo "║  Background: bash start_screen.sh        ║"
echo "║  Open browser: http://localhost:5001     ║"
echo "║                                          ║"
echo "║  Binaries installed:                     ║"
echo "║   bin/cpuminer-multi  (DASH/X11)         ║"
echo "║   bin/cpuminer-opt    (KAS/kHeavyHash)   ║"
echo "║   bin/nheqminer       (ZEC/Equihash)     ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"


# =============================================================================
# SCRIPT: start.sh
# =============================================================================

#!/bin/bash
# =============================================================================
#  start.sh -- UMP ULTIMATE v4.2
#  Runs the Flask dev server in the BACKGROUND via nohup.
#  Use start_gunicorn.sh for production (recommended).
# =============================================================================
cd "$(dirname "$0")"

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/ump.log"
PID_FILE="ump.pid"

mkdir -p "$LOG_DIR"

# Kill any existing instance
if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[UMP] Stopping previous instance (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null
        sleep 1
    fi
    rm -f "$PID_FILE"
fi

echo "[UMP] Starting Universal Miner Pro ULTIMATE v4.2..."
echo "[UMP] Dashboard: http://localhost:8080"
echo "[UMP] Log file : $LOG_FILE"
echo "[UMP] PID file : $PID_FILE"

nohup python3 universal_miner.py >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

sleep 1
if kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    echo "[UMP] Running -- PID $(cat "$PID_FILE")"
    echo "[UMP] Open:  http://localhost:8080"
    echo "[UMP] Stop:  bash stop.sh"
    echo "[UMP] Logs:  tail -f $LOG_FILE"
else
    echo "[UMP] ERROR: Process failed to start. Check $LOG_FILE"
fi


# =============================================================================
# SCRIPT: stop.sh
# =============================================================================

#!/bin/bash
# =============================================================================
#  stop.sh -- UMP ULTIMATE v4.2
#  Gracefully stops whichever server is running (Flask dev or Gunicorn).
# =============================================================================
cd "$(dirname "$0")"

PID_FILE="ump.pid"
STOPPED=0

# ---------------------------------------------------------------------------
# Method 1: PID file
# ---------------------------------------------------------------------------
if [ -f "$PID_FILE" ]; then
    PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        echo "[UMP] Stopping UMP (PID $PID)..."
        kill -TERM "$PID" 2>/dev/null
        sleep 2
        if kill -0 "$PID" 2>/dev/null; then
            echo "[UMP] Process still alive -- sending SIGKILL..."
            kill -KILL "$PID" 2>/dev/null
            sleep 1
        fi
        if ! kill -0 "$PID" 2>/dev/null; then
            echo "[UMP] Stopped."
            STOPPED=1
        else
            echo "[UMP] WARNING: Could not stop PID $PID"
        fi
    else
        echo "[UMP] PID $PID not running -- cleaning up PID file"
        STOPPED=1
    fi
    rm -f "$PID_FILE"
fi

# ---------------------------------------------------------------------------
# Method 2: pkill fallback (catches orphan processes)
# ---------------------------------------------------------------------------
if pkill -f "gunicorn.*wsgi:app" 2>/dev/null; then
    echo "[UMP] Stopped gunicorn workers"
    STOPPED=1
fi
if pkill -f "python3 universal_miner.py" 2>/dev/null; then
    echo "[UMP] Stopped Flask dev server"
    STOPPED=1
fi

if [ "$STOPPED" -eq 1 ]; then
    echo "[UMP] UMP ULTIMATE stopped."
else
    echo "[UMP] No running UMP instance found."
fi


# =============================================================================
# SCRIPT: restart.sh
# =============================================================================

#!/bin/bash
# =============================================================================
#  restart.sh -- UMP ULTIMATE v4.2
#  Stops then starts the production Gunicorn server.
# =============================================================================
cd "$(dirname "$0")"
echo "[UMP] Restarting UMP ULTIMATE..."
bash stop.sh
sleep 1
bash start_gunicorn.sh


# =============================================================================
# SCRIPT: start_gunicorn.sh
# =============================================================================

#!/bin/bash
# =============================================================================
#  start_gunicorn.sh -- UMP ULTIMATE v4.2
#  Production WSGI server using Gunicorn + gthread workers.
#  Eliminates the "development server" warning.
#  Handles SSE correctly via thread-based workers.
# =============================================================================
cd "$(dirname "$0")"

LOG_DIR="logs"
PID_FILE="ump.pid"
GUNICORN_LOG="$LOG_DIR/gunicorn_error.log"

mkdir -p "$LOG_DIR"

# ---------------------------------------------------------------------------
# Check gunicorn is installed
# ---------------------------------------------------------------------------
if ! command -v gunicorn > /dev/null 2>&1; then
    echo "[UMP] Gunicorn not found -- installing..."
    pip3 install gunicorn --break-system-packages --quiet \
        || pip install gunicorn --break-system-packages --quiet
    if ! command -v gunicorn > /dev/null 2>&1; then
        # Try finding it in local bin paths
        GUNICORN_BIN="$(python3 -m site --user-base 2>/dev/null)/bin/gunicorn"
        if [ ! -f "$GUNICORN_BIN" ]; then
            echo "[UMP] ERROR: Could not install gunicorn."
            echo "[UMP] Run manually: pip3 install gunicorn --break-system-packages"
            echo "[UMP] Falling back to development server..."
            bash start.sh
            exit 0
        fi
        export PATH="$PATH:$(python3 -m site --user-base 2>/dev/null)/bin"
    fi
    echo "[UMP] Gunicorn installed OK"
fi

# ---------------------------------------------------------------------------
# Stop any existing instance
# ---------------------------------------------------------------------------
if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[UMP] Stopping previous instance (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null
        sleep 2
    fi
    rm -f "$PID_FILE"
fi

# ---------------------------------------------------------------------------
# Detect CPU count for thread tuning
# ---------------------------------------------------------------------------
CPU_COUNT="$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null || echo 4)"
THREADS="$CPU_COUNT"
if [ "$THREADS" -gt 8 ]; then
    THREADS=8
fi

echo "[UMP] ============================================"
echo "[UMP]  Universal Miner Pro ULTIMATE v4.2"
echo "[UMP]  Production WSGI Server (Gunicorn)"
echo "[UMP] ============================================"
echo "[UMP]  CPU cores  : $CPU_COUNT"
echo "[UMP]  Workers    : 1 (gthread)"
echo "[UMP]  Threads    : $THREADS"
echo "[UMP]  Port       : 8080"
echo "[UMP]  Dashboard  : http://localhost:8080"
echo "[UMP]  Error log  : $GUNICORN_LOG"
echo "[UMP]  PID file   : $PID_FILE"
echo "[UMP] ============================================"

# ---------------------------------------------------------------------------
# Launch Gunicorn in background via nohup
# ---------------------------------------------------------------------------
nohup gunicorn \
    --config gunicorn_config.py \
    --worker-class gthread \
    --workers 1 \
    --threads "$THREADS" \
    --bind 0.0.0.0:8080 \
    --timeout 0 \
    --graceful-timeout 10 \
    --keepalive 5 \
    --pid "$PID_FILE" \
    --access-logfile "$LOG_DIR/gunicorn_access.log" \
    --error-logfile "$GUNICORN_LOG" \
    --log-level info \
    --name ump_miner \
    wsgi:app >> "$LOG_DIR/ump.log" 2>&1 &

GUNICORN_PID=$!
echo $GUNICORN_PID > "$PID_FILE"

# ---------------------------------------------------------------------------
# Verify startup
# ---------------------------------------------------------------------------
sleep 2
if kill -0 "$GUNICORN_PID" 2>/dev/null; then
    echo "[UMP] Gunicorn running -- PID $GUNICORN_PID"
    echo "[UMP] Open:  http://localhost:8080"
    echo "[UMP] Stop:  bash stop.sh"
    echo "[UMP] Logs:  tail -f $LOG_DIR/ump.log"
    echo "[UMP] Errors: tail -f $GUNICORN_LOG"
else
    echo "[UMP] ERROR: Gunicorn failed to start"
    echo "[UMP] Last log lines:"
    tail -20 "$GUNICORN_LOG" 2>/dev/null || tail -20 "$LOG_DIR/ump.log" 2>/dev/null
    echo ""
    echo "[UMP] Falling back to development server..."
    bash start.sh
fi


# =============================================================================
# SCRIPT: start_screen.sh
# =============================================================================

#!/bin/bash
# =============================================================================
#  start_screen.sh -- UMP ULTIMATE v4.2
#  Runs Gunicorn inside a screen session so you can detach safely.
# =============================================================================
cd "$(dirname "$0")"
SESSION="ump_miner"

if ! command -v screen > /dev/null 2>&1; then
    echo "[UMP] screen not installed -- installing..."
    apt-get install -y screen 2>/dev/null || pkg install screen 2>/dev/null
fi

if screen -list 2>/dev/null | grep -q "$SESSION"; then
    echo "[UMP] Session '$SESSION' already running."
    echo "[UMP] Reattach: screen -r $SESSION"
else
    screen -dmS "$SESSION" bash start_gunicorn.sh
    sleep 2
    echo "[UMP] Started in screen session: $SESSION"
    echo "[UMP] Reattach : screen -r $SESSION"
    echo "[UMP] Detach   : Ctrl+A then D"
    echo "[UMP] Dashboard: http://localhost:8080"
fi

