# UNIVERSAL MINER PRO - ALL DOCUMENTATION (CONSOLIDATED v5.2)

> This file contains all Markdown documentation merged from all versions.

---

# README.md

# ⛏ UNIVERSAL MINER PRO — ULTIMATE EDITION v4.0

> 100% real. No gatekeeping. Mine crypto from any device you currently own.

[![MIT License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Android%20%7C%20Linux%20%7C%20macOS%20%7C%20Windows-blue)]()
[![Architecture](https://img.shields.io/badge/arch-armv7l%20%7C%20aarch64%20%7C%20x86__64-yellow)]()

---

## What is this?

Universal Miner Pro is a self-contained cryptocurrency mining management platform that
runs on **any device** — an old Android phone, a Raspberry Pi, a laptop, or a
high-end server. It gives you a real browser-based dashboard, a built-in HD blockchain
wallet, multi-pool support, and automatic profit switching.

No subscription. No ads. No middleman. MIT licensed and open source.

---

## Who is this for?

Anyone who wants to start mining cryptocurrency without expensive hardware.

- Start today on whatever device you have
- A phone today, a PC next month, a multi-GPU rig next year
- Every device you add increases your earnings
- Funds go directly to your own wallet — no platform takes a cut

**Built in South Africa. Built for people who need real tools, not promises.**

---

## Honest Earnings Expectations

**Your earnings depend entirely on your hashrate.** The dashboard has a built-in
earnings calculator — enter your actual hashrate from the miner log and it will
show you real daily/weekly/monthly/yearly estimates based on current coin prices.

Real observed hashrates from actual phone testing (X11/DASH, 3 threads):

| Device | Algorithm | Observed Hashrate | Notes |
|--------|-----------|-------------------|-------|
| Android / Userland Ubuntu (3 threads) | X11 / DASH | 4–13 kH/s | Real observed — varies by chip |
| Android / Userland Ubuntu (3 threads) | RandomX / XMR | 50–300 H/s | Steady on ARM |

| Mid-range laptop (4 threads) | X11 | 50–200 kH/s | Depends on CPU |
| Mid-range laptop (4 threads) | RandomX | 500–2000 H/s | Depends on CPU |
| Desktop PC (8+ threads) | RandomX | 2000–8000 H/s | Scales with core count |
| Server (32+ threads) | RandomX | 10000–25000+ H/s | High-end hardware |

**Important:** The earnings calculator in the dashboard uses live coin prices from
CoinGecko. Cryptocurrency prices are volatile — your actual earnings in fiat currency
will change as prices move. The hashrate number is what your hardware produces.
The dollar value of that hashrate changes daily.

**The real strategy:**
1. Start mining on what you have right now
2. Check your actual hashrate in the miner log
3. Enter it into the earnings calculator for a realistic estimate
4. Reinvest earnings into more or better hardware over time
5. Scale up gradually — more devices = more earnings

This is not a get-rich-quick scheme. It is a legitimate, transparent way to generate
income from hardware you already own.

---

## Features

- **41-node swarm mining** — up to 40 parallel miner processes + 1 master
- **Multi-pool support** — Kryptex, ViaBTC, Unmineable, MoneroOcean, Mining Pool Hub, Binance Pool
- **30+ coins** — XMR, DASH, BTC, LTC, ETH, DOGE, ADA, SOL, RVN, ETC, and more
- **Dual algorithm** — RandomX (XMRig) and X11 (cpuminer-multi), switchable live
- **HD Blockchain Wallet** — BIP39/BIP44 real wallet for BTC, LTC, DASH, ETH, XMR
- **Profit auto-switching** — automatically mines the most profitable coin every 5 min
- **Pre-flight validator** — checks all credentials before mining starts
- **Binance integration** — fetch deposit addresses, initiate withdrawals via API
- **Hardware detection** — auto-detects CPU, GPU, arch, and sets optimal config
- **Live dashboard** — real-time hashrate, earnings calculator, log tail, SSE stream
- **REST API** — full API for all operations (50+ endpoints)
- **Gunicorn WSGI** — production-ready, ARM-tuned, SSE-compatible

---

## Supported Platforms

| Platform | Architecture | Notes |
|----------|-------------|-------|
| Android / Userland Ubuntu | armv7l, aarch64 | **Recommended** — full Ubuntu environment |
| Android / Termux | armv7l, aarch64 | Alternative — install from F-Droid only |
| Linux Desktop/Server | x86_64, arm64 | Full feature set |
| Raspberry Pi | armv7l, arm64 | Low hashrate but fully functional |
| macOS | x86_64, M-chip | Homebrew required for build deps |
| Windows | x86_64 | WSL2 Ubuntu recommended |

---

## Quick Start

### Android / Userland Ubuntu (Recommended)

Userland Ubuntu gives you a full Ubuntu Linux environment on Android —
more stable, better package support, and better performance than Termux
for running UMP.

```bash
# 1. Install Userland from the Play Store
# 2. Launch Ubuntu session
# 3. Run:
apt-get update && apt-get upgrade -y
apt-get install -y git python3 python3-pip cmake make gcc     libssl-dev libuv1-dev build-essential

# 4. Clone and install
git clone https://github.com/aitechnologyptyltd-cyber/UNIVERSAL-CRYPTO-MINER.git
cd UNIVERSAL-CRYPTO-MINER
chmod +x install_universal_miner.sh
./install_universal_miner.sh

# Build takes 15-25 minutes on ARM.
# Keep screen on and device plugged in during build.

# 5. Start mining
./start.sh

# 6. Open dashboard
# From phone:          http://localhost:8080
# From PC (same WiFi): http://YOUR_PHONE_IP:8080
```

### Android / Termux (Alternative)

```bash
# Install Termux from F-Droid only (NOT the Play Store version)
pkg update && pkg upgrade -y
pkg install git python cmake make gcc openssl libuv

git clone https://github.com/aitechnologyptyltd-cyber/UNIVERSAL-CRYPTO-MINER.git
cd UNIVERSAL-CRYPTO-MINER
chmod +x install_universal_miner.sh
./install_universal_miner.sh

./start.sh
```

### Linux / macOS

```bash
git clone https://github.com/aitechnologyptyltd-cyber/UNIVERSAL-CRYPTO-MINER.git
cd UNIVERSAL-CRYPTO-MINER
chmod +x install_universal_miner.sh
./install_universal_miner.sh

./start.sh             # Foreground
./start_screen.sh      # Background (persists after terminal close)
./start_gunicorn.sh    # Production (Gunicorn)
```

### Python dependencies only

```bash
pip install -r requirements.txt --break-system-packages
python3 universal_miner.py
```

---

## Setup (First Time)

1. Open `http://localhost:8080` in your browser
2. Click **Setup** in the navigation bar
3. Choose your coin and pool
4. Enter your wallet address or Binance account
5. Click **Save Profile**
6. Return to Dashboard → click **START MINING**
7. Watch the miner log — your per-CPU hashrate will appear within 30 seconds
8. Enter your hashrate into the **Earnings Calculator** for a real estimate

The pre-flight validator runs automatically and warns you if anything is
misconfigured before mining starts.

---

## Understanding Your Hashrate

Once mining starts, the miner log will show lines like:

```
[2026-05-28 16:07:09] CPU #0: 3.19 kH/s
[2026-05-28 16:07:09] CPU #1: 3.20 kH/s
[2026-05-28 16:07:09] CPU #2: 3.09 kH/s
```

Add those together — that is your total hashrate. Enter it in the
**Earnings Calculator** on the dashboard to see your real earning estimate
at current market prices.

**Your hashrate will vary** based on:
- CPU model and number of cores
- Device temperature (phones throttle when hot)
- Number of threads configured
- Background apps using CPU

---

## Supported Mining Pools

| Pool | Coins | Notes |
|------|-------|-------|
| **Kryptex** | XMR, ZEC, RVN, ETC, BTC, LTC, KAS, ERG, ALPH | Auto-converts to BTC |
| **ViaBTC** | BTC, BCH, LTC, ZEC, DASH, XMR, ETC, KAS | PPS+ payouts |
| **Unmineable** | Mine XMR, receive any 100+ coin | Great for DOGE, ADA, SOL payouts |
| **MoneroOcean** | XMR + variants | Auto-switches algo for max XMR profit |
| **Mining Pool Hub** | Multi-coin auto-switch | Requires registration + API key |
| **Binance Pool** | DASH (X11) | Direct payout to Binance account |
| **Custom / Direct** | Any coin | Enter any stratum URL manually |

---

## HD Wallet

UMP includes a real self-custodial blockchain wallet:

- Generates a **BIP39 12-word mnemonic** (write it down — this is your backup)
- Derives real addresses for **BTC, LTC, DASH, ETH, XMR**
- Signs and broadcasts real on-chain transactions
- Fetches live balances from public blockchain explorers
- Connects to Binance API to fetch deposit addresses and initiate withdrawals
- All private keys encrypted with **AES-256-GCM** and stored locally

**Security rules:**
- Write your mnemonic phrase on paper. Never store it digitally.
- Use **read-only** Binance API keys only. Never enable trading or withdrawal permissions.
- Never share your private keys or mnemonic with anyone.
- Your keys never leave your device.

---

## Wallet & API Key Setup

### Binance API Keys (read-only)

1. Log in to Binance.com
2. Profile → API Management → Create API
3. Label: `UMP Monitor`
4. Enable ONLY: **[x] Enable Reading**
5. Disable everything else: Trading, Withdrawals, Futures
6. Copy both the 64-character API Key and Secret into UMP Setup

### Binance Pool (DASH mining)

- Miner username format: `BINANCE_ACCOUNT.WORKER_NAME`
- Example: `john_doe.rig1`
- No minimum payout threshold for DASH
- Payouts credited to your Binance account daily

---

## Stop Mining

```bash
./stop.sh      # Stop everything cleanly
./restart.sh   # Stop then start again
```

---

## Logs

```
logs/ump.log                  Main application log
logs/PROFILE_xmrig.log        XMRig output per profile
logs/PROFILE_cpuminer.log     cpuminer-multi output (X11/DASH)
logs/profit_switch.log        Automatic profit switching events
logs/gunicorn_access.log      HTTP access log
logs/gunicorn_error.log       Gunicorn errors
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Dashboard won't load | Run `python3 universal_miner.py` to see startup errors |
| XMRig not found | Re-run `./install_universal_miner.sh` |
| 0.00 H/s hashrate | Check pool URL and credentials in Setup |
| Build fails on armv7l | Need 1GB+ free RAM. Enable swap: `fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile` |
| Port 8080 in use | Edit `universal_miner.py` and change `port=8080` to `port=5002` |
| Payout not arriving | Wait 24h — pools pay daily. Run validator to check credentials. |
| Swarm nodes dying | Reduce `TOTAL_NODES` in `miner_config.py` for low-RAM devices |
| Phone getting hot | Normal during mining. Reduce threads in Setup if it throttles badly. |

---

## API Reference (key endpoints)

```
GET  /api/stats              Live miner stats
GET  /stream                 SSE real-time stream
POST /mine/start             Start mining
POST /mine/stop              Stop mining
GET  /api/profiles           List profiles
GET  /api/coins              Coin registry
GET  /api/validate           Pre-flight validation result
GET  /wallet/api/portfolio   Wallet portfolio summary
GET  /wallet/api/balances    Live blockchain balances
POST /wallet/api/transfer    Send a transaction
GET  /health                 Health check
```

Full API reference: see `UMP_ULTIMATE_v4_0_Documentation.pdf`

---

## Requirements

```
Python 3.6+
flask >= 2.0
requests >= 2.28
psutil >= 5.9
apscheduler >= 3.10
gunicorn >= 20.1
cryptography >= 41.0
```

---

## License

MIT License — free to use, modify, and distribute.
See [LICENSE](LICENSE) for full terms.

---

## Built by

**Francois Nel — AI Technology PTY LTD**
South Africa 🇿🇦

*Built on a Hisense Y82 Pro. Built for everyone.*

> "Why let people suffer when any device can generate real income?"

---

## Disclaimer

Cryptocurrency mining profitability depends on your hashrate, electricity costs,
coin prices, and network difficulty — all of which change constantly. Use the
built-in earnings calculator with your actual observed hashrate to get a realistic
estimate. This software makes no guarantees about earnings. Mine responsibly and
understand your costs before scaling up hardware.

---

# USER_GUIDE.md
> Source: Android Addition (13222 bytes - most complete version)

# Universal Miner Pro — Android Edition
## Complete User Guide
### Built for Userland Ubuntu on armv7l (32-bit ARM)

---

## TABLE OF CONTENTS

1. Overview
2. System Requirements
3. File Structure
4. Installation (Step-by-Step)
5. First Launch & Profile Setup
6. Dashboard Guide
7. Mining Controls
8. Coin Switching (ZEC / KAS / DASH)
9. Profile Management (Multi-User)
10. ViaBTC Pool Reference
11. Binance Integration
12. Command Reference
13. Troubleshooting
14. Security Notes

---

## 1. OVERVIEW

Universal Miner Pro is a full-stack CPU mining terminal that runs entirely
on your Android device inside Userland Ubuntu. It provides:

- Real-time mining dashboard with live hashrate, CPU load, temperature
- Support for 3 coins: ZEC (Zcash), KAS (Kaspa), DASH (Dash)
- ViaBTC pool integration with Stratum V1 protocol
- Live Binance market prices via WebSocket/REST
- Multi-user profile system — each user enters their own credentials
- Auto-resume — mining restarts automatically if the app is closed
- 3-second heartbeat persistence to SQLite

Mining engine per coin:
  ZEC  → nheqminer       (Equihash 200,9)
  KAS  → cpuminer-opt    (kHeavyHash)
  DASH → cpuminer-multi  (X11)

---

## 2. SYSTEM REQUIREMENTS

  Device:       Any Android phone running Userland
  Architecture: armv7l (32-bit ARM) or aarch64
  OS:           Userland Ubuntu 20.04 or 22.04
  RAM:          Minimum 1.5GB free
  Storage:      ~200MB for binaries + logs
  Network:      Wi-Fi or Mobile Data
  Python:       3.8 or higher

---

## 3. FILE STRUCTURE

```
universal-miner-pro/
├── universal_miner.py      ← Main Flask app (port 5001)
├── miner_config.py         ← Coin configs, DB schema, profile fields
├── miner_manager.py        ← Subprocess manager, hashrate parser
├── install_miner.sh        ← One-shot installer
├── start.sh                ← Quick launch (created by installer)
├── start_screen.sh         ← Background launch via screen
├── requirements.txt        ← Python packages
├── USER_GUIDE.md           ← This file
├── templates/
│   ├── dashboard.html      ← Main UI
│   ├── setup.html          ← Profile wizard
│   └── profiles.html       ← Profile manager
├── bin/                    ← Miner binaries (created by installer)
│   ├── nheqminer           ← ZEC
│   ├── cpuminer-opt        ← KAS
│   └── cpuminer-multi      ← DASH
├── logs/                   ← Miner output logs (auto-created)
└── miner.db                ← SQLite database (auto-created)
```

---

## 4. INSTALLATION (STEP-BY-STEP)

### Step 1 — Open Userland Ubuntu terminal

Launch Userland on your Android device and open your Ubuntu session.

### Step 2 — Navigate to the project folder

```bash
cd ~
mkdir universal-miner-pro
cd universal-miner-pro
```

### Step 3 — Copy all files into the folder

Transfer the files from this zip to ~/universal-miner-pro/ using any
method: Userland file browser, adb push, or a file manager app.

### Step 4 — Run the installer

```bash
chmod +x install_miner.sh
bash install_miner.sh
```

The installer will:
  - Install system packages (git, build-essential, libssl-dev, etc.)
  - Install Python packages (flask, requests, apscheduler)
  - Clone and compile cpuminer-multi (DASH)
  - Clone and compile cpuminer-opt (KAS)
  - Clone and compile nheqminer (ZEC)
  - Create start.sh and start_screen.sh launch scripts

Installation takes 10–20 minutes on first run (compilation).

### Step 5 — Start the app

```bash
bash start.sh
```

Then open a browser on your phone and go to:

```
http://localhost:5001
```

Or from another device on the same network:

```
http://<your-phone-ip>:5001
```

---

## 5. FIRST LAUNCH & PROFILE SETUP

On first launch you will be redirected to the Setup Wizard automatically.

The wizard has 5 steps:

### Step 01 — IDENTITY
- Profile Name: optional — auto-generated if blank
- Default Coin: ZEC / KAS / DASH
- CPU Threads: recommended 2 for armv7l

### Step 02 — VIABTC
- ViaBTC Account Name: your login username (NOT email)
- Worker ID: e.g. 001 (numbers/lowercase only)
- Worker Password: leave blank or enter any value
- ViaBTC API Key: from viabtc.com/en/setting/api
- ViaBTC API Secret: from the same page
- Payment Method: PPLNS / PPS+ / SOLO

### Step 03 — WALLETS
- ZEC Wallet: transparent address starting with t1
- KAS Wallet: full kaspa: address
- DASH Wallet: address starting with X

### Step 04 — BINANCE
- Binance UID: your numeric user ID
- Binance Email: your registered email
- Binance API Key + Secret: from Binance API Management
  IMPORTANT: Enable Read Only permission only

### Step 05 — CONFIRM
- Review all entries
- Click SAVE PROFILE

---

## 6. DASHBOARD GUIDE

The dashboard has these panels:

### Top Bar
- UNIVERSAL MINER logo
- Network status (ONLINE / OFFLINE)
- UTC clock

### Sidebar
- Profile switcher — click any profile to activate it
- Coin switcher — click ZEC / KAS / DASH
- Current session uptime

### Coin Tabs
Three tabs across the top — click to switch active coin:
  ZEC  — gold accent — Equihash algorithm
  KAS  — teal accent — kHeavyHash algorithm
  DASH — blue accent — X11 algorithm

### Gauges (3 cards)
  HASHRATE:    Live H/s or Sol/s from miner output
  CPU LOAD:    Percentage CPU usage
  TEMPERATURE: Device temperature in °C

### Stats Row
  ACCEPTED:  Shares accepted by pool
  REJECTED:  Shares rejected
  COIN:      Currently active coin
  SESSION:   Time since mining started

### Controls
  ▶ START button: starts miner for active coin
  ■ STOP button:  stops current miner
  THREADS:        dropdown 1–4

### Market Ticker
Live prices from Binance REST API, refreshed every 15 seconds:
  ZEC/USDT  KAS/USDT  DASH/USDT  BTC/USDT

### Log Panel
Last 30 lines of miner output, auto-scrolling:
  Green lines = accepted shares
  Red lines   = errors or rejected shares

---

## 7. MINING CONTROLS

### Start Mining

1. Select your coin (tab at top or sidebar)
2. Select thread count from dropdown
3. Click ▶ START

The miner binary launches as a subprocess. Output streams to the
log panel via SSE (Server-Sent Events) in real time.

### Stop Mining

Click ■ STOP at any time. The process receives SIGTERM, waits 10
seconds, then SIGKILL if needed.

### Switch Coin While Running

Click any coin tab while mining. The current miner stops, and the
new coin's miner starts automatically (2-second pause between).

### Auto-Resume

If the Flask app is closed or crashes, mining state is saved every
3 seconds. On next start, the miner auto-resumes the last session.

To disable auto-resume, stop mining before closing the app.

---

## 8. COIN SWITCHING

Each coin uses a different algorithm and binary:

| Coin | Algorithm   | Binary         | ViaBTC Port |
|------|-------------|----------------|-------------|
| ZEC  | Equihash    | nheqminer      | 3002        |
| KAS  | kHeavyHash  | cpuminer-opt   | 315         |
| DASH | X11         | cpuminer-multi | 3004        |

Worker string format for all coins:
  username.workerID
  Example: francoisnel321.001

Pool URLs per coin:
  ZEC Primary:   stratum+tcp://mining.viabtc.io:3002
  ZEC Failover:  stratum+tcp://mining.viabtc.top:3002
  ZEC SSL:       stratum+tcp://hash-ssl.viabtc.top:3002

  KAS Primary:   stratum+tcp://mining.viabtc.io:315
  KAS Failover:  stratum+tcp://hash.viabtc.io:315
  KAS SSL:       stratum+tcp://hash-ssl.viabtc.top:3015

  DASH Primary:  stratum+tcp://mining.viabtc.io:3004
  DASH Failover: stratum+tcp://mining.viabtc.top:3004

---

## 9. PROFILE MANAGEMENT

Each person using the miner creates their own profile with their own
ViaBTC credentials, wallet addresses, and Binance keys.

### Create New Profile
  → Click + NEW PROFILE in the sidebar or /setup

### Switch Profile
  → Click any profile in the sidebar (instant switch)
  → Or go to /profiles and click USE

### Delete Profile
  → Go to /profiles → click DELETE next to the profile
  → Confirms before deleting

### Multiple Users
Example setup:
  Profile 1: alice_ZEC  — ViaBTC: alice321  — Default: ZEC
  Profile 2: bob_DASH   — ViaBTC: bob123    — Default: DASH

Each user switches to their profile before starting mining.

---

## 10. VIABTC POOL REFERENCE

### How to get ViaBTC API Keys
1. Log in to viabtc.com
2. Go to Settings → API Management
3. Click Create API Key
4. Copy API Key and Secret Key immediately
5. Update every 3 months (ViaBTC requirement)

### Worker Format
  username.workerID  e.g.  francoisnel321.001
  Password: any value or blank — does not matter

### Payment Methods
  PPLNS:  Pay Per Last N Shares — lower variance, better for steady miners
  PPS+:   Fixed rate per share — predictable income
  SOLO:   Full block reward — high risk, high reward

### Payout Schedule
  Auto Withdrawal: daily between 10:00–18:00 UTC+8 (zero fee)
  Normal Transfer: anytime (fee applies)

---

## 11. BINANCE INTEGRATION

Binance credentials are used for:
  - Live ZEC/USDT, KAS/USDT, DASH/USDT price ticker
  - 24-hour price change percentages
  - BTC/USDT reference price

### Create a Read-Only API Key
1. Log in to Binance
2. Go to Account → API Management
3. Create API Key → select System Generated
4. Enable: Read Info only
5. Disable: Spot Trading, Withdrawals, Futures
6. Copy API Key and Secret immediately

### Market Data Endpoint
The dashboard fetches from Binance public REST:
  https://api.binance.com/api/v3/ticker/24hr

This does NOT require API keys. Your keys are stored for
future balance monitoring features.

---

## 12. COMMAND REFERENCE

### Start the app (foreground)
```bash
cd ~/universal-miner-pro
bash start.sh
```

### Start in background (screen session)
```bash
bash start_screen.sh
```

### Attach to background session
```bash
screen -r miner
```

### Detach from screen (keep running)
```
Ctrl+A  then  D
```

### Stop background session
```bash
screen -X -S miner quit
```

### Check if running
```bash
screen -ls
```

### View live logs
```bash
tail -f logs/ZEC_*.log
tail -f logs/KAS_*.log
tail -f logs/DASH_*.log
```

### Check miner processes
```bash
ps aux | grep cpuminer
ps aux | grep nheqminer
```

### Kill all miners manually
```bash
pkill -f cpuminer
pkill -f nheqminer
```

### Reinstall Python packages only
```bash
pip3 install --break-system-packages flask requests apscheduler
```

### Rebuild a single binary (example: cpuminer-multi)
```bash
cd /tmp/cpuminer-multi
make clean
make -j2
cp cpuminer ~/universal-miner-pro/bin/cpuminer-multi
chmod +x ~/universal-miner-pro/bin/cpuminer-multi
```

### Check your ARM architecture
```bash
uname -m
```
Expected output: armv7l

### Test Flask is running
```bash
curl http://localhost:5001/health
```

### Check database
```bash
sqlite3 miner.db "SELECT profile_name, active_coin FROM profiles;"
```

### Reset database (WARNING: deletes all profiles)
```bash
rm miner.db
python3 -c "from miner_config import init_db; init_db()"
```

---

## 13. TROUBLESHOOTING

### App won't start — ModuleNotFoundError
```bash
pip3 install --break-system-packages flask requests apscheduler
```

### Binary not found error in dashboard
The installer did not complete. Run:
```bash
bash install_miner.sh
```
Check that bin/ folder contains: nheqminer, cpuminer-opt, cpuminer-multi

### Port 5001 already in use
```bash
pkill -f universal_miner.py
bash start.sh
```

### Miner starts but hashrate shows 0
- Pool connection may be refused. Check your internet.
- Worker name may be wrong. Format must be: username.workerID
- Binary may have compiled without the correct algorithm support.
  Try switching coins — one may work while another does not.

### nheqminer fails to compile
ZEC will automatically fall back to cpuminer-multi with equihash flag.
This is handled by the installer. Check bin/nheqminer exists.

### Temperature shows -- (dashes)
Temperature reading requires /sys/class/thermal/ access which may
not be available in Userland. This is cosmetic only.

### Screen is black / browser can't connect
Make sure you're connecting to the right address:
  Same device:   http://localhost:5001
  Another phone: http://<ip>:5001

Find your IP:
```bash
hostname -I
```

### Mining keeps stopping after a few minutes
Userland may be killing background processes. Use screen:
```bash
bash start_screen.sh
```

### ViaBTC shows worker offline after 20 minutes
This is normal — ViaBTC takes 10–20 minutes to show a new worker
as active after first connection.

---

## 14. SECURITY NOTES

- All credentials are stored locally in miner.db (SQLite)
- No data is sent to any external server except:
    ViaBTC stratum pools (mining)
    Binance public REST API (market prices only)
- Use a Read-Only Binance API key — never enable withdrawals
- Do not share your miner.db file
- ViaBTC recommends rotating API keys every 3 months
- The app runs on port 5001 — not exposed externally unless you
  forward the port. On same-device access only by default.

---

## SUPPORT

Project: Universal Miner Pro — Android Edition
Architecture: armv7l Userland Ubuntu
Built by: Francois Nel
Version: 1.0

---
*End of User Guide*

---

# UPSTREAM README (UNIVERSAL-CRYPTO-MINER)

# ⛏ UNIVERSAL MINER PRO — ULTIMATE EDITION v4.0

> 100% real. No gatekeeping. Mine crypto from any device you currently own.

[![MIT License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Android%20%7C%20Linux%20%7C%20macOS%20%7C%20Windows-blue)]()
[![Architecture](https://img.shields.io/badge/arch-armv7l%20%7C%20aarch64%20%7C%20x86__64-yellow)]()

---

## What is this?

Universal Miner Pro is a self-contained cryptocurrency mining management platform that
runs on **any device** — an old Android phone, a Raspberry Pi, a laptop, or a
high-end server. It gives you a real browser-based dashboard, a built-in HD blockchain
wallet, multi-pool support, and automatic profit switching.

No subscription. No ads. No middleman. MIT licensed and open source.

---

## Who is this for?

Anyone who wants to start mining cryptocurrency without expensive hardware.

- Start today on whatever device you have
- A phone today, a PC next month, a multi-GPU rig next year
- Every device you add increases your earnings
- Funds go directly to your own wallet — no platform takes a cut

**Built in South Africa. Built for people who need real tools, not promises.**

---

## Honest Earnings Expectations

**Your earnings depend entirely on your hashrate.** The dashboard has a built-in
earnings calculator — enter your actual hashrate from the miner log and it will
show you real daily/weekly/monthly/yearly estimates based on current coin prices.

Real observed hashrates from actual phone testing (X11/DASH, 3 threads):

| Device | Algorithm | Observed Hashrate | Notes |
|--------|-----------|-------------------|-------|
| Android / Userland Ubuntu (3 threads) | X11 / DASH | 4–13 kH/s | Real observed — varies by chip |
| Android / Userland Ubuntu (3 threads) | RandomX / XMR | 50–300 H/s | Steady on ARM |

| Mid-range laptop (4 threads) | X11 | 50–200 kH/s | Depends on CPU |
| Mid-range laptop (4 threads) | RandomX | 500–2000 H/s | Depends on CPU |
| Desktop PC (8+ threads) | RandomX | 2000–8000 H/s | Scales with core count |
| Server (32+ threads) | RandomX | 10000–25000+ H/s | High-end hardware |

**Important:** The earnings calculator in the dashboard uses live coin prices from
CoinGecko. Cryptocurrency prices are volatile — your actual earnings in fiat currency
will change as prices move. The hashrate number is what your hardware produces.
The dollar value of that hashrate changes daily.

**The real strategy:**
1. Start mining on what you have right now
2. Check your actual hashrate in the miner log
3. Enter it into the earnings calculator for a realistic estimate
4. Reinvest earnings into more or better hardware over time
5. Scale up gradually — more devices = more earnings

This is not a get-rich-quick scheme. It is a legitimate, transparent way to generate
income from hardware you already own.

---

## Features

- **41-node swarm mining** — up to 40 parallel miner processes + 1 master
- **Multi-pool support** — Kryptex, ViaBTC, Unmineable, MoneroOcean, Mining Pool Hub, Binance Pool
- **30+ coins** — XMR, DASH, BTC, LTC, ETH, DOGE, ADA, SOL, RVN, ETC, and more
- **Dual algorithm** — RandomX (XMRig) and X11 (cpuminer-multi), switchable live
- **HD Blockchain Wallet** — BIP39/BIP44 real wallet for BTC, LTC, DASH, ETH, XMR
- **Profit auto-switching** — automatically mines the most profitable coin every 5 min
- **Pre-flight validator** — checks all credentials before mining starts
- **Binance integration** — fetch deposit addresses, initiate withdrawals via API
- **Hardware detection** — auto-detects CPU, GPU, arch, and sets optimal config
- **Live dashboard** — real-time hashrate, earnings calculator, log tail, SSE stream
- **REST API** — full API for all operations (50+ endpoints)
- **Gunicorn WSGI** — production-ready, ARM-tuned, SSE-compatible

---

## Supported Platforms

| Platform | Architecture | Notes |
|----------|-------------|-------|
| Android / Userland Ubuntu | armv7l, aarch64 | **Recommended** — full Ubuntu environment |
| Android / Termux | armv7l, aarch64 | Alternative — install from F-Droid only |
| Linux Desktop/Server | x86_64, arm64 | Full feature set |
| Raspberry Pi | armv7l, arm64 | Low hashrate but fully functional |
| macOS | x86_64, M-chip | Homebrew required for build deps |
| Windows | x86_64 | WSL2 Ubuntu recommended |

---

## Quick Start

### Android / Userland Ubuntu (Recommended)

Userland Ubuntu gives you a full Ubuntu Linux environment on Android —
more stable, better package support, and better performance than Termux
for running UMP.

```bash
# 1. Install Userland from the Play Store
# 2. Launch Ubuntu session
# 3. Run:
apt-get update && apt-get upgrade -y
apt-get install -y git python3 python3-pip cmake make gcc     libssl-dev libuv1-dev build-essential

# 4. Clone and install
git clone https://github.com/aitechnologyptyltd-cyber/UNIVERSAL-CRYPTO-MINER.git
cd UNIVERSAL-CRYPTO-MINER
chmod +x install_universal_miner.sh
./install_universal_miner.sh

# Build takes 15-25 minutes on ARM.
# Keep screen on and device plugged in during build.

# 5. Start mining
./start.sh

# 6. Open dashboard
# From phone:          http://localhost:8080
# From PC (same WiFi): http://YOUR_PHONE_IP:8080
```

### Android / Termux (Alternative)

```bash
# Install Termux from F-Droid only (NOT the Play Store version)
pkg update && pkg upgrade -y
pkg install git python cmake make gcc openssl libuv

git clone https://github.com/aitechnologyptyltd-cyber/UNIVERSAL-CRYPTO-MINER.git
cd UNIVERSAL-CRYPTO-MINER
chmod +x install_universal_miner.sh
./install_universal_miner.sh

./start.sh
```

### Linux / macOS

```bash
git clone https://github.com/aitechnologyptyltd-cyber/UNIVERSAL-CRYPTO-MINER.git
cd UNIVERSAL-CRYPTO-MINER
chmod +x install_universal_miner.sh
./install_universal_miner.sh

./start.sh             # Foreground
./start_screen.sh      # Background (persists after terminal close)
./start_gunicorn.sh    # Production (Gunicorn)
```

### Python dependencies only

```bash
pip install -r requirements.txt --break-system-packages
python3 universal_miner.py
```

---

## Setup (First Time)

1. Open `http://localhost:8080` in your browser
2. Click **Setup** in the navigation bar
3. Choose your coin and pool
4. Enter your wallet address or Binance account
5. Click **Save Profile**
6. Return to Dashboard → click **START MINING**
7. Watch the miner log — your per-CPU hashrate will appear within 30 seconds
8. Enter your hashrate into the **Earnings Calculator** for a real estimate

The pre-flight validator runs automatically and warns you if anything is
misconfigured before mining starts.

---

## Understanding Your Hashrate

Once mining starts, the miner log will show lines like:

```
[2026-05-28 16:07:09] CPU #0: 3.19 kH/s
[2026-05-28 16:07:09] CPU #1: 3.20 kH/s
[2026-05-28 16:07:09] CPU #2: 3.09 kH/s
```

Add those together — that is your total hashrate. Enter it in the
**Earnings Calculator** on the dashboard to see your real earning estimate
at current market prices.

**Your hashrate will vary** based on:
- CPU model and number of cores
- Device temperature (phones throttle when hot)
- Number of threads configured
- Background apps using CPU

---

## Supported Mining Pools

| Pool | Coins | Notes |
|------|-------|-------|
| **Kryptex** | XMR, ZEC, RVN, ETC, BTC, LTC, KAS, ERG, ALPH | Auto-converts to BTC |
| **ViaBTC** | BTC, BCH, LTC, ZEC, DASH, XMR, ETC, KAS | PPS+ payouts |
| **Unmineable** | Mine XMR, receive any 100+ coin | Great for DOGE, ADA, SOL payouts |
| **MoneroOcean** | XMR + variants | Auto-switches algo for max XMR profit |
| **Mining Pool Hub** | Multi-coin auto-switch | Requires registration + API key |
| **Binance Pool** | DASH (X11) | Direct payout to Binance account |
| **Custom / Direct** | Any coin | Enter any stratum URL manually |

---

## HD Wallet

UMP includes a real self-custodial blockchain wallet:

- Generates a **BIP39 12-word mnemonic** (write it down — this is your backup)
- Derives real addresses for **BTC, LTC, DASH, ETH, XMR**
- Signs and broadcasts real on-chain transactions
- Fetches live balances from public blockchain explorers
- Connects to Binance API to fetch deposit addresses and initiate withdrawals
- All private keys encrypted with **AES-256-GCM** and stored locally

**Security rules:**
- Write your mnemonic phrase on paper. Never store it digitally.
- Use **read-only** Binance API keys only. Never enable trading or withdrawal permissions.
- Never share your private keys or mnemonic with anyone.
- Your keys never leave your device.

---

## Wallet & API Key Setup

### Binance API Keys (read-only)

1. Log in to Binance.com
2. Profile → API Management → Create API
3. Label: `UMP Monitor`
4. Enable ONLY: **[x] Enable Reading**
5. Disable everything else: Trading, Withdrawals, Futures
6. Copy both the 64-character API Key and Secret into UMP Setup

### Binance Pool (DASH mining)

- Miner username format: `BINANCE_ACCOUNT.WORKER_NAME`
- Example: `john_doe.rig1`
- No minimum payout threshold for DASH
- Payouts credited to your Binance account daily

---

## Stop Mining

```bash
./stop.sh      # Stop everything cleanly
./restart.sh   # Stop then start again
```

---

## Logs

```
logs/ump.log                  Main application log
logs/PROFILE_xmrig.log        XMRig output per profile
logs/PROFILE_cpuminer.log     cpuminer-multi output (X11/DASH)
logs/profit_switch.log        Automatic profit switching events
logs/gunicorn_access.log      HTTP access log
logs/gunicorn_error.log       Gunicorn errors
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Dashboard won't load | Run `python3 universal_miner.py` to see startup errors |
| XMRig not found | Re-run `./install_universal_miner.sh` |
| 0.00 H/s hashrate | Check pool URL and credentials in Setup |
| Build fails on armv7l | Need 1GB+ free RAM. Enable swap: `fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile` |
| Port 8080 in use | Edit `universal_miner.py` and change `port=8080` to `port=5002` |
| Payout not arriving | Wait 24h — pools pay daily. Run validator to check credentials. |
| Swarm nodes dying | Reduce `TOTAL_NODES` in `miner_config.py` for low-RAM devices |
| Phone getting hot | Normal during mining. Reduce threads in Setup if it throttles badly. |

---

## API Reference (key endpoints)

```
GET  /api/stats              Live miner stats
GET  /stream                 SSE real-time stream
POST /mine/start             Start mining
POST /mine/stop              Stop mining
GET  /api/profiles           List profiles
GET  /api/coins              Coin registry
GET  /api/validate           Pre-flight validation result
GET  /wallet/api/portfolio   Wallet portfolio summary
GET  /wallet/api/balances    Live blockchain balances
POST /wallet/api/transfer    Send a transaction
GET  /health                 Health check
```

Full API reference: see `UMP_ULTIMATE_v4_0_Documentation.pdf`

---

## Requirements

```
Python 3.6+
flask >= 2.0
requests >= 2.28
psutil >= 5.9
apscheduler >= 3.10
gunicorn >= 20.1
cryptography >= 41.0
```

---

## License

MIT License — free to use, modify, and distribute.
See [LICENSE](LICENSE) for full terms.

---

## Built by

**Francois Nel — AI Technology PTY LTD**
South Africa 🇿🇦

*Built on a Hisense Y82 Pro. Built for everyone.*

> "Why let people suffer when any device can generate real income?"

---

## Disclaimer

Cryptocurrency mining profitability depends on your hashrate, electricity costs,
coin prices, and network difficulty — all of which change constantly. Use the
built-in earnings calculator with your actual observed hashrate to get a realistic
estimate. This software makes no guarantees about earnings. Mine responsibly and
understand your costs before scaling up hardware.

