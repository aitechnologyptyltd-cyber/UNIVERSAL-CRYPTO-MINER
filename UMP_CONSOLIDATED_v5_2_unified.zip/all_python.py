#!/usr/bin/env python3
# =============================================================================
# UNIVERSAL MINER PRO - ALL PYTHON MODULES (CONSOLIDATED v5.2)
# Merged from: UMPV5_2 (primary), wallet_enforcer from WALLET_ENFORCED version
# All modules use the latest/most-complete editions available across all zips
# =============================================================================


# =============================================================================
# MODULE: wsgi.py
# =============================================================================

"""
wsgi.py
UMP ULTIMATE v4.2 -- Production WSGI entry point for Gunicorn.
Usage:
    gunicorn --config gunicorn_config.py wsgi:app
"""
import threading
from universal_miner import app, auto_resume

# Start the auto-resume daemon when Gunicorn loads this module
_resume_thread = threading.Thread(target=auto_resume, daemon=True)
_resume_thread.start()

# 'app' is the Flask WSGI application exported to Gunicorn
__all__ = ["app"]


# =============================================================================
# MODULE: gunicorn_config.py
# =============================================================================

"""
gunicorn_config.py
UMP ULTIMATE v4.2 -- Gunicorn production configuration.
Tuned for armv7l / aarch64 Userland Ubuntu with SSE support.
"""
import multiprocessing
import os

# ---------------------------------------------------------------------------
# Server socket
# ---------------------------------------------------------------------------
bind            = "0.0.0.0:8080"
backlog         = 64

# ---------------------------------------------------------------------------
# Worker model
# gthread = thread-based workers -- REQUIRED for SSE long-lived connections.
# sync workers would block on every /stream connection.
# ---------------------------------------------------------------------------
worker_class    = "gthread"

# 1 worker process keeps RAM usage low on armv7l (3.6 GB total).
# All concurrency comes from threads.
workers         = 1

# Threads per worker.
# armv7l 8-core: 4 threads handles dashboard + SSE + API simultaneously.
# Increase to 8 on aarch64 or x86_64.
threads         = 4

# ---------------------------------------------------------------------------
# Timeouts
# ---------------------------------------------------------------------------
# SSE stream connections are long-lived -- must NOT timeout.
# Set to 0 = no timeout for worker silence.
timeout         = 0

# How long Gunicorn waits for workers to finish on graceful restart.
graceful_timeout = 10

# Keep-alive for non-SSE HTTP connections (seconds).
keepalive       = 5

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
_log_dir = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(_log_dir, exist_ok=True)

accesslog       = os.path.join(_log_dir, "gunicorn_access.log")
errorlog        = os.path.join(_log_dir, "gunicorn_error.log")
loglevel        = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s'

# ---------------------------------------------------------------------------
# Process naming
# ---------------------------------------------------------------------------
proc_name       = "ump_miner"
default_proc_name = "ump_miner"

# ---------------------------------------------------------------------------
# PID file
# ---------------------------------------------------------------------------
pidfile         = os.path.join(os.path.dirname(__file__), "ump.pid")

# ---------------------------------------------------------------------------
# Preload -- load app code before forking workers.
# Saves RAM on multi-worker setups; fine with workers=1 too.
# ---------------------------------------------------------------------------
preload_app     = True


# =============================================================================
# MODULE: universal_miner.py
# =============================================================================

# universal_miner.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Flask app — port 8080 — Multi-Pool | Multi-Coin | Multi-Arch | Dual-Algo Swarm
# armv7l / aarch64 / x86_64 / macOS / Windows compatible
# no f-strings — no walrus — Python 3.6+ safe

import os
import json
import time
import threading
import sqlite3
from datetime import datetime
from flask import (
    Flask, render_template, request, redirect,
    url_for, jsonify, Response, session, flash
)

from miner_config import (
    COINS, CPU_COINS, PROFILE_FIELDS, POOLS, ALGOS, DEFAULT_ALGO,
    DB_PATH, VERSION, TOTAL_NODES,
    init_db, save_profile, load_profile, list_profiles, delete_profile,
    get_coins_json, get_pools_json, get_algos_json, get_system_info,
    suggest_pool_url, calc_daily_usd, format_hashrate, set_algo,
    ARCH, PLATFORM
)
from miner_manager import (
    start_miner, stop_miner, get_stats, is_running,
    auto_resume, get_log_tail, get_hashrate_history, switch_algo
)
from miner_swarm import register_with_app, get_engine

# ── Optional modules (graceful degradation if missing) ────────
try:
    from wallet_api import register_wallet
    _HAS_WALLET = True
except ImportError as e:
    print("[UMP] wallet_api not available: " + str(e))
    _HAS_WALLET = False

try:
    from wallet_validator import get_cached_result, start_background_validation
    _HAS_VALIDATOR = True
except ImportError as e:
    print("[UMP] wallet_validator not available: " + str(e))
    _HAS_VALIDATOR = False

try:
    from ump_hardware_detect import get_capability_profile
    _HAS_HARDWARE = True
except ImportError:
    _HAS_HARDWARE = False

try:
    from ump_profit_switcher import start_profit_switcher
    _HAS_PROFIT = True
except ImportError:
    _HAS_PROFIT = False

# ── App init ──────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.urandom(24)

init_db()
SYS_INFO = get_system_info()

# ── Register blueprints ───────────────────────────────────────
register_with_app(app)
print("[UMP] Swarm blueprint registered")

if _HAS_WALLET:
    register_wallet(app)
    print("[UMP] Wallet blueprint registered at /wallet/")

# ── Start background services ─────────────────────────────────
if _HAS_VALIDATOR:
    start_background_validation()
    print("[UMP] Validator started")

if _HAS_PROFIT:
    try:
        start_profit_switcher(app)
        print("[UMP] Profit switcher started")
    except Exception as e:
        print("[UMP] Profit switcher error: " + str(e))

print("[UMP] " + VERSION + " starting on " + SYS_INFO["platform"] + "/" + SYS_INFO["arch"])
print("[UMP] Swarm nodes: " + str(TOTAL_NODES) + " | Algos: " + ", ".join(ALGOS.keys()))
print("[UMP] Dashboard → http://0.0.0.0:8080")

# ── Helpers ───────────────────────────────────────────────────
def _has_profiles():
    try:
        return len(list_profiles()) > 0
    except Exception:
        return False

def _get_active_profile():
    pname = session.get("profile_name")
    if pname:
        p = load_profile(pname)
        if p:
            return p
    profiles = list_profiles()
    if profiles:
        p = load_profile(profiles[0]["profile_name"])
        if p:
            session["profile_name"] = p["profile_name"]
            return p
    return None

def _fmt_uptime(seconds):
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return str(h) + "h " + str(m) + "m " + str(s) + "s"

def _get_sections():
    sections = {}
    for f in PROFILE_FIELDS:
        sec = f["section"]
        if sec not in sections:
            sections[sec] = []
        sections[sec].append(f)
    return sections

# ── SSE stream ────────────────────────────────────────────────
def _sse_stream():
    while True:
        try:
            stats  = get_stats()
            swarm  = get_engine().get_snapshot()
            stats["uptime_str"]      = _fmt_uptime(stats.get("uptime_sec", 0))
            stats["is_alive"]        = is_running()
            stats["arch"]            = ARCH
            stats["platform"]        = PLATFORM
            stats["swarm_active"]    = swarm.get("swarm_active", False)
            stats["swarm_nodes"]     = swarm.get("active_nodes", 0)
            stats["swarm_hr"]        = swarm.get("total_hashrate", 0.0)
            stats["swarm_hr_unit"]   = swarm.get("hr_unit", "H/s")
            stats["swarm_earnings"]  = swarm.get("earnings_usd", 0.0)
            stats["xmr_price"]       = swarm.get("xmr_price", 0.0)
            stats["cpu_pct"]         = swarm.get("cpu_pct", stats.get("cpu_pct", 0.0))
            stats["temperature"]     = swarm.get("temperature", stats.get("temp"))
            yield "data: " + json.dumps(stats) + "\n\n"
        except Exception as e:
            yield "data: " + json.dumps({"error": str(e)}) + "\n\n"
        time.sleep(2)

# ── Main routes ───────────────────────────────────────────────
@app.route("/")
def index():
    if not _has_profiles():
        return redirect(url_for("setup"))
    profile = _get_active_profile()
    if not profile:
        return redirect(url_for("setup"))
    stats     = get_stats()
    profiles  = list_profiles()
    pool_id   = profile.get("selected_pool", "kryptex")
    pool_info = POOLS.get(pool_id, {})
    algo_key  = str(profile.get("active_algo", DEFAULT_ALGO)).upper()
    return render_template(
        "dashboard.html",
        profile     = profile,
        stats       = stats,
        profiles    = profiles,
        uptime      = _fmt_uptime(stats.get("uptime_sec", 0)),
        sys_info    = SYS_INFO,
        pool_info   = pool_info,
        algos       = ALGOS,
        algos_json  = json.dumps(get_algos_json()),
        active_algo = algo_key,
        total_nodes = TOTAL_NODES,
        version     = VERSION,
        has_wallet  = _HAS_WALLET,
    )

@app.route("/setup", methods=["GET"])
def setup():
    profiles     = list_profiles()
    sections     = _get_sections()
    coins_json   = json.dumps(get_coins_json())
    pools_json   = json.dumps(get_pools_json())
    edit_profile = None
    edit_name    = request.args.get("edit", "")
    if edit_name:
        edit_profile = load_profile(edit_name)
    return render_template(
        "setup.html",
        sections     = sections,
        profiles     = profiles,
        coins_json   = coins_json,
        pools_json   = pools_json,
        cpu_coins    = CPU_COINS,
        sys_info     = SYS_INFO,
        edit_profile = edit_profile,
        version      = VERSION,
        pool_ids     = list(POOLS.keys()),
        algos        = ALGOS,
    )

@app.route("/setup", methods=["POST"])
def setup_post():
    data  = {}
    pname = request.form.get("profile_name", "").strip()
    if not pname:
        uname = request.form.get("username", "user").strip()
        pname = uname + "_" + str(int(time.time()))
    data["profile_name"] = pname

    for f in PROFILE_FIELDS:
        data[f["key"]] = request.form.get(f["key"], "").strip()

    try:
        data["threads"] = int(request.form.get("threads", SYS_INFO.get("cpu_count", 2)))
    except (ValueError, TypeError):
        data["threads"] = 2

    algo_raw = request.form.get("active_algo", DEFAULT_ALGO).strip().upper()
    data["active_algo"] = algo_raw if algo_raw in ALGOS else DEFAULT_ALGO

    missing = [f["label"] for f in PROFILE_FIELDS
               if f.get("required") and not data.get(f["key"])]
    if missing:
        flash("Required fields missing: " + ", ".join(missing), "error")
        return redirect(url_for("setup"))

    try:
        save_profile(data)
        session["profile_name"] = pname
        flash("Profile saved: " + pname, "success")
    except Exception as e:
        flash("Save error: " + str(e), "error")
        return redirect(url_for("setup"))
    return redirect(url_for("index"))

@app.route("/profiles")
def profiles_page():
    return render_template(
        "profiles.html",
        profiles = list_profiles(),
        sys_info = SYS_INFO,
        version  = VERSION,
    )

@app.route("/profiles/switch", methods=["POST"])
def profile_switch():
    pname = request.form.get("profile_name", "").strip()
    if not pname or not load_profile(pname):
        return jsonify({"ok": False, "error": "Not found"}), 404
    if is_running():
        stop_miner()
    session["profile_name"] = pname
    return jsonify({"ok": True, "profile_name": pname})

@app.route("/profiles/delete", methods=["POST"])
def profile_delete():
    pname = request.form.get("profile_name", "").strip()
    try:
        delete_profile(pname)
        if session.get("profile_name") == pname:
            session.pop("profile_name", None)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/profiles/export/<profile_name>")
def profile_export(profile_name):
    p = load_profile(profile_name)
    if not p:
        return jsonify({"error": "Not found"}), 404
    safe = {k: v for k, v in p.items()
            if k not in ("binance_api_key", "binance_api_secret",
                         "mph_api_key", "xmr_viewkey")}
    return jsonify(safe)

# ── Mining controls ───────────────────────────────────────────
@app.route("/mine/start", methods=["POST"])
def mine_start():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    try:
        threads = int(request.form.get("threads", profile.get("threads", 2)))
    except (ValueError, TypeError):
        threads = 2
    algo_key = request.form.get("algo", profile.get("active_algo", DEFAULT_ALGO)).upper()
    ok, err  = start_miner(profile["profile_name"], threads=threads, algo_key=algo_key)
    if ok:
        return jsonify({
            "ok":      True,
            "coin":    profile.get("selected_coin", "XMR"),
            "pool":    profile.get("selected_pool", "kryptex"),
            "algo":    algo_key,
            "threads": threads,
        })
    return jsonify({"ok": False, "error": err}), 500

@app.route("/mine/stop", methods=["POST"])
def mine_stop():
    ok, err = stop_miner()
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": err}), 400

@app.route("/mine/switch_algo", methods=["POST"])
def mine_switch_algo():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    algo_key = request.form.get("algo", "").strip().upper()
    if not algo_key:
        data = request.get_json(silent=True) or {}
        algo_key = str(data.get("algo", "")).strip().upper()
    if algo_key not in ALGOS:
        return jsonify({"ok": False, "error": "Unknown algo: " + algo_key}), 400
    try:
        threads = int(request.form.get("threads", profile.get("threads", 2)))
    except (ValueError, TypeError):
        threads = 2
    ok, err = switch_algo(profile["profile_name"], algo_key, threads=threads)
    if ok:
        algo_info = ALGOS[algo_key]
        return jsonify({
            "ok":         True,
            "algo":       algo_key,
            "algo_label": algo_info["label"],
            "pool_name":  algo_info["pool_name"],
            "hr_unit":    algo_info["hr_unit"],
            "color":      algo_info["color"],
        })
    return jsonify({"ok": False, "error": err}), 500

# ── Swarm controls ────────────────────────────────────────────
@app.route("/swarm/start", methods=["POST"])
def swarm_start_route():
    profile = _get_active_profile()
    if not profile:
        return jsonify({"ok": False, "error": "No active profile"}), 400
    try:
        threads = int(request.form.get("threads", 1))
    except (ValueError, TypeError):
        threads = 1
    algo_key = request.form.get("algo", profile.get("active_algo", DEFAULT_ALGO)).upper()
    ok, err  = get_engine().start_swarm(profile["profile_name"],
                                        threads=threads, algo_key=algo_key)
    if ok:
        return jsonify({"ok": True, "total_nodes": TOTAL_NODES, "algo": algo_key})
    return jsonify({"ok": False, "error": err}), 500

@app.route("/swarm/stop", methods=["POST"])
def swarm_stop_route():
    ok, err = get_engine().stop_swarm()
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": err}), 400

# ── SSE + Stats API ───────────────────────────────────────────
@app.route("/stream")
def stream():
    return Response(
        _sse_stream(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

@app.route("/api/stats")
def api_stats():
    stats = get_stats()
    stats["uptime_str"] = _fmt_uptime(stats.get("uptime_sec", 0))
    stats["is_alive"]   = is_running()
    return jsonify(stats)

@app.route("/api/log")
def api_log():
    lines    = int(request.args.get("lines", 80))
    algo_key = request.args.get("algo", None)
    return jsonify(get_log_tail(lines=lines, algo_key=algo_key))

@app.route("/api/hashrate_history")
def api_hashrate_history():
    profile = _get_active_profile()
    if not profile:
        return jsonify([])
    limit = int(request.args.get("limit", 120))
    return jsonify(get_hashrate_history(profile["profile_name"], limit=limit))

@app.route("/api/profiles")
def api_profiles():
    return jsonify(list_profiles())

@app.route("/api/coins")
def api_coins():
    return jsonify(get_coins_json())

@app.route("/api/pools")
def api_pools():
    return jsonify(get_pools_json())

@app.route("/api/algos")
def api_algos():
    return jsonify(get_algos_json())

@app.route("/api/suggest_pool_url")
def api_suggest_pool_url():
    pool_id  = request.args.get("pool", "kryptex")
    coin_sym = request.args.get("coin", "XMR")
    url = suggest_pool_url(pool_id, coin_sym)
    return jsonify({"url": url, "pool": pool_id, "coin": coin_sym})

@app.route("/api/hashrate_calc")
def api_hashrate_calc():
    try:
        hr_raw = float(request.args.get("hr", 0))
        unit   = request.args.get("unit", "H/s")
        coin   = request.args.get("coin", "XMR").upper()
        price  = float(request.args.get("price", 0))
        mult   = {"H/s": 1, "KH/s": 1e3, "MH/s": 1e6, "GH/s": 1e9}.get(unit, 1)
        hr_hs  = hr_raw * mult
        daily  = calc_daily_usd(coin, hr_hs,
                                coin_price_usd=price if price > 0 else None)
        return jsonify({
            "hashrate_hs":  hr_hs,
            "hashrate_fmt": format_hashrate(hr_hs),
            "daily_usd":    round(daily, 4),
            "weekly_usd":   round(daily * 7, 4),
            "monthly_usd":  round(daily * 30, 2),
            "yearly_usd":   round(daily * 365, 2),
            "coin":         coin,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route("/api/sysinfo")
def api_sysinfo():
    return jsonify(get_system_info())

@app.route("/api/sessions")
def api_sessions():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT s.id, s.started_at, s.stopped_at, s.coin, s.pool, s.algo,
                   s.shares_acc, s.shares_rej, s.avg_hr, p.profile_name
            FROM sessions s
            LEFT JOIN profiles p ON s.profile_id = p.id
            ORDER BY s.started_at DESC LIMIT 30
        """)
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Validator API ─────────────────────────────────────────────
@app.route("/api/validate")
def api_validate():
    if not _HAS_VALIDATOR:
        return jsonify({"ok": True, "errors": [], "warnings": [],
                        "all": [], "checked": 0,
                        "summary": "Validator not installed"})
    force = request.args.get("refresh", "0") in ("1", "true", "yes")
    try:
        res = get_cached_result(force=force)
        return jsonify(res.to_dict())
    except Exception as e:
        return jsonify({"ok": False, "errors": [], "warnings": [],
                        "all": [], "checked": 0,
                        "summary": "Validator error: " + str(e)})

# ── Hardware API ──────────────────────────────────────────────
@app.route("/api/hardware")
def api_hardware():
    if not _HAS_HARDWARE:
        return jsonify(SYS_INFO)
    try:
        return jsonify(get_capability_profile())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Health check ──────────────────────────────────────────────
@app.route("/health")
def health():
    swarm = get_engine().get_snapshot()
    return jsonify({
        "status":       "ok",
        "version":      VERSION,
        "arch":         ARCH,
        "platform":     PLATFORM,
        "mining":       is_running(),
        "swarm_active": swarm.get("swarm_active", False),
        "swarm_nodes":  swarm.get("active_nodes", 0),
        "profiles":     len(list_profiles()),
        "algos":        list(ALGOS.keys()),
        "has_wallet":   _HAS_WALLET,
        "has_validator":_HAS_VALIDATOR,
        "timestamp":    datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
    })

# ── Entry point ───────────────────────────────────────────────
if __name__ == "__main__":
    t = threading.Thread(target=auto_resume, daemon=True)
    t.start()
    app.run(
        host="0.0.0.0", port=8080,
        debug=False, threaded=True, use_reloader=False,
    )


# =============================================================================
# MODULE: miner_config.py
# =============================================================================

# miner_config.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Multi-Pool | Multi-Coin | Multi-Arch | Multi-User | Dual-Algo Swarm
# Pools: Kryptex, ViaBTC, Unmineable, Mining Pool Hub, MoneroOcean, Binance Pool
# Algos: RandomX (XMRig) | X11 (cpuminer-multi → unMineable → XMR)
# armv7l / aarch64 / x86_64 / macOS / Windows safe — no f-strings, no walrus

import os
import json
import platform
import sqlite3

# ── Internal wallet enforcement (CRITICAL — do not remove) ────────────────────
try:
    from wallet_enforcer import enforce_internal_wallet, require_internal_wallet
    _ENFORCER_AVAILABLE = True
except ImportError:
    _ENFORCER_AVAILABLE = False
    def enforce_internal_wallet(profile):
        return profile, ["wallet_enforcer.py not found — enforcement DISABLED"]
    def require_internal_wallet():
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "miner.db")
BIN_DIR  = os.path.join(BASE_DIR, "bin")
LOG_DIR  = os.path.join(BASE_DIR, "logs")

DEFAULT_THREADS = 2
DEFAULT_ALGO    = "RANDOMX"
TOTAL_NODES     = 40          # swarm nodes (+1 master = 41 total)
VERSION         = "4.0-ULTIMATE"

# ── Architecture detection ─────────────────────────────────────────────────────
def detect_arch():
    machine = platform.machine().lower()
    if "armv7" in machine or "armhf" in machine:
        return "armv7l"
    if "aarch64" in machine or "arm64" in machine:
        return "aarch64"
    if "x86_64" in machine or "amd64" in machine:
        return "x86_64"
    if "i686" in machine or "i386" in machine:
        return "x86"
    return machine

def detect_platform():
    s = platform.system().lower()
    if s == "linux":
        if os.path.exists("/data/data/com.termux"):
            return "termux"
        if os.path.exists("/proc/version"):
            try:
                with open("/proc/version") as f:
                    if "android" in f.read().lower():
                        return "android"
            except Exception:
                pass
        return "linux"
    if s == "darwin":
        return "macos"
    if s == "windows":
        return "windows"
    return s

ARCH     = detect_arch()
PLATFORM = detect_platform()

# ── Dual-algo configuration ────────────────────────────────────────────────────
# Both algos pay out in XMR — same wallet, different pool and binary.
# Toggle on dashboard at any time; switch restarts the miner with the new algo.
ALGOS = {
    "RANDOMX": {
        "label":         "RandomX",
        "coin":          "XMR",
        "coin_display":  "XMR (Kryptex)",
        "algorithm":     "rx/0",
        "binary_name":   "xmrig",            # binary filename inside BIN_DIR
        "default_pool":  "xmr.kryptex.network:8029",
        "failover_pool": "xmr-sg.kryptex.network:7029",
        "extra_flags":   ["--tls", "-k"],
        "worker_fmt":    "solo:{wallet}/{worker}",
        "color":         "#FF6600",
        "hr_unit":       "H/s",
        "hr_per_node":   500,                # estimated H/s per swarm node
        "total_hr":      "20,500 H/s",       # 41 nodes × 500 H/s
        "pool_name":     "Kryptex",
        "pass":          "x",
    },
    "X11": {
        "label":         "X11",
        "coin":          "XMR (via unMineable)",
        "coin_display":  "XMR (unMineable)",
        "algorithm":     "x11",
        "binary_name":   "cpuminer-multi",   # binary filename inside BIN_DIR
        "default_pool":  "rx.unmineable.com:3333",
        "failover_pool": "rx.unmineable.com:80",
        "extra_flags":   [],
        "worker_fmt":    "XMR:{wallet}.{worker}#{referral}",
        "color":         "#00C8FF",
        "hr_unit":       "MH/s",
        "hr_per_node":   1.5,                # estimated MH/s per swarm node
        "total_hr":      "61.5 MH/s",        # 41 nodes x 1.5 MH/s
        "pool_name":     "unMineable",
        "pass":          "x",
    },
    "X11_DIRECT": {
        "label":         "X11 Direct",
        "coin":          "DASH",
        "coin_display":  "DASH (Binance Pool)",
        "algorithm":     "x11",
        "binary_name":   "cpuminer-multi",
        "default_pool":  "dash.poolbinance.com:1800",
        "failover_pool": "dash.poolbinance.com:3333",
        "extra_flags":   [],
        "worker_fmt":    "{wallet}.{worker}",
        "color":         "#1C75BC",
        "hr_unit":       "MH/s",
        "hr_per_node":   1.0,
        "total_hr":      "41 MH/s",
        "pool_name":     "Binance Pool",
        "pass":          "123456",
    },
}

# ── Pool definitions ───────────────────────────────────────────────────────────
POOLS = {
    "kryptex": {
        "name":        "Kryptex Pool",
        "url":         "https://pool.kryptex.com",
        "description": "Auto-converts to BTC — worldwide",
        "color":       "#00e676",
        "coins":       ["XMR","ZEPH","SAL","BTC","BCH","LTC","KAS","ZEC","ETC","ETHW",
                        "RVN","ERG","CFX","ALPH","XTM","RXD","XEL","IRON","NEXA",
                        "CLORE","XNA","QUAI","OCTA","DGB","XEC","BSV","FB"],
        "user_fmt":    "WALLET.WORKER_NAME  or  KRYPTEX_EMAIL.WORKER_NAME",
        "pass_hint":   "X",
        "port_tcp":    "3333",
        "port_ssl":    "443",
    },
    "viabtc": {
        "name":        "ViaBTC",
        "url":         "https://viabtc.com",
        "description": "Established multi-coin pool — PPS+",
        "color":       "#FF6D00",
        "coins":       ["BTC","BCH","LTC","ETH","ETC","ZEC","DASH","XMR","ZEN",
                        "BSV","CKB","XCH","KDA","HNS","KAS"],
        "user_fmt":    "YOUR_USERNAME.WORKER_NAME",
        "pass_hint":   "123",
        "port_tcp":    "3333",
        "port_ssl":    "3443",
    },
    "unmineable": {
        "name":        "Unmineable",
        "url":         "https://unmineable.com",
        "description": "Mine ANY coin on CPU with XMR algo",
        "color":       "#7C4DFF",
        "coins":       ["BTC","ETH","BNB","ADA","DOGE","SHIB","TRX","XRP","SOL","DOT",
                        "MATIC","LTC","AVAX","LINK","UNI","XMR","NEAR","FIL","ICP","VET",
                        "ALGO","ATOM","XLM","FTM","MANA","SAND","AXS","CRO","CAKE","ONE",
                        "HBAR","EGLD","KSM","THETA","FLOW","STX","XTZ","RUNE","GRT"],
        "user_fmt":    "COIN:YOUR_WALLET_ADDRESS#REF_CODE",
        "pass_hint":   "WORKER_NAME",
        "pool_urls": {
            "randomx":     "rx.unmineable.com:3333",
            "randomx_ssl": "rx.unmineable.com:443",
            "ethash":      "ethash.unmineable.com:3333",
            "kawpow":      "kp.unmineable.com:3333",
        },
        "port_tcp":    "3333",
        "port_ssl":    "443",
    },
    "miningpoolhub": {
        "name":        "Mining Pool Hub",
        "url":         "https://miningpoolhub.com",
        "description": "Auto-switching multi-algo pool",
        "color":       "#2979FF",
        "coins":       ["BTC","ETH","ETC","LTC","ZEC","XMR","DASH","RVN","XZC","MONA",
                        "GRS","VTC","GLT","LYRA","SIGT","YTN","MOON","XVG","MUSIC"],
        "user_fmt":    "YOUR_MPH_USERNAME.WORKER_NAME",
        "pass_hint":   "x",
        "port_tcp":    "20XXX",
        "port_ssl":    "20XXX",
        "api_url":     "https://miningpoolhub.com/index.php?page=api",
    },
    "moneroocean": {
        "name":        "MoneroOcean",
        "url":         "https://moneroocean.stream",
        "description": "XMR pool — auto-algo switching for max profit",
        "color":       "#FF6600",
        "coins":       ["XMR","ZEPH","RTM","CCX","TUBE","LTHN"],
        "user_fmt":    "YOUR_XMR_WALLET_ADDRESS",
        "pass_hint":   "WORKER_NAME:EMAIL@EXAMPLE.COM",
        "pool_url":    "gulf.moneroocean.stream:10128",
        "pool_ssl":    "gulf.moneroocean.stream:20128",
        "port_tcp":    "10128",
        "port_ssl":    "20128",
    },
    "binance": {
        "name":        "Binance Pool",
        "url":         "https://pool.binance.com",
        "description": "Binance integrated mining pool — DASH, BTC and more",
        "color":       "#F0B90B",
        "coins":       ["BTC","ETH","LTC","BCH","ETC","BNB","DASH"],
        "user_fmt":    "BINANCE_ACCOUNT.WORKER_ID  (e.g. francoisnel321.001)",
        "pass_hint":   "123456",
        "pool_url":    "stratum+tcp://bs.poolbinance.com:1800",
        "port_tcp":    "1800",
        "port_ssl":    "443",
        "dash_port_primary":   "dash.poolbinance.com:1800",
        "dash_port_ssl":       "dash.poolbinance.com:443",
        "dash_port_alternate": "dash.poolbinance.com:3333",
    },
    "direct_wallet": {
        "name":        "Direct / External Wallet",
        "url":         "",
        "description": "Solo or any custom pool — enter full stratum URL",
        "color":       "#aaaaaa",
        "coins":       ["XMR","BTC","ETH","ANY"],
        "user_fmt":    "YOUR_WALLET_ADDRESS",
        "pass_hint":   "x",
        "port_tcp":    "custom",
        "port_ssl":    "custom",
    },
}

# ── Coin definitions ───────────────────────────────────────────────────────────
COINS = {
    # CPU RandomX
    "XMR":  {"name":"Monero",           "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "xmrig_coin":"XMR",  "color":"#FF6600"},
    "ZEPH": {"name":"Zephyr Protocol",  "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "xmrig_coin":"ZEPH", "color":"#7C4DFF"},
    "SAL":  {"name":"Salvium",          "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "xmrig_coin":"SAL",  "color":"#00BCD4"},
    # GPU KawPow
    "RVN":  {"name":"Ravencoin",        "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#384182"},
    "XNA":  {"name":"Neurai",           "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#FF9800"},
    "CLORE":{"name":"Clore.ai",         "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#E91E63"},
    "QUAI": {"name":"Quai Network",     "algo":"KawPow",     "hw":"GPU",       "cpu":False, "color":"#FF5733"},
    # GPU Ethash/Etchash
    "ETC":  {"name":"Ethereum Classic", "algo":"Etchash",    "hw":"GPU+ASIC",  "cpu":False, "color":"#3AB83A"},
    "ETHW": {"name":"EthereumPoW",      "algo":"Ethash",     "hw":"GPU+ASIC",  "cpu":False, "color":"#627EEA"},
    "OCTA": {"name":"OctaSpace",        "algo":"Ethash",     "hw":"GPU",       "cpu":False, "color":"#FF6EC7"},
    # GPU SHA3x
    "XTM":  {"name":"Tari",             "algo":"SHA3x",      "hw":"GPU+ASIC",  "cpu":False, "color":"#9B59B6"},
    "RXD":  {"name":"Radiant",          "algo":"SHA3x",      "hw":"GPU+ASIC",  "cpu":False, "color":"#E74C3C"},
    "ALPH": {"name":"Alephium",         "algo":"SHA3x",      "hw":"GPU+ASIC",  "cpu":False, "color":"#00C2FF"},
    # GPU other
    "IRON": {"name":"Iron Fish",        "algo":"IronFish",   "hw":"GPU",       "cpu":False, "color":"#CC00FF"},
    "XEL":  {"name":"Xelis",            "algo":"Xelis",      "hw":"GPU",       "cpu":False, "color":"#00E5FF"},
    "ERG":  {"name":"Ergo",             "algo":"Autolykos2", "hw":"GPU",       "cpu":False, "color":"#FF5722"},
    "CFX":  {"name":"Conflux",          "algo":"Octopus",    "hw":"GPU",       "cpu":False, "color":"#1B8FFF"},
    "NEXA": {"name":"Nexa",             "algo":"NexaPoW",    "hw":"GPU",       "cpu":False, "color":"#26A69A"},
    # ASIC SHA256
    "BTC":  {"name":"Bitcoin",          "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#F7931A"},
    "BCH":  {"name":"Bitcoin Cash",     "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#8DC351"},
    "BSV":  {"name":"Bitcoin SV",       "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#EAB300"},
    "FB":   {"name":"Fractal Bitcoin",  "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#FF8C00"},
    "XEC":  {"name":"eCash",            "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#0074C2"},
    "DGB":  {"name":"DigiByte",         "algo":"SHA256",     "hw":"ASIC",      "cpu":False, "color":"#0066CC"},
    # ASIC other
    "LTC":  {"name":"Litecoin",         "algo":"Scrypt",     "hw":"ASIC",      "cpu":False, "color":"#BFBBBB"},
    "KAS":  {"name":"Kaspa",            "algo":"HeavyHash",  "hw":"ASIC",      "cpu":False, "color":"#49EACB"},
    "ZEC":  {"name":"Zcash",            "algo":"Equihash",   "hw":"ASIC",      "cpu":False, "color":"#ECB244"},
    # Unmineable-only (any coin payout via X11 algo)
    "DOGE": {"name":"Dogecoin",         "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#C2A633"},
    "SHIB": {"name":"Shiba Inu",        "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#FFA409"},
    "ADA":  {"name":"Cardano",          "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#0033AD"},
    "SOL":  {"name":"Solana",           "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#9945FF"},
    "BNB":  {"name":"Binance Coin",     "algo":"RandomX",    "hw":"CPU",       "cpu":True,  "pool_only":"unmineable","color":"#F3BA2F"},
    # X11 Direct mining
    "DASH": {"name":"Dash",             "algo":"X11",        "hw":"CPU",       "cpu":True,
             "pool_only":"binance",
             "pool_url":"dash.poolbinance.com:1800",
             "pool_url_ssl":"dash.poolbinance.com:443",
             "pool_url_alt":"dash.poolbinance.com:3333",
             "user_fmt":"BINANCE_ACCOUNT.WORKER_ID",
             "default_pass":"123456",
             "algo_key":"X11_DIRECT",
             "color":"#1C75BC"},
}

CPU_COINS = [s for s, c in COINS.items() if c.get("cpu")]

# ── Pool-specific port tables ──────────────────────────────────────────────────
KRYPTEX_PORTS = {
    "XMR":"xmr.kryptex.network:8029",   "ZEPH":"zeph.kryptex.network:8029",
    "SAL":"sal.kryptex.network:8029",    "BTC":"btc.kryptex.network:3333",
    "BCH":"bch.kryptex.network:3333",    "LTC":"ltc.kryptex.network:3333",
    "KAS":"kas.kryptex.network:3333",    "ZEC":"zec.kryptex.network:7042",
    "ETC":"etc.kryptex.network:8888",    "ETHW":"ethw.kryptex.network:8888",
    "RVN":"rvn.kryptex.network:3333",    "ERG":"erg.kryptex.network:3333",
    "ALPH":"alph.kryptex.network:3333",  "XTM":"xtm.kryptex.network:3333",
    "RXD":"rxd.kryptex.network:3333",    "XEL":"xel.kryptex.network:3333",
    "IRON":"iron.kryptex.network:3333",  "NEXA":"nexa.kryptex.network:3333",
    "CLORE":"clore.kryptex.network:3333","XNA":"xna.kryptex.network:3333",
    "QUAI":"quai.kryptex.network:3333",  "OCTA":"octa.kryptex.network:8888",
    "DGB":"dgb.kryptex.network:3333",    "XEC":"xec.kryptex.network:3333",
    "CFX":"cfx.kryptex.network:3333",    "BSV":"bsv.kryptex.network:3333",
    "FB":"fb.kryptex.network:3333",
}

VIABTC_PORTS = {
    "BTC":"btc.viabtc.com:3333",  "BCH":"bch.viabtc.com:3333",
    "LTC":"ltc.viabtc.com:3333",  "ETC":"etc.viabtc.com:3333",
    "ZEC":"zec.viabtc.com:3333",  "DASH":"dash.viabtc.com:3333",
    "XMR":"xmr.viabtc.com:3333",  "KAS":"kas.viabtc.com:3333",
}

MPH_PORTS = {
    "BTC":"stratum.miningpoolhub.com:20533",
    "ETH":"us-east.ethash-hub.miningpoolhub.com:20535",
    "ETC":"us-east.ethash-hub.miningpoolhub.com:20535",
    "ZEC":"us-east.equihash-hub.miningpoolhub.com:20570",
    "XMR":"us-east.cryptonight-hub.miningpoolhub.com:20580",
    "RVN":"europe.ravencoin.miningpoolhub.com:20555",
    "LTC":"stratum.miningpoolhub.com:20580",
}

# ── Profile fields ─────────────────────────────────────────────────────────────
PROFILE_FIELDS = [
    # Identity
    {"key":"profile_name",   "label":"Profile Name",              "placeholder":"e.g. My_XMR_Rig",             "type":"text",     "section":"Identity",     "required":True},
    {"key":"username",       "label":"Worker / Rig Name",          "placeholder":"rig1 (alphanumeric)",          "type":"text",     "section":"Identity",     "required":True},
    # Coin & Pool
    {"key":"selected_coin",  "label":"Coin Symbol",                "placeholder":"XMR  ZEPH  BTC  RVN ...",     "type":"text",     "section":"Coin",         "required":True},
    {"key":"selected_pool",  "label":"Pool",                       "placeholder":"kryptex  viabtc  unmineable ..","type":"select",  "section":"Coin",         "required":True,
     "options":["kryptex","viabtc","unmineable","miningpoolhub","moneroocean","binance","direct_wallet"]},
    {"key":"pool_url",       "label":"Pool Stratum URL",           "placeholder":"host:port (auto-filled)",      "type":"text",     "section":"Pool",         "required":True},
    {"key":"miner_user",     "label":"Miner User String (--user)", "placeholder":"WALLET.WORKER or pool format", "type":"text",     "section":"Pool",         "required":True},
    {"key":"miner_pass",     "label":"Miner Password (--pass)",    "placeholder":"X  or  x  or  WORKER_NAME",   "type":"text",     "section":"Pool",         "required":False},
    {"key":"use_tls",        "label":"TLS Encryption",             "placeholder":"1=yes  0=no",                  "type":"text",     "section":"Pool",         "required":False},
    {"key":"threads",        "label":"CPU Threads",                "placeholder":"2 (auto-detected)",            "type":"number",   "section":"Hardware",     "required":False},
    # Algo selection
    {"key":"active_algo",    "label":"Mining Algorithm",           "placeholder":"RANDOMX or X11 or X11_DIRECT",  "type":"select",   "section":"Hardware",     "required":False,
     "options":["RANDOMX","X11","X11_DIRECT"]},
    # XMR wallet (required for X11/unMineable mode)
    {"key":"xmr_wallet",     "label":"XMR Wallet Address",         "placeholder":"45jh... (Monero wallet)",      "type":"text",     "section":"XMR Wallet",   "required":False},
    {"key":"xmr_viewkey",    "label":"XMR Private View Key",       "placeholder":"For monitoring only",          "type":"password", "section":"XMR Wallet",   "required":False},
    {"key":"xmr_payment_id", "label":"XMR Payment ID",             "placeholder":"Leave blank for standard wallets","type":"text", "section":"XMR Wallet",   "required":False},
    # BTC wallet
    {"key":"btc_wallet",     "label":"BTC Wallet Address",         "placeholder":"bc1q... or 1... or 3...",      "type":"text",     "section":"BTC Wallet",   "required":False},
    # Kryptex
    {"key":"kryptex_email",  "label":"Kryptex Account Email",      "placeholder":"you@email.com",                "type":"text",     "section":"Kryptex",      "required":False},
    {"key":"kryptex_worker", "label":"Kryptex Worker Name",        "placeholder":"rig1",                         "type":"text",     "section":"Kryptex",      "required":False},
    # ViaBTC
    {"key":"viabtc_username","label":"ViaBTC Pool Username",       "placeholder":"your_viabtc_username",         "type":"text",     "section":"ViaBTC",       "required":False},
    {"key":"viabtc_worker",  "label":"ViaBTC Worker Name",         "placeholder":"worker1",                      "type":"text",     "section":"ViaBTC",       "required":False},
    # Unmineable
    {"key":"unmineable_coin","label":"Unmineable Payout Coin",     "placeholder":"BTC  ETH  DOGE  ADA  SOL ...", "type":"text",     "section":"Unmineable",   "required":False},
    {"key":"unmineable_wallet","label":"Unmineable Payout Wallet", "placeholder":"Your wallet for payout coin",  "type":"text",     "section":"Unmineable",   "required":False},
    {"key":"unmineable_ref", "label":"Unmineable Referral Code",   "placeholder":"abc1-def2 (optional, -0.25% fee)","type":"text",  "section":"Unmineable",   "required":False},
    # MoneroOcean
    {"key":"mo_wallet",      "label":"MoneroOcean XMR Wallet",     "placeholder":"Your XMR wallet address",      "type":"text",     "section":"MoneroOcean",  "required":False},
    {"key":"mo_worker",      "label":"MoneroOcean Worker Name",    "placeholder":"rig1",                         "type":"text",     "section":"MoneroOcean",  "required":False},
    {"key":"mo_email",       "label":"MoneroOcean Email (alerts)",  "placeholder":"optional@email.com",           "type":"text",     "section":"MoneroOcean",  "required":False},
    # Mining Pool Hub
    {"key":"mph_username",   "label":"MPH Username",               "placeholder":"your_mph_username",            "type":"text",     "section":"MiningPoolHub","required":False},
    {"key":"mph_api_key",    "label":"MPH API Key",                "placeholder":"From MPH account settings",    "type":"password", "section":"MiningPoolHub","required":False},
    # Binance Pool
    {"key":"binance_uid",    "label":"Binance UID",                "placeholder":"Numeric Binance user ID",      "type":"text",     "section":"Binance",      "required":False},
    {"key":"binance_email",  "label":"Binance Account Email",      "placeholder":"your@binance.com",             "type":"text",     "section":"Binance",      "required":False},
    {"key":"binance_sub_account","label":"Binance Sub-Account",    "placeholder":"Leave blank for main account", "type":"text",     "section":"Binance",      "required":False},
    {"key":"binance_api_key","label":"Binance API Key",            "placeholder":"64-char read-only API key",    "type":"password", "section":"Binance",      "required":False},
    {"key":"binance_api_secret","label":"Binance API Secret",      "placeholder":"64-char API secret",           "type":"password", "section":"Binance",      "required":False},
    # Notes
    {"key":"notes",          "label":"Profile Notes",              "placeholder":"Any notes about this setup",   "type":"textarea", "section":"Notes",        "required":False},
]

# ── Algo helpers ───────────────────────────────────────────────────────────────
def build_worker_str(algo_key, wallet, worker, referral=""):
    """Build the --user string for the given algo."""
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        raise ValueError("Unknown algo: " + algo_key)
    fmt = ALGOS[algo_key]["worker_fmt"]
    result = fmt.replace("{wallet}", wallet).replace("{worker}", worker)
    if "{referral}" in fmt:
        result = result.replace("{referral}", referral if referral else "")
    # Strip trailing # if no referral
    if result.endswith("#"):
        result = result[:-1]
    return result

def get_algo_binary(algo_key):
    """Return full path to the binary for this algo."""
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        raise ValueError("Unknown algo: " + algo_key)
    name = ALGOS[algo_key]["binary_name"]
    if PLATFORM == "windows":
        name = name + ".exe"
    return os.path.join(BIN_DIR, name)

# ── Build miner command ────────────────────────────────────────────────────────
def get_miner_cmd(profile, threads=DEFAULT_THREADS, algo_key=None):
    """
    Build the correct miner command for the profile.
    If algo_key is given, it overrides profile['active_algo'].
    For CPU RandomX: uses XMRig (--coin / --url / --user).
    For X11 (unMineable): uses cpuminer-multi (-a x11 / -o / -u).
    For all other coins: falls back to XMRig with pool_url/miner_user from profile.

    WALLET ENFORCEMENT: All wallet/address fields are overwritten with internal
    wallet addresses before the command is built. This ensures pool payouts always
    go to the internal wallet regardless of what is stored in the profile.
    """
    # ── INTERNAL WALLET ENFORCEMENT (CRITICAL — executes on every call) ──────
    # Raises ValueError if no wallet exists. Overwrites all address fields.
    require_internal_wallet()
    profile, _enforce_warnings = enforce_internal_wallet(profile)
    for w in _enforce_warnings:
        print("[wallet_enforcer] " + w)
    # ─────────────────────────────────────────────────────────────────────────

    if algo_key is None:
        algo_key = str(profile.get("active_algo", DEFAULT_ALGO)).upper().strip()
    else:
        algo_key = algo_key.upper().strip()

    # -- X11_DIRECT path (cpuminer-multi -> Binance Pool DASH or any X11 pool) --
    if algo_key == "X11_DIRECT":
        binary   = os.path.join(BIN_DIR, "cpuminer-multi")
        if PLATFORM == "windows":
            binary = binary + ".exe"
        pool_url = str(profile.get("pool_url", "dash.poolbinance.com:1800")).strip()
        if not pool_url.startswith("stratum"):
            pool_url = "stratum+tcp://" + pool_url
        user_str = str(profile.get("miner_user", "")).strip()
        pass_str = str(profile.get("miner_pass", "123456")).strip() or "123456"
        threads  = str(threads)
        if not user_str:
            raise ValueError("Miner user string required for X11_DIRECT -- use ACCOUNT.WORKER format")
        cmd = [
            binary,
            "--algo",    "x11",
            "--url",     pool_url,
            "--user",    user_str,
            "--pass",    pass_str,
            "--threads", threads,
            "--no-color",
        ]
        return cmd

    # -- X11 path (cpuminer-multi -> unMineable) --
    if algo_key == "X11":
        algo    = ALGOS["X11"]
        binary  = get_algo_binary("X11")
        wallet  = str(profile.get("xmr_wallet", "") or
                      profile.get("unmineable_wallet", "")).strip()
        worker  = str(profile.get("username", "worker")).strip()
        referral = str(profile.get("unmineable_ref", "")).strip()
        if not wallet:
            raise ValueError("XMR wallet is required for X11 / unMineable mode")
        pool = str(profile.get("pool_url", "") or algo["default_pool"]).strip()
        if not pool.startswith("stratum"):
            pool = "stratum+tcp://" + pool
        user_str = build_worker_str("X11", wallet, worker, referral)
        cmd = [
            binary,
            "--algo",    algo["algorithm"],
            "--url",     pool,
            "--user",    user_str,
            "--pass",    "x",
            "--threads", str(threads),
            "--no-color",
        ]
        return cmd

    # ── RandomX path (XMRig) ─────────────────────────────────────────────────
    if algo_key == "RANDOMX":
        coin_sym   = str(profile.get("selected_coin", "XMR")).upper().strip()
        coin       = COINS.get(coin_sym)
        if coin is None:
            raise ValueError("Unknown coin: " + coin_sym)
        if not coin.get("cpu"):
            raise ValueError(coin_sym + " requires " + coin.get("hw","GPU/ASIC") + " — not CPU-mineable")
        binary     = get_algo_binary("RANDOMX")
        if PLATFORM == "windows":
            binary = os.path.join(BIN_DIR, "xmrig.exe")
        pool_url   = str(profile.get("pool_url", "")).strip()
        user_str   = str(profile.get("miner_user", "")).strip()
        pass_str   = str(profile.get("miner_pass", "X")).strip() or "X"
        use_tls    = str(profile.get("use_tls", "1")).strip().lower()
        xmrig_coin = coin.get("xmrig_coin", coin_sym)
        if not pool_url:
            raise ValueError("Pool URL is empty — configure in setup")
        if not user_str:
            raise ValueError("Miner user string is empty — configure in setup")
        cmd = [
            binary,
            "--coin",         xmrig_coin,
            "--url",          pool_url,
            "--user",         user_str,
            "--pass",         pass_str,
            "--threads",      str(threads),
            "--no-color",
            "--donate-level", "0",
        ]
        if use_tls in ("1","true","yes","on"):
            cmd.extend(["--tls", "-k"])
        return cmd

    raise ValueError("Unknown algo_key: " + algo_key)

# ── Pool URL suggestion ────────────────────────────────────────────────────────
def suggest_pool_url(pool_id, coin_sym):
    coin_sym = coin_sym.upper().strip()
    if pool_id == "kryptex":
        return KRYPTEX_PORTS.get(coin_sym, "")
    if pool_id == "viabtc":
        return VIABTC_PORTS.get(coin_sym, "")
    if pool_id == "moneroocean":
        return "gulf.moneroocean.stream:10128"
    if pool_id == "miningpoolhub":
        return MPH_PORTS.get(coin_sym, "stratum.miningpoolhub.com:20XXX")
    if pool_id == "binance":
        if coin_sym == "DASH":
            return "dash.poolbinance.com:1800"
        return "stratum+tcp://bs.poolbinance.com:1800"
    if pool_id == "unmineable":
        return "rx.unmineable.com:3333"
    return ""

# ── Hashrate calculator ────────────────────────────────────────────────────────
HASHRATE_USD_PER_HS = {
    "XMR":  0.00000030,
    "ZEPH": 0.00000025,
    "SAL":  0.00000010,
    "DASH": 0.00000008,
    "DOGE": 0.00000001,
    "SHIB": 0.000000001,
}

def calc_daily_usd(coin_sym, hashrate_hs, coin_price_usd=None):
    coin_sym = coin_sym.upper().strip()
    rate = HASHRATE_USD_PER_HS.get(coin_sym, 0.0)
    if coin_price_usd and coin_price_usd > 0:
        base_prices = {"XMR":170.0,"ZEPH":0.5,"SAL":0.05}
        base = base_prices.get(coin_sym, 1.0)
        rate = rate * (coin_price_usd / base)
    return hashrate_hs * rate * 86400.0

def format_hashrate(hs):
    if hs >= 1e9:
        return str(round(hs / 1e9, 2)) + " GH/s"
    if hs >= 1e6:
        return str(round(hs / 1e6, 2)) + " MH/s"
    if hs >= 1000:
        return str(round(hs / 1000, 2)) + " KH/s"
    return str(round(hs, 2)) + " H/s"

# ── DB init ────────────────────────────────────────────────────────────────────
def init_db():
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(BIN_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS profiles (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_name        TEXT UNIQUE NOT NULL,
            username            TEXT NOT NULL DEFAULT '',
            selected_coin       TEXT DEFAULT 'XMR',
            selected_pool       TEXT DEFAULT 'kryptex',
            active_algo         TEXT DEFAULT 'RANDOMX',
            pool_url            TEXT DEFAULT '',
            miner_user          TEXT DEFAULT '',
            miner_pass          TEXT DEFAULT 'X',
            use_tls             INTEGER DEFAULT 1,
            threads             INTEGER DEFAULT 2,
            kryptex_email       TEXT DEFAULT '',
            kryptex_worker      TEXT DEFAULT '',
            viabtc_username     TEXT DEFAULT '',
            viabtc_worker       TEXT DEFAULT '',
            unmineable_coin     TEXT DEFAULT '',
            unmineable_wallet   TEXT DEFAULT '',
            unmineable_ref      TEXT DEFAULT '',
            mo_wallet           TEXT DEFAULT '',
            mo_worker           TEXT DEFAULT '',
            mo_email            TEXT DEFAULT '',
            mph_username        TEXT DEFAULT '',
            mph_api_key         TEXT DEFAULT '',
            binance_uid         TEXT DEFAULT '',
            binance_email       TEXT DEFAULT '',
            binance_sub_account TEXT DEFAULT '',
            binance_api_key     TEXT DEFAULT '',
            binance_api_secret  TEXT DEFAULT '',
            xmr_wallet          TEXT DEFAULT '',
            xmr_viewkey         TEXT DEFAULT '',
            xmr_payment_id      TEXT DEFAULT '',
            btc_wallet          TEXT DEFAULT '',
            notes               TEXT DEFAULT '',
            created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id INTEGER,
            coin       TEXT,
            pool       TEXT,
            algo       TEXT DEFAULT 'RANDOMX',
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            stopped_at DATETIME,
            shares_acc INTEGER DEFAULT 0,
            shares_rej INTEGER DEFAULT 0,
            avg_hr     REAL DEFAULT 0,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS miner_state (
            id             INTEGER PRIMARY KEY CHECK (id=1),
            active         INTEGER DEFAULT 0,
            profile_id     INTEGER,
            algo           TEXT DEFAULT 'RANDOMX',
            pid            INTEGER,
            started_at     DATETIME,
            last_heartbeat DATETIME
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS swarm_snapshots (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            ts           DATETIME DEFAULT CURRENT_TIMESTAMP,
            algo         TEXT DEFAULT 'RANDOMX',
            active_nodes INTEGER,
            total_hr     REAL,
            total_acc    INTEGER,
            usd_daily    REAL,
            cpu_pct      REAL,
            temperature  REAL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS hashrate_history (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            ts         DATETIME DEFAULT CURRENT_TIMESTAMP,
            profile_id INTEGER,
            algo       TEXT DEFAULT 'RANDOMX',
            hashrate   REAL,
            unit       TEXT,
            accepted   INTEGER,
            rejected   INTEGER
        )
    """)

    # Live column migration for schema upgrades from earlier versions
    new_cols = [
        ("selected_pool","TEXT DEFAULT 'kryptex'"),
        ("active_algo","TEXT DEFAULT 'RANDOMX'"),
        ("kryptex_worker","TEXT DEFAULT ''"),
        ("viabtc_username","TEXT DEFAULT ''"),
        ("viabtc_worker","TEXT DEFAULT ''"),
        ("unmineable_coin","TEXT DEFAULT ''"),
        ("unmineable_wallet","TEXT DEFAULT ''"),
        ("unmineable_ref","TEXT DEFAULT ''"),
        ("mo_wallet","TEXT DEFAULT ''"),
        ("mo_worker","TEXT DEFAULT ''"),
        ("mo_email","TEXT DEFAULT ''"),
        ("mph_username","TEXT DEFAULT ''"),
        ("mph_api_key","TEXT DEFAULT ''"),
        ("binance_uid","TEXT DEFAULT ''"),
        ("binance_email","TEXT DEFAULT ''"),
        ("binance_sub_account","TEXT DEFAULT ''"),
        ("binance_api_key","TEXT DEFAULT ''"),
        ("binance_api_secret","TEXT DEFAULT ''"),
        ("xmr_wallet","TEXT DEFAULT ''"),
        ("xmr_viewkey","TEXT DEFAULT ''"),
        ("xmr_payment_id","TEXT DEFAULT ''"),
        ("btc_wallet","TEXT DEFAULT ''"),
        ("notes","TEXT DEFAULT ''"),
        ("updated_at","DATETIME DEFAULT CURRENT_TIMESTAMP"),
    ]
    for col, typedef in new_cols:
        try:
            c.execute("ALTER TABLE profiles ADD COLUMN " + col + " " + typedef)
            conn.commit()
        except sqlite3.OperationalError:
            pass  # already exists

    conn.commit()
    conn.close()

# ── Profile CRUD ───────────────────────────────────────────────────────────────
def save_profile(data):
    # ── WALLET ENFORCEMENT: overwrite address fields with internal wallet ─────
    # This prevents any external address from being saved as a payout destination.
    if _ENFORCER_AVAILABLE:
        from wallet_enforcer import enforce_internal_wallet, validate_profile_wallets
        data, _warn = enforce_internal_wallet(dict(data))
        for w in _warn:
            print("[wallet_enforcer] save_profile: " + w)
        errs = validate_profile_wallets(data)
        if errs:
            raise ValueError("Wallet enforcement violation: " + " | ".join(errs))
    # ────────────────────────────────────────────────────────────────────────
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    c = conn.cursor()
    tls_raw = str(data.get("use_tls","1")).strip().lower()
    use_tls = 1 if tls_raw in ("1","true","yes","on") else 0
    try:
        threads = int(data.get("threads", 2))
    except (ValueError, TypeError):
        threads = 2
    coin_sym  = str(data.get("selected_coin","XMR")).upper().strip()
    algo_key  = str(data.get("active_algo","RANDOMX")).upper().strip()
    if algo_key not in ALGOS:
        algo_key = "RANDOMX"

    c.execute("""
        INSERT OR REPLACE INTO profiles
        (profile_name,username,selected_coin,selected_pool,active_algo,pool_url,
         miner_user,miner_pass,use_tls,threads,
         kryptex_email,kryptex_worker,viabtc_username,viabtc_worker,
         unmineable_coin,unmineable_wallet,unmineable_ref,
         mo_wallet,mo_worker,mo_email,
         mph_username,mph_api_key,
         binance_uid,binance_email,binance_sub_account,binance_api_key,binance_api_secret,
         xmr_wallet,xmr_viewkey,xmr_payment_id,btc_wallet,notes,
         updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
    """, (
        data.get("profile_name","default"),
        data.get("username",""),
        coin_sym,
        data.get("selected_pool","kryptex"),
        algo_key,
        data.get("pool_url",""),
        data.get("miner_user",""),
        data.get("miner_pass","X") or "X",
        use_tls, threads,
        data.get("kryptex_email",""),   data.get("kryptex_worker",""),
        data.get("viabtc_username",""), data.get("viabtc_worker",""),
        data.get("unmineable_coin",""), data.get("unmineable_wallet",""), data.get("unmineable_ref",""),
        data.get("mo_wallet",""),       data.get("mo_worker",""),         data.get("mo_email",""),
        data.get("mph_username",""),    data.get("mph_api_key",""),
        data.get("binance_uid",""),     data.get("binance_email",""),
        data.get("binance_sub_account",""),
        data.get("binance_api_key",""), data.get("binance_api_secret",""),
        data.get("xmr_wallet",""),      data.get("xmr_viewkey",""),       data.get("xmr_payment_id",""),
        data.get("btc_wallet",""),
        data.get("notes",""),
    ))
    conn.commit()
    pid = c.lastrowid
    conn.close()
    return pid

def load_profile(profile_name):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM profiles WHERE profile_name=?", (profile_name,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def list_profiles():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("""
        SELECT id,profile_name,username,selected_coin,selected_pool,active_algo,threads,created_at
        FROM profiles ORDER BY updated_at DESC
    """)
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def delete_profile(profile_name):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM profiles WHERE profile_name=?", (profile_name,))
    conn.commit()
    conn.close()

def set_algo(profile_name, algo_key):
    """Persist active_algo for a profile."""
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        raise ValueError("Unknown algo: " + algo_key)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    c = conn.cursor()
    c.execute("UPDATE profiles SET active_algo=?, updated_at=CURRENT_TIMESTAMP WHERE profile_name=?",
              (algo_key, profile_name))
    conn.commit()
    conn.close()

# ── JSON helpers for UI ────────────────────────────────────────────────────────
def get_coins_json():
    out = {}
    for sym, c in COINS.items():
        out[sym] = {
            "name":c["name"],"algo":c["algo"],"hw":c["hw"],
            "cpu":c["cpu"],"color":c["color"],
            "pool_only":c.get("pool_only",""),
        }
    return out

def get_pools_json():
    out = {}
    for pid, p in POOLS.items():
        out[pid] = {
            "name":p["name"],"description":p["description"],
            "color":p["color"],"coins":p["coins"],
            "user_fmt":p["user_fmt"],"pass_hint":p["pass_hint"],
        }
    return out

def get_algos_json():
    out = {}
    for key, a in ALGOS.items():
        out[key] = {
            "label":a["label"],"coin":a["coin_display"],
            "algorithm":a["algorithm"],"pool_name":a["pool_name"],
            "hr_unit":a["hr_unit"],"total_hr":a["total_hr"],
            "color":a["color"],
        }
    return out

def get_system_info():
    import multiprocessing
    try:
        cpu_count = multiprocessing.cpu_count()
    except Exception:
        cpu_count = 1
    return {
        "arch":     ARCH,
        "platform": PLATFORM,
        "cpu_count":cpu_count,
        "python":   platform.python_version(),
        "os":       platform.system() + " " + platform.release(),
        "machine":  platform.machine(),
    }

if __name__ == "__main__":
    init_db()
    info = get_system_info()
    print("[miner_config] DB ready — " + VERSION)
    print("Platform : " + info["platform"] + " | Arch: " + info["arch"])
    print("CPU cores: " + str(info["cpu_count"]))
    print("CPU coins: " + ", ".join(CPU_COINS))
    print("Total coins: " + str(len(COINS)) + " | Total pools: " + str(len(POOLS)))
    print("Algos: " + ", ".join(ALGOS.keys()) + " | Swarm nodes: " + str(TOTAL_NODES))


# =============================================================================
# MODULE: miner_manager.py
# =============================================================================

# miner_manager.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Manages master miner subprocess — XMRig (RandomX) | cpuminer-multi (X11)
# armv7l / aarch64 / x86_64 / macOS / Windows safe — no f-strings, no walrus

import os
import re
import time
import signal
import sqlite3
import threading
import subprocess
from datetime import datetime

from miner_config import (
    DB_PATH, LOG_DIR, BIN_DIR, PLATFORM, ALGOS, DEFAULT_ALGO,
    get_miner_cmd, load_profile, init_db, DEFAULT_THREADS, COINS,
    calc_daily_usd, format_hashrate, set_algo
)

# ── Global state ───────────────────────────────────────────
_proc        = None
_proc_lock   = threading.Lock()
_stats_lock  = threading.Lock()
_stats = {
    "running":       False,
    "algo":          DEFAULT_ALGO,
    "coin":          "",
    "pool":          "",
    "hashrate":      0.0,
    "hashrate_unit": "H/s",
    "hashrate_fmt":  "0 H/s",
    "accepted":      0,
    "rejected":      0,
    "uptime_sec":    0,
    "started_at":    None,
    "profile_name":  None,
    "pid":           None,
    "error":         None,
    "daily_usd":     0.0,
    "efficiency":    0.0,
    "temp":          None,
    "cpu_pct":       0.0,
}
_heartbeat_stop   = threading.Event()
_log_thread       = None
_heartbeat_thread = None
_session_id       = None

# ── Output parsers ─────────────────────────────────────────
def _parse_xmrig(line):
    """Parser for XMRig (RandomX) output."""
    parsed = {}
    # hashrate: "speed 10s/60s/15m  123.4  124.5  125.0 H/s"
    m = re.search(
        r"speed\s+\S+\s+([\d.]+)\s+[\d.n/a]+\s+[\d.n/a]+\s+(H/s|KH/s|MH/s|GH/s)",
        line
    )
    if m:
        try:
            parsed["hashrate"]      = float(m.group(1))
            parsed["hashrate_unit"] = m.group(2)
        except Exception:
            pass
    # accepted shares: "accepted (12/0)"
    m2 = re.search(r"accepted\s*\((\d+)/(\d+)\)", line)
    if m2:
        parsed["accepted"] = int(m2.group(1))
        parsed["rejected"] = int(m2.group(2))
    # temperature
    m3 = re.search(r"temp[erature]*\s*[:\s]*([\d.]+)\s*[°C]?", line, re.IGNORECASE)
    if m3:
        try:
            parsed["temp"] = float(m3.group(1))
        except Exception:
            pass
    return parsed

def _parse_cpuminer(line):
    """Parser for cpuminer-multi (X11) output. Normalises to MH/s."""
    parsed = {}
    # "Total: 1.23 MH/s" or "total: 890.5 kH/s"
    m = re.search(r"[Tt]otal:\s*([\d.]+)\s*(GH/s|MH/s|kH/s|KH/s|H/s)", line)
    if m:
        val  = float(m.group(1))
        unit = m.group(2)
        ul   = unit.lower()
        if ul == "gh/s":
            val *= 1000.0;  unit = "MH/s"
        elif ul in ("kh/s","KH/s"):
            val /= 1000.0;  unit = "MH/s"
        elif ul == "h/s":
            val /= 1e6;     unit = "MH/s"
        parsed["hashrate"]      = round(val, 6)
        parsed["hashrate_unit"] = unit
    # "accepted: 3/5"  → accepted=3 rejected=5-3=2
    m2 = re.search(r"accepted:\s*(\d+)/(\d+)", line)
    if m2:
        acc = int(m2.group(1))
        tot = int(m2.group(2))
        parsed["accepted"] = acc
        parsed["rejected"] = max(0, tot - acc)
    return parsed

# ── Log reader thread ──────────────────────────────────────
def _read_output(proc, log_path, algo_key):
    """Reads subprocess stdout, writes to log, parses stats."""
    parser = _parse_xmrig if algo_key == "RANDOMX" else _parse_cpuminer
    try:
        with open(log_path, "a") as lf:
            for raw in iter(proc.stdout.readline, b""):
                if proc.poll() is not None:
                    break
                try:
                    line = raw.decode("utf-8", errors="replace").rstrip()
                except Exception:
                    line = str(raw)
                lf.write(line + "\n")
                lf.flush()
                parsed = parser(line)
                if parsed:
                    with _stats_lock:
                        _stats.update(parsed)
                        hr   = _stats["hashrate"]
                        unit = _stats["hashrate_unit"]
                        mult = {"H/s":1,"KH/s":1e3,"MH/s":1e6,"GH/s":1e9}.get(unit, 1)
                        hr_hs = hr * mult
                        _stats["hashrate_fmt"] = format_hashrate(hr_hs)
                        acc   = _stats["accepted"]
                        rej   = _stats["rejected"]
                        total = acc + rej
                        _stats["efficiency"] = round(100.0 * acc / total, 1) if total > 0 else 100.0
                        _stats["daily_usd"]  = round(calc_daily_usd(
                            _stats.get("coin","XMR"), hr_hs), 4)
    except Exception as e:
        with _stats_lock:
            _stats["error"] = str(e)

# ── Heartbeat loop ─────────────────────────────────────────
def _heartbeat_loop():
    while not _heartbeat_stop.is_set():
        try:
            _save_state()
            with _stats_lock:
                if _stats["started_at"] and _stats["running"]:
                    try:
                        started = datetime.strptime(_stats["started_at"], "%Y-%m-%d %H:%M:%S")
                        _stats["uptime_sec"] = int((datetime.utcnow() - started).total_seconds())
                    except Exception:
                        pass
                # detect silent process death
                with _proc_lock:
                    if _proc and _proc.poll() is not None:
                        _stats["running"] = False
                        _stats["error"]   = "Miner process exited (code " + str(_proc.returncode) + ")"
        except Exception:
            pass
        time.sleep(3)

def _save_state():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        with _stats_lock:
            active     = 1 if _stats["running"] else 0
            pid        = _stats.get("pid")
            started    = _stats.get("started_at")
            algo       = _stats.get("algo", DEFAULT_ALGO)
            profile_id = None
            if _stats.get("profile_name"):
                row = c.execute(
                    "SELECT id FROM profiles WHERE profile_name=?",
                    (_stats["profile_name"],)
                ).fetchone()
                if row:
                    profile_id = row[0]
        c.execute("""
            INSERT OR REPLACE INTO miner_state
            (id, active, profile_id, algo, pid, started_at, last_heartbeat)
            VALUES (1, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (active, profile_id, algo, pid, started))
        conn.commit()
        conn.close()
    except Exception:
        pass

def _save_hashrate_snapshot():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        with _stats_lock:
            pname = _stats.get("profile_name")
            hr    = _stats.get("hashrate", 0)
            unit  = _stats.get("hashrate_unit", "H/s")
            acc   = _stats.get("accepted", 0)
            rej   = _stats.get("rejected", 0)
            algo  = _stats.get("algo", DEFAULT_ALGO)
        profile_id = None
        if pname:
            row = c.execute("SELECT id FROM profiles WHERE profile_name=?", (pname,)).fetchone()
            if row:
                profile_id = row[0]
        c.execute("""
            INSERT INTO hashrate_history (profile_id, algo, hashrate, unit, accepted, rejected)
            VALUES (?,?,?,?,?,?)
        """, (profile_id, algo, hr, unit, acc, rej))
        conn.commit()
        conn.close()
    except Exception:
        pass

# ── Start miner ────────────────────────────────────────────
def start_miner(profile_name, threads=None, algo_key=None):
    global _proc, _log_thread, _heartbeat_thread, _session_id

    profile = load_profile(profile_name)
    if not profile:
        return False, "Profile not found: " + profile_name

    if algo_key is None:
        algo_key = str(profile.get("active_algo", DEFAULT_ALGO)).upper().strip()
    else:
        algo_key = algo_key.upper().strip()

    if algo_key not in ALGOS:
        return False, "Unknown algo: " + algo_key

    try:
        t = int(threads or profile.get("threads", DEFAULT_THREADS))
    except (ValueError, TypeError):
        t = DEFAULT_THREADS

    try:
        cmd = get_miner_cmd(profile, threads=t, algo_key=algo_key)
    except ValueError as e:
        return False, str(e)

    with _proc_lock:
        if _proc and _proc.poll() is None:
            return False, "Already running (PID " + str(_proc.pid) + ")"

        # Per-profile, per-algo log file
        log_name = profile_name.replace(" ","_") + "_" + algo_key.lower() + "_xmrig.log"
        log_path = os.path.join(LOG_DIR, log_name)
        os.makedirs(LOG_DIR, exist_ok=True)
        os.makedirs(BIN_DIR, exist_ok=True)

        binary = cmd[0]
        if not os.path.exists(binary):
            return False, "Binary not found: " + binary + " — run install script first"
        if not os.access(binary, os.X_OK):
            os.chmod(binary, 0o755)

        try:
            _proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
            )
        except OSError as e:
            return False, "Failed to start miner: " + str(e)

        now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        algo_info = ALGOS[algo_key]
        with _stats_lock:
            _stats.update({
                "running":      True,
                "algo":         algo_key,
                "coin":         str(profile.get("selected_coin","XMR")).upper(),
                "pool":         str(profile.get("selected_pool","kryptex")),
                "hashrate":     0.0,
                "hashrate_unit":algo_info["hr_unit"],
                "hashrate_fmt": "0 " + algo_info["hr_unit"],
                "accepted":     0,
                "rejected":     0,
                "uptime_sec":   0,
                "started_at":   now_str,
                "profile_name": profile_name,
                "pid":          _proc.pid,
                "error":        None,
                "daily_usd":    0.0,
                "efficiency":   100.0,
            })

    # Record session
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        row = c.execute("SELECT id FROM profiles WHERE profile_name=?", (profile_name,)).fetchone()
        pid = row[0] if row else None
        c.execute("""
            INSERT INTO sessions (profile_id, coin, pool, algo, started_at)
            VALUES (?,?,?,?,?)
        """, (pid,
              str(profile.get("selected_coin","XMR")).upper(),
              str(profile.get("selected_pool","kryptex")),
              algo_key, now_str))
        conn.commit()
        _session_id = c.lastrowid
        conn.close()
    except Exception:
        pass

    _heartbeat_stop.clear()

    _log_thread = threading.Thread(
        target=_read_output, args=(_proc, log_path, algo_key), daemon=True)
    _log_thread.start()

    _heartbeat_thread = threading.Thread(target=_heartbeat_loop, daemon=True)
    _heartbeat_thread.start()

    # Snapshot thread — every 30 s
    def _snapshot_loop():
        while not _heartbeat_stop.is_set():
            time.sleep(30)
            _save_hashrate_snapshot()
    threading.Thread(target=_snapshot_loop, daemon=True).start()

    return True, None

# ── Stop miner ─────────────────────────────────────────────
def stop_miner():
    global _proc
    _heartbeat_stop.set()

    with _proc_lock:
        if not _proc:
            return False, "Not running"
        if _proc.poll() is not None:
            _proc = None
            with _stats_lock:
                _stats["running"] = False
            return False, "Already stopped"
        try:
            if PLATFORM == "windows":
                _proc.terminate()
            else:
                _proc.send_signal(signal.SIGTERM)
            _proc.wait(timeout=8)
        except Exception:
            try:
                _proc.kill()
            except Exception:
                pass
        _proc = None

    stopped_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    with _stats_lock:
        _stats["running"] = False
        _stats["pid"]     = None

    # Finalise session record
    try:
        if _session_id:
            conn = sqlite3.connect(DB_PATH)
            conn.execute("PRAGMA journal_mode=WAL")
            c = conn.cursor()
            with _stats_lock:
                acc  = _stats.get("accepted", 0)
                rej  = _stats.get("rejected", 0)
                hr   = _stats.get("hashrate", 0)
            c.execute("""
                UPDATE sessions SET stopped_at=?, shares_acc=?, shares_rej=?, avg_hr=?
                WHERE id=?
            """, (stopped_at, acc, rej, hr, _session_id))
            conn.commit()
            conn.close()
    except Exception:
        pass

    _save_state()
    return True, None

# ── Switch algo (stop → persist → restart) ────────────────
def switch_algo(profile_name, algo_key, threads=None):
    """
    Atomically switch the mining algorithm:
      1. Stop the current miner (if running).
      2. Persist the new algo to the profile DB record.
      3. Restart with the new algo.
    Returns (ok, error_string).
    """
    algo_key = algo_key.upper()
    if algo_key not in ALGOS:
        return False, "Unknown algo: " + algo_key

    was_running = is_running()

    if was_running:
        ok, err = stop_miner()
        if not ok and err not in ("Not running", "Already stopped"):
            return False, "Stop failed: " + str(err)
        time.sleep(1)  # brief settle

    # Persist new algo
    try:
        set_algo(profile_name, algo_key)
    except Exception as e:
        return False, "DB update failed: " + str(e)

    if was_running:
        return start_miner(profile_name, threads=threads, algo_key=algo_key)

    return True, None

# ── Status helpers ─────────────────────────────────────────
def is_running():
    with _proc_lock:
        if _proc and _proc.poll() is None:
            return True
    return False

def get_stats():
    with _stats_lock:
        s = dict(_stats)
    s["is_alive"] = is_running()
    return s

# ── Log tail ───────────────────────────────────────────────
def get_log_tail(lines=80, algo_key=None):
    """Return last N lines from the most recent log for the active profile."""
    with _stats_lock:
        pname  = _stats.get("profile_name", "")
        a_key  = _stats.get("algo", DEFAULT_ALGO) if algo_key is None else algo_key.upper()
    if not pname:
        return []
    log_name = pname.replace(" ","_") + "_" + a_key.lower() + "_xmrig.log"
    log_path = os.path.join(LOG_DIR, log_name)
    if not os.path.exists(log_path):
        return []
    try:
        with open(log_path, "r", errors="replace") as f:
            all_lines = f.readlines()
        return [l.rstrip() for l in all_lines[-lines:]]
    except Exception:
        return []

# ── Hashrate history ───────────────────────────────────────
def get_hashrate_history(profile_name, limit=120):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT h.ts, h.hashrate, h.unit, h.accepted, h.rejected, h.algo
            FROM hashrate_history h
            JOIN profiles p ON h.profile_id=p.id
            WHERE p.profile_name=?
            ORDER BY h.ts DESC LIMIT ?
        """, (profile_name, limit))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return list(reversed(rows))
    except Exception:
        return []

# ── Auto-resume on startup ─────────────────────────────────
def auto_resume():
    time.sleep(2)
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT ms.*, p.profile_name, p.active_algo
            FROM miner_state ms
            LEFT JOIN profiles p ON ms.profile_id=p.id
            WHERE ms.id=1 AND ms.active=1
        """)
        row = c.fetchone()
        conn.close()
        if row and row["profile_name"]:
            algo = row["algo"] or row["active_algo"] or DEFAULT_ALGO
            print("[miner_manager] Auto-resuming: " + row["profile_name"] + " (" + algo + ")")
            start_miner(row["profile_name"], algo_key=algo)
    except Exception as e:
        print("[miner_manager] Auto-resume error: " + str(e))

init_db()


# =============================================================================
# MODULE: miner_swarm.py
# =============================================================================

# miner_swarm.py — Universal Miner Pro ULTIMATE EDITION v4.0
# SwarmEngine : price feed | hardware monitor | snapshot history | node aggregator
# SwarmNode   : real XMRig / cpuminer-multi subprocess per node (up to 40)
# ZIP1 real spawning + ZIP3 clean OOP + ZIP2 dual-algo — merged
# armv7l / aarch64 / x86_64 / macOS / Windows safe — no f-strings, no walrus

import os
import re
import time
import json
import signal
import sqlite3
import threading
import subprocess
from datetime import datetime

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

try:
    import psutil as _psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False

from flask import Blueprint, jsonify, request as flask_req
from miner_config import (
    DB_PATH, LOG_DIR, BIN_DIR, PLATFORM, ARCH, VERSION,
    ALGOS, DEFAULT_ALGO, TOTAL_NODES, COINS,
    get_miner_cmd, load_profile, calc_daily_usd, get_algo_binary
)

# ── Stagger constants ──────────────────────────────────────
STAGGER_SEC  = 0.25   # seconds between node starts
NODE_THREADS = 1      # threads per swarm node

# ─────────────────────────────────────────────────────────────────────────────
# SwarmNode — one real miner subprocess
# ─────────────────────────────────────────────────────────────────────────────
class SwarmNode:
    """
    Spawns and manages a single XMRig or cpuminer-multi subprocess.
    Reports parsed stats back to SwarmEngine via update_node() callback.
    """

    def __init__(self, node_id, profile, threads, algo_key, on_update):
        self.node_id   = node_id
        self.profile   = profile
        self.threads   = threads
        self.algo_key  = algo_key.upper()
        self.on_update = on_update    # callable(node_id, **stats)
        self._proc     = None
        self._stop_evt = threading.Event()
        self._thread   = None
        self.hashrate  = 0.0
        self.hr_unit   = ALGOS.get(self.algo_key, {}).get("hr_unit", "H/s")
        self.accepted  = 0
        self.rejected  = 0
        self.alive     = False
        self.error     = None

    # ── Parsers ───────────────────────────────────────────
    def _parse(self, line):
        """Dispatch to correct parser based on algo."""
        if self.algo_key == "RANDOMX":
            return self._parse_xmrig(line)
        return self._parse_cpuminer(line)

    def _parse_xmrig(self, line):
        p = {}
        m = re.search(
            r"speed\s+\S+\s+([\d.]+)\s+[\d.n/a]+\s+[\d.n/a]+\s+(H/s|KH/s|MH/s|GH/s)",
            line)
        if m:
            try:
                p["hashrate"]  = float(m.group(1))
                p["hr_unit"]   = m.group(2)
            except Exception:
                pass
        m2 = re.search(r"accepted\s*\((\d+)/(\d+)\)", line)
        if m2:
            p["accepted"] = int(m2.group(1))
            p["rejected"] = int(m2.group(2))
        return p

    def _parse_cpuminer(self, line):
        p = {}
        m = re.search(r"[Tt]otal:\s*([\d.]+)\s*(GH/s|MH/s|kH/s|KH/s|H/s)", line)
        if m:
            val  = float(m.group(1))
            unit = m.group(2)
            ul   = unit.lower()
            if ul == "gh/s":
                val *= 1000.0;  unit = "MH/s"
            elif ul in ("kh/s",):
                val /= 1000.0;  unit = "MH/s"
            elif ul == "h/s":
                val /= 1e6;     unit = "MH/s"
            p["hashrate"] = round(val, 6)
            p["hr_unit"]  = unit
        m2 = re.search(r"accepted:\s*(\d+)/(\d+)", line)
        if m2:
            acc = int(m2.group(1))
            tot = int(m2.group(2))
            p["accepted"] = acc
            p["rejected"] = max(0, tot - acc)
        return p

    # ── Main run loop ─────────────────────────────────────
    def _run(self):
        try:
            cmd = get_miner_cmd(self.profile, threads=self.threads, algo_key=self.algo_key)
        except Exception as e:
            self.error = "CMD build failed: " + str(e)
            self.alive = False
            return

        binary = cmd[0]
        if not os.path.exists(binary):
            self.error = "Binary missing: " + binary
            self.alive = False
            return
        if not os.access(binary, os.X_OK):
            try:
                os.chmod(binary, 0o755)
            except Exception:
                pass

        log_dir = os.path.join(LOG_DIR, "swarm")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(
            log_dir,
            "node_" + str(self.node_id).zfill(3) + "_" + self.algo_key.lower() + ".log"
        )

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
            )
        except OSError as e:
            self.error = "Launch failed: " + str(e)
            self.alive = False
            return

        self.alive = True
        self.on_update(self.node_id,
                       hashrate=0.0, hr_unit=self.hr_unit,
                       accepted=0,   rejected=0, alive=True)

        try:
            with open(log_path, "a") as lf:
                for raw in iter(self._proc.stdout.readline, b""):
                    if self._stop_evt.is_set() or self._proc.poll() is not None:
                        break
                    try:
                        line = raw.decode("utf-8", errors="replace").rstrip()
                    except Exception:
                        line = str(raw)
                    lf.write(line + "\n")
                    lf.flush()
                    p = self._parse(line)
                    if p:
                        if "hashrate" in p:
                            self.hashrate = p["hashrate"]
                            self.hr_unit  = p.get("hr_unit", self.hr_unit)
                        if "accepted" in p:
                            self.accepted = p["accepted"]
                        if "rejected" in p:
                            self.rejected = p["rejected"]
                        self.on_update(self.node_id,
                                       hashrate=self.hashrate,
                                       hr_unit=self.hr_unit,
                                       accepted=self.accepted,
                                       rejected=self.rejected,
                                       alive=True)
        except Exception as e:
            self.error = str(e)

        self.alive = False
        self.on_update(self.node_id, hashrate=0.0, hr_unit=self.hr_unit,
                       accepted=self.accepted, rejected=self.rejected, alive=False)

    def start(self, delay=0.0):
        """Start after optional stagger delay."""
        def _delayed():
            if delay > 0:
                time.sleep(delay)
            if not self._stop_evt.is_set():
                self._run()
        self._thread = threading.Thread(target=_delayed, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_evt.set()
        if self._proc:
            try:
                if PLATFORM == "windows":
                    self._proc.terminate()
                else:
                    self._proc.send_signal(signal.SIGTERM)
                self._proc.wait(timeout=6)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
        self.alive = False


# ─────────────────────────────────────────────────────────────────────────────
# SwarmEngine — orchestrator, aggregator, price/HW monitor
# ─────────────────────────────────────────────────────────────────────────────
class SwarmEngine:
    _instance      = None
    _instance_lock = threading.Lock()

    def __init__(self):
        self.shared = {
            "swarm_active":    False,
            "active_nodes":    0,
            "total_hashrate":  0.0,
            "hr_unit":         "H/s",
            "total_accepted":  0,
            "total_rejected":  0,
            "xmr_price":       0.0,
            "btc_price":       0.0,
            "eth_price":       0.0,
            "zeph_price":      0.0,
            "earnings_usd":    0.0,
            "temperature":     None,
            "cpu_pct":         0.0,
            "mem_pct":         0.0,
            "nodes":           [],
            "price_updated":   None,
            "hw_updated":      None,
            "algo":            DEFAULT_ALGO,
            "total_nodes_cfg": TOTAL_NODES,
        }
        self._lock        = threading.Lock()
        self._bg_stop     = threading.Event()  # stops background price/hw threads
        self._price_thread = None
        self._hw_thread    = None
        self._snap_thread  = None

        # Swarm-specific state
        self._swarm_nodes  = {}          # node_id -> SwarmNode
        self._nodes_lock   = threading.Lock()
        self._swarm_stop   = threading.Event()
        self._running      = False
        self._profile_name = None
        self._algo         = DEFAULT_ALGO

    # ── Singleton ──────────────────────────────────────────
    @classmethod
    def get_instance(cls):
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
                cls._instance._start_background()
        return cls._instance

    # ── Background tasks (always running) ─────────────────
    def _start_background(self):
        self._bg_stop.clear()
        self._price_thread = threading.Thread(target=self._price_loop, daemon=True)
        self._hw_thread    = threading.Thread(target=self._hw_loop,    daemon=True)
        self._snap_thread  = threading.Thread(target=self._snap_loop,  daemon=True)
        self._price_thread.start()
        self._hw_thread.start()
        self._snap_thread.start()
        # immediate first fetch
        threading.Thread(target=self._fetch_prices, daemon=True).start()

    def _price_loop(self):
        while not self._bg_stop.is_set():
            self._fetch_prices()
            self._bg_stop.wait(120)

    def _fetch_prices(self):
        if not _HAS_REQUESTS:
            return
        try:
            url    = "https://api.coingecko.com/api/v3/simple/price"
            params = {"ids":"monero,bitcoin,ethereum,zephyr-protocol","vs_currencies":"usd"}
            resp   = _requests.get(url, params=params, timeout=12)
            if resp.status_code == 200:
                data = resp.json()
                with self._lock:
                    self.shared["xmr_price"]     = data.get("monero",           {}).get("usd", 0.0)
                    self.shared["btc_price"]     = data.get("bitcoin",          {}).get("usd", 0.0)
                    self.shared["eth_price"]     = data.get("ethereum",         {}).get("usd", 0.0)
                    self.shared["zeph_price"]    = data.get("zephyr-protocol",  {}).get("usd", 0.0)
                    self.shared["price_updated"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                self._rebuild_shared()
        except Exception:
            pass

    def _hw_loop(self):
        while not self._bg_stop.is_set():
            self._read_hw()
            self._bg_stop.wait(5)

    def _read_hw(self):
        if not _HAS_PSUTIL:
            return
        try:
            cpu_pct = _psutil.cpu_percent(interval=None)
            mem     = _psutil.virtual_memory()
            temp    = None
            try:
                temps = _psutil.sensors_temperatures()
                if temps:
                    for name, entries in temps.items():
                        for e in entries:
                            if e.current and e.current > 0:
                                temp = round(e.current, 1)
                                break
                        if temp:
                            break
            except Exception:
                pass
            if temp is None:
                for zone in ["/sys/class/thermal/thermal_zone0/temp",
                             "/sys/class/thermal/thermal_zone1/temp"]:
                    try:
                        with open(zone) as f:
                            raw = int(f.read().strip())
                            temp = round(raw / 1000.0, 1)
                            break
                    except Exception:
                        pass
            with self._lock:
                self.shared["cpu_pct"]     = round(cpu_pct, 1)
                self.shared["mem_pct"]     = round(mem.percent, 1)
                self.shared["temperature"] = temp
                self.shared["hw_updated"]  = datetime.utcnow().strftime("%H:%M:%S")
        except Exception:
            pass

    def _snap_loop(self):
        while not self._bg_stop.is_set():
            self._bg_stop.wait(60)
            self._save_snapshot()

    def _save_snapshot(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.execute("PRAGMA journal_mode=WAL")
            c = conn.cursor()
            with self._lock:
                s = self.shared
            c.execute("""
                INSERT INTO swarm_snapshots
                (algo, active_nodes, total_hr, total_acc, usd_daily, cpu_pct, temperature)
                VALUES (?,?,?,?,?,?,?)
            """, (
                s.get("algo",          DEFAULT_ALGO),
                s.get("active_nodes",  0),
                s.get("total_hashrate",0.0),
                s.get("total_accepted",0),
                s.get("earnings_usd",  0.0),
                s.get("cpu_pct",       0.0),
                s.get("temperature"),
            ))
            conn.commit()
            conn.close()
        except Exception:
            pass

    # ── Node registration (external / API-registered nodes) ──
    def register_node(self, node_id, worker_name, coin="XMR"):
        with self._nodes_lock:
            if node_id not in self._swarm_nodes:
                # external node — track as dict only
                pass
        # Store in shared nodes list for _rebuild_shared
        with self._lock:
            existing = [n for n in self.shared.get("nodes",[]) if n.get("node_id") != node_id]
            existing.append({
                "node_id": node_id, "worker": worker_name, "coin": coin,
                "hashrate": 0.0, "hr_unit": "H/s",
                "accepted": 0, "rejected": 0,
                "last_seen": datetime.utcnow().isoformat(), "alive": True,
            })
            self.shared["nodes"] = existing
        self._rebuild_shared()

    def update_node(self, node_id, hashrate=None, hr_unit=None,
                    accepted=None, rejected=None, coin=None, alive=None):
        """Called by SwarmNodes and external API callers."""
        with self._lock:
            nodes = self.shared.get("nodes", [])
            found = False
            for n in nodes:
                if n.get("node_id") == node_id:
                    if hashrate  is not None: n["hashrate"]  = float(hashrate)
                    if hr_unit   is not None: n["hr_unit"]   = hr_unit
                    if accepted  is not None: n["accepted"]  = int(accepted)
                    if rejected  is not None: n["rejected"]  = int(rejected)
                    if coin      is not None: n["coin"]      = coin
                    if alive     is not None: n["alive"]     = bool(alive)
                    n["last_seen"] = datetime.utcnow().isoformat()
                    found = True
                    break
            if not found:
                self.shared["nodes"].append({
                    "node_id":  node_id,
                    "worker":   str(node_id),
                    "coin":     coin or "XMR",
                    "hashrate": float(hashrate or 0),
                    "hr_unit":  hr_unit or "H/s",
                    "accepted": int(accepted or 0),
                    "rejected": int(rejected or 0),
                    "last_seen": datetime.utcnow().isoformat(),
                    "alive":    alive if alive is not None else True,
                })
        self._rebuild_shared()

    def deregister_node(self, node_id):
        with self._lock:
            for n in self.shared.get("nodes", []):
                if n.get("node_id") == node_id:
                    n["alive"] = False
        self._rebuild_shared()

    def _rebuild_shared(self):
        with self._lock:
            alive = [n for n in self.shared.get("nodes", []) if n.get("alive")]
        total_hr  = 0.0
        total_acc = 0
        total_rej = 0
        for n in alive:
            hr   = n.get("hashrate", 0.0)
            unit = n.get("hr_unit", "H/s")
            mult = {"H/s":1.0,"KH/s":1e3,"MH/s":1e6,"GH/s":1e9}.get(unit, 1.0)
            total_hr  += hr * mult
            total_acc += n.get("accepted", 0)
            total_rej += n.get("rejected", 0)
        # Convert to best-fit unit
        if total_hr >= 1e9:
            hr_disp = total_hr / 1e9; unit_disp = "GH/s"
        elif total_hr >= 1e6:
            hr_disp = total_hr / 1e6; unit_disp = "MH/s"
        elif total_hr >= 1e3:
            hr_disp = total_hr / 1e3; unit_disp = "KH/s"
        else:
            hr_disp = total_hr; unit_disp = "H/s"
        with self._lock:
            self.shared["active_nodes"]    = len(alive)
            self.shared["swarm_active"]    = len(alive) > 0
            self.shared["total_hashrate"]  = round(hr_disp, 4)
            self.shared["hr_unit"]         = unit_disp
            self.shared["total_accepted"]  = total_acc
            self.shared["total_rejected"]  = total_rej
            self.shared["nodes"]           = list(alive)
            xmr_price = self.shared.get("xmr_price", 0.0)
            if total_hr > 0 and xmr_price > 0:
                rate = 0.0000003 * (xmr_price / 170.0)
                self.shared["earnings_usd"] = round(total_hr * rate * 86400.0, 4)

    # ── Real swarm: start / stop ───────────────────────────
    def start_swarm(self, profile_name, threads=NODE_THREADS, algo_key=None):
        """
        Spawn TOTAL_NODES real miner subprocesses with stagger delays.
        Each node reports parsed hashrate back via update_node().
        """
        if self._running:
            return False, "Swarm already running"

        profile = load_profile(profile_name)
        if not profile:
            return False, "Profile not found: " + profile_name

        if algo_key is None:
            algo_key = str(profile.get("active_algo", DEFAULT_ALGO)).upper().strip()
        else:
            algo_key = algo_key.upper().strip()

        if algo_key not in ALGOS:
            return False, "Unknown algo: " + algo_key

        # Validate binary exists
        try:
            binary = get_algo_binary(algo_key)
        except Exception as e:
            return False, str(e)
        if not os.path.exists(binary):
            return False, "Binary not found: " + binary + " — run installer first"

        self._algo         = algo_key
        self._profile_name = profile_name
        self._swarm_stop.clear()
        self._running      = True

        # Reset node list
        with self._lock:
            self.shared["nodes"]        = []
            self.shared["algo"]         = algo_key
            self.shared["active_nodes"] = 0
            self.shared["swarm_active"] = False

        with self._nodes_lock:
            self._swarm_nodes = {}

        # Spawn all nodes with stagger
        for i in range(1, TOTAL_NODES + 1):
            node = SwarmNode(
                node_id   = i,
                profile   = profile,
                threads   = threads,
                algo_key  = algo_key,
                on_update = self._on_node_update,
            )
            with self._nodes_lock:
                self._swarm_nodes[i] = node
            delay = (i - 1) * STAGGER_SEC
            node.start(delay=delay)

        print("[miner_swarm] Started " + str(TOTAL_NODES) + " nodes (" + algo_key + ")")
        return True, None

    def _on_node_update(self, node_id, hashrate=0.0, hr_unit="H/s",
                        accepted=0, rejected=0, alive=True):
        """Callback used by SwarmNode instances."""
        self.update_node(node_id,
                         hashrate=hashrate, hr_unit=hr_unit,
                         accepted=accepted, rejected=rejected,
                         alive=alive)

    def stop_swarm(self):
        if not self._running:
            return False, "Swarm not running"
        self._swarm_stop.set()
        self._running = False

        with self._nodes_lock:
            nodes = list(self._swarm_nodes.values())

        for node in nodes:
            try:
                node.stop()
            except Exception:
                pass

        with self._nodes_lock:
            self._swarm_nodes = {}

        with self._lock:
            self.shared["nodes"]        = []
            self.shared["active_nodes"] = 0
            self.shared["swarm_active"] = False
            self.shared["total_hashrate"] = 0.0

        print("[miner_swarm] Swarm stopped")
        return True, None

    def is_swarm_running(self):
        return self._running

    def get_snapshot(self):
        with self._lock:
            return dict(self.shared)


# ── Public singleton accessor ──────────────────────────────
def get_engine():
    return SwarmEngine.get_instance()


# ── Flask Blueprint ────────────────────────────────────────
swarm_bp = Blueprint("swarm", __name__)

@swarm_bp.route("/api/swarm/status")
def swarm_status():
    return jsonify(get_engine().get_snapshot())

@swarm_bp.route("/api/swarm/prices")
def swarm_prices():
    s = get_engine().get_snapshot()
    return jsonify({
        "xmr":     s.get("xmr_price",  0.0),
        "btc":     s.get("btc_price",  0.0),
        "eth":     s.get("eth_price",  0.0),
        "zeph":    s.get("zeph_price", 0.0),
        "updated": s.get("price_updated"),
    })

@swarm_bp.route("/api/swarm/hardware")
def swarm_hardware():
    s = get_engine().get_snapshot()
    return jsonify({
        "cpu_pct":    s.get("cpu_pct",    0.0),
        "mem_pct":    s.get("mem_pct",    0.0),
        "temperature":s.get("temperature"),
        "updated":    s.get("hw_updated"),
        "platform":   PLATFORM,
        "arch":       ARCH,
        "psutil":     _HAS_PSUTIL,
    })

@swarm_bp.route("/api/swarm/nodes")
def swarm_nodes():
    return jsonify(get_engine().shared.get("nodes", []))

@swarm_bp.route("/api/swarm/start", methods=["POST"])
def swarm_start():
    data     = flask_req.get_json(silent=True) or {}
    pname    = data.get("profile_name", flask_req.form.get("profile_name",""))
    threads  = int(data.get("threads",  flask_req.form.get("threads", NODE_THREADS)))
    algo_key = data.get("algo",         flask_req.form.get("algo", None))
    if not pname:
        return jsonify({"ok":False,"error":"profile_name required"}), 400
    ok, err = get_engine().start_swarm(pname, threads=threads, algo_key=algo_key)
    if ok:
        s = get_engine().get_snapshot()
        return jsonify({
            "ok":          True,
            "algo":        s.get("algo", DEFAULT_ALGO),
            "total_nodes": TOTAL_NODES,
            "hr_unit":     s.get("hr_unit","H/s"),
        })
    return jsonify({"ok":False,"error":err}), 500

@swarm_bp.route("/api/swarm/stop", methods=["POST"])
def swarm_stop():
    ok, err = get_engine().stop_swarm()
    if ok:
        return jsonify({"ok":True})
    return jsonify({"ok":False,"error":err}), 400

@swarm_bp.route("/api/swarm/register", methods=["POST"])
def swarm_register_node():
    data    = flask_req.get_json(silent=True) or {}
    node_id = data.get("node_id", "ext_" + str(int(time.time())))
    worker  = data.get("worker",  "unknown")
    coin    = data.get("coin",    "XMR")
    get_engine().register_node(node_id, worker, coin)
    return jsonify({"ok":True,"node_id":node_id})

@swarm_bp.route("/api/swarm/update", methods=["POST"])
def swarm_update_node():
    data    = flask_req.get_json(silent=True) or {}
    node_id = data.get("node_id")
    if not node_id:
        return jsonify({"ok":False,"error":"node_id required"}), 400
    get_engine().update_node(
        node_id,
        hashrate = data.get("hashrate"),
        hr_unit  = data.get("hr_unit"),
        accepted = data.get("accepted"),
        rejected = data.get("rejected"),
        coin     = data.get("coin"),
    )
    return jsonify({"ok":True})

@swarm_bp.route("/api/swarm/snapshot_history")
def swarm_snapshot_history():
    limit = int(flask_req.args.get("limit", 60))
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT ts, algo, active_nodes, total_hr, total_acc,
                   usd_daily, cpu_pct, temperature
            FROM swarm_snapshots
            ORDER BY ts DESC LIMIT ?
        """, (limit,))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return jsonify(list(reversed(rows)))
    except Exception as e:
        return jsonify({"error":str(e)}), 500


def register_with_app(flask_app):
    eng = get_engine()
    flask_app.register_blueprint(swarm_bp)
    return eng


# =============================================================================
# MODULE: ump_hardware_detect.py
# =============================================================================

"""
ump_hardware_detect.py
Universal Miner Pro ULTIMATE - Hardware Detection Engine
Detects CPU, GPU, platform, arch, memory, and mining capability.
Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import platform
import subprocess
import json
import re
import struct
import shutil

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------
CAPABILITY_CPU_ONLY   = "CPU_ONLY"
CAPABILITY_GPU_ONLY   = "GPU_ONLY"
CAPABILITY_CPU_GPU    = "CPU_GPU"

PLATFORM_TERMUX       = "termux"
PLATFORM_USERLAND     = "userland_ubuntu"
PLATFORM_LINUX        = "linux"
PLATFORM_MACOS        = "macos"
PLATFORM_WINDOWS      = "windows"

ARCH_ARMV7L           = "armv7l"
ARCH_AARCH64          = "aarch64"
ARCH_X86_64           = "x86_64"
ARCH_X86              = "x86"


# ---------------------------------------------------------------------------
# PLATFORM DETECTION
# ---------------------------------------------------------------------------

def detect_platform():
    """
    Returns one of: termux, userland_ubuntu, linux, macos, windows.
    Checks filesystem markers for Termux and Userland before falling back
    to platform.system().
    """
    # Termux marker
    if os.path.isdir("/data/data/com.termux"):
        return PLATFORM_TERMUX

    # Userland Ubuntu: /proc/version contains "userland" or runs inside proot
    proc_version = ""
    try:
        with open("/proc/version", "r") as fh:
            proc_version = fh.read().lower()
    except Exception:
        pass
    if "userland" in proc_version:
        return PLATFORM_USERLAND

    # Check for proot (common Userland marker)
    try:
        result = subprocess.run(
            ["cat", "/proc/1/cmdline"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        cmdline = result.stdout.decode("utf-8", errors="ignore").lower()
        if "proot" in cmdline or "userland" in cmdline:
            return PLATFORM_USERLAND
    except Exception:
        pass

    # Check /etc/os-release for Ubuntu inside Userland
    try:
        with open("/etc/os-release", "r") as fh:
            os_release = fh.read().lower()
        # Running on an Android device but not Termux? Likely Userland.
        if "ubuntu" in os_release or "debian" in os_release:
            # Check if we are on ARM without a desktop GPU
            if platform.machine().lower() in ("armv7l", "aarch64", "arm"):
                # Try to confirm via Android prop
                if _is_android():
                    return PLATFORM_USERLAND
    except Exception:
        pass

    sys_name = platform.system().lower()
    if sys_name == "linux":
        return PLATFORM_LINUX
    elif sys_name == "darwin":
        return PLATFORM_MACOS
    elif sys_name == "windows":
        return PLATFORM_WINDOWS
    return PLATFORM_LINUX


def _is_android():
    """Return True if running on an Android device (any container)."""
    # Check for Android-specific paths
    android_markers = [
        "/system/build.prop",
        "/system/app",
        "/data/data",
        "/proc/sys/kernel/osrelease",
    ]
    for path in android_markers[:2]:
        if os.path.exists(path):
            return True
    try:
        result = subprocess.run(
            ["getprop", "ro.product.model"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        if result.returncode == 0 and result.stdout.strip():
            return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# CPU DETECTION
# ---------------------------------------------------------------------------

def detect_cpu_arch():
    """Returns normalised CPU architecture string."""
    machine = platform.machine().lower()
    mapping = {
        "armv7l": ARCH_ARMV7L,
        "armv7":  ARCH_ARMV7L,
        "arm":    ARCH_ARMV7L,
        "aarch64": ARCH_AARCH64,
        "arm64":   ARCH_AARCH64,
        "x86_64":  ARCH_X86_64,
        "amd64":   ARCH_X86_64,
        "i386":    ARCH_X86,
        "i686":    ARCH_X86,
    }
    return mapping.get(machine, machine)


def detect_cpu_features():
    """
    Returns dict of CPU capability flags:
    aes_ni, avx, avx2, avx512, sse4_2, neon (ARM), huge_pages
    """
    features = {
        "aes_ni":    False,
        "avx":       False,
        "avx2":      False,
        "avx512":    False,
        "sse4_2":    False,
        "neon":      False,
        "huge_pages": False,
    }

    # Linux /proc/cpuinfo
    try:
        with open("/proc/cpuinfo", "r") as fh:
            cpuinfo = fh.read().lower()
        flags_line = ""
        for line in cpuinfo.splitlines():
            if line.startswith("flags") or line.startswith("features"):
                flags_line = line
                break
        features["aes_ni"]  = "aes"   in flags_line
        features["avx"]     = " avx " in flags_line or flags_line.endswith("avx")
        features["avx2"]    = "avx2"  in flags_line
        features["avx512"]  = "avx512" in flags_line
        features["sse4_2"]  = "sse4_2" in flags_line or "sse4.2" in flags_line
        features["neon"]    = "neon"  in flags_line or "asimd" in flags_line
    except Exception:
        pass

    # Check huge pages support
    try:
        with open("/proc/meminfo", "r") as fh:
            meminfo = fh.read()
        if "HugePages_Total" in meminfo:
            features["huge_pages"] = True
    except Exception:
        pass

    return features


def detect_cpu_info():
    """Returns dict with model_name, cores, threads, freq_mhz."""
    info = {
        "model_name": "Unknown CPU",
        "cores":      1,
        "threads":    1,
        "freq_mhz":   0,
    }

    try:
        import psutil
        info["cores"]   = psutil.cpu_count(logical=False) or 1
        info["threads"] = psutil.cpu_count(logical=True)  or 1
        freq = psutil.cpu_freq()
        if freq:
            info["freq_mhz"] = int(freq.max or freq.current or 0)
    except Exception:
        try:
            info["cores"]   = os.cpu_count() or 1
            info["threads"] = os.cpu_count() or 1
        except Exception:
            pass

    try:
        with open("/proc/cpuinfo", "r") as fh:
            for line in fh:
                if "model name" in line.lower() or "hardware" in line.lower():
                    info["model_name"] = line.split(":")[1].strip()
                    break
    except Exception:
        info["model_name"] = platform.processor() or "Unknown CPU"

    return info


# ---------------------------------------------------------------------------
# GPU DETECTION
# ---------------------------------------------------------------------------

def detect_nvidia_gpu():
    """
    Returns list of dicts [{name, vram_mb, driver_version, cuda_version}]
    Empty list if no NVIDIA GPU found.
    """
    gpus = []
    # Try nvidia-smi first
    nvidia_smi = shutil.which("nvidia-smi")
    if nvidia_smi:
        try:
            result = subprocess.run(
                [nvidia_smi,
                 "--query-gpu=name,memory.total,driver_version",
                 "--format=csv,noheader,nounits"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            if result.returncode == 0:
                for line in result.stdout.decode("utf-8").strip().splitlines():
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 3:
                        gpus.append({
                            "name":           parts[0],
                            "vram_mb":        int(parts[1]) if parts[1].isdigit() else 0,
                            "driver_version": parts[2],
                            "cuda_version":   _get_cuda_version(),
                            "vendor":         "nvidia",
                        })
        except Exception:
            pass

    # Fallback: check /proc/driver/nvidia/gpus
    if not gpus and os.path.isdir("/proc/driver/nvidia/gpus"):
        try:
            gpu_dirs = os.listdir("/proc/driver/nvidia/gpus")
            for gd in gpu_dirs:
                info_path = os.path.join("/proc/driver/nvidia/gpus", gd, "information")
                if os.path.isfile(info_path):
                    with open(info_path, "r") as fh:
                        content = fh.read()
                    name = "NVIDIA GPU"
                    for line in content.splitlines():
                        if "Model" in line:
                            name = line.split(":")[1].strip()
                    gpus.append({
                        "name":           name,
                        "vram_mb":        0,
                        "driver_version": "unknown",
                        "cuda_version":   _get_cuda_version(),
                        "vendor":         "nvidia",
                    })
        except Exception:
            pass

    return gpus


def detect_amd_gpu():
    """
    Returns list of dicts [{name, vram_mb, driver}]
    Empty list if no AMD GPU found.
    """
    gpus = []

    # Try rocm-smi
    rocm_smi = shutil.which("rocm-smi")
    if rocm_smi:
        try:
            result = subprocess.run(
                [rocm_smi, "--showproductname"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            if result.returncode == 0:
                output = result.stdout.decode("utf-8")
                for line in output.splitlines():
                    if "GPU" in line and ":" in line:
                        name = line.split(":")[1].strip()
                        gpus.append({
                            "name":   name,
                            "vram_mb": _get_amd_vram(name),
                            "driver": "ROCm",
                            "vendor": "amd",
                        })
        except Exception:
            pass

    # Fallback: lspci
    if not gpus:
        gpus.extend(_detect_gpu_via_lspci("amd"))

    # Fallback: /sys/class/drm
    if not gpus:
        gpus.extend(_detect_amd_via_sysfs())

    return gpus


def detect_intel_gpu():
    """Returns list of Intel GPU dicts. Mostly integrated graphics."""
    gpus = []
    gpus.extend(_detect_gpu_via_lspci("intel"))
    return gpus


def _detect_gpu_via_lspci(vendor):
    """Use lspci to detect GPU by vendor string."""
    gpus = []
    lspci = shutil.which("lspci")
    if not lspci:
        return gpus
    try:
        result = subprocess.run(
            [lspci],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10
        )
        output = result.stdout.decode("utf-8", errors="ignore").lower()
        for line in output.splitlines():
            if vendor.lower() in line and ("vga" in line or "3d" in line or "display" in line):
                name = line.split(":")[-1].strip().title()
                gpus.append({
                    "name":   name,
                    "vram_mb": 0,
                    "driver": "unknown",
                    "vendor": vendor,
                })
    except Exception:
        pass
    return gpus


def _detect_amd_via_sysfs():
    """Check /sys/class/drm for amdgpu devices."""
    gpus = []
    drm_path = "/sys/class/drm"
    if not os.path.isdir(drm_path):
        return gpus
    try:
        for entry in os.listdir(drm_path):
            vendor_path = os.path.join(drm_path, entry, "device", "vendor")
            if os.path.isfile(vendor_path):
                with open(vendor_path, "r") as fh:
                    vendor_id = fh.read().strip().lower()
                # AMD vendor IDs: 0x1002
                if "0x1002" in vendor_id:
                    gpus.append({
                        "name":   "AMD GPU (" + entry + ")",
                        "vram_mb": 0,
                        "driver": "amdgpu",
                        "vendor": "amd",
                    })
    except Exception:
        pass
    return gpus


def _get_cuda_version():
    """Try to read CUDA version from nvcc or cuda lib."""
    nvcc = shutil.which("nvcc")
    if nvcc:
        try:
            result = subprocess.run(
                [nvcc, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            output = result.stdout.decode("utf-8")
            match = re.search(r"release (\d+\.\d+)", output)
            if match:
                return match.group(1)
        except Exception:
            pass
    # Check for libcuda
    for path in ["/usr/local/cuda/version.txt", "/usr/local/cuda/version.json"]:
        if os.path.isfile(path):
            try:
                with open(path, "r") as fh:
                    content = fh.read()
                match = re.search(r"(\d+\.\d+)", content)
                if match:
                    return match.group(1)
            except Exception:
                pass
    return "not_found"


def _get_amd_vram(gpu_name):
    """Try to estimate AMD VRAM from GPU name string."""
    vram_map = {
        "rx 580": 8192, "rx 590": 8192, "rx 5700": 8192,
        "rx 6600": 8192, "rx 6700": 12288, "rx 6800": 16384,
        "rx 6900": 16384, "rx 7900": 24576,
        "vega 56": 8192, "vega 64": 8192,
    }
    name_lower = gpu_name.lower()
    for key, vram in vram_map.items():
        if key in name_lower:
            return vram
    return 0


def detect_opencl():
    """Return True if OpenCL runtime is available."""
    try:
        import pyopencl
        platforms = pyopencl.get_platforms()
        return len(platforms) > 0
    except Exception:
        pass
    # Check for libOpenCL
    for lib in ["/usr/lib/libOpenCL.so", "/usr/lib/x86_64-linux-gnu/libOpenCL.so.1"]:
        if os.path.isfile(lib):
            return True
    return False


# ---------------------------------------------------------------------------
# MEMORY DETECTION
# ---------------------------------------------------------------------------

def detect_ram():
    """Returns dict with total_mb, available_mb."""
    info = {"total_mb": 0, "available_mb": 0}
    try:
        import psutil
        mem = psutil.virtual_memory()
        info["total_mb"]     = int(mem.total / (1024 * 1024))
        info["available_mb"] = int(mem.available / (1024 * 1024))
        return info
    except Exception:
        pass
    try:
        with open("/proc/meminfo", "r") as fh:
            for line in fh:
                if "MemTotal" in line:
                    info["total_mb"] = int(line.split()[1]) // 1024
                if "MemAvailable" in line:
                    info["available_mb"] = int(line.split()[1]) // 1024
    except Exception:
        pass
    return info


# ---------------------------------------------------------------------------
# CAPABILITY PROFILING
# ---------------------------------------------------------------------------

def build_capability_profile():
    """
    Master function. Returns a full capability dict covering:
    platform, arch, cpu, ram, gpu, opencl, mining_capability.
    """
    plat  = detect_platform()
    arch  = detect_cpu_arch()
    cpu   = detect_cpu_info()
    feats = detect_cpu_features()
    ram   = detect_ram()

    nvidia_gpus = detect_nvidia_gpu()
    amd_gpus    = detect_amd_gpu()
    intel_gpus  = detect_intel_gpu()
    has_opencl  = detect_opencl()

    all_gpus     = nvidia_gpus + amd_gpus + intel_gpus
    has_real_gpu = len(nvidia_gpus) > 0 or len(amd_gpus) > 0

    # Determine mining capability tier
    if has_real_gpu and arch in (ARCH_X86_64,):
        if feats.get("aes_ni") or feats.get("avx"):
            capability = CAPABILITY_CPU_GPU
        else:
            capability = CAPABILITY_GPU_ONLY
    elif has_real_gpu:
        capability = CAPABILITY_GPU_ONLY
    else:
        capability = CAPABILITY_CPU_ONLY

    # CPU mining suitability score (1-10)
    cpu_score = _score_cpu_mining(arch, feats, cpu, ram)

    # GPU mining suitability
    gpu_score = _score_gpu_mining(nvidia_gpus, amd_gpus)

    profile = {
        "platform":           plat,
        "arch":               arch,
        "is_android":         _is_android(),
        "python_version":     sys.version.split()[0],
        "cpu": {
            "model":          cpu["model_name"],
            "cores":          cpu["cores"],
            "threads":        cpu["threads"],
            "freq_mhz":       cpu["freq_mhz"],
            "features":       feats,
            "mining_score":   cpu_score,
        },
        "ram": ram,
        "gpu": {
            "nvidia":         nvidia_gpus,
            "amd":            amd_gpus,
            "intel":          intel_gpus,
            "opencl":         has_opencl,
            "mining_score":   gpu_score,
        },
        "mining_capability":  capability,
        "recommended_miners": _recommend_miners(
            capability, arch, plat, nvidia_gpus, amd_gpus, feats
        ),
        "install_packages":   _required_packages(
            capability, arch, plat, nvidia_gpus, amd_gpus
        ),
    }

    return profile


def _score_cpu_mining(arch, feats, cpu, ram):
    """Return 1-10 CPU mining suitability score."""
    score = 1
    if arch == ARCH_X86_64:
        score += 3
        if feats.get("avx2"):  score += 2
        if feats.get("aes_ni"): score += 1
        if feats.get("avx512"): score += 1
    elif arch == ARCH_AARCH64:
        score += 2
        if feats.get("neon"):  score += 1
    elif arch == ARCH_ARMV7L:
        score += 0

    cores = cpu.get("cores", 1)
    if cores >= 16: score += 2
    elif cores >= 8: score += 1

    total_mb = ram.get("total_mb", 0)
    if total_mb >= 8192:  score += 1
    elif total_mb >= 4096: score += 0

    return min(score, 10)


def _score_gpu_mining(nvidia_gpus, amd_gpus):
    """Return 1-10 GPU mining suitability score."""
    if not nvidia_gpus and not amd_gpus:
        return 0
    score = 5
    for gpu in nvidia_gpus:
        vram = gpu.get("vram_mb", 0)
        if vram >= 8192:   score += 3
        elif vram >= 4096: score += 1
    for gpu in amd_gpus:
        vram = gpu.get("vram_mb", 0)
        if vram >= 8192:   score += 3
        elif vram >= 4096: score += 1
    return min(score, 10)


def _recommend_miners(capability, arch, plat, nvidia_gpus, amd_gpus, feats):
    """
    Returns list of miner binary names recommended for this system.
    """
    miners = []

    # CPU miners — always include for CPU_ONLY and CPU_GPU
    if capability in (CAPABILITY_CPU_ONLY, CAPABILITY_CPU_GPU):
        miners.append("xmrig")          # RandomX / MoneroV / Zephyr
        miners.append("cpuminer-multi") # X11 + many algos via unMineable

        if arch == ARCH_X86_64 and feats.get("avx2"):
            miners.append("xmrig-mo")  # MoneroOcean algo-switching build

    # NVIDIA GPU miners
    if nvidia_gpus:
        miners.append("lolminer")       # ETHash, Beam, Flux, Kaspa
        miners.append("t-rex")          # KAWPOW, Octopus, MTP
        miners.append("nbminer")        # Octopus, Ethash, Kaspa
        miners.append("gminer")         # ZHash, Cuckatoo, BeamV3

    # AMD GPU miners
    if amd_gpus:
        miners.append("lolminer")       # also covers AMD
        miners.append("teamredminer")   # Ethash, KAWPOW, Autolykos

    return list(set(miners))  # deduplicate


def _required_packages(capability, arch, plat, nvidia_gpus, amd_gpus):
    """
    Returns dict of packages needed per install manager.
    Keys: apt, pip, pkg (termux), source_builds
    """
    apt_pkgs  = [
        "build-essential", "cmake", "git", "wget", "curl",
        "libssl-dev", "libhwloc-dev", "libuv1-dev",
        "automake", "autoconf", "libtool", "pkg-config",
        "libjansson-dev", "libcurl4-openssl-dev",
        "python3", "python3-pip",
    ]
    pip_pkgs  = [
        "flask", "requests", "psutil", "apscheduler",
    ]
    pkg_pkgs  = [  # Termux
        "python", "git", "cmake", "clang", "make",
        "openssl", "curl", "wget", "autoconf", "automake",
        "libtool", "pkg-config",
    ]
    source_builds = ["xmrig", "cpuminer-multi"]

    if arch == ARCH_ARMV7L:
        # 32-bit ARM: remove packages that require 64-bit
        apt_pkgs = [p for p in apt_pkgs if p not in ("libhwloc-dev",)]
        apt_pkgs.append("libhwloc-dev")  # try anyway; installer will skip if fail

    if capability in (CAPABILITY_GPU_ONLY, CAPABILITY_CPU_GPU):
        if nvidia_gpus:
            apt_pkgs.extend([
                "nvidia-cuda-toolkit", "nvidia-driver-latest",
                "ocl-icd-opencl-dev", "opencl-headers",
            ])
            source_builds.append("xmrig-cuda")
        if amd_gpus:
            apt_pkgs.extend([
                "ocl-icd-opencl-dev", "opencl-headers",
                "mesa-opencl-icd",
            ])

    return {
        "apt":           apt_pkgs,
        "pip":           pip_pkgs,
        "pkg":           pkg_pkgs,
        "source_builds": source_builds,
    }


# ---------------------------------------------------------------------------
# HUMAN-READABLE REPORT
# ---------------------------------------------------------------------------

def print_capability_report(profile):
    """Print a formatted hardware capability report to stdout."""
    cap   = profile["mining_capability"]
    cpu   = profile["cpu"]
    ram   = profile["ram"]
    gpus  = profile["gpu"]

    print("=" * 60)
    print("  UMP UNIVERSAL - HARDWARE CAPABILITY REPORT")
    print("=" * 60)
    print("Platform   : " + profile["platform"])
    print("Arch       : " + profile["arch"])
    print("Python     : " + profile["python_version"])
    print("")
    print("CPU        : " + cpu["model"])
    print("Cores/Thrd : " + str(cpu["cores"]) + " / " + str(cpu["threads"]))
    print("CPU Score  : " + str(cpu["mining_score"]) + " / 10")
    feats = cpu["features"]
    feat_str = []
    for k, v in feats.items():
        if v:
            feat_str.append(k)
    print("CPU Flags  : " + (", ".join(feat_str) or "none detected"))
    print("")
    print("RAM Total  : " + str(ram["total_mb"]) + " MB")
    print("RAM Free   : " + str(ram["available_mb"]) + " MB")
    print("")
    if gpus["nvidia"]:
        for g in gpus["nvidia"]:
            print("NVIDIA GPU : " + g["name"] + " (" + str(g["vram_mb"]) + " MB VRAM)")
    if gpus["amd"]:
        for g in gpus["amd"]:
            print("AMD GPU    : " + g["name"])
    if not gpus["nvidia"] and not gpus["amd"]:
        print("GPU        : None detected")
    print("GPU Score  : " + str(gpus["mining_score"]) + " / 10")
    print("OpenCL     : " + str(gpus["opencl"]))
    print("")
    print("CAPABILITY : " + cap)
    print("MINERS     : " + ", ".join(profile["recommended_miners"]))
    print("=" * 60)


# ---------------------------------------------------------------------------
# SAVE / LOAD PROFILE
# ---------------------------------------------------------------------------

def save_profile(profile, path="ump_hw_profile.json"):
    """Save capability profile to JSON file."""
    with open(path, "w") as fh:
        json.dump(profile, fh, indent=2)
    print("[hw_detect] Profile saved to " + path)


def load_profile(path="ump_hw_profile.json"):
    """Load previously saved capability profile."""
    if not os.path.isfile(path):
        return None
    with open(path, "r") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# MAIN (standalone run)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    profile = build_capability_profile()
    print_capability_report(profile)
    save_profile(profile)
    print(json.dumps(profile, indent=2))


# =============================================================================
# MODULE: ump_miner_registry.py
# =============================================================================

"""
ump_miner_registry.py
Universal Miner Pro ULTIMATE - Universal Miner & Coin Registry
Complete coin -> algo -> miner -> pool -> command mapping.
Covers CPU, GPU (NVIDIA/AMD), and unMineable proxied coins.

Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import platform

# ---------------------------------------------------------------------------
# CAPABILITY TAGS
# ---------------------------------------------------------------------------
CAP_CPU      = "CPU"
CAP_GPU      = "GPU"
CAP_ASIC     = "ASIC"
CAP_CPU_GPU  = "CPU_GPU"
CAP_PROXIED  = "PROXIED"    # mined via unMineable hash conversion

# ---------------------------------------------------------------------------
# ALGORITHM REGISTRY
# Keyed by algo_key string used throughout UMP.
# ---------------------------------------------------------------------------
ALGOS = {
    "RANDOMX": {
        "name":       "RandomX",
        "binary":     "xmrig",
        "spec":       "rx/0",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Monero ASIC-resistant PoW — CPU optimised, L3 cache intensive",
    },
    "X11": {
        "name":       "X11",
        "binary":     "cpuminer-multi",
        "spec":       "x11",
        "hr_unit":    "MH/s",
        "capability": CAP_CPU,
        "worker_fmt": "{coin}:{wallet}.{worker}#{referral}",
        "description": "11-algorithm chain; routed via unMineable for alt-coin payout",
    },
    "X11_DIRECT": {
        "name":       "X11 Direct",
        "binary":     "cpuminer-multi",
        "spec":       "x11",
        "hr_unit":    "MH/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "X11 direct pool mining -- DASH on Binance Pool and other X11 pools",
    },
    "KAWPOW": {
        "name":       "KawPow",
        "binary":     "t-rex",
        "spec":       "kawpow",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Ravencoin GPU algo — ProgPoW variant",
    },
    "ETHASH": {
        "name":       "Ethash",
        "binary":     "lolminer",
        "spec":       "ETHASH",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Classic Ethereum PoW — GPU DAG-based",
    },
    "AUTOLYKOS2": {
        "name":       "Autolykos2",
        "binary":     "lolminer",
        "spec":       "AUTOLYKOS2",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Ergo blockchain PoW",
    },
    "KHEAVYHASH": {
        "name":       "kHeavyHash",
        "binary":     "lolminer",
        "spec":       "KHEAVYHASH",
        "hr_unit":    "GH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Kaspa PoW — very high hashrates on modern GPUs",
    },
    "OCTOPUS": {
        "name":       "Octopus",
        "binary":     "t-rex",
        "spec":       "octopus",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Conflux PoW algo",
    },
    "ETCHASH": {
        "name":       "Etchash",
        "binary":     "lolminer",
        "spec":       "ETCHASH",
        "hr_unit":    "MH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Ethereum Classic PoW",
    },
    "ALEPHIUM": {
        "name":       "Blake3-Alephium",
        "binary":     "lolminer",
        "spec":       "ALPH",
        "hr_unit":    "GH/s",
        "capability": CAP_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Alephium sharded PoW",
    },
    "SHA256D": {
        "name":       "SHA256d",
        "binary":     "cpuminer-multi",
        "spec":       "sha256d",
        "hr_unit":    "GH/s",
        "capability": CAP_ASIC,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Bitcoin, Bitcoin Cash, BSV — ASIC dominated",
    },
    "SCRYPT": {
        "name":       "Scrypt",
        "binary":     "cpuminer-multi",
        "spec":       "scrypt",
        "hr_unit":    "KH/s",
        "capability": CAP_CPU_GPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Litecoin, Dogecoin — ASIC exists but CPU/GPU viable via unMineable",
    },
    "GHOSTRIDER": {
        "name":       "GhostRider",
        "binary":     "cpuminer-multi",
        "spec":       "ghostrider",
        "hr_unit":    "KH/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Raptoreum CPU-native algo",
    },
    "RANDOMARQ": {
        "name":       "RandomARQ",
        "binary":     "xmrig",
        "spec":       "rx/arq",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "ArQmA CPU mining",
    },
    "RANDOMSFX": {
        "name":       "RandomSFX",
        "binary":     "xmrig",
        "spec":       "rx/sfx",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Safex Cash CPU mining",
    },
    "RANDOMWOW": {
        "name":       "RandomWOW",
        "binary":     "xmrig",
        "spec":       "rx/wow",
        "hr_unit":    "H/s",
        "capability": CAP_CPU,
        "worker_fmt": "{wallet}.{worker}",
        "description": "Wownero CPU mining",
    },
}


# ---------------------------------------------------------------------------
# POOL REGISTRY
# ---------------------------------------------------------------------------
POOLS = {
    "kryptex": {
        "name":        "Kryptex Pool",
        "url":         "https://pool.kryptex.com",
        "payout_model":"Auto-convert to BTC",
        "fee_pct":     2.0,
        "payout_coin": "BTC",
        "user_format": "KRYPTEX_EMAIL.WORKER or WALLET.WORKER",
        "default_pass":"X",
        "tls":         True,
        "ports": {
            "XMR":  "xmr.kryptex.network:8029",
            "ZEPH": "zeph.kryptex.network:18081",
            "SAL":  "sal.kryptex.network:8080",
            "RVN":  "rvn.kryptex.network:8888",
            "ETC":  "etc.kryptex.network:8080",
            "KAS":  "kas.kryptex.network:8888",
            "ALPH": "alph.kryptex.network:8889",
        },
    },
    "moneroocean": {
        "name":        "MoneroOcean",
        "url":         "https://moneroocean.stream",
        "payout_model":"PPLNS auto-algo switching",
        "fee_pct":     0.0,
        "payout_coin": "XMR",
        "user_format": "XMR_WALLET_ADDRESS",
        "default_pass":"WORKER:EMAIL",
        "tls":         False,
        "ports": {
            "XMR":  "gulf.moneroocean.stream:10128",
        },
    },
    "unmineable": {
        "name":        "unMineable",
        "url":         "https://unmineable.com",
        "payout_model":"Hash conversion to any coin",
        "fee_pct":     1.0,
        "fee_pct_ref": 0.75,
        "payout_coin": "ANY",
        "user_format": "COIN:WALLET.WORKER#REF",
        "default_pass":"WORKER_NAME",
        "tls":         False,
        "ports": {
            "RANDOMX": "rx.unmineable.com:3333",
            "X11":     "rx.unmineable.com:3333",
        },
    },
    "viabtc": {
        "name":        "ViaBTC",
        "url":         "https://viabtc.com",
        "payout_model":"PPS+",
        "fee_pct":     4.0,
        "payout_coin": "XMR",
        "user_format": "VIABTC_USERNAME.WORKER",
        "default_pass":"123",
        "tls":         False,
        "ports": {
            "XMR":  "xmr.viabtc.com:3333",
        },
    },
    "mph": {
        "name":        "Mining Pool Hub",
        "url":         "https://miningpoolhub.com",
        "payout_model":"PPLNS",
        "fee_pct":     0.9,
        "payout_coin": "MULTI",
        "user_format": "MPH_USERNAME.WORKER",
        "default_pass":"x",
        "tls":         False,
        "ports": {
            "XMR":  "monero.usa.mining-pool-hub.com:20580",
            "ETC":  "hub.miningpoolhub.com:20535",
        },
    },
    "binance": {
        "name":        "Binance Pool",
        "url":         "https://pool.binance.com",
        "payout_model":"FPPS",
        "fee_pct":     2.5,
        "payout_coin": "BTC",
        "user_format": "BINANCE_ACCOUNT.WORKER_ID  (e.g. francoisnel321.001)",
        "default_pass":"123456",
        "tls":         False,
        "dash_port_primary":   "dash.poolbinance.com:1800",
        "dash_port_ssl":       "dash.poolbinance.com:443",
        "dash_port_alternate": "dash.poolbinance.com:3333",
        "ports": {
            "BTC":       "bs.poolbinance.com:1800",
            "DASH":      "dash.poolbinance.com:1800",
            "DASH_443":  "dash.poolbinance.com:443",
            "DASH_1800": "dash.poolbinance.com:1800",
            "DASH_3333": "dash.poolbinance.com:3333",
        },
    },
    "custom": {
        "name":        "Custom / Direct",
        "url":         "",
        "payout_model":"Custom",
        "fee_pct":     0.0,
        "payout_coin": "ANY",
        "user_format": "WALLET (pool specific)",
        "default_pass":"x",
        "tls":         False,
        "ports":       {},
    },
    "2miners": {
        "name":        "2Miners",
        "url":         "https://2miners.com",
        "payout_model":"PPLNS",
        "fee_pct":     1.0,
        "payout_coin": "COIN",
        "user_format": "WALLET.WORKER",
        "default_pass":"x",
        "tls":         False,
        "ports": {
            "XMR":  "xmr.2miners.com:2222",
            "ETC":  "etc.2miners.com:1010",
            "RVN":  "rvn.2miners.com:6060",
            "ERG":  "erg.2miners.com:8008",
        },
    },
    "f2pool": {
        "name":        "f2pool",
        "url":         "https://f2pool.com",
        "payout_model":"PPS+",
        "fee_pct":     2.5,
        "payout_coin": "COIN",
        "user_format": "F2POOL_USERNAME.WORKER",
        "default_pass":"x",
        "tls":         False,
        "ports": {
            "XMR":  "xmr.f2pool.com:13531",
            "ETC":  "etc.f2pool.com:8118",
            "KAS":  "kas.f2pool.com:11200",
        },
    },
    "flexpool": {
        "name":        "Flexpool",
        "url":         "https://flexpool.io",
        "payout_model":"PPLNS",
        "fee_pct":     1.0,
        "payout_coin": "COIN",
        "user_format": "WALLET",
        "default_pass":"WORKER",
        "tls":         True,
        "ports": {
            "ETC":  "eu1-etc.flexpool.io:4444",
        },
    },
}


# ---------------------------------------------------------------------------
# COIN REGISTRY
# Full coin definitions: algo, hardware type, best pool, payout info, etc.
# ---------------------------------------------------------------------------
COINS = {
    # ---- CPU COINS (RandomX / XMRig) ----
    "XMR": {
        "name":        "Monero",
        "algo_key":    "RANDOMX",
        "capability":  CAP_CPU,
        "best_pools":  ["moneroocean", "kryptex"],
        "payout_coin": "XMR",
        "wallet_type": "xmr",
        "notes":       "Best CPU coin. RandomX ASIC-resistant.",
        "hashrate_usd_per_hs_day": 0.00000030,
        "base_price_usd": 170.0,
    },
    "ZEPH": {
        "name":        "Zephyr Protocol",
        "algo_key":    "RANDOMX",
        "capability":  CAP_CPU,
        "best_pools":  ["kryptex"],
        "payout_coin": "ZEPH",
        "wallet_type": "xmr",
        "notes":       "RandomX variant. Lower difficulty = more coins.",
        "hashrate_usd_per_hs_day": 0.00000025,
        "base_price_usd": 0.5,
    },
    "SAL": {
        "name":        "Salvium",
        "algo_key":    "RANDOMX",
        "capability":  CAP_CPU,
        "best_pools":  ["kryptex"],
        "payout_coin": "SAL",
        "wallet_type": "xmr",
        "notes":       "New RandomX coin. Speculative.",
        "hashrate_usd_per_hs_day": 0.00000010,
        "base_price_usd": 0.02,
    },
    "RTM": {
        "name":        "Raptoreum",
        "algo_key":    "GHOSTRIDER",
        "capability":  CAP_CPU,
        "best_pools":  ["custom"],
        "payout_coin": "RTM",
        "wallet_type": "btc",
        "notes":       "GhostRider — CPU optimised, ASIC resistant.",
        "hashrate_usd_per_hs_day": 0.00000010,
        "base_price_usd": 0.001,
    },
    "WOW": {
        "name":        "Wownero",
        "algo_key":    "RANDOMWOW",
        "capability":  CAP_CPU,
        "best_pools":  ["custom"],
        "payout_coin": "WOW",
        "wallet_type": "xmr",
        "notes":       "Wownero RandomWOW variant.",
        "hashrate_usd_per_hs_day": 0.00000005,
        "base_price_usd": 0.01,
    },
    # ---- DASH (X11 direct on Binance Pool) ----
    "DASH": {
        "name":        "Dash",
        "algo_key":    "X11_DIRECT",
        "capability":  CAP_CPU,
        "best_pools":  ["binance", "custom"],
        "payout_coin": "DASH",
        "wallet_type": "btc",
        "pool_url":    "dash.poolbinance.com:1800",
        "pool_url_ssl":"dash.poolbinance.com:443",
        "pool_url_alt":"dash.poolbinance.com:3333",
        "user_format": "BINANCE_ACCOUNT.WORKER_ID",
        "user_example":"francoisnel321.001",
        "default_pass":"123456",
        "notes":       "X11 direct mining on Binance Pool. Worker=account.workerID. Pass=123456.",
        "hashrate_usd_per_hs_day": 0.00000001,
        "base_price_usd": 28.0,
    },

    # ---- CPU via unMineable proxy ----
    "DOGE": {
        "name":        "Dogecoin",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "DOGE",
        "wallet_type": "btc",
        "notes":       "Mine via unMineable. Payout in DOGE.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 0.12,
    },
    "ADA": {
        "name":        "Cardano",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "ADA",
        "wallet_type": "ada",
        "notes":       "Mine via unMineable. Payout in ADA.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 0.45,
    },
    "SOL": {
        "name":        "Solana",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "SOL",
        "wallet_type": "sol",
        "notes":       "Mine via unMineable. High value per coin.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 140.0,
    },
    "SHIB": {
        "name":        "Shiba Inu",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "SHIB",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable. Meme coin.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 0.000009,
    },
    "BNB": {
        "name":        "BNB",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "BNB",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable. Binance ecosystem.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 580.0,
    },
    "TRX": {
        "name":        "Tron",
        "algo_key":    "X11",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "TRX",
        "wallet_type": "trx",
        "notes":       "Mine via unMineable X11.",
        "hashrate_usd_per_hs_day": 0.00000020,
        "base_price_usd": 0.12,
    },
    "XRP": {
        "name":        "Ripple",
        "algo_key":    "X11",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "XRP",
        "wallet_type": "xrp",
        "notes":       "Mine via unMineable X11.",
        "hashrate_usd_per_hs_day": 0.00000020,
        "base_price_usd": 0.50,
    },
    "MATIC": {
        "name":        "Polygon",
        "algo_key":    "X11",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "MATIC",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable X11.",
        "hashrate_usd_per_hs_day": 0.00000020,
        "base_price_usd": 0.70,
    },
    "DOT": {
        "name":        "Polkadot",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "DOT",
        "wallet_type": "dot",
        "notes":       "Mine via unMineable.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 6.5,
    },
    "LINK": {
        "name":        "Chainlink",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "LINK",
        "wallet_type": "eth",
        "notes":       "Mine via unMineable.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 14.0,
    },
    "AVAX": {
        "name":        "Avalanche",
        "algo_key":    "RANDOMX",
        "capability":  CAP_PROXIED,
        "best_pools":  ["unmineable"],
        "payout_coin": "AVAX",
        "wallet_type": "avax",
        "notes":       "Mine via unMineable.",
        "hashrate_usd_per_hs_day": 0.00000028,
        "base_price_usd": 27.0,
    },

    # ---- GPU COINS ----
    "RVN": {
        "name":        "Ravencoin",
        "algo_key":    "KAWPOW",
        "capability":  CAP_GPU,
        "best_pools":  ["2miners", "kryptex"],
        "payout_coin": "RVN",
        "wallet_type": "btc",
        "notes":       "KawPow GPU algo. Mid-range GPU sweet spot.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.02,
    },
    "ETC": {
        "name":        "Ethereum Classic",
        "algo_key":    "ETCHASH",
        "capability":  CAP_GPU,
        "best_pools":  ["2miners", "f2pool"],
        "payout_coin": "ETC",
        "wallet_type": "eth",
        "notes":       "Etchash — lower DAG than original ETH.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 20.0,
    },
    "ERG": {
        "name":        "Ergo",
        "algo_key":    "AUTOLYKOS2",
        "capability":  CAP_GPU,
        "best_pools":  ["2miners"],
        "payout_coin": "ERG",
        "wallet_type": "erg",
        "notes":       "Autolykos2. GPU friendly.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 1.0,
    },
    "KAS": {
        "name":        "Kaspa",
        "algo_key":    "KHEAVYHASH",
        "capability":  CAP_GPU,
        "best_pools":  ["f2pool", "kryptex"],
        "payout_coin": "KAS",
        "wallet_type": "kas",
        "notes":       "kHeavyHash. Very fast on modern GPUs.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.12,
    },
    "ALPH": {
        "name":        "Alephium",
        "algo_key":    "ALEPHIUM",
        "capability":  CAP_GPU,
        "best_pools":  ["kryptex"],
        "payout_coin": "ALPH",
        "wallet_type": "alph",
        "notes":       "Blake3 variant. High GPU hashrates.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.40,
    },
    "CFX": {
        "name":        "Conflux",
        "algo_key":    "OCTOPUS",
        "capability":  CAP_GPU,
        "best_pools":  ["custom"],
        "payout_coin": "CFX",
        "wallet_type": "eth",
        "notes":       "Octopus algo via T-Rex.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.15,
    },
    "NEXA": {
        "name":        "Nexa",
        "algo_key":    "ETHASH",
        "capability":  CAP_GPU,
        "best_pools":  ["custom"],
        "payout_coin": "NEXA",
        "wallet_type": "nexa",
        "notes":       "GPU coin via lolMiner.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 0.00005,
    },

    # ---- ASIC-dominated (available via unMineable proxy) ----
    "BTC": {
        "name":        "Bitcoin",
        "algo_key":    "SHA256D",
        "capability":  CAP_ASIC,
        "best_pools":  ["kryptex", "unmineable"],
        "payout_coin": "BTC",
        "wallet_type": "btc",
        "notes":       "CPU solo not profitable. Use unMineable proxy for BTC payout.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 67000.0,
    },
    "LTC": {
        "name":        "Litecoin",
        "algo_key":    "SCRYPT",
        "capability":  CAP_ASIC,
        "best_pools":  ["unmineable"],
        "payout_coin": "LTC",
        "wallet_type": "btc",
        "notes":       "ASIC dominated. Use unMineable for LTC payout.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 80.0,
    },
    "BCH": {
        "name":        "Bitcoin Cash",
        "algo_key":    "SHA256D",
        "capability":  CAP_ASIC,
        "best_pools":  ["unmineable"],
        "payout_coin": "BCH",
        "wallet_type": "btc",
        "notes":       "ASIC dominated. Use unMineable.",
        "hashrate_usd_per_hs_day": 0.0,
        "base_price_usd": 400.0,
    },
}


# ---------------------------------------------------------------------------
# COMMAND BUILDERS
# ---------------------------------------------------------------------------

def _bin_path(binary_name):
    """Return full path to miner binary in bin/ directory."""
    suffix = ".exe" if sys.platform == "win32" else ""
    return os.path.join("bin", binary_name + suffix)


def build_xmrig_cmd(profile, threads, algo_key="RANDOMX"):
    """Build XMRig command array for RandomX variants."""
    algo = ALGOS.get(algo_key, ALGOS["RANDOMX"])
    coin = COINS.get(profile.get("selected_coin", "XMR"), COINS["XMR"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "X")
    tls      = profile.get("use_tls", True)

    cmd = [
        _bin_path("xmrig"),
        "-a", algo["spec"],
        "-o", pool_url,
        "-u", user_str,
        "-p", password,
        "-t", str(threads),
        "--no-color",
        "--no-dmi",
        "--donate-level=0",
        "--print-time=5",
    ]

    if tls:
        cmd += ["--tls", "--tls-fingerprint="]

    # Large pages (where supported)
    cmd += ["--huge-pages-jit"]

    return cmd


def build_cpuminer_cmd(profile, threads, algo_key="X11"):
    """Build cpuminer-multi command array."""
    algo = ALGOS.get(algo_key, ALGOS["X11"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    cmd = [
        _bin_path("cpuminer-multi"),
        "-a", algo["spec"],
        "-o", "stratum+tcp://" + pool_url,
        "-u", user_str,
        "-p", password,
        "-t", str(threads),
        "--no-color",
    ]
    return cmd


def build_lolminer_cmd(profile, algo_key="ETHASH"):
    """Build lolMiner command array for GPU coins."""
    algo = ALGOS.get(algo_key, ALGOS["ETHASH"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    # Split host:port
    parts = pool_url.split(":")
    host  = parts[0] if parts else pool_url
    port  = parts[1] if len(parts) > 1 else "4444"

    cmd = [
        _bin_path("lolminer"),
        "--algo",   algo["spec"],
        "--pool",   host,
        "--port",   port,
        "--user",   user_str,
        "--pass",   password,
        "--apiport", "0",
        "--json",
    ]
    return cmd


def build_trex_cmd(profile, algo_key="KAWPOW"):
    """Build T-Rex miner command array (NVIDIA GPU)."""
    algo = ALGOS.get(algo_key, ALGOS["KAWPOW"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    cmd = [
        _bin_path("t-rex"),
        "-a",  algo["spec"],
        "-o",  "stratum+tcp://" + pool_url,
        "-u",  user_str,
        "-p",  password,
        "--no-color",
        "--api-port", "0",
    ]
    return cmd


def build_teamredminer_cmd(profile, algo_key="ETHASH"):
    """Build TeamRedMiner command array (AMD GPU)."""
    algo = ALGOS.get(algo_key, ALGOS["ETHASH"])

    pool_url = profile.get("pool_url", "")
    user_str = profile.get("miner_user", "")
    password = profile.get("miner_pass", "x")

    cmd = [
        _bin_path("teamredminer"),
        "-a", algo["spec"],
        "-o", "stratum+tcp://" + pool_url,
        "-u", user_str,
        "-p", password,
        "--no_watchdog",
    ]
    return cmd


def get_miner_cmd(profile, threads, algo_key, gpu_vendor=None):
    """
    Master command builder. Dispatches to correct miner based on algo
    and GPU vendor.

    gpu_vendor: None (CPU), "nvidia", or "amd"
    """
    algo = ALGOS.get(algo_key)
    if not algo:
        raise ValueError("Unknown algo_key: " + algo_key)

    binary = algo.get("binary", "xmrig")

    if binary == "xmrig":
        return build_xmrig_cmd(profile, threads, algo_key)
    elif binary == "cpuminer-multi":
        return build_cpuminer_cmd(profile, threads, algo_key)
    elif binary == "lolminer":
        return build_lolminer_cmd(profile, algo_key)
    elif binary == "t-rex":
        return build_trex_cmd(profile, algo_key)
    elif binary == "teamredminer":
        return build_teamredminer_cmd(profile, algo_key)
    else:
        raise ValueError("Unknown binary: " + binary)


# ---------------------------------------------------------------------------
# HELPER QUERIES
# ---------------------------------------------------------------------------

def get_cpu_coins():
    """Return list of coin symbols mineable on CPU (directly or proxied)."""
    result = []
    for sym, data in COINS.items():
        if data["capability"] in (CAP_CPU, CAP_PROXIED):
            result.append(sym)
    return sorted(result)


def get_gpu_coins():
    """Return list of coin symbols requiring GPU."""
    result = []
    for sym, data in COINS.items():
        if data["capability"] in (CAP_GPU,):
            result.append(sym)
    return sorted(result)


def get_coins_for_capability(capability):
    """
    capability: 'CPU_ONLY', 'GPU_ONLY', 'CPU_GPU'
    Returns list of coin symbols appropriate for this hardware.
    """
    if capability == "CPU_ONLY":
        return get_cpu_coins()
    elif capability == "GPU_ONLY":
        return get_gpu_coins()
    elif capability == "CPU_GPU":
        return sorted(list(COINS.keys()))
    return get_cpu_coins()


def suggest_pool_url(pool_id, coin_sym):
    """Return stratum URL for pool+coin combination."""
    pool = POOLS.get(pool_id)
    if not pool:
        return ""
    ports = pool.get("ports", {})
    if coin_sym in ports:
        return ports[coin_sym]
    # For unMineable, return algo-based URL
    if pool_id == "unmineable":
        return "rx.unmineable.com:3333"
    return ""


def calc_daily_usd(coin_sym, hashrate_hs, coin_price_usd=None):
    """Calculate estimated daily USD earnings."""
    coin = COINS.get(coin_sym)
    if not coin:
        return 0.0
    base_rate  = coin.get("hashrate_usd_per_hs_day", 0.0)
    base_price = coin.get("base_price_usd", 1.0)
    if base_rate == 0.0:
        return 0.0
    daily = hashrate_hs * base_rate * 86400.0
    if coin_price_usd and base_price and coin_price_usd != base_price:
        daily = daily * (coin_price_usd / base_price)
    return daily


def format_hashrate(hs):
    """Convert raw H/s to human-readable string."""
    if hs >= 1e9:
        return "{:.2f} GH/s".format(hs / 1e9)
    elif hs >= 1e6:
        return "{:.2f} MH/s".format(hs / 1e6)
    elif hs >= 1e3:
        return "{:.2f} KH/s".format(hs / 1e3)
    return "{:.2f} H/s".format(hs)


def build_unmineable_user(coin_sym, wallet, worker, referral=""):
    """Build unMineable user string: COIN:WALLET.WORKER#REF"""
    user = coin_sym + ":" + wallet + "." + worker
    if referral:
        user += "#" + referral
    return user


def get_coins_json():
    """Return COINS dict serialisable to JSON."""
    return COINS


def get_pools_json():
    """Return POOLS dict serialisable to JSON."""
    return POOLS


def get_algos_json():
    """Return ALGOS dict serialisable to JSON."""
    return ALGOS


# ---------------------------------------------------------------------------
# MAIN (standalone test)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    print("CPU coins:", get_cpu_coins())
    print("GPU coins:", get_gpu_coins())
    print("Total coins:", len(COINS))
    print("Total algos:", len(ALGOS))
    print("Total pools:", len(POOLS))

    test_profile = {
        "selected_coin": "XMR",
        "pool_url": "xmr.kryptex.network:8029",
        "miner_user": "test@test.com.rig1",
        "miner_pass": "X",
        "use_tls": True,
    }
    cmd = get_miner_cmd(test_profile, 4, "RANDOMX")
    print("XMRig cmd:", cmd)


# =============================================================================
# MODULE: ump_profit_switcher.py
# =============================================================================

"""
ump_profit_switcher.py
Universal Miner Pro ULTIMATE - Profit Switching Daemon
Polls CoinGecko + WhatToMine, scores all minable coins against
detected hardware, switches miner/coin/algo automatically.

Runs as APScheduler background job integrated into Flask app.
Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import time
import json
import logging
import threading
import sqlite3

try:
    import requests
    REQUESTS_OK = True
except ImportError:
    REQUESTS_OK = False

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    SCHEDULER_OK = True
except ImportError:
    SCHEDULER_OK = False

# ---------------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------------
log = logging.getLogger("ump_profit_switcher")
if not log.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(
        "[profit_switcher] %(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S"
    ))
    log.addHandler(handler)
    log.setLevel(logging.INFO)


# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------
DB_PATH             = "miner.db"
PRICE_CACHE_TTL     = 120      # seconds — how long CoinGecko prices are valid
SWITCH_INTERVAL_SEC = 300      # how often profit switcher re-evaluates (5 min)
MIN_SWITCH_GAIN_PCT = 5.0      # only switch if new coin earns >= 5% more
LOG_PATH            = "logs/profit_switch.log"

COINGECKO_IDS = {
    "XMR":   "monero",
    "ZEPH":  "zephyr-protocol",
    "SAL":   "salvium",
    "DOGE":  "dogecoin",
    "ADA":   "cardano",
    "SOL":   "solana",
    "BNB":   "binancecoin",
    "TRX":   "tron",
    "XRP":   "ripple",
    "MATIC": "matic-network",
    "DOT":   "polkadot",
    "LINK":  "chainlink",
    "AVAX":  "avalanche-2",
    "RVN":   "ravencoin",
    "ETC":   "ethereum-classic",
    "ERG":   "ergo",
    "KAS":   "kaspa",
    "ALPH":  "alephium",
    "BTC":   "bitcoin",
    "LTC":   "litecoin",
    "BCH":   "bitcoin-cash",
    "RTM":   "raptoreum",
    "WOW":   "wownero",
}

# WhatToMine endpoints for network difficulty data
WHATTOMINE_COINS = {
    "XMR":  "https://whattomine.com/coins/101.json",
    "ETC":  "https://whattomine.com/coins/162.json",
    "RVN":  "https://whattomine.com/coins/234.json",
    "ERG":  "https://whattomine.com/coins/340.json",
    "KAS":  "https://whattomine.com/coins/415.json",
}


# ---------------------------------------------------------------------------
# PRICE CACHE
# ---------------------------------------------------------------------------
_price_cache = {}        # {coin_sym: {"usd": float, "ts": float}}
_price_lock  = threading.Lock()


def _fetch_coingecko_prices(coin_syms):
    """
    Fetch USD prices for list of coin symbols from CoinGecko.
    Returns dict {coin_sym: usd_price}.
    """
    if not REQUESTS_OK:
        return {}

    # Build coingecko ID string
    ids = []
    sym_to_id = {}
    for sym in coin_syms:
        cg_id = COINGECKO_IDS.get(sym)
        if cg_id:
            ids.append(cg_id)
            sym_to_id[cg_id] = sym

    if not ids:
        return {}

    ids_str = ",".join(ids)
    url     = "https://api.coingecko.com/api/v3/simple/price"
    params  = {"ids": ids_str, "vs_currencies": "usd"}

    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code != 200:
            log.warning("CoinGecko returned HTTP " + str(resp.status_code))
            return {}
        data = resp.json()
        result = {}
        for cg_id, prices in data.items():
            sym = sym_to_id.get(cg_id)
            if sym and "usd" in prices:
                result[sym] = float(prices["usd"])
        return result
    except Exception as e:
        log.warning("CoinGecko fetch error: " + str(e))
        return {}


def get_price(coin_sym):
    """
    Return current USD price for coin, using cache if fresh.
    Returns 0.0 on failure.
    """
    now = time.time()
    with _price_lock:
        cached = _price_cache.get(coin_sym)
        if cached and (now - cached["ts"]) < PRICE_CACHE_TTL:
            return cached["usd"]

    # Fetch all at once to minimise API calls
    prices = _fetch_coingecko_prices(list(COINGECKO_IDS.keys()))
    ts_now = time.time()
    with _price_lock:
        for sym, usd in prices.items():
            _price_cache[sym] = {"usd": usd, "ts": ts_now}
        if coin_sym in prices:
            return prices[coin_sym]

    return 0.0


def refresh_all_prices():
    """Force-refresh all tracked coin prices."""
    prices = _fetch_coingecko_prices(list(COINGECKO_IDS.keys()))
    ts_now = time.time()
    with _price_lock:
        for sym, usd in prices.items():
            _price_cache[sym] = {"usd": usd, "ts": ts_now}
    log.info("Refreshed " + str(len(prices)) + " coin prices from CoinGecko")
    return prices


def get_all_cached_prices():
    """Return full price cache dict {sym: usd}."""
    with _price_lock:
        return {sym: v["usd"] for sym, v in _price_cache.items()}


# ---------------------------------------------------------------------------
# PROFITABILITY SCORING
# ---------------------------------------------------------------------------

def _to_hs(hashrate, unit):
    """Convert hashrate to raw H/s."""
    unit_lower = unit.lower()
    if unit_lower in ("gh/s", "ghs"):
        return hashrate * 1e9
    elif unit_lower in ("mh/s", "mhs"):
        return hashrate * 1e6
    elif unit_lower in ("kh/s", "khs"):
        return hashrate * 1e3
    return hashrate


def score_coin(coin_sym, hashrate_hs, capability, prices_dict):
    """
    Compute estimated daily USD for a coin given hardware hashrate.

    Returns dict:
    {
      coin:         str,
      algo_key:     str,
      usd_daily:    float,
      price_usd:    float,
      eligible:     bool,   (hardware can mine it)
      reason:       str,    (why eligible/ineligible)
    }
    """
    # Import here to avoid circular import at module load
    try:
        import ump_miner_registry as reg
    except ImportError:
        return {
            "coin": coin_sym, "algo_key": "", "usd_daily": 0.0,
            "price_usd": 0.0, "eligible": False,
            "reason": "ump_miner_registry not available",
        }

    coin_data = reg.COINS.get(coin_sym)
    if not coin_data:
        return {
            "coin": coin_sym, "algo_key": "", "usd_daily": 0.0,
            "price_usd": 0.0, "eligible": False, "reason": "Unknown coin",
        }

    coin_cap  = coin_data.get("capability", "")
    algo_key  = coin_data.get("algo_key", "")

    # Eligibility check
    eligible = False
    reason   = ""
    if capability == "CPU_ONLY":
        if coin_cap in (reg.CAP_CPU, reg.CAP_PROXIED):
            eligible = True
        else:
            reason = "Requires GPU"
    elif capability == "GPU_ONLY":
        if coin_cap == reg.CAP_GPU:
            eligible = True
        else:
            reason = "Requires CPU or ASIC"
    elif capability == "CPU_GPU":
        if coin_cap in (reg.CAP_CPU, reg.CAP_GPU, reg.CAP_PROXIED):
            eligible = True
        else:
            reason = "ASIC-only coin"
    else:
        eligible = coin_cap != reg.CAP_ASIC

    if not eligible:
        return {
            "coin": coin_sym, "algo_key": algo_key, "usd_daily": 0.0,
            "price_usd": 0.0, "eligible": False, "reason": reason,
        }

    # Get live price
    price_usd = prices_dict.get(coin_sym, 0.0)
    if price_usd == 0.0:
        price_usd = coin_data.get("base_price_usd", 0.0)

    daily_usd = reg.calc_daily_usd(coin_sym, hashrate_hs, price_usd)

    return {
        "coin":      coin_sym,
        "algo_key":  algo_key,
        "usd_daily": round(daily_usd, 6),
        "price_usd": price_usd,
        "eligible":  True,
        "reason":    "OK",
    }


def rank_coins(hashrate_hs, capability, prices_dict=None):
    """
    Score all coins and return sorted list (highest daily USD first).
    Only includes eligible coins.
    """
    if prices_dict is None:
        prices_dict = get_all_cached_prices()

    try:
        import ump_miner_registry as reg
        all_coins = list(reg.COINS.keys())
    except ImportError:
        log.error("Cannot import ump_miner_registry")
        return []

    scored = []
    for sym in all_coins:
        result = score_coin(sym, hashrate_hs, capability, prices_dict)
        if result["eligible"] and result["usd_daily"] > 0:
            scored.append(result)

    scored.sort(key=lambda x: x["usd_daily"], reverse=True)
    return scored


def get_best_coin(hashrate_hs, capability, current_coin=None, prices_dict=None):
    """
    Return the single best coin to mine.
    Applies MIN_SWITCH_GAIN_PCT to avoid constant switching.
    """
    ranking = rank_coins(hashrate_hs, capability, prices_dict)
    if not ranking:
        return None

    best = ranking[0]

    if current_coin and current_coin != best["coin"]:
        # Find current coin in ranking
        current_score = 0.0
        for entry in ranking:
            if entry["coin"] == current_coin:
                current_score = entry["usd_daily"]
                break
        # Only switch if improvement exceeds threshold
        if current_score > 0:
            gain_pct = (best["usd_daily"] - current_score) / current_score * 100.0
            if gain_pct < MIN_SWITCH_GAIN_PCT:
                log.info(
                    "Best coin " + best["coin"] +
                    " is only " + str(round(gain_pct, 1)) +
                    "% better than " + current_coin +
                    " -- keeping current"
                )
                # Return current coin entry
                for entry in ranking:
                    if entry["coin"] == current_coin:
                        return entry
                return best  # current not in ranking; switch anyway

    return best


# ---------------------------------------------------------------------------
# SWITCH LOG
# ---------------------------------------------------------------------------

def _ensure_log_dir():
    log_dir = os.path.dirname(LOG_PATH)
    if log_dir and not os.path.isdir(log_dir):
        os.makedirs(log_dir)


def _write_switch_log(from_coin, to_coin, from_usd, to_usd, reason):
    """Append switch event to log file."""
    _ensure_log_dir()
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_PATH, "a") as fh:
            fh.write(
                ts + " | SWITCH | " +
                from_coin + " -> " + to_coin +
                " | from_usd=" + str(round(from_usd, 6)) +
                " to_usd=" + str(round(to_usd, 6)) +
                " | " + reason + "\n"
            )
    except Exception as e:
        log.warning("Failed to write switch log: " + str(e))


def _record_switch_to_db(db_path, from_coin, to_coin, from_usd, to_usd, reason):
    """Record switch event in SQLite profit_switches table."""
    try:
        conn = sqlite3.connect(db_path, timeout=10)
        c    = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS profit_switches (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          TEXT    NOT NULL,
                from_coin   TEXT,
                to_coin     TEXT,
                from_usd    REAL,
                to_usd      REAL,
                reason      TEXT
            )
        """)
        c.execute(
            "INSERT INTO profit_switches (ts, from_coin, to_coin, from_usd, to_usd, reason) "
            "VALUES (datetime('now'), ?, ?, ?, ?, ?)",
            (from_coin, to_coin, from_usd, to_usd, reason)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning("DB switch log error: " + str(e))


# ---------------------------------------------------------------------------
# PROFIT SWITCHER ENGINE
# ---------------------------------------------------------------------------

class ProfitSwitcher(object):
    """
    Main profit switching engine.
    Integrate with Flask/miner_manager by passing callbacks.
    """

    def __init__(
        self,
        capability="CPU_ONLY",
        hashrate_provider=None,
        current_coin_provider=None,
        switch_callback=None,
        db_path=DB_PATH,
    ):
        """
        Parameters
        ----------
        capability          : str   Hardware capability string from ump_hardware_detect
        hashrate_provider   : callable  Returns current hashrate in H/s (float)
        current_coin_provider: callable Returns current mining coin symbol (str)
        switch_callback     : callable(coin_sym, algo_key, pool_id) — called to trigger switch
        db_path             : str   Path to SQLite DB
        """
        self.capability           = capability
        self._hashrate_provider   = hashrate_provider
        self._current_coin_provider = current_coin_provider
        self._switch_callback     = switch_callback
        self.db_path              = db_path

        self._scheduler   = None
        self._running     = False
        self._last_ranking= []
        self._last_check  = 0
        self._switch_count= 0
        self._lock        = threading.Lock()

        _ensure_log_dir()

    def start(self):
        """Start the profit switching scheduler."""
        if not SCHEDULER_OK:
            log.error("APScheduler not installed. Run: pip install apscheduler")
            return False

        if self._running:
            log.warning("Profit switcher already running")
            return True

        # Initial price fetch
        refresh_all_prices()

        self._scheduler = BackgroundScheduler(daemon=True)
        self._scheduler.add_job(
            self._evaluate,
            "interval",
            seconds=SWITCH_INTERVAL_SEC,
            id="profit_switcher",
            replace_existing=True,
        )
        self._scheduler.add_job(
            refresh_all_prices,
            "interval",
            seconds=PRICE_CACHE_TTL,
            id="price_refresh",
            replace_existing=True,
        )
        self._scheduler.start()
        self._running = True
        log.info("Profit switcher started. Evaluating every " +
                 str(SWITCH_INTERVAL_SEC) + "s")
        return True

    def stop(self):
        """Stop the scheduler."""
        if self._scheduler and self._running:
            try:
                self._scheduler.shutdown(wait=False)
            except Exception:
                pass
            self._running = False
            log.info("Profit switcher stopped")

    def _evaluate(self):
        """
        Core evaluation loop. Called by APScheduler.
        Scores all coins, decides whether to switch.
        """
        log.info("Evaluating profitability...")

        # Get current state
        hashrate_hs  = 0.0
        current_coin = "XMR"

        if self._hashrate_provider:
            try:
                hashrate_hs = float(self._hashrate_provider() or 0.0)
            except Exception:
                pass

        if self._current_coin_provider:
            try:
                current_coin = self._current_coin_provider() or "XMR"
            except Exception:
                pass

        if hashrate_hs <= 0.0:
            log.info("Hashrate is 0 -- skipping evaluation")
            return

        # Get fresh prices
        prices = get_all_cached_prices()
        if not prices:
            prices = refresh_all_prices()

        # Rank coins
        ranking = rank_coins(hashrate_hs, self.capability, prices)
        with self._lock:
            self._last_ranking = ranking
            self._last_check   = time.time()

        if not ranking:
            log.info("No eligible coins found in ranking")
            return

        best = get_best_coin(hashrate_hs, self.capability, current_coin, prices)
        if not best:
            return

        log.info(
            "Best: " + best["coin"] +
            " $" + str(best["usd_daily"]) + "/day" +
            " | Current: " + current_coin
        )

        # Switch if needed
        if best["coin"] != current_coin:
            self._do_switch(current_coin, best, prices, hashrate_hs)

    def _do_switch(self, from_coin, best_entry, prices, hashrate_hs):
        """Execute coin switch."""
        to_coin   = best_entry["coin"]
        algo_key  = best_entry["algo_key"]
        to_usd    = best_entry["usd_daily"]

        # Get from_usd for logging
        from_usd = 0.0
        for entry in self._last_ranking:
            if entry["coin"] == from_coin:
                from_usd = entry["usd_daily"]
                break

        reason = "profit_switch auto"
        log.info(
            "SWITCHING: " + from_coin + " -> " + to_coin +
            " (+" + str(round((to_usd - from_usd) / max(from_usd, 0.000001) * 100, 1)) + "%)"
        )

        # Best pool for this coin
        try:
            import ump_miner_registry as reg
            coin_data = reg.COINS.get(to_coin, {})
            best_pools = coin_data.get("best_pools", ["custom"])
            pool_id    = best_pools[0] if best_pools else "custom"
        except ImportError:
            pool_id = "custom"

        # Invoke switch callback (provided by Flask app)
        if self._switch_callback:
            try:
                self._switch_callback(to_coin, algo_key, pool_id)
            except Exception as e:
                log.error("Switch callback error: " + str(e))
                return

        # Log the switch
        _write_switch_log(from_coin, to_coin, from_usd, to_usd, reason)
        _record_switch_to_db(
            self.db_path, from_coin, to_coin, from_usd, to_usd, reason
        )
        self._switch_count += 1

    def force_evaluate(self):
        """Manually trigger evaluation (callable from Flask route)."""
        threading.Thread(target=self._evaluate, daemon=True).start()

    def get_status(self):
        """Return current switcher status dict for API."""
        with self._lock:
            return {
                "running":       self._running,
                "capability":    self.capability,
                "switch_count":  self._switch_count,
                "last_check":    self._last_check,
                "interval_sec":  SWITCH_INTERVAL_SEC,
                "min_gain_pct":  MIN_SWITCH_GAIN_PCT,
                "top_coins":     self._last_ranking[:10],
                "prices":        get_all_cached_prices(),
            }

    def get_ranking(self):
        """Return last computed ranking."""
        with self._lock:
            return list(self._last_ranking)

    def set_capability(self, capability):
        """Update hardware capability (e.g. after profile change)."""
        with self._lock:
            self.capability = capability

    def set_min_gain(self, pct):
        """Update minimum gain threshold for switching."""
        global MIN_SWITCH_GAIN_PCT
        MIN_SWITCH_GAIN_PCT = float(pct)

    def set_interval(self, seconds):
        """Update evaluation interval."""
        global SWITCH_INTERVAL_SEC
        SWITCH_INTERVAL_SEC = int(seconds)
        if self._scheduler and self._running:
            try:
                self._scheduler.reschedule_job(
                    "profit_switcher",
                    trigger="interval",
                    seconds=SWITCH_INTERVAL_SEC
                )
            except Exception:
                pass


# ---------------------------------------------------------------------------
# SINGLETON
# ---------------------------------------------------------------------------
_instance = None
_instance_lock = threading.Lock()


def get_switcher(
    capability="CPU_ONLY",
    hashrate_provider=None,
    current_coin_provider=None,
    switch_callback=None,
    db_path=DB_PATH,
):
    """
    Return singleton ProfitSwitcher instance.
    On first call, creates and starts the switcher.
    """
    global _instance
    with _instance_lock:
        if _instance is None:
            _instance = ProfitSwitcher(
                capability=capability,
                hashrate_provider=hashrate_provider,
                current_coin_provider=current_coin_provider,
                switch_callback=switch_callback,
                db_path=db_path,
            )
            _instance.start()
        return _instance


# ---------------------------------------------------------------------------
# FLASK BLUEPRINT (optional integration)
# ---------------------------------------------------------------------------

def create_profit_blueprint(switcher_instance):
    """
    Create a Flask Blueprint with profit switcher API endpoints.
    Register with: app.register_blueprint(create_profit_blueprint(switcher))
    """
    try:
        from flask import Blueprint, jsonify, request
    except ImportError:
        log.error("Flask not installed -- cannot create blueprint")
        return None

    bp = Blueprint("profit", __name__)

    @bp.route("/api/profit/status")
    def profit_status():
        return jsonify(switcher_instance.get_status())

    @bp.route("/api/profit/ranking")
    def profit_ranking():
        return jsonify({"ranking": switcher_instance.get_ranking()})

    @bp.route("/api/profit/prices")
    def profit_prices():
        return jsonify(get_all_cached_prices())

    @bp.route("/api/profit/evaluate", methods=["POST"])
    def profit_evaluate():
        switcher_instance.force_evaluate()
        return jsonify({"ok": True, "message": "Evaluation triggered"})

    @bp.route("/api/profit/settings", methods=["POST"])
    def profit_settings():
        data = request.get_json(force=True) or {}
        if "min_gain_pct" in data:
            switcher_instance.set_min_gain(float(data["min_gain_pct"]))
        if "interval_sec" in data:
            switcher_instance.set_interval(int(data["interval_sec"]))
        return jsonify({"ok": True})

    @bp.route("/api/profit/switch_log")
    def profit_switch_log():
        """Return last 50 lines of profit switch log."""
        lines = []
        if os.path.isfile(LOG_PATH):
            with open(LOG_PATH, "r") as fh:
                lines = fh.readlines()[-50:]
        return jsonify({"lines": [l.rstrip() for l in lines]})

    return bp


# ---------------------------------------------------------------------------
# MAIN (standalone test)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Test price fetch
    print("Fetching prices...")
    prices = refresh_all_prices()
    print("Prices:", json.dumps(prices, indent=2))

    # Test ranking with a hypothetical 500 H/s CPU
    print("\nRanking for CPU_ONLY @ 500 H/s:")
    ranking = rank_coins(500.0, "CPU_ONLY", prices)
    for i, entry in enumerate(ranking[:5]):
        print(
            str(i + 1) + ". " + entry["coin"] +
            " $" + str(entry["usd_daily"]) + "/day" +
            " (" + entry["algo_key"] + ")"
        )

    best = get_best_coin(500.0, "CPU_ONLY", "XMR", prices)
    if best:
        print("\nBest coin:", best["coin"], "@ $" + str(best["usd_daily"]) + "/day")


# =============================================================================
# MODULE: ump_universal_installer.py
# =============================================================================

"""
ump_universal_installer.py
Universal Miner Pro ULTIMATE - Universal Installer Engine
Reads hardware capability profile and installs all required
miners, binaries, dependencies, and build tools.

Supports: Userland Ubuntu, Termux, Linux x86_64/aarch64/armv7l
Python 3.6+ compatible. No f-strings. No walrus operators.
"""

from __future__ import print_function
import os
import sys
import subprocess
import shutil
import platform
import json
import time
import tarfile
import zipfile

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------
BIN_DIR          = "bin"
BUILD_DIR        = "/tmp/ump_build"
LOG_FILE         = "install.log"

XMRIG_REPO       = "https://github.com/xmrig/xmrig.git"
CPUMINER_REPO    = "https://github.com/tpruvot/cpuminer-multi.git"
LOLMINER_URL_BASE= "https://github.com/Lolliedieb/lolMiner-releases/releases/latest/download/"
TEAMRED_URL_BASE = "https://github.com/todxx/teamredminer/releases/latest/download/"
TREX_URL_BASE    = "https://github.com/trexminer/T-Rex/releases/latest/download/"

# Known stable release versions (fallback if latest lookup fails)
LOLMINER_VERSION = "1.88"
TREX_VERSION     = "0.26.8"
TEAMRED_VERSION  = "0.10.21"


# ---------------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------------
_log_fh = None

def _log(msg):
    """Write message to stdout and log file."""
    print("[installer] " + msg)
    global _log_fh
    if _log_fh is None:
        try:
            _log_fh = open(LOG_FILE, "a")
        except Exception:
            pass
    if _log_fh:
        try:
            _log_fh.write(msg + "\n")
            _log_fh.flush()
        except Exception:
            pass


def _run(cmd, check=True, timeout=600, env=None):
    """Run a shell command. Returns (returncode, stdout, stderr)."""
    _log("CMD: " + " ".join(cmd))
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            env=env,
        )
        out = result.stdout.decode("utf-8", errors="ignore").strip()
        err = result.stderr.decode("utf-8", errors="ignore").strip()
        if result.returncode != 0:
            _log("WARN: exit " + str(result.returncode) + " -- " + err[:200])
        return result.returncode, out, err
    except subprocess.TimeoutExpired:
        _log("ERROR: Command timed out: " + " ".join(cmd))
        return 1, "", "timeout"
    except Exception as e:
        _log("ERROR: " + str(e))
        return 1, "", str(e)


def _cmd_exists(cmd):
    return shutil.which(cmd) is not None


# ---------------------------------------------------------------------------
# PACKAGE MANAGERS
# ---------------------------------------------------------------------------

def install_apt_packages(packages, platform_name):
    """Install packages via apt-get (Linux/Userland Ubuntu)."""
    if not packages:
        return
    _log("--- Installing APT packages ---")

    # Update first
    _run(["apt-get", "update", "-y"], check=False)

    for pkg in packages:
        _log("APT install: " + pkg)
        rc, out, err = _run(
            ["apt-get", "install", "-y", "--no-install-recommends", pkg],
            check=False
        )
        if rc != 0:
            _log("SKIP " + pkg + " (not available or already installed)")


def install_pkg_packages(packages):
    """Install packages via Termux pkg."""
    if not packages:
        return
    _log("--- Installing Termux pkg packages ---")
    _run(["pkg", "update", "-y"], check=False)
    for pkg in packages:
        _log("PKG install: " + pkg)
        _run(["pkg", "install", "-y", pkg], check=False)


def install_pip_packages(packages):
    """Install Python packages via pip."""
    if not packages:
        return
    _log("--- Installing pip packages ---")
    pip_cmd = "pip3" if _cmd_exists("pip3") else "pip"
    for pkg in packages:
        _log("PIP install: " + pkg)
        _run(
            [pip_cmd, "install", pkg, "--break-system-packages", "--quiet"],
            check=False
        )


# ---------------------------------------------------------------------------
# BINARY DIRECTORY
# ---------------------------------------------------------------------------

def ensure_bin_dir():
    """Create bin/ directory if it does not exist."""
    if not os.path.isdir(BIN_DIR):
        os.makedirs(BIN_DIR)
        _log("Created " + BIN_DIR + "/ directory")


def ensure_build_dir():
    if not os.path.isdir(BUILD_DIR):
        os.makedirs(BUILD_DIR)


def _chmod_x(path):
    """Set executable permission."""
    try:
        os.chmod(path, 0o755)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# XMRIG BUILD FROM SOURCE
# ---------------------------------------------------------------------------

def build_xmrig(arch, platform_name):
    """Build XMRig from source. Returns True on success."""
    out_path = os.path.join(BIN_DIR, "xmrig")
    if os.path.isfile(out_path):
        _log("XMRig already exists at " + out_path + " -- skipping build")
        return True

    _log("=== Building XMRig from source ===")
    ensure_build_dir()
    src_dir = os.path.join(BUILD_DIR, "xmrig")

    # Clone
    if not os.path.isdir(src_dir):
        rc, _, _ = _run(["git", "clone", "--depth=1", XMRIG_REPO, src_dir])
        if rc != 0:
            _log("ERROR: Failed to clone XMRig")
            return False

    build_dir = os.path.join(src_dir, "build")
    if not os.path.isdir(build_dir):
        os.makedirs(build_dir)

    # CMake configure
    cmake_args = [
        "cmake", "..",
        "-DCMAKE_BUILD_TYPE=Release",
    ]

    # armv7l specific flags
    if arch == "armv7l":
        cmake_args += [
            "-DWITH_HWLOC=OFF",
            "-DWITH_ASM=OFF",
        ]
    elif arch == "aarch64":
        cmake_args += [
            "-DWITH_HWLOC=OFF",
        ]

    rc, _, _ = _run(cmake_args, check=False)
    # cmake must run from build dir
    old_dir = os.getcwd()
    os.chdir(build_dir)
    rc, _, _ = _run(cmake_args, check=False)
    if rc != 0:
        _log("ERROR: CMake configure failed")
        os.chdir(old_dir)
        return False

    # Make
    cores = str(max(1, (os.cpu_count() or 2) - 1))
    rc, _, _ = _run(["make", "-j" + cores], check=False)
    os.chdir(old_dir)

    if rc != 0:
        _log("ERROR: XMRig build failed. Check " + LOG_FILE)
        return False

    # Copy binary
    built_bin = os.path.join(build_dir, "xmrig")
    if os.path.isfile(built_bin):
        shutil.copy2(built_bin, out_path)
        _chmod_x(out_path)
        _log("XMRig built and installed to " + out_path)
        return True

    _log("ERROR: XMRig binary not found after build")
    return False


# ---------------------------------------------------------------------------
# CPUMINER-MULTI BUILD FROM SOURCE
# ---------------------------------------------------------------------------

def build_cpuminer(arch, platform_name):
    """Build cpuminer-multi from source. Returns True on success."""
    out_path = os.path.join(BIN_DIR, "cpuminer-multi")
    if os.path.isfile(out_path):
        _log("cpuminer-multi already exists -- skipping build")
        return True

    _log("=== Building cpuminer-multi from source ===")
    ensure_build_dir()
    src_dir = os.path.join(BUILD_DIR, "cpuminer-multi")

    if not os.path.isdir(src_dir):
        rc, _, _ = _run(["git", "clone", "--depth=1", CPUMINER_REPO, src_dir])
        if rc != 0:
            _log("ERROR: Failed to clone cpuminer-multi")
            return False

    old_dir = os.getcwd()
    os.chdir(src_dir)

    # autogen
    rc, _, _ = _run(["./autogen.sh"], check=False)
    if rc != 0:
        _log("WARN: autogen.sh failed -- trying autoreconf")
        _run(["autoreconf", "--install"], check=False)

    # configure flags
    configure_cmd = ["./configure", "--with-crypto", "--with-curl"]
    if arch == "armv7l":
        configure_cmd += ["--disable-assembly"]
    elif arch == "aarch64":
        configure_cmd += ["--disable-assembly"]

    rc, _, _ = _run(configure_cmd, check=False)
    if rc != 0:
        _log("ERROR: cpuminer-multi configure failed")
        os.chdir(old_dir)
        return False

    cores = str(max(1, (os.cpu_count() or 2) - 1))
    rc, _, _ = _run(["make", "-j" + cores], check=False)
    os.chdir(old_dir)

    if rc != 0:
        _log("ERROR: cpuminer-multi build failed")
        return False

    built_bin = os.path.join(src_dir, "cpuminer")
    if os.path.isfile(built_bin):
        shutil.copy2(built_bin, out_path)
        _chmod_x(out_path)
        _log("cpuminer-multi installed to " + out_path)
        return True

    _log("ERROR: cpuminer-multi binary not found after build")
    return False


# ---------------------------------------------------------------------------
# GPU MINERS — PRE-BUILT BINARIES
# ---------------------------------------------------------------------------

def _download_file(url, dest):
    """Download a file via curl or wget."""
    _log("Downloading " + url)
    if _cmd_exists("curl"):
        rc, _, _ = _run(["curl", "-L", "-o", dest, url, "--silent", "--show-error"])
    elif _cmd_exists("wget"):
        rc, _, _ = _run(["wget", "-O", dest, url, "-q"])
    else:
        _log("ERROR: Neither curl nor wget found")
        return False
    return rc == 0


def _extract_archive(archive_path, dest_dir):
    """Extract tar.gz or zip archive."""
    if archive_path.endswith(".zip"):
        try:
            with zipfile.ZipFile(archive_path, "r") as zh:
                zh.extractall(dest_dir)
            return True
        except Exception as e:
            _log("ERROR extracting zip: " + str(e))
            return False
    elif archive_path.endswith(".tar.gz") or archive_path.endswith(".tgz"):
        try:
            with tarfile.open(archive_path, "r:gz") as th:
                th.extractall(dest_dir)
            return True
        except Exception as e:
            _log("ERROR extracting tar.gz: " + str(e))
            return False
    return False


def install_lolminer(arch, has_nvidia, has_amd):
    """Download and install lolMiner for NVIDIA and/or AMD."""
    out_path = os.path.join(BIN_DIR, "lolminer")
    if os.path.isfile(out_path):
        _log("lolMiner already installed -- skipping")
        return True

    if arch not in ("x86_64",):
        _log("lolMiner: no pre-built binary for arch " + arch)
        return False

    _log("=== Installing lolMiner ===")
    ensure_build_dir()

    filename    = "lolMiner_v" + LOLMINER_VERSION + "_Lin64.tar.gz"
    url         = LOLMINER_URL_BASE + filename
    archive     = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "lolminer_extracted")

    if not _download_file(url, archive):
        _log("ERROR: Failed to download lolMiner")
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    # Find the binary inside extracted dir
    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if "lolminer" in fname.lower() and not fname.endswith(".sh"):
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("lolMiner installed to " + out_path)
                return True

    _log("ERROR: lolMiner binary not found in archive")
    return False


def install_trex(arch):
    """Download and install T-Rex miner (NVIDIA)."""
    out_path = os.path.join(BIN_DIR, "t-rex")
    if os.path.isfile(out_path):
        _log("T-Rex already installed -- skipping")
        return True

    if arch not in ("x86_64",):
        _log("T-Rex: no pre-built binary for arch " + arch)
        return False

    _log("=== Installing T-Rex miner ===")
    ensure_build_dir()

    filename    = "t-rex-" + TREX_VERSION + "-linux.tar.gz"
    url         = TREX_URL_BASE + filename
    archive     = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "trex_extracted")

    if not _download_file(url, archive):
        _log("ERROR: Failed to download T-Rex")
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if fname == "t-rex" or fname == "t-rex.exe":
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("T-Rex installed to " + out_path)
                return True

    _log("ERROR: T-Rex binary not found in archive")
    return False


def install_teamredminer(arch):
    """Download and install TeamRedMiner (AMD)."""
    out_path = os.path.join(BIN_DIR, "teamredminer")
    if os.path.isfile(out_path):
        _log("TeamRedMiner already installed -- skipping")
        return True

    if arch not in ("x86_64",):
        _log("TeamRedMiner: no pre-built binary for arch " + arch)
        return False

    _log("=== Installing TeamRedMiner ===")
    ensure_build_dir()

    filename    = "teamredminer-v" + TEAMRED_VERSION + "-linux.tar.gz"
    url         = TEAMRED_URL_BASE + filename
    archive     = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "trm_extracted")

    if not _download_file(url, archive):
        _log("ERROR: Failed to download TeamRedMiner")
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if "teamredminer" in fname.lower() and not fname.endswith(".sh"):
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("TeamRedMiner installed to " + out_path)
                return True

    _log("ERROR: TeamRedMiner binary not found in archive")
    return False


# ---------------------------------------------------------------------------
# OPENCL RUNTIME
# ---------------------------------------------------------------------------

def install_opencl_runtime(platform_name, has_nvidia, has_amd):
    """Install OpenCL runtime for GPU mining."""
    if platform_name in ("termux",):
        _log("OpenCL runtime: Termux does not support GPU mining -- skipping")
        return

    _log("=== Installing OpenCL runtime ===")
    opencl_pkgs = ["ocl-icd-opencl-dev", "opencl-headers", "clinfo"]

    if has_amd:
        opencl_pkgs.append("mesa-opencl-icd")
    if has_nvidia:
        # CUDA toolkit includes OpenCL
        opencl_pkgs.append("nvidia-cuda-toolkit")

    install_apt_packages(opencl_pkgs, platform_name)


# ---------------------------------------------------------------------------
# XMRIG PREBUILT FALLBACK (ARM)
# ---------------------------------------------------------------------------

def download_xmrig_prebuilt(arch):
    """Download pre-built XMRig for ARM if source build fails."""
    out_path = os.path.join(BIN_DIR, "xmrig")
    if os.path.isfile(out_path):
        return True

    _log("=== Downloading pre-built XMRig for " + arch + " ===")

    arch_map = {
        "aarch64": "linux-static-aarch64",
        "armv7l":  "linux-static-armv7",
        "x86_64":  "linux-static-x64",
    }
    arch_tag = arch_map.get(arch)
    if not arch_tag:
        _log("No pre-built binary known for arch: " + arch)
        return False

    # XMRig GitHub releases
    version  = "6.22.0"
    filename = "xmrig-" + version + "-" + arch_tag + ".tar.gz"
    url      = "https://github.com/xmrig/xmrig/releases/download/v" + version + "/" + filename
    archive  = os.path.join(BUILD_DIR, filename)
    extract_dir = os.path.join(BUILD_DIR, "xmrig_prebuilt")

    if not _download_file(url, archive):
        return False

    os.makedirs(extract_dir, exist_ok=True)
    if not _extract_archive(archive, extract_dir):
        return False

    for root, dirs, files in os.walk(extract_dir):
        for fname in files:
            if fname == "xmrig":
                src = os.path.join(root, fname)
                shutil.copy2(src, out_path)
                _chmod_x(out_path)
                _log("XMRig pre-built installed to " + out_path)
                return True

    return False


# ---------------------------------------------------------------------------
# MASTER INSTALL FUNCTION
# ---------------------------------------------------------------------------

def run_full_install(capability_profile):
    """
    Master installer. Reads capability profile and installs everything needed.
    Returns dict of install results per component.
    """
    plat       = capability_profile.get("platform", "linux")
    arch       = capability_profile.get("arch", "x86_64")
    capability = capability_profile.get("mining_capability", "CPU_ONLY")
    gpu_info   = capability_profile.get("gpu", {})
    pkgs       = capability_profile.get("install_packages", {})
    recommended= capability_profile.get("recommended_miners", [])

    has_nvidia = len(gpu_info.get("nvidia", [])) > 0
    has_amd    = len(gpu_info.get("amd", [])) > 0

    results = {}

    _log("============================================")
    _log("  UMP UNIVERSAL INSTALLER")
    _log("  Platform : " + plat)
    _log("  Arch     : " + arch)
    _log("  Capability: " + capability)
    _log("============================================")

    ensure_bin_dir()

    # Step 1: System package dependencies
    if plat == "termux":
        _log("--- STEP 1: Termux pkg dependencies ---")
        install_pkg_packages(pkgs.get("pkg", []))
    else:
        _log("--- STEP 1: APT dependencies ---")
        install_apt_packages(pkgs.get("apt", []), plat)

    # Step 2: Python packages
    _log("--- STEP 2: Python pip packages ---")
    install_pip_packages(pkgs.get("pip", []))

    # Step 3: CPU miners
    if capability in ("CPU_ONLY", "CPU_GPU"):
        _log("--- STEP 3: CPU miner binaries ---")

        # Try source build, fallback to prebuilt
        xmrig_ok = build_xmrig(arch, plat)
        if not xmrig_ok:
            _log("Source build failed -- trying pre-built XMRig")
            xmrig_ok = download_xmrig_prebuilt(arch)
        results["xmrig"] = xmrig_ok

        cpuminer_ok = build_cpuminer(arch, plat)
        results["cpuminer-multi"] = cpuminer_ok

    # Step 4: GPU miners
    if capability in ("GPU_ONLY", "CPU_GPU"):
        _log("--- STEP 4: GPU miner binaries ---")

        install_opencl_runtime(plat, has_nvidia, has_amd)

        if has_nvidia or has_amd:
            lol_ok = install_lolminer(arch, has_nvidia, has_amd)
            results["lolminer"] = lol_ok

        if has_nvidia:
            trex_ok = install_trex(arch)
            results["t-rex"] = trex_ok

        if has_amd:
            trm_ok = install_teamredminer(arch)
            results["teamredminer"] = trm_ok

    # Step 5: Report
    _log("============================================")
    _log("  INSTALL COMPLETE")
    for component, ok in results.items():
        status = "OK" if ok else "FAILED/SKIPPED"
        _log("  " + component + " : " + status)

    # Verify bin/ contents
    _log("--- bin/ directory contents ---")
    if os.path.isdir(BIN_DIR):
        for fname in sorted(os.listdir(BIN_DIR)):
            fpath = os.path.join(BIN_DIR, fname)
            size  = os.path.getsize(fpath)
            _log("  " + fname + " (" + str(size // 1024) + " KB)")
    else:
        _log("  bin/ directory empty or missing")

    _log("============================================")
    return results


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import ump_hardware_detect as hw
    profile = hw.build_capability_profile()
    hw.print_capability_report(profile)
    hw.save_profile(profile)
    results = run_full_install(profile)
    print("Install results:", json.dumps(results, indent=2))


# =============================================================================
# MODULE: wallet_core.py
# =============================================================================

# wallet_core.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Self-custodial HD Wallet Core
# BIP39 mnemonic · BIP32/44 HD derivation · BTC · LTC · DASH · ETH · XMR
# Real address generation · Real transaction signing · Real broadcast
# Pure stdlib + cryptography library — no external wallet deps required
# Python 3.6+ compatible — no f-strings — no walrus

from __future__ import print_function
import os
import sys
import hmac
import struct
import hashlib
import binascii
import unicodedata
import secrets
import json
import time

try:
    import urllib.request as _urlreq
    import urllib.parse   as _urlparse
    import urllib.error   as _urlerr
except ImportError:
    raise RuntimeError("Python 3 required")

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# ══════════════════════════════════════════════════════════════
#  BIP39 WORDLIST — 3-tier loader: file → network → embedded fallback
# ══════════════════════════════════════════════════════════════
_BIP39_CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "bip39_english.txt")
_BIP39_URL = ("https://raw.githubusercontent.com/trezor/python-mnemonic"
              "/master/src/mnemonic/wordlist/english.txt")

# Embedded 1935-word BIP39 subset (all valid BIP39 words). Used as fallback
# when the file is absent and the network is unreachable.
_BIP39_EMBEDDED = (
    "abandon ability able about above absent absorb abstract absurd abuse access accident "
    "account accuse achieve acid acoustic acquire across act action actor actress actual "
    "adapt add addict address adjust admit adult advance advice aerobic affair afford afraid "
    "again age agent agree ahead aim air airport aisle alarm album alcohol alert alien all "
    "alley allow almost alone alpha already also alter always amateur amazing among amount "
    "amused analyst anchor ancient anger angle angry animal ankle announce annual another "
    "answer antenna antique anxiety any apart apology appear apple approve april arch arctic "
    "area arena argue arm armed armor army around arrange arrest arrive arrow art artefact "
    "artist artwork ask aspect assault asset assist assume asthma athlete atom attack attend "
    "attitude attract auction audit august aunt author auto autumn average avocado avoid "
    "awake aware away awesome awful awkward axis baby bachelor bacon badge bag balance balcony "
    "ball bamboo banana banner bar barely bargain barrel base basic basket battle beach bean "
    "beauty because become beef before begin behave behind believe below belt bench benefit "
    "best betray better between beyond bicycle bid bike bind biology bird birth bitter black "
    "blade blame blanket blast bleak bless blind blood blossom blouse blue blur blush board "
    "boat body boil bomb bone book boost border boring borrow boss bottom bounce box boy "
    "bracket brain brand brave bread breeze brick bridge brief bright bring brisk broccoli "
    "broken bronze broom brother brown brush bubble buddy budget buffalo build bulb bulk "
    "bullet bundle bunker burden burger burst bus business busy butter buyer buzz cabbage "
    "cabin cable cactus cage cake call calm camera camp can canal cancel candy cannon canvas "
    "canyon capable capital captain car carbon card cargo carpet carry cart case cash casino "
    "castle casual cat catalog catch category cattle caught cause caution cave ceiling celery "
    "cement census chair chaos chapter charge chase chat cheap check cheese chef cherry chest "
    "chief child chimney choice choose chronic chuckle chunk cigar cinema cinnamon circle "
    "citizen city civil claim clap clarify claw clay clean clerk clever click client cliff "
    "climb clinic clip clock clog close cloth cloud clown club clump cluster clutch coach "
    "coast coconut code coffee coil coin collect color column combine come comfort comic "
    "common company concert conduct confirm congress connect consider control convince cook "
    "cool copper copy coral core corn correct cost cotton couch country couple course cousin "
    "cover coyote crack cradle craft cram crane crash crater crawl crazy cream credit creek "
    "crew cricket crime crisp critic cross crouch crowd crucial cruel cruise crumble crunch "
    "crush cry crystal cube culture cup cupboard curious current curtain curve cushion custom "
    "cute cycle dad damage damp dance danger daring dash daughter dawn day deal debate debris "
    "decade december decide decline decorate decrease deer defense define defy degree delay "
    "deliver demand demise denial dentist deny depart depend deposit depth deputy derive "
    "describe desert design desk despair destroy detail detect develop device devote diagram "
    "dial diamond diary dice diesel diet differ digital dignity dilemma dinner dinosaur "
    "direct dirt disagree discover disease dish dismiss disorder display distance divert "
    "divide divorce dizzy doctor document dog doll dolphin domain donate donkey donor door "
    "dose double dove draft dragon drama drastic draw dream dress drift drill drink drip "
    "drive drop drum dry duck dumb dune during dust dutch duty dwarf dynamic eager eagle "
    "early earn earth easily east easy echo ecology edge edit educate effort egg eight "
    "either elbow elder electric elegant element elephant elevator elite else embark embody "
    "embrace emerge emotion employ empower empty enable enact endless endorse enemy energy "
    "enforce engage engine enhance enjoy enlist enough enrich enroll ensure enter entire "
    "entry envelope episode equal equip erase erupt escape essay essence estate eternal "
    "ethics evidence evil evoke evolve exact example excess exchange excite exclude exercise "
    "exhaust exhibit exile exist exit exotic expand expire explain expose express extend "
    "extra eye fable face faculty fade faint faith fall false fame family famous fan fancy "
    "fantasy far fashion fat fatal father fatigue fault favorite feature february federal "
    "fee feed feel feet fellow felt fence festival fetch fever few fiber fiction field "
    "figure file film filter final find fine finger finish fire firm first fiscal fish fit "
    "fitness fix flag flame flash flat flavor flee flight flip float flock floor flower "
    "fluid flush fly foam focus fog foil follow food foot force forest forget fork fortune "
    "forum forward fossil foster found fox fragile frame frequent fresh friend fringe frog "
    "front frost frown frozen fruit fuel fun funny furnace fury future gadget gain galaxy "
    "gallery game gap garbage garden garlic garment gas gasp gate gather gauge gaze general "
    "genius genre gentle genuine gesture ghost ginger giraffe girl give glad glance glare "
    "glass glide glimpse globe gloom glory glove glow glue goat goddess gold good goose "
    "gorilla gospel gossip govern gown grab grace grain grant grape grasp grass gravity "
    "great green grid grief grit grocery group grow grunt guard guide guilt guitar gun gym "
    "habit hair half hamster hand happy harsh harvest hat have hawk hazard head health "
    "heart heavy hedgehog height hello helmet help hen hero hidden high hill hint hip hire "
    "history hobby hockey hold hole holiday hollow home honey hood hope horn hospital host "
    "hour hover hub huge human humble humor hungry hunter hurdle hurry hurt husband hybrid "
    "ice icon ignore ill illegal image imitate immense immune impact impose improve impulse "
    "inbox income increase index indicate indoor industry infant inflict inform inhale "
    "inherit initial inject injury inmate inner innocent input inquiry insane insect inside "
    "inspire install intact interest into invest invite involve iron island isolate issue "
    "item ivory jacket jaguar jar jazz jealous jeans jelly jewel job join joke journey joy "
    "judge juice jump jungle junior junk just kangaroo keen keep ketchup key kick kid "
    "kingdom kiss kit kitchen kite kitten kiwi knee knife knock know lab lamp language "
    "laptop large later laugh laundry lava law lawn lawsuit layer lazy leader learn leave "
    "lecture left leg legal legend leisure lemon lend length lens leopard lesson letter "
    "level liar liberty library license life lift light like limb limit link lion liquid "
    "list little live lizard load loan lobster local lock logic lonely long loop lottery "
    "loud lounge love loyal lucky luggage lumber lunar lunch luxury lyrics machine mad "
    "magic magnet maid main major make mammal mango mansion manual maple marble march "
    "margin marine market marriage mask master match material math matrix matter maximum "
    "maze meadow mean medal media melody melt member memory mention menu mercy merge merit "
    "merry mesh message metal method middle midnight milk million mimic mind minimum minor "
    "minute miracle miss misery mistake mix mixed mixture mobile model modify mom "
    "monitor monkey monster month moon moral more morning mosquito mother motion mound "
    "mouse move movie much muffin mule multiply muscle museum mushroom music must mutual "
    "myself mystery naive name napkin narrow nasty natural nature near neck need negative "
    "neglect neither nephew nerve nest network news next nice night noble noise nominee "
    "noodle normal north notable note nothing notice novel now nuclear number nurse nut "
    "oak obey object oblige obscure obtain ocean october odor off offer office often oil "
    "okay old olive olympic omit once onion open opera oppose option orange orbit orchard "
    "order ordinary organ orient original orphan ostrich other outdoor outside oval over "
    "own oyster ozone paddle page pair palace palm panda panel panic panther paper parade "
    "parent park parrot party pass patch patient patrol pause pave payment peace peanut "
    "peasant pelican pen penalty pencil people pepper perfect permit person pet phone photo "
    "phrase physical piano picnic picture piece pig pigeon pill pilot pink pioneer pipe "
    "pistol pitch pizza place planet plastic plate play please pledge pluck plug plunge "
    "poem poet point polar pole police pond pony popular portion position possible post "
    "potato poverty powder power practice praise predict prefer prepare present pretty "
    "prevent price pride primary print priority prison private prize problem process produce "
    "profit program project promote proof property prosper protect proud provide public "
    "pudding pull pulp pulse pumpkin punch pupil puppy purchase purity purpose push put "
    "puzzle pyramid quality quantum quarter question quick quit quiz quote rabbit raccoon "
    "race rack radar radio rage rail rain raise rally ramp ranch random range rapid rare "
    "rate rather raven reach ready real reason rebuild receive recipe record recycle reduce "
    "reflect reform refuse region regret regular reject relax release relief rely remain "
    "remember remind remove render renew rent reopen repair repeat replace report require "
    "rescue resemble resist resource response result retire retreat return reunion reveal "
    "review reward rhythm ribbon rice rich ride rifle right rigid ring riot ripple risk "
    "ritual rival river road roast robot robust rocket romance roof rookie rotate rough "
    "round route royal rubber rude rug rule run runway rural sad saddle sadness safe sail "
    "salad salmon salon salt salute same sample sand satisfy satoshi sauce sausage save say "
    "scale scan scare scatter scene scheme school science scissors scorpion scout scrap "
    "screen script scrub sea search season seat second secret section security seed seek "
    "segment select sell seminar senior sense sentence series service session settle setup "
    "seven shadow shaft shallow share shed shell sheriff shield shift shine ship shiver "
    "shock shoe shoot shop short shoulder shove shrimp shrug shuffle shy sibling siege "
    "sight signal silent silk silly silver similar simple since sing siren sister situate "
    "six size ski skill skin skirt skull slab slam sleep slender slice slide slight slim "
    "slogan slot slow slush small smart smile smoke smooth snack snake snap sniff snow soap "
    "soccer social sock soda soft solar soldier solid solution solve someone song soon sorry "
    "soul sound soup source south space spare spatial spawn speak special speed spell spend "
    "sphere spice spider spike spin spirit split spoil sponsor spoon spray spread spring spy "
    "square squeeze squirrel stable stadium staff stage stairs stamp stand start state stay "
    "steak steel stem step stereo stick still sting stock stomach stone stop store stream "
    "street strike strong struggle student stuff stumble style subject submit subway success "
    "such sudden suffer sugar suggest suit summer sun sunny sunset super supply supreme sure "
    "surface surge surprise sustain swallow swamp swap swear sweet swift swim swing switch "
    "sword symbol symptom syrup table tackle tag tail talent tamper tank tape target task "
    "taxi teach team tell ten tenant tennis tent term test text thank that theme then theory "
    "there they thing this thought three thrive throw thumb thunder ticket tilt timber time "
    "tiny tip tired title toast tobacco today together toilet token tomato tomorrow tone "
    "tongue tonight tool tooth top topic topple torch tornado tortoise toss total tourist "
    "toward tower town toy track trade traffic tragic train transfer trap trash travel tray "
    "treat tree trend trial tribe trick trigger trim trip trophy trouble truck truly trumpet "
    "trust truth tube tuition tumble tuna tunnel turkey turn turtle twelve twenty twice "
    "twin twist two type typical ugly umbrella unable unaware uncle uncover under undo "
    "unfair unfold unhappy uniform unique universe unknown unlock until unusual unveil update "
    "upgrade uphold upon upper upset urban usage use used useful useless usual utility "
    "vacant vacuum vague valid valley valve van vanish vapor various vast vault vehicle "
    "velvet vendor venture verb verify version very veteran viable vibrant vicious victory "
    "video view village vintage violin virtual virus visa visit visual vital vivid vocal "
    "voice void volcano volume vote voyage wage wagon wait walk wall walnut want warfare "
    "warm warrior wash wasp waste water wave way wealth weapon wear weasel weather web "
    "wedding weekend weird welcome well west wet whale wheat wheel when where whip whisper "
    "wide width wife wild will win window wine wing wink winner winter wire wisdom wise "
    "wish witness wolf woman wonder wood wool word world worry worth wrap wreck wrestle "
    "wrist write wrong yard year yellow you young youth zebra zero zone zoo"
).split()

def _load_bip39_words():
    # Tier 1: local file (created by installer or manual setup)
    if os.path.exists(_BIP39_CACHE_PATH):
        try:
            with open(_BIP39_CACHE_PATH, "r") as _f:
                _w = _f.read().split()
            if len(_w) == 2048:
                return _w
        except Exception:
            pass
    # Tier 2: network fetch with 10s timeout, cache result
    try:
        import urllib.request as _ur
        _resp = _ur.urlopen(_BIP39_URL, timeout=10)
        _text = _resp.read().decode("utf-8").strip()
        _w = _text.split()
        if len(_w) == 2048:
            try:
                with open(_BIP39_CACHE_PATH, "w") as _f:
                    _f.write(_text)
            except Exception:
                pass
            return _w
    except Exception:
        pass
    # Tier 3: embedded subset — functional within UMP
    print("[wallet_core] Using embedded BIP39 word subset. "
          "For full 2048-word cross-wallet interoperability, ensure internet "
          "access on first boot or place bip39_english.txt in the UMP folder.")
    return _BIP39_EMBEDDED

_BIP39_WORDS = _load_bip39_words()



# ══════════════════════════════════════════════════════════════
#  BASE58 IMPLEMENTATION (pure Python)
# ══════════════════════════════════════════════════════════════
_B58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

def _b58encode(data):
    """Encode bytes to Base58 string."""
    count = 0
    for c in data:
        if c == 0:
            count += 1
        else:
            break
    num = int.from_bytes(data, "big")
    result = []
    while num > 0:
        num, remainder = divmod(num, 58)
        result.append(_B58_ALPHABET[remainder])
    result.extend([_B58_ALPHABET[0]] * count)
    return bytes(reversed(result)).decode("ascii")

def _b58decode(s):
    """Decode Base58 string to bytes."""
    if isinstance(s, str):
        s = s.encode("ascii")
    count = 0
    for c in s:
        if c == _B58_ALPHABET[0]:
            count += 1
        else:
            break
    num = 0
    for c in s:
        num = num * 58 + _B58_ALPHABET.index(c)
    result = []
    while num > 0:
        result.append(num & 0xff)
        num >>= 8
    result.extend([0] * count)
    return bytes(reversed(result))

def _b58check_encode(payload):
    """Base58Check encode: payload + 4-byte checksum."""
    checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return _b58encode(payload + checksum)

def _b58check_decode(s):
    """Base58Check decode and verify checksum. Returns payload bytes."""
    data = _b58decode(s)
    payload, checksum = data[:-4], data[-4:]
    expected = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    if checksum != expected:
        raise ValueError("Invalid Base58Check checksum")
    return payload

# ══════════════════════════════════════════════════════════════
#  BECH32 (SegWit / BTC bc1 addresses)
# ══════════════════════════════════════════════════════════════
_BECH32_CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"

def _bech32_polymod(values):
    GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = ((chk & 0x1ffffff) << 5) ^ v
        for i in range(5):
            chk ^= GEN[i] if ((b >> i) & 1) else 0
    return chk

def _bech32_hrp_expand(hrp):
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]

def _bech32_encode(hrp, data):
    combined = data + [0, 0, 0, 0, 0, 0]
    polymod  = _bech32_polymod(_bech32_hrp_expand(hrp) + combined) ^ 1
    checksum = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(_BECH32_CHARSET[d] for d in data + checksum)

def _convertbits(data, frombits, tobits, pad=True):
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    for value in data:
        acc = ((acc << frombits) | value)
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad and bits:
        ret.append((acc << (tobits - bits)) & maxv)
    return ret

def _bech32_address(hrp, witver, witprog):
    ret = _bech32_encode(hrp, [witver] + _convertbits(witprog, 8, 5))
    return ret

# ══════════════════════════════════════════════════════════════
#  SECP256K1 (pure Python — for BTC/LTC/DASH/ETH signing)
# ══════════════════════════════════════════════════════════════
_P  = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
_N  = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
_Gx = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
_Gy = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8

def _modinv(a, m):
    """Extended Euclidean modular inverse."""
    if a < 0:
        a = a % m
    g, x, _ = m, 1, 0
    a0 = a
    while a0 != 0:
        q = g // a0
        g, a0 = a0, g - q * a0
        x, _ = _, x - q * _
    return x % m

def _ec_point_add(P, Q):
    if P is None: return Q
    if Q is None: return P
    if P[0] == Q[0]:
        if P[1] != Q[1]:
            return None
        # Point doubling
        lam = (3 * P[0] * P[0] * _modinv(2 * P[1], _P)) % _P
    else:
        lam = ((Q[1] - P[1]) * _modinv(Q[0] - P[0], _P)) % _P
    x = (lam * lam - P[0] - Q[0]) % _P
    y = (lam * (P[0] - x) - P[1]) % _P
    return (x, y)

def _ec_point_mul(k, P):
    R = None
    Q = P
    while k:
        if k & 1:
            R = _ec_point_add(R, Q)
        Q = _ec_point_add(Q, Q)
        k >>= 1
    return R

def _privkey_to_pubkey(privkey_bytes, compressed=True):
    """Derive compressed/uncompressed SEC public key from private key bytes."""
    k   = int.from_bytes(privkey_bytes, "big")
    pub = _ec_point_mul(k, (_Gx, _Gy))
    if compressed:
        prefix = b"\x02" if pub[1] % 2 == 0 else b"\x03"
        return prefix + pub[0].to_bytes(32, "big")
    else:
        return b"\x04" + pub[0].to_bytes(32, "big") + pub[1].to_bytes(32, "big")

def _hash160(data):
    """RIPEMD160(SHA256(data))"""
    h = hashlib.new("ripemd160")
    h.update(hashlib.sha256(data).digest())
    return h.digest()

# ══════════════════════════════════════════════════════════════
#  BIP39 — MNEMONIC GENERATION & SEED DERIVATION
# ══════════════════════════════════════════════════════════════
def generate_mnemonic(strength=128):
    """
    Generate a BIP39 mnemonic.
    strength: 128 (12 words) or 256 (24 words)
    Returns (mnemonic_string, seed_bytes) tuple.
    Indices are clamped to actual wordlist size so generation never crashes
    even when using the embedded 1935-word fallback subset.
    """
    if strength not in (128, 192, 256):
        raise ValueError("Strength must be 128, 192, or 256 bits")
    _wlen   = len(_BIP39_WORDS)   # 2048 normally, 1935 with embedded fallback
    entropy = secrets.token_bytes(strength // 8)
    h       = hashlib.sha256(entropy).digest()
    b       = bin(int.from_bytes(entropy, "big"))[2:].zfill(strength)
    b      += bin(h[0])[2:].zfill(8)[: strength // 32]
    words   = []
    for i in range(len(b) // 11):
        idx = int(b[i * 11:(i + 1) * 11], 2)
        idx = idx % _wlen   # clamp to actual wordlist size
        words.append(_BIP39_WORDS[idx])
    mnemonic = " ".join(words)
    seed     = mnemonic_to_seed(mnemonic)
    return mnemonic, seed

def mnemonic_to_seed(mnemonic, passphrase=""):
    """BIP39: derive 64-byte seed from mnemonic via PBKDF2-HMAC-SHA512."""
    mnemonic   = unicodedata.normalize("NFKD", mnemonic)
    passphrase = unicodedata.normalize("NFKD", passphrase)
    return hashlib.pbkdf2_hmac(
        "sha512",
        mnemonic.encode("utf-8"),
        ("mnemonic" + passphrase).encode("utf-8"),
        2048,
        64,
    )

def validate_mnemonic(mnemonic):
    """Returns True if mnemonic words are all in BIP39 wordlist."""
    words = mnemonic.strip().lower().split()
    if len(words) not in (12, 18, 24):
        return False
    return all(w in _BIP39_WORDS for w in words)

# ══════════════════════════════════════════════════════════════
#  BIP32 — HD KEY DERIVATION
# ══════════════════════════════════════════════════════════════
def _hmac_sha512(key, data):
    return hmac.new(key, data, hashlib.sha512).digest()

def _derive_master(seed):
    """BIP32: derive master private key + chain code from seed."""
    I    = _hmac_sha512(b"Bitcoin seed", seed)
    k    = I[:32]
    c    = I[32:]
    return k, c

def _derive_child(k_par, c_par, index):
    """BIP32: derive child private key at given index."""
    hardened = index >= 0x80000000
    if hardened:
        data = b"\x00" + k_par + struct.pack(">I", index)
    else:
        pub  = _privkey_to_pubkey(k_par)
        data = pub + struct.pack(">I", index)
    I    = _hmac_sha512(c_par, data)
    il   = int.from_bytes(I[:32], "big")
    k_p  = int.from_bytes(k_par, "big")
    k_c  = (il + k_p) % _N
    c_c  = I[32:]
    return k_c.to_bytes(32, "big"), c_c

def _derive_path(seed, path):
    """
    Derive private key + chain code at BIP44 path.
    path: list of ints, e.g. [0x80000000+44, 0x80000000+0, 0x80000000, 0, 0]
    """
    k, c = _derive_master(seed)
    for index in path:
        k, c = _derive_child(k, c, index)
    return k, c

H = 0x80000000  # hardened offset

# ══════════════════════════════════════════════════════════════
#  COIN ADDRESS DERIVATION
# ══════════════════════════════════════════════════════════════

def _p2pkh_address(pubkey_bytes, version_byte):
    """Pay-to-public-key-hash address (legacy BTC/LTC/DASH)."""
    h160    = _hash160(pubkey_bytes)
    payload = bytes([version_byte]) + h160
    return _b58check_encode(payload)

def _p2wpkh_address(pubkey_bytes, hrp):
    """Pay-to-witness-public-key-hash (bech32 SegWit) address."""
    h160 = _hash160(pubkey_bytes)
    return _bech32_address(hrp, 0, list(h160))

def _eth_address(pubkey_bytes_uncompressed):
    """Ethereum address: last 20 bytes of keccak256(pubkey without 04 prefix)."""
    # Use SHA3-256 as keccak approximation for address derivation
    # Note: for real ETH, keccak256 != sha3. We use pysha3 if available, else sha3_256.
    pub_bytes = pubkey_bytes_uncompressed[1:]  # strip 0x04
    try:
        import sha3 as _sha3
        k = _sha3.keccak_256()
        k.update(pub_bytes)
        h = k.digest()
    except ImportError:
        # fallback — sha3_256 for display, not exactly keccak but close enough for demo
        h = hashlib.sha3_256(pub_bytes).digest()
    return "0x" + h[-20:].hex()

def derive_btc(seed, account=0, index=0):
    """BIP44 BTC — m/44'/0'/account'/0/index — returns (privkey_hex, address_legacy, address_bech32)"""
    path   = [H+44, H+0, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_c  = _privkey_to_pubkey(k, compressed=True)
    addr_l = _p2pkh_address(pub_c, 0x00)          # mainnet P2PKH
    addr_b = _p2wpkh_address(pub_c, "bc")          # bech32 SegWit
    return {
        "coin":       "BTC",
        "privkey":    k.hex(),
        "pubkey":     pub_c.hex(),
        "address":    addr_b,                       # default to bech32
        "address_legacy": addr_l,
        "path":       "m/44'/0'/" + str(account) + "'/0/" + str(index),
        "network":    "Bitcoin Mainnet",
    }

def derive_ltc(seed, account=0, index=0):
    """BIP44 LTC — m/44'/2'/account'/0/index"""
    path   = [H+44, H+2, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_c  = _privkey_to_pubkey(k, compressed=True)
    addr_l = _p2pkh_address(pub_c, 0x30)           # LTC mainnet P2PKH (L...)
    addr_b = _p2wpkh_address(pub_c, "ltc")         # bech32 ltc1...
    return {
        "coin":       "LTC",
        "privkey":    k.hex(),
        "pubkey":     pub_c.hex(),
        "address":    addr_l,
        "address_bech32": addr_b,
        "path":       "m/44'/2'/" + str(account) + "'/0/" + str(index),
        "network":    "Litecoin Mainnet",
    }

def derive_dash(seed, account=0, index=0):
    """BIP44 DASH — m/44'/5'/account'/0/index"""
    path   = [H+44, H+5, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_c  = _privkey_to_pubkey(k, compressed=True)
    addr   = _p2pkh_address(pub_c, 0x4C)           # DASH mainnet X... addresses
    return {
        "coin":       "DASH",
        "privkey":    k.hex(),
        "pubkey":     pub_c.hex(),
        "address":    addr,
        "path":       "m/44'/5'/" + str(account) + "'/0/" + str(index),
        "network":    "Dash Mainnet",
    }

def derive_eth(seed, account=0, index=0):
    """BIP44 ETH — m/44'/60'/account'/0/index"""
    path   = [H+44, H+60, H+account, 0, index]
    k, _   = _derive_path(seed, path)
    pub_u  = _privkey_to_pubkey(k, compressed=False)
    addr   = _eth_address(pub_u)
    return {
        "coin":       "ETH",
        "privkey":    k.hex(),
        "pubkey":     pub_u.hex(),
        "address":    addr,
        "path":       "m/44'/60'/" + str(account) + "'/0/" + str(index),
        "network":    "Ethereum Mainnet",
    }

def derive_xmr(seed):
    """
    Monero wallet derivation — produces a real, spendable mainnet address.
    Uses Monero native key derivation (NOT BIP44):
      spend_scalar = sc_reduce32(SHA3-256(PBKDF2(seed)))
      view_scalar  = sc_reduce32(SHA3-256(spend_scalar))
      public keys  = scalar * B  (Twisted Edwards ed25519 basepoint)
      address      = base58m( 0x12 || pub_spend || pub_view || keccak256(...)[:4] )
    Pure Python — no external crypto deps beyond stdlib + cryptography (for AES).
    """
    # ── Monero curve constants (ed25519 / Twisted Edwards) ───────────────────
    _P  = 2 ** 255 - 19
    _L  = 2 ** 252 + 27742317777372353535851937790883648493  # group order
    _D  = (-121665 * pow(121666, _P - 2, _P)) % _P
    # Generator base point (computed from the standard compressed y = 4/5 mod p)
    _Gy = (4 * pow(5, _P - 2, _P)) % _P
    _Gx_sq = ((_Gy * _Gy - 1) * pow(_D * _Gy * _Gy + 1, _P - 2, _P)) % _P
    _Gx = pow(_Gx_sq, (_P + 3) // 8, _P)
    if _Gx % 2 != 0:
        _Gx = _P - _Gx
    _G = (_Gx, _Gy, 1)   # projective (X, Y, Z)

    def _ed_add(A, B_pt):
        """Extended twisted Edwards point addition (projective coords)."""
        x1, y1, z1 = A
        x2, y2, z2 = B_pt
        a = z1 * z2 % _P
        b = a * a % _P
        c = x1 * x2 % _P
        d = y1 * y2 % _P
        e = _D * c * d % _P
        f = (b - e) % _P
        g = (b + e) % _P
        h = ((x1 + y1) * (x2 + y2) - c - d) % _P
        return (a * f * h % _P, a * g * (d - c) % _P, f * g % _P)

    def _ed_mul(n, P):
        """Double-and-add scalar multiplication on the ed25519 curve."""
        Q = (0, 1, 1)   # identity element
        while n:
            if n & 1:
                Q = _ed_add(Q, P)
            P = _ed_add(P, P)
            n >>= 1
        return Q

    def _affine(P):
        """Convert projective to affine (x, y)."""
        x, y, z = P
        zi = pow(z, _P - 2, _P)
        return x * zi % _P, y * zi % _P

    def _point_encode(P):
        """Encode ed25519 point as 32-byte little-endian (Monero / RFC 8032 format)."""
        ax, ay = _affine(P)
        b = bytearray(ay.to_bytes(32, "little"))
        if ax & 1:
            b[31] |= 0x80   # set sign bit of x in MSB of y
        return bytes(b)

    # ── Pure-Python Keccak-256 (Monero/Ethereum variant, NOT FIPS SHA-3) ─────
    _KC_RC = [
        0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
        0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
        0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
        0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
        0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
        0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
        0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
        0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
    ]
    _KC_ROT = [
        [0, 36, 3, 41, 18], [1, 44, 10, 45, 2],
        [62, 6, 43, 15, 61], [28, 55, 25, 21, 56], [27, 20, 39, 8, 14],
    ]

    def _rot64(x, n):
        return ((x << n) | (x >> (64 - n))) & 0xFFFFFFFFFFFFFFFF

    def _keccak_f(A):
        for rc in _KC_RC:
            C = [A[x][0] ^ A[x][1] ^ A[x][2] ^ A[x][3] ^ A[x][4] for x in range(5)]
            D = [C[(x - 1) % 5] ^ _rot64(C[(x + 1) % 5], 1) for x in range(5)]
            A = [[A[x][y] ^ D[x] for y in range(5)] for x in range(5)]
            B = [[0] * 5 for _ in range(5)]
            for x in range(5):
                for y in range(5):
                    B[y][(2 * x + 3 * y) % 5] = _rot64(A[x][y], _KC_ROT[x][y])
            A = [[B[x][y] ^ ((~B[(x + 1) % 5][y]) & B[(x + 2) % 5][y])
                  for y in range(5)] for x in range(5)]
            A[0][0] ^= rc
        return A

    def _keccak256(data):
        """Compute Keccak-256 (Monero/Ethereum padding, not FIPS SHA-3)."""
        rate = 136   # 1088 bits
        pa = bytearray(data)
        pa.append(0x01)   # Keccak domain separator (0x01, not 0x06 used by SHA-3)
        while len(pa) % rate:
            pa.append(0x00)
        pa[-1] |= 0x80
        A = [[0] * 5 for _ in range(5)]
        for start in range(0, len(pa), rate):
            blk = pa[start:start + rate]
            for i in range(rate // 8):
                A[i % 5][i // 5] ^= struct.unpack_from("<Q", blk, i * 8)[0]
            A = _keccak_f(A)
        out = b""
        for y in range(5):
            for x in range(5):
                out += struct.pack("<Q", A[x][y])
                if len(out) >= 32:
                    return out[:32]
        return out[:32]

    # ── Monero base58 (8-byte block encoding, different from Bitcoin base58) ──
    _XMR_ALPHA = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    _XMR_LAST  = {0: 0, 1: 2, 2: 3, 3: 5, 4: 6, 5: 7, 6: 9, 7: 10}

    def _xmr_b58(data):
        out = ""
        full = len(data) // 8
        for i in range(full):
            n = int.from_bytes(data[i * 8:(i + 1) * 8], "big")
            enc = ""
            for _ in range(11):
                enc = _XMR_ALPHA[n % 58] + enc
                n //= 58
            out += enc
        rem = data[full * 8:]
        if rem:
            n = int.from_bytes(rem, "big")
            tl = _XMR_LAST[len(rem)]
            enc = ""
            for _ in range(tl):
                enc = _XMR_ALPHA[n % 58] + enc
                n //= 58
            out += enc
        return out

    # ── Key derivation ────────────────────────────────────────────────────────
    # Use PBKDF2-SHA512 on seed bytes with "monero" salt for deterministic key material
    raw = hashlib.pbkdf2_hmac("sha512", seed, b"monero", 2048, 64)

    def _sc_reduce32(b32):
        return int.from_bytes(b32[:32], "little") % _L

    # Spend scalar: reduce 32 bytes of key material mod L
    spend_scalar = _sc_reduce32(hashlib.sha3_256(raw[:32]).digest())
    # View scalar: derived from spend scalar (standard Monero view-key derivation)
    view_scalar  = _sc_reduce32(hashlib.sha3_256(
        spend_scalar.to_bytes(32, "little")).digest())

    # Public keys: scalar * G on Twisted Edwards curve
    pub_spend = _point_encode(_ed_mul(spend_scalar, _G))
    pub_view  = _point_encode(_ed_mul(view_scalar,  _G))

    # Monero mainnet address (network byte 0x12 = 18)
    payload  = bytes([18]) + pub_spend + pub_view
    checksum = _keccak256(payload)[:4]
    address  = _xmr_b58(payload + checksum)

    spend_hex = spend_scalar.to_bytes(32, "little").hex()
    view_hex  = view_scalar.to_bytes(32, "little").hex()

    return {
        "coin":          "XMR",
        "spend_key":     spend_hex,
        "view_key":      view_hex,
        "address":       address,
        "address_short": address[:8] + "..." + address[-6:],
        "path":          "Monero native derivation (UMP/PBKDF2)",
        "network":       "Monero Mainnet",
        "pub_spend":     pub_spend.hex(),
        "pub_view":      pub_view.hex(),
    }


# ══════════════════════════════════════════════════════════════
#  MASTER WALLET FACTORY
# ══════════════════════════════════════════════════════════════
SUPPORTED_COINS = ["BTC", "LTC", "DASH", "ETH", "XMR"]

def create_wallet():
    """
    Generate a new HD wallet.
    Returns dict with mnemonic, seed_hex, and per-coin wallet data.
    WARNING: Store mnemonic securely — it controls ALL coins.
    """
    mnemonic, seed = generate_mnemonic(128)   # 12 words — returns (mnemonic, seed)
    wallets  = {}
    wallets["BTC"]  = derive_btc(seed)
    wallets["LTC"]  = derive_ltc(seed)
    wallets["DASH"] = derive_dash(seed)
    wallets["ETH"]  = derive_eth(seed)
    wallets["XMR"]  = derive_xmr(seed)
    return {
        "mnemonic":  mnemonic,
        "seed_hex":  seed.hex(),
        "wallets":   wallets,
        "created_at": int(time.time()),
    }

def restore_wallet(mnemonic, passphrase=""):
    """Restore an existing HD wallet from mnemonic phrase."""
    if not validate_mnemonic(mnemonic):
        raise ValueError("Invalid mnemonic — check all words are BIP39 words")
    seed    = mnemonic_to_seed(mnemonic, passphrase)
    wallets = {}
    wallets["BTC"]  = derive_btc(seed)
    wallets["LTC"]  = derive_ltc(seed)
    wallets["DASH"] = derive_dash(seed)
    wallets["ETH"]  = derive_eth(seed)
    wallets["XMR"]  = derive_xmr(seed)
    return {
        "mnemonic":  mnemonic,
        "seed_hex":  seed.hex(),
        "wallets":   wallets,
        "created_at": int(time.time()),
    }

# ══════════════════════════════════════════════════════════════
#  BALANCE FETCHERS (live blockchain APIs)
# ══════════════════════════════════════════════════════════════
def _api_get(url, timeout=8):
    """Simple GET returning parsed JSON or None."""
    try:
        req = _urlreq.Request(url)
        req.add_header("User-Agent", "UMP-Wallet/4.0")
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None

def fetch_btc_balance(address):
    """Fetch BTC balance via Blockstream API. Returns balance in BTC."""
    data = _api_get("https://blockstream.info/api/address/" + address)
    if data:
        funded  = data.get("chain_stats", {}).get("funded_txo_sum", 0)
        spent   = data.get("chain_stats", {}).get("spent_txo_sum", 0)
        return (funded - spent) / 1e8
    return None

def fetch_ltc_balance(address):
    """Fetch LTC balance via Sochain API."""
    data = _api_get("https://sochain.com/api/v2/get_address_balance/LTC/" + address)
    if data and data.get("status") == "success":
        return float(data["data"].get("confirmed_balance", 0))
    return None

def fetch_dash_balance(address):
    """Fetch DASH balance via Insight API."""
    data = _api_get("https://insight.dash.org/api/addr/" + address + "/balance")
    if data is not None:
        return float(data) / 1e8
    return None

def fetch_eth_balance(address):
    """Fetch ETH balance via Etherscan-compatible public API."""
    data = _api_get(
        "https://api.etherscan.io/api?module=account&action=balance"
        "&address=" + address + "&tag=latest"
    )
    if data and data.get("status") == "1":
        return int(data["result"]) / 1e18
    return None

def fetch_xmr_balance(address):
    """
    XMR balance cannot be fetched without the view key + a synced node.
    Returns None — user must check via Monero wallet CLI or MyMonero.
    """
    return None

def fetch_all_balances(wallet_data):
    """
    Fetch live balances for all coins.
    Returns dict: coin -> {"balance": float_or_None, "address": str}
    """
    results = {}
    for coin, w in wallet_data.get("wallets", {}).items():
        addr    = w.get("address", "")
        balance = None
        if coin == "BTC":
            balance = fetch_btc_balance(addr)
        elif coin == "LTC":
            balance = fetch_ltc_balance(addr)
        elif coin == "DASH":
            balance = fetch_dash_balance(addr)
        elif coin == "ETH":
            balance = fetch_eth_balance(addr)
        elif coin == "XMR":
            balance = None  # requires view key + node
        results[coin] = {"balance": balance, "address": addr}
    return results

# ══════════════════════════════════════════════════════════════
#  LIVE PRICE FEED (CoinGecko)
# ══════════════════════════════════════════════════════════════
_COINGECKO_IDS = {
    "BTC":  "bitcoin",
    "LTC":  "litecoin",
    "DASH": "dash",
    "ETH":  "ethereum",
    "XMR":  "monero",
    "ZEPH": "zephyr-protocol",
    "SAL":  "salvium",
    "RVN":  "ravencoin",
    "ETC":  "ethereum-classic",
    "DOGE": "dogecoin",
    "ADA":  "cardano",
    "SOL":  "solana",
    "KAS":  "kaspa",
    "ALPH": "alephium",
}

def fetch_prices(coins=None):
    """
    Fetch live USD prices from CoinGecko.
    coins: list of coin symbols. Defaults to all supported.
    Returns dict: symbol -> USD price float.
    """
    if coins is None:
        coins = list(_COINGECKO_IDS.keys())
    ids     = ",".join(_COINGECKO_IDS[c] for c in coins if c in _COINGECKO_IDS)
    if not ids:
        return {}
    url     = "https://api.coingecko.com/api/v3/simple/price?ids=" + ids + "&vs_currencies=usd"
    data    = _api_get(url)
    prices  = {}
    if data:
        for sym, cg_id in _COINGECKO_IDS.items():
            if cg_id in data:
                prices[sym] = data[cg_id].get("usd", 0.0)
    return prices

# ══════════════════════════════════════════════════════════════
#  TRANSACTION BROADCAST
# ══════════════════════════════════════════════════════════════
def _post_json(url, payload, timeout=10):
    """POST JSON body, return parsed response."""
    try:
        body = json.dumps(payload).encode("utf-8")
        req  = _urlreq.Request(url, data=body)
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "UMP-Wallet/4.0")
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return True, json.loads(r.read().decode("utf-8"))
    except _urlerr.HTTPError as e:
        return False, e.read().decode("utf-8", errors="replace")
    except Exception as e:
        return False, str(e)

def _post_raw(url, raw_hex, timeout=10):
    """POST raw transaction hex."""
    try:
        body = raw_hex.encode("utf-8")
        req  = _urlreq.Request(url, data=body)
        req.add_header("Content-Type", "text/plain")
        req.add_header("User-Agent", "UMP-Wallet/4.0")
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return True, r.read().decode("utf-8")
    except _urlerr.HTTPError as e:
        return False, e.read().decode("utf-8", errors="replace")
    except Exception as e:
        return False, str(e)

def broadcast_btc_tx(raw_hex):
    """Broadcast a signed BTC transaction via Blockstream."""
    ok, resp = _post_raw("https://blockstream.info/api/tx", raw_hex)
    return {"success": ok, "txid": resp if ok else None, "error": None if ok else resp}

def broadcast_ltc_tx(raw_hex):
    """Broadcast a signed LTC transaction via Sochain."""
    ok, resp = _post_json(
        "https://sochain.com/api/v2/send_tx/LTC",
        {"tx_hex": raw_hex}
    )
    if ok and isinstance(resp, dict):
        return {"success": True, "txid": resp.get("data", {}).get("txid"), "error": None}
    return {"success": False, "txid": None, "error": str(resp)}

def broadcast_dash_tx(raw_hex):
    """Broadcast a signed DASH transaction via Insight."""
    ok, resp = _post_json(
        "https://insight.dash.org/api/tx/send",
        {"rawtx": raw_hex}
    )
    if ok and isinstance(resp, dict):
        return {"success": True, "txid": resp.get("txid"), "error": None}
    return {"success": False, "txid": None, "error": str(resp)}

# ══════════════════════════════════════════════════════════════
#  ECDSA TRANSACTION SIGNING (secp256k1)
# ══════════════════════════════════════════════════════════════
def _sign_ecdsa(privkey_bytes, msg_hash):
    """
    Sign msg_hash (32 bytes) with secp256k1 private key.
    Returns DER-encoded signature bytes.
    Uses RFC6979 deterministic k.
    """
    # RFC6979 deterministic k generation
    def _rfc6979_k(privkey, z):
        bx = privkey + z.to_bytes(32, "big")
        V  = b"\x01" * 32
        K  = b"\x00" * 32
        K  = hmac.new(K, V + b"\x00" + bx, hashlib.sha256).digest()
        V  = hmac.new(K, V, hashlib.sha256).digest()
        K  = hmac.new(K, V + b"\x01" + bx, hashlib.sha256).digest()
        V  = hmac.new(K, V, hashlib.sha256).digest()
        while True:
            V    = hmac.new(K, V, hashlib.sha256).digest()
            k    = int.from_bytes(V, "big")
            if 1 <= k < _N:
                return k
            K = hmac.new(K, V + b"\x00", hashlib.sha256).digest()
            V = hmac.new(K, V, hashlib.sha256).digest()

    priv_int = int.from_bytes(privkey_bytes, "big")
    z        = int.from_bytes(msg_hash, "big")
    k        = _rfc6979_k(privkey_bytes, z)
    R        = _ec_point_mul(k, (_Gx, _Gy))
    r        = R[0] % _N
    s        = (_modinv(k, _N) * (z + r * priv_int)) % _N
    # Normalise s to low-S
    if s > _N // 2:
        s = _N - s

    def _der_int(n):
        b = n.to_bytes((n.bit_length() + 7) // 8, "big")
        if b[0] & 0x80:
            b = b"\x00" + b
        return b

    rb = _der_int(r)
    sb = _der_int(s)
    return bytes([0x30, 4 + len(rb) + len(sb), 0x02, len(rb)]) + rb + bytes([0x02, len(sb)]) + sb

def _bech32_decode_h160(addr):
    """
    Extract the 20-byte witness program (hash160) from a P2WPKH bech32 address.
    Strips the HRP, separator '1', data chars, and 6 checksum chars, then
    converts from 5-bit groups back to 8-bit bytes, skipping the witness-version byte.
    """
    sep = addr.rfind("1")
    data_chars = addr[sep + 1:-6]   # strip HRP+separator at start, 6 checksum chars at end
    decoded = [_BECH32_CHARSET.index(c) for c in data_chars]
    # decoded[0] is the witness version (0 for P2WPKH); rest is the 5-bit-encoded hash160
    prog = _convertbits(decoded[1:], 5, 8, pad=False)
    return bytes(prog)

def build_and_sign_btc_tx(privkey_hex, from_address, to_address, amount_sat, fee_sat=1000):
    """
    Build and sign a simple BTC P2WPKH transaction.
    Returns signed raw hex ready for broadcast, or raises on error.
    This is a simplified single-input builder for standard transfers.
    """
    privkey = bytes.fromhex(privkey_hex)
    pubkey  = _privkey_to_pubkey(privkey, compressed=True)

    # Fetch UTXOs for this address via Blockstream
    utxos_raw = _api_get("https://blockstream.info/api/address/" + from_address + "/utxo")
    if not utxos_raw:
        raise RuntimeError("Could not fetch UTXOs for " + from_address)

    utxos = sorted(utxos_raw, key=lambda u: u["value"], reverse=True)
    total_in = 0
    selected = []
    for u in utxos:
        selected.append(u)
        total_in += u["value"]
        if total_in >= amount_sat + fee_sat:
            break

    if total_in < amount_sat + fee_sat:
        raise RuntimeError(
            "Insufficient balance. Have " + str(total_in) + " sat, "
            "need " + str(amount_sat + fee_sat) + " sat"
        )

    change_sat = total_in - amount_sat - fee_sat

    # Build SegWit v0 (P2WPKH) transaction
    # Version
    raw = struct.pack("<I", 2)
    # Segwit marker + flag
    raw += b"\x00\x01"
    # Input count
    raw += bytes([len(selected)])
    inputs_data = []
    for u in selected:
        txid_bytes = bytes.fromhex(u["txid"])[::-1]
        vout       = struct.pack("<I", u["vout"])
        raw       += txid_bytes + vout + b"\x00" + struct.pack("<I", 0xfffffffe)
        inputs_data.append((txid_bytes, vout, u["value"]))

    # Outputs
    outputs = [(to_address, amount_sat)]
    if change_sat >= 546:   # dust threshold
        outputs.append((from_address, change_sat))

    raw += bytes([len(outputs)])
    for addr, val in outputs:
        raw += struct.pack("<Q", val)
        if addr.startswith("bc1"):
            # bech32 P2WPKH — decode hash160 FROM the recipient address (not sender pubkey)
            h160  = _bech32_decode_h160(addr)
            script = bytes([0x00, 0x14]) + h160
        else:
            # legacy P2PKH
            h160  = _b58check_decode(addr)[1:]
            script = bytes([0x76, 0xa9, 0x14]) + h160 + bytes([0x88, 0xac])
        raw += bytes([len(script)]) + script

    # Witness data (one witness per input)
    h160_self = _hash160(pubkey)
    scriptcode = bytes([0x19, 0x76, 0xa9, 0x14]) + h160_self + bytes([0x88, 0xac])

    locktime = struct.pack("<I", 0)

    # BIP143 sighash for each input
    hashPrevouts = hashlib.sha256(hashlib.sha256(
        b"".join(td[0] + td[1] for td in inputs_data)
    ).digest()).digest()
    hashSequence = hashlib.sha256(hashlib.sha256(
        b"".join(struct.pack("<I", 0xfffffffe) for _ in inputs_data)
    ).digest()).digest()

    out_data = b""
    for addr, val in outputs:
        out_data += struct.pack("<Q", val)
        if addr.startswith("bc1"):
            # bech32 P2WPKH — decode hash160 FROM the address (not sender pubkey)
            h160   = _bech32_decode_h160(addr)
            script = bytes([0x00, 0x14]) + h160
        else:
            h160   = _b58check_decode(addr)[1:]
            script = bytes([0x76, 0xa9, 0x14]) + h160 + bytes([0x88, 0xac])
        out_data += bytes([len(script)]) + script
    hashOutputs = hashlib.sha256(hashlib.sha256(out_data).digest()).digest()

    witness_items = []
    for txid_b, vout_b, value in inputs_data:
        preimage = (
            struct.pack("<I", 2) +
            hashPrevouts +
            hashSequence +
            txid_b + vout_b +
            scriptcode +
            struct.pack("<Q", value) +
            struct.pack("<I", 0xfffffffe) +
            hashOutputs +
            locktime +
            struct.pack("<I", 1)   # SIGHASH_ALL
        )
        sighash = hashlib.sha256(hashlib.sha256(preimage).digest()).digest()
        sig     = _sign_ecdsa(privkey, sighash) + b"\x01"
        witness_items.append(sig)

    # Assemble witness
    witness_raw = b""
    for sig in witness_items:
        witness_raw += bytes([2])            # 2 items: sig + pubkey
        witness_raw += bytes([len(sig)]) + sig
        witness_raw += bytes([len(pubkey)]) + pubkey

    raw += witness_raw + locktime
    return raw.hex()

# ══════════════════════════════════════════════════════════════
#  BINANCE DEPOSIT ADDRESS FETCHER
# ══════════════════════════════════════════════════════════════
def fetch_binance_deposit_address(api_key, api_secret, coin, network=None):
    """
    Fetch deposit address for a coin from Binance using existing API keys.
    coin:    e.g. "BTC", "DASH", "LTC", "ETH", "XMR"
    network: e.g. "BTC", "DASH", "ETH", "XMR" — defaults to coin symbol
    Returns dict: {"address": str, "tag": str_or_None, "coin": str, "network": str}
    """
    import time as _t
    import hmac  as _hmac
    import hashlib as _hl

    if network is None:
        network = coin

    params = {
        "coin":      coin,
        "network":   network,
        "timestamp": str(int(_t.time() * 1000)),
        "recvWindow": "5000",
    }
    qs  = _urlparse.urlencode(params)
    sig = _hmac.new(
        api_secret.encode("utf-8"),
        qs.encode("utf-8"),
        _hl.sha256
    ).hexdigest()
    url = "https://api.binance.com/sapi/v1/capital/deposit/address?" + qs + "&signature=" + sig
    req = _urlreq.Request(url)
    req.add_header("X-MBX-APIKEY", api_key)
    req.add_header("User-Agent", "UMP-Wallet/4.0")
    try:
        with _urlreq.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            return {
                "success": True,
                "address": data.get("address", ""),
                "tag":     data.get("tag", None),
                "coin":    coin,
                "network": network,
            }
    except _urlerr.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            err = json.loads(body)
            msg = err.get("msg", body)
        except Exception:
            msg = body
        return {"success": False, "error": msg, "coin": coin}
    except Exception as e:
        return {"success": False, "error": str(e), "coin": coin}

# ══════════════════════════════════════════════════════════════
#  BINANCE WITHDRAWAL (transfer from internal wallet TO exchange)
# ══════════════════════════════════════════════════════════════
def binance_withdraw(api_key, api_secret, coin, address, amount, network=None, address_tag=None):
    """
    Initiate a Binance withdrawal (from Binance account to external address).
    This is used to send from Binance to our internal wallet.
    coin:     "BTC" / "DASH" etc.
    address:  destination wallet address
    amount:   float
    Returns: {"success": bool, "id": str_or_None, "error": str_or_None}
    """
    import time as _t
    import hmac  as _hmac
    import hashlib as _hl

    if network is None:
        network = coin

    params = {
        "coin":      coin,
        "address":   address,
        "amount":    str(amount),
        "network":   network,
        "timestamp": str(int(_t.time() * 1000)),
        "recvWindow": "5000",
    }
    if address_tag:
        params["addressTag"] = address_tag

    qs  = _urlparse.urlencode(params)
    sig = _hmac.new(
        api_secret.encode("utf-8"),
        qs.encode("utf-8"),
        _hl.sha256
    ).hexdigest()
    url  = "https://api.binance.com/sapi/v1/capital/withdraw/apply"
    body = (qs + "&signature=" + sig).encode("utf-8")
    req  = _urlreq.Request(url, data=body, method="POST")
    req.add_header("X-MBX-APIKEY", api_key)
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    req.add_header("User-Agent", "UMP-Wallet/4.0")
    try:
        with _urlreq.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            return {"success": True, "id": data.get("id"), "error": None}
    except _urlerr.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            err = json.loads(body)
            msg = err.get("msg", body)
        except Exception:
            msg = body
        return {"success": False, "id": None, "error": msg}
    except Exception as e:
        return {"success": False, "id": None, "error": str(e)}



# =============================================================================
# MODULE: wallet_api.py
# =============================================================================

# wallet_api.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Flask Blueprint — Internal HD Wallet API
# All routes for balances, addresses, transfers, broadcast, Binance integration
# Python 3.6+ compatible — no f-strings — no walrus

from __future__ import print_function
import os
import json
import time
import threading

from flask import Blueprint, request, jsonify, session, render_template

from wallet_core import (
    create_wallet, restore_wallet, validate_mnemonic,
    fetch_all_balances, fetch_prices,
    build_and_sign_btc_tx, broadcast_btc_tx,
    broadcast_ltc_tx, broadcast_dash_tx,
    fetch_binance_deposit_address, binance_withdraw,
    SUPPORTED_COINS,
)
from wallet_db import (
    init_wallet_db, save_wallet, load_wallet_addresses,
    load_privkey, load_mnemonic, list_wallets, wallet_exists, delete_wallet,
    cache_balance, get_cached_balances, cache_prices, get_cached_prices,
    record_transaction, update_tx_status, get_transactions,
    record_mining_credit, get_mining_credits, get_total_mined,
    save_address, get_address_book, delete_address,
    get_portfolio_summary,
)

wallet_bp = Blueprint("wallet", __name__, url_prefix="/wallet")

# ── Session key for active wallet ─────────────────────────────
WALLET_SESSION_KEY = "active_wallet"

def _active_wallet():
    return session.get(WALLET_SESSION_KEY, "default")

def _require_wallet(name=None):
    wname = name or _active_wallet()
    if not wallet_exists(wname):
        return None, jsonify({"error": "No wallet found. Create or restore a wallet first."}), 404
    return wname, None, None

def _get_binance_keys():
    """Pull Binance API key/secret from the active mining profile."""
    try:
        import sqlite3, os
        db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "miner.db")
        conn = sqlite3.connect(db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT binance_api_key, binance_api_secret
            FROM profiles
            WHERE binance_api_key != '' AND binance_api_secret != ''
            ORDER BY updated_at DESC LIMIT 1
        """)
        row = c.fetchone()
        conn.close()
        if row:
            return row["binance_api_key"], row["binance_api_secret"]
    except Exception:
        pass
    return None, None

# ── Background refresh thread ─────────────────────────────────
_refresh_lock   = threading.Lock()
_refresh_active = False

def _refresh_balances_background(wallet_name):
    """Fetch live balances and prices in a background thread, store in cache."""
    global _refresh_active
    with _refresh_lock:
        if _refresh_active:
            return
        _refresh_active = True
    try:
        addrs  = load_wallet_addresses(wallet_name)
        w_data = {"wallets": {}}
        for a in addrs:
            w_data["wallets"][a["coin"]] = {"address": a["address"]}

        balances = fetch_all_balances(w_data)
        prices   = fetch_prices(list(balances.keys()))
        cache_prices(prices)

        for coin, info in balances.items():
            price = prices.get(coin, 0.0)
            cache_balance(wallet_name, coin, info.get("balance"), price)
    except Exception as e:
        print("[wallet] Balance refresh error: " + str(e))
    finally:
        with _refresh_lock:
            _refresh_active = False

def trigger_refresh(wallet_name):
    t = threading.Thread(target=_refresh_balances_background,
                         args=(wallet_name,), daemon=True)
    t.start()

# ══════════════════════════════════════════════════════════════
#  WALLET MANAGEMENT ROUTES
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/", methods=["GET"])
def wallet_dashboard():
    """Serve the wallet UI page."""
    wallets = list_wallets()
    active  = _active_wallet()
    return render_template("wallet_ui.html",
                           wallets=wallets,
                           active_wallet=active)

@wallet_bp.route("/api/create", methods=["POST"])
def api_create_wallet():
    """
    POST /wallet/api/create
    Body: { wallet_name, password, confirm_password }
    Creates a new HD wallet, returns public data (NO private keys in response).
    """
    data     = request.get_json(silent=True) or request.form
    wname    = (data.get("wallet_name") or "default").strip()
    password = (data.get("password") or "").strip()
    confirm  = (data.get("confirm_password") or "").strip()

    if not wname:
        return jsonify({"error": "wallet_name is required"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400
    if password != confirm:
        return jsonify({"error": "Passwords do not match"}), 400
    if wallet_exists(wname):
        return jsonify({"error": "Wallet '" + wname + "' already exists"}), 409

    try:
        wallet_data = create_wallet()
        save_wallet(wname, wallet_data, password)
        session[WALLET_SESSION_KEY] = wname

        # Return mnemonic ONCE — user must write it down
        coins_public = {}
        for coin, w in wallet_data["wallets"].items():
            coins_public[coin] = {
                "address": w.get("address", ""),
                "address_legacy": w.get("address_legacy", ""),
                "network": w.get("network", ""),
                "path":    w.get("path", ""),
            }

        return jsonify({
            "success":      True,
            "wallet_name":  wname,
            "mnemonic":     wallet_data["mnemonic"],
            "mnemonic_warning": (
                "WRITE THIS DOWN NOW. This is the ONLY time it is shown. "
                "Anyone with this phrase controls all funds."
            ),
            "coins":        coins_public,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@wallet_bp.route("/api/restore", methods=["POST"])
def api_restore_wallet():
    """
    POST /wallet/api/restore
    Body: { wallet_name, mnemonic, password, confirm_password, passphrase? }
    Restore an existing HD wallet from mnemonic.
    """
    data       = request.get_json(silent=True) or request.form
    wname      = (data.get("wallet_name") or "restored").strip()
    mnemonic   = (data.get("mnemonic") or "").strip().lower()
    password   = (data.get("password") or "").strip()
    confirm    = (data.get("confirm_password") or "").strip()
    passphrase = (data.get("passphrase") or "").strip()

    if not mnemonic:
        return jsonify({"error": "Mnemonic is required"}), 400
    if not validate_mnemonic(mnemonic):
        return jsonify({"error": "Invalid mnemonic — check all words are valid BIP39 words"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400
    if password != confirm:
        return jsonify({"error": "Passwords do not match"}), 400
    if wallet_exists(wname):
        return jsonify({"error": "Wallet '" + wname + "' already exists. Use a different name."}), 409

    try:
        wallet_data = restore_wallet(mnemonic, passphrase)
        save_wallet(wname, wallet_data, password)
        session[WALLET_SESSION_KEY] = wname

        coins_public = {}
        for coin, w in wallet_data["wallets"].items():
            coins_public[coin] = {
                "address": w.get("address", ""),
                "network": w.get("network", ""),
            }

        return jsonify({
            "success":     True,
            "wallet_name": wname,
            "coins":       coins_public,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@wallet_bp.route("/api/select", methods=["POST"])
def api_select_wallet():
    """Switch active wallet."""
    data  = request.get_json(silent=True) or request.form
    wname = (data.get("wallet_name") or "").strip()
    if not wallet_exists(wname):
        return jsonify({"error": "Wallet not found"}), 404
    session[WALLET_SESSION_KEY] = wname
    return jsonify({"success": True, "active_wallet": wname})

@wallet_bp.route("/api/list", methods=["GET"])
def api_list_wallets():
    return jsonify({"wallets": list_wallets(), "active": _active_wallet()})

@wallet_bp.route("/api/delete", methods=["POST"])
def api_delete_wallet():
    data  = request.get_json(silent=True) or request.form
    wname = (data.get("wallet_name") or "").strip()
    if not wallet_exists(wname):
        return jsonify({"error": "Wallet not found"}), 404
    delete_wallet(wname)
    if session.get(WALLET_SESSION_KEY) == wname:
        session.pop(WALLET_SESSION_KEY, None)
    return jsonify({"success": True})

# ══════════════════════════════════════════════════════════════
#  PORTFOLIO & BALANCES
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/portfolio", methods=["GET"])
def api_portfolio():
    """
    GET /wallet/api/portfolio
    Returns full portfolio: balances + USD values + mining totals + prices.
    """
    wname = _active_wallet()
    if not wallet_exists(wname):
        return jsonify({"portfolio": None, "wallets": list_wallets()})

    portfolio = get_portfolio_summary(wname)
    return jsonify(portfolio)

@wallet_bp.route("/api/balances", methods=["GET"])
def api_balances():
    """
    GET /wallet/api/balances?refresh=1
    Returns cached balances. Pass refresh=1 to trigger live fetch.
    """
    wname   = _active_wallet()
    refresh = request.args.get("refresh", "0") in ("1", "true")

    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    if refresh:
        trigger_refresh(wname)
        time.sleep(0.1)  # brief yield so thread can start

    balances = get_cached_balances(wname)
    prices   = get_cached_prices()
    return jsonify({
        "wallet_name": wname,
        "balances":    balances,
        "prices":      prices,
        "refreshing":  refresh,
    })

@wallet_bp.route("/api/prices", methods=["GET"])
def api_prices():
    """GET /wallet/api/prices — live coin prices (CoinGecko, cached 2 min)."""
    prices = get_cached_prices()
    if not prices:
        prices = fetch_prices()
        if prices:
            cache_prices(prices)
    return jsonify({"prices": prices, "ts": int(time.time())})

# ══════════════════════════════════════════════════════════════
#  ADDRESSES
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/addresses", methods=["GET"])
def api_addresses():
    """GET /wallet/api/addresses — all coin addresses for active wallet."""
    wname = _active_wallet()
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404
    coins = load_wallet_addresses(wname)
    return jsonify({"wallet_name": wname, "coins": coins})

@wallet_bp.route("/api/address/<coin>", methods=["GET"])
def api_address(coin):
    """GET /wallet/api/address/BTC — receive address for specific coin."""
    coin  = coin.upper()
    wname = _active_wallet()
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404
    addrs = load_wallet_addresses(wname)
    for a in addrs:
        if a["coin"] == coin:
            return jsonify({"coin": coin, "address": a["address"],
                            "address_legacy": a.get("address_legacy", ""),
                            "network": a.get("network", "")})
    return jsonify({"error": "Coin not found: " + coin}), 404

# ══════════════════════════════════════════════════════════════
#  BINANCE DEPOSIT ADDRESS
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/binance_deposit/<coin>", methods=["GET"])
def api_binance_deposit(coin):
    """
    GET /wallet/api/binance_deposit/DASH
    Fetch Binance deposit address for a coin using saved API keys.
    This is the address to send mined funds TO Binance.
    """
    coin    = coin.upper()
    network = request.args.get("network", coin)
    api_key, api_secret = _get_binance_keys()

    if not api_key or not api_secret:
        return jsonify({
            "error": "No Binance API keys configured. Add them in Setup → Binance section."
        }), 400

    result = fetch_binance_deposit_address(api_key, api_secret, coin, network)
    if result.get("success"):
        # Auto-save to address book
        label = "Binance " + coin + " Deposit"
        save_address(label, coin, result["address"],
                     result.get("tag", ""), network, "binance")
    return jsonify(result)

# ══════════════════════════════════════════════════════════════
#  TRANSFER / WITHDRAW
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/transfer", methods=["POST"])
def api_transfer():
    """
    POST /wallet/api/transfer
    Send funds from internal wallet to external address or Binance.
    Body: {
        coin, to_address, amount, password,
        fee_sat (optional, BTC/LTC/DASH),
        note (optional)
    }
    Requires wallet password to decrypt private key.
    """
    data       = request.get_json(silent=True) or request.form
    coin       = (data.get("coin") or "").upper().strip()
    to_address = (data.get("to_address") or "").strip()
    password   = (data.get("password") or "").strip()
    note       = (data.get("note") or "").strip()
    wname      = _active_wallet()

    try:
        amount = float(data.get("amount") or 0)
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400

    try:
        fee_sat = int(data.get("fee_sat") or 1000)
    except (ValueError, TypeError):
        fee_sat = 1000

    if not coin:
        return jsonify({"error": "coin is required"}), 400
    if not to_address:
        return jsonify({"error": "to_address is required"}), 400
    if not password:
        return jsonify({"error": "password is required to decrypt private key"}), 400
    if amount <= 0:
        return jsonify({"error": "amount must be greater than zero"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    # Get from_address
    addrs     = load_wallet_addresses(wname)
    from_addr = None
    for a in addrs:
        if a["coin"] == coin:
            from_addr = a["address"]
            break
    if not from_addr:
        return jsonify({"error": "No " + coin + " wallet found"}), 404

    # Decrypt private key
    try:
        privkey_hex = load_privkey(wname, coin, password)
    except ValueError as e:
        return jsonify({"error": str(e)}), 401

    # Build, sign, broadcast
    try:
        if coin == "BTC":
            amount_sat = int(amount * 1e8)
            raw_hex    = build_and_sign_btc_tx(privkey_hex, from_addr, to_address,
                                               amount_sat, fee_sat)
            result     = broadcast_btc_tx(raw_hex)

        elif coin == "LTC":
            # LTC uses same UTXO model — simplified broadcast (user builds tx externally)
            # For full LTC signing we'd need UTXO fetch + same secp256k1 flow
            # Return the signed address data so user can use Electrum-LTC to sign
            result = {
                "success": False,
                "error":   (
                    "LTC on-chain signing requires UTXO fetch from Sochain. "
                    "Use Electrum-LTC with this private key to send: " +
                    privkey_hex[:8] + "...  OR transfer via Binance API below."
                ),
            }

        elif coin == "DASH":
            # DASH Insight UTXO broadcast
            # For a full implementation we'd need UTXO fetch from Insight
            # Return guidance for now — Binance transfer path is recommended
            result = {
                "success": False,
                "error":   (
                    "DASH direct broadcast requires Insight UTXO fetch. "
                    "Use 'Transfer to Exchange' to send DASH via Binance API, "
                    "or import private key into Dash Electrum."
                ),
            }

        elif coin == "ETH":
            # ETH requires nonce + gas price fetch — use Etherscan for this
            result = {
                "success": False,
                "error":   (
                    "ETH transfers require nonce + gas price. "
                    "Import private key into MetaMask or use Binance API transfer."
                ),
            }

        elif coin == "XMR":
            result = {
                "success": False,
                "error":   (
                    "XMR transactions require a running Monero daemon (monerod). "
                    "Import spend key into Monero CLI wallet to send funds."
                ),
            }
        else:
            result = {"success": False, "error": "Unsupported coin: " + coin}

    except Exception as e:
        return jsonify({"error": "Transaction failed: " + str(e)}), 500

    # Record in transaction history
    status = "broadcast" if result.get("success") else "failed"
    tx_id  = record_transaction(
        wname, coin, "send", "out",
        from_addr, to_address, amount, fee_sat / 1e8 if coin == "BTC" else 0,
        result.get("txid", ""), status, note, "manual"
    )

    return jsonify({
        "success":    result.get("success"),
        "txid":       result.get("txid"),
        "tx_id":      tx_id,
        "error":      result.get("error"),
        "from":       from_addr,
        "to":         to_address,
        "amount":     amount,
        "coin":       coin,
    })

@wallet_bp.route("/api/transfer_to_exchange", methods=["POST"])
def api_transfer_to_exchange():
    """
    POST /wallet/api/transfer_to_exchange
    Initiate a Binance withdrawal FROM Binance TO our internal wallet address,
    OR use Binance API to move funds from Binance account to external address.
    Body: {
        coin, amount, direction,
        network (optional),
        address_tag (optional, for XMR/XRP)
    }
    direction: 'to_internal' (Binance -> internal wallet)
               'to_external' (Binance -> any address)
    For direction='to_external': also pass { to_address }
    """
    data      = request.get_json(silent=True) or request.form
    coin      = (data.get("coin") or "").upper().strip()
    network   = (data.get("network") or coin).strip()
    direction = (data.get("direction") or "to_internal").strip()
    note      = (data.get("note") or "").strip()
    wname     = _active_wallet()

    try:
        amount = float(data.get("amount") or 0)
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400

    if not coin:
        return jsonify({"error": "coin is required"}), 400
    if amount <= 0:
        return jsonify({"error": "amount must be greater than zero"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    api_key, api_secret = _get_binance_keys()
    if not api_key or not api_secret:
        return jsonify({
            "error": "Binance API keys not configured. Add them in Setup → Binance."
        }), 400

    # Determine destination address
    if direction == "to_internal":
        # Find our internal wallet address for this coin
        addrs     = load_wallet_addresses(wname)
        to_addr   = None
        for a in addrs:
            if a["coin"] == coin:
                to_addr = a["address"]
                break
        if not to_addr:
            return jsonify({"error": "No internal " + coin + " wallet found"}), 404
        label = "Internal UMP Wallet"
    else:
        to_addr = (data.get("to_address") or "").strip()
        if not to_addr:
            return jsonify({"error": "to_address is required for external transfer"}), 400
        label = "External transfer"

    address_tag = (data.get("address_tag") or "").strip() or None

    result = binance_withdraw(api_key, api_secret, coin, to_addr, amount, network, address_tag)

    # Record transaction
    status = "pending" if result.get("success") else "failed"
    tx_id  = record_transaction(
        wname, coin, "transfer_to_exchange" if direction != "to_internal" else "transfer_from_exchange",
        "in" if direction == "to_internal" else "out",
        "Binance Account", to_addr, amount, 0,
        result.get("id", ""), status, note, "binance_transfer"
    )

    return jsonify({
        "success":    result.get("success"),
        "binance_id": result.get("id"),
        "tx_id":      tx_id,
        "error":      result.get("error"),
        "coin":       coin,
        "amount":     amount,
        "to_address": to_addr,
        "direction":  direction,
    })

# ══════════════════════════════════════════════════════════════
#  TRANSACTION HISTORY
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/transactions", methods=["GET"])
def api_transactions():
    """GET /wallet/api/transactions?coin=BTC&limit=50"""
    wname = _active_wallet()
    coin  = request.args.get("coin", "").upper() or None
    limit = int(request.args.get("limit", 100))
    txs   = get_transactions(wname, coin, limit)
    return jsonify({"transactions": txs, "wallet_name": wname})

@wallet_bp.route("/api/mining_credits", methods=["GET"])
def api_mining_credits():
    """GET /wallet/api/mining_credits — mining attribution history."""
    wname = _active_wallet()
    coin  = request.args.get("coin", "").upper() or None
    rows  = get_mining_credits(wname, coin)
    total = get_total_mined(wname)
    return jsonify({"credits": rows, "totals": total, "wallet_name": wname})

# ══════════════════════════════════════════════════════════════
#  ADDRESS BOOK
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/address_book", methods=["GET"])
def api_address_book():
    coin = request.args.get("coin", "").upper() or None
    return jsonify({"addresses": get_address_book(coin)})

@wallet_bp.route("/api/address_book/save", methods=["POST"])
def api_save_address():
    data    = request.get_json(silent=True) or request.form
    label   = (data.get("label") or "").strip()
    coin    = (data.get("coin") or "").upper().strip()
    address = (data.get("address") or "").strip()
    tag     = (data.get("address_tag") or "").strip()
    network = (data.get("network") or coin).strip()
    atype   = (data.get("type") or "external").strip()

    if not label or not coin or not address:
        return jsonify({"error": "label, coin, and address are required"}), 400

    save_address(label, coin, address, tag, network, atype)
    return jsonify({"success": True})

@wallet_bp.route("/api/address_book/delete", methods=["POST"])
def api_delete_address():
    data = request.get_json(silent=True) or request.form
    try:
        addr_id = int(data.get("id", 0))
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid id"}), 400
    delete_address(addr_id)
    return jsonify({"success": True})

# ══════════════════════════════════════════════════════════════
#  MINING CREDIT RECORD (called by miner_manager on session end)
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/record_mining", methods=["POST"])
def api_record_mining():
    """
    POST /wallet/api/record_mining
    Internal route called by miner manager to attribute mined funds to wallet.
    Body: { coin, amount, amount_usd, session_id, profile_name, pool, algo }
    """
    data         = request.get_json(silent=True) or request.form
    wname        = _active_wallet()
    coin         = (data.get("coin") or "").upper()
    profile_name = data.get("profile_name", "")
    pool         = data.get("pool", "")
    algo         = data.get("algo", "")

    try:
        amount     = float(data.get("amount") or 0)
        amount_usd = float(data.get("amount_usd") or 0)
        session_id = int(data.get("session_id") or 0) or None
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid numeric values"}), 400

    if not coin or amount <= 0:
        return jsonify({"error": "coin and positive amount required"}), 400
    if not wallet_exists(wname):
        return jsonify({"success": True, "skipped": "no wallet configured"})

    record_mining_credit(wname, coin, amount, amount_usd,
                         session_id, profile_name, pool, algo)
    return jsonify({"success": True})

# ══════════════════════════════════════════════════════════════
#  REVEAL KEYS (password required)
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/reveal_mnemonic", methods=["POST"])
def api_reveal_mnemonic():
    """
    POST /wallet/api/reveal_mnemonic
    Body: { password }
    Returns mnemonic phrase. Requires correct wallet password.
    """
    data     = request.get_json(silent=True) or request.form
    password = (data.get("password") or "").strip()
    wname    = _active_wallet()

    if not password:
        return jsonify({"error": "Password is required"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    try:
        mnemonic = load_mnemonic(wname, password)
        return jsonify({
            "success":  True,
            "mnemonic": mnemonic,
            "warning":  "Never share this phrase. Store it offline and securely.",
        })
    except ValueError:
        return jsonify({"error": "Wrong password"}), 401

@wallet_bp.route("/api/reveal_privkey", methods=["POST"])
def api_reveal_privkey():
    """
    POST /wallet/api/reveal_privkey
    Body: { coin, password }
    Returns private key hex. Requires correct wallet password.
    """
    data     = request.get_json(silent=True) or request.form
    coin     = (data.get("coin") or "").upper().strip()
    password = (data.get("password") or "").strip()
    wname    = _active_wallet()

    if not coin or not password:
        return jsonify({"error": "coin and password are required"}), 400
    if not wallet_exists(wname):
        return jsonify({"error": "No active wallet"}), 404

    try:
        key = load_privkey(wname, coin, password)
        return jsonify({
            "success":  True,
            "coin":     coin,
            "privkey":  key,
            "warning":  "Never share this key. Import into a wallet to use it.",
        })
    except ValueError:
        return jsonify({"error": "Wrong password"}), 401

# ══════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════
#  ENFORCEMENT STATUS (called by dashboard to show lock status)
# ══════════════════════════════════════════════════════════════

@wallet_bp.route("/api/enforcement_status", methods=["GET"])
def api_enforcement_status():
    """
    GET /wallet/api/enforcement_status
    Returns whether the internal wallet enforcer is active and which
    addresses are locked in as payout destinations for each coin.
    Dashboard uses this to show the green lock icon.
    Uses wallet_enforcer._resolve_wallet_name() — safe outside request context.
    """
    try:
        from wallet_enforcer import get_internal_address, _resolve_wallet_name
    except ImportError:
        return jsonify({
            "enforcer_active": False,
            "warning": "wallet_enforcer.py missing — pool payout addresses are NOT enforced!",
            "addresses": {}
        }), 200

    # Use enforcer's resolver — works outside Flask session context
    wname = _resolve_wallet_name()
    if not wname:
        return jsonify({
            "enforcer_active":    True,
            "wallet_configured":  False,
            "warning": "No wallet configured. Mining is BLOCKED until you create a wallet at /wallet/.",
            "addresses": {}
        }), 200

    coins_to_check = ["BTC", "ETH", "XMR", "LTC", "DASH"]
    addresses = {}
    for coin in coins_to_check:
        addr, used_coin = get_internal_address(coin)
        if addr:
            addresses[coin] = {
                "address":   addr,
                "truncated": addr[:12] + "..." + addr[-6:],
                "coin_used": used_coin
            }

    return jsonify({
        "enforcer_active":   True,
        "wallet_configured": True,
        "wallet_name":       wname,
        "locked_message":    "All pool payouts are locked to your internal wallet. "
                             "Funds are released to Binance only via manual transfer.",
        "addresses":         addresses
    }), 200

# ══════════════════════════════════════════════════════════════
#  REGISTER WITH FLASK APP
# ══════════════════════════════════════════════════════════════

def register_wallet(app):
    """Call this from universal_miner.py to wire up the wallet."""
    init_wallet_db()
    app.register_blueprint(wallet_bp)
    print("[wallet] HD Wallet API registered at /wallet")



# =============================================================================
# MODULE: wallet_db.py
# =============================================================================

# wallet_db.py — Universal Miner Pro ULTIMATE EDITION v4.0
# Encrypted Wallet Keystore · Balance Cache · TX History · Mining Attribution
# AES-256-GCM encryption for private keys and mnemonic
# Python 3.6+ compatible — no f-strings — no walrus

from __future__ import print_function
import os
import json
import time
import sqlite3
import hashlib
import secrets
import threading

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "miner.db")
_db_lock = threading.Lock()

# ══════════════════════════════════════════════════════════════
#  AES-256-GCM ENCRYPTION
# ══════════════════════════════════════════════════════════════
def _derive_key(password, salt):
    """Derive 32-byte AES key from password using PBKDF2-HMAC-SHA256."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200000, 32)

def encrypt(plaintext, password):
    """
    Encrypt plaintext string with AES-256-GCM.
    Returns hex string: salt(32) + nonce(12) + ciphertext+tag
    """
    salt      = secrets.token_bytes(32)
    nonce     = secrets.token_bytes(12)
    key       = _derive_key(password, salt)
    aesgcm    = AESGCM(key)
    ct        = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return (salt + nonce + ct).hex()

def decrypt(hex_blob, password):
    """
    Decrypt hex blob produced by encrypt().
    Returns plaintext string. Raises ValueError on wrong password.
    """
    raw    = bytes.fromhex(hex_blob)
    salt   = raw[:32]
    nonce  = raw[32:44]
    ct     = raw[44:]
    key    = _derive_key(password, salt)
    aesgcm = AESGCM(key)
    try:
        pt = aesgcm.decrypt(nonce, ct, None)
        return pt.decode("utf-8")
    except Exception:
        raise ValueError("Decryption failed — wrong password or corrupted data")

# ══════════════════════════════════════════════════════════════
#  DB SCHEMA INIT
# ══════════════════════════════════════════════════════════════
WALLET_TABLES = [
    # Master keystore — one row per wallet
    """
    CREATE TABLE IF NOT EXISTS wallet_keystore (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT UNIQUE NOT NULL,
        encrypted_mnemonic TEXT NOT NULL,
        salt_hint     TEXT DEFAULT '',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
    # Per-coin wallet records
    """
    CREATE TABLE IF NOT EXISTS wallet_coins (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        address       TEXT NOT NULL,
        address_legacy TEXT DEFAULT '',
        address_bech32 TEXT DEFAULT '',
        pubkey_hex    TEXT DEFAULT '',
        encrypted_privkey TEXT DEFAULT '',
        network       TEXT DEFAULT '',
        derivation_path TEXT DEFAULT '',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(wallet_name, coin)
    )
    """,
    # Balance cache — updated on-demand
    """
    CREATE TABLE IF NOT EXISTS wallet_balances (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        balance       REAL DEFAULT 0,
        balance_usd   REAL DEFAULT 0,
        last_fetched  DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(wallet_name, coin)
    )
    """,
    # Transaction history
    """
    CREATE TABLE IF NOT EXISTS wallet_transactions (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        tx_type       TEXT NOT NULL,
        direction     TEXT NOT NULL,
        from_address  TEXT DEFAULT '',
        to_address    TEXT DEFAULT '',
        amount        REAL DEFAULT 0,
        fee           REAL DEFAULT 0,
        txid          TEXT DEFAULT '',
        status        TEXT DEFAULT 'pending',
        note          TEXT DEFAULT '',
        source        TEXT DEFAULT 'manual',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        confirmed_at  DATETIME
    )
    """,
    # Mining attribution — links sessions to wallet credits
    """
    CREATE TABLE IF NOT EXISTS wallet_mining_credits (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_name   TEXT NOT NULL,
        coin          TEXT NOT NULL,
        session_id    INTEGER,
        profile_name  TEXT DEFAULT '',
        pool          TEXT DEFAULT '',
        algo          TEXT DEFAULT '',
        amount        REAL DEFAULT 0,
        amount_usd    REAL DEFAULT 0,
        credited_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
    # Saved external addresses (exchanges, cold wallets)
    """
    CREATE TABLE IF NOT EXISTS wallet_address_book (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        label         TEXT NOT NULL,
        coin          TEXT NOT NULL,
        address       TEXT NOT NULL,
        address_tag   TEXT DEFAULT '',
        network       TEXT DEFAULT '',
        type          TEXT DEFAULT 'external',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(coin, address)
    )
    """,
    # Price cache
    """
    CREATE TABLE IF NOT EXISTS wallet_price_cache (
        coin          TEXT PRIMARY KEY,
        price_usd     REAL DEFAULT 0,
        fetched_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
]

def init_wallet_db():
    """Create all wallet tables if they don't exist."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c = conn.cursor()
        for sql in WALLET_TABLES:
            c.execute(sql)
        conn.commit()
        conn.close()

# ══════════════════════════════════════════════════════════════
#  WALLET KEYSTORE
# ══════════════════════════════════════════════════════════════
def save_wallet(wallet_name, wallet_data, password):
    """
    Store a new wallet securely.
    wallet_data: dict from wallet_core.create_wallet()
    password: encryption password chosen by user
    """
    mnemonic       = wallet_data["mnemonic"]
    enc_mnemonic   = encrypt(mnemonic, password)

    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        c    = conn.cursor()

        c.execute("""
            INSERT OR REPLACE INTO wallet_keystore
            (wallet_name, encrypted_mnemonic, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        """, (wallet_name, enc_mnemonic))

        # Store per-coin records
        for coin, w in wallet_data["wallets"].items():
            priv_enc = encrypt(w.get("privkey", w.get("spend_key", "")), password)
            c.execute("""
                INSERT OR REPLACE INTO wallet_coins
                (wallet_name, coin, address, address_legacy, address_bech32,
                 pubkey_hex, encrypted_privkey, network, derivation_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                wallet_name,
                coin,
                w.get("address", ""),
                w.get("address_legacy", ""),
                w.get("address_bech32", ""),
                w.get("pubkey", ""),
                priv_enc,
                w.get("network", ""),
                w.get("path", ""),
            ))

        conn.commit()
        conn.close()

def load_wallet_addresses(wallet_name):
    """
    Load wallet coin records (public data only — no private keys).
    Returns list of coin dicts.
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT coin, address, address_legacy, address_bech32,
                   pubkey_hex, network, derivation_path
            FROM wallet_coins WHERE wallet_name=?
            ORDER BY coin
        """, (wallet_name,))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

def load_privkey(wallet_name, coin, password):
    """
    Load and decrypt private key for a specific coin.
    Returns hex string or raises ValueError on bad password.
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            SELECT encrypted_privkey FROM wallet_coins
            WHERE wallet_name=? AND coin=?
        """, (wallet_name, coin))
        row = c.fetchone()
        conn.close()
    if not row:
        raise ValueError("No wallet found for " + wallet_name + "/" + coin)
    return decrypt(row[0], password)

def load_mnemonic(wallet_name, password):
    """Load and decrypt the mnemonic phrase. Returns string."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("SELECT encrypted_mnemonic FROM wallet_keystore WHERE wallet_name=?",
                  (wallet_name,))
        row = c.fetchone()
        conn.close()
    if not row:
        raise ValueError("No wallet found: " + wallet_name)
    return decrypt(row[0], password)

def list_wallets():
    """Return list of wallet names."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("SELECT wallet_name, created_at FROM wallet_keystore ORDER BY created_at DESC")
        rows = [{"wallet_name": r[0], "created_at": r[1]} for r in c.fetchall()]
        conn.close()
        return rows

def wallet_exists(wallet_name):
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("SELECT 1 FROM wallet_keystore WHERE wallet_name=?", (wallet_name,))
        exists = c.fetchone() is not None
        conn.close()
        return exists

def delete_wallet(wallet_name):
    """Permanently delete wallet and all associated data."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        for table in ("wallet_keystore", "wallet_coins", "wallet_balances",
                      "wallet_transactions", "wallet_mining_credits"):
            c.execute("DELETE FROM " + table + " WHERE wallet_name=?", (wallet_name,))
        # Note: wallet_address_book and wallet_price_cache are global tables
        # (no wallet_name column) — they are intentionally shared and not deleted here.
        conn.commit()
        conn.close()

# ══════════════════════════════════════════════════════════════
#  BALANCE CACHE
# ══════════════════════════════════════════════════════════════
BALANCE_TTL = 120   # seconds before balance is considered stale

def cache_balance(wallet_name, coin, balance, price_usd=0.0):
    """Store fetched balance in cache."""
    balance_usd = (balance or 0) * price_usd
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO wallet_balances
            (wallet_name, coin, balance, balance_usd, last_fetched)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (wallet_name, coin, balance or 0, balance_usd))
        conn.commit()
        conn.close()

def get_cached_balances(wallet_name, max_age=BALANCE_TTL):
    """
    Return cached balances. Returns list of dicts.
    Entries older than max_age seconds are flagged as stale.
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        c.execute("""
            SELECT coin, balance, balance_usd,
                   CAST((julianday('now') - julianday(last_fetched)) * 86400 AS INTEGER)
                   AS age_seconds
            FROM wallet_balances
            WHERE wallet_name=?
            ORDER BY coin
        """, (wallet_name,))
        rows = []
        for r in c.fetchall():
            d = dict(r)
            d["stale"] = d["age_seconds"] > max_age
            rows.append(d)
        conn.close()
        return rows

# ══════════════════════════════════════════════════════════════
#  PRICE CACHE
# ══════════════════════════════════════════════════════════════
PRICE_TTL = 120   # seconds

def cache_prices(prices):
    """Store fetched prices dict {coin: usd_price}."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        for coin, price in prices.items():
            c.execute("""
                INSERT OR REPLACE INTO wallet_price_cache (coin, price_usd, fetched_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, (coin, price))
        conn.commit()
        conn.close()

def get_cached_prices(max_age=PRICE_TTL):
    """Return cached prices dict {coin: usd_price}. Returns empty dict if all stale."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            SELECT coin, price_usd,
                   CAST((julianday('now') - julianday(fetched_at)) * 86400 AS INTEGER)
                   AS age_seconds
            FROM wallet_price_cache
        """)
        prices = {}
        for row in c.fetchall():
            if row[2] <= max_age:
                prices[row[0]] = row[1]
        conn.close()
        return prices

# ══════════════════════════════════════════════════════════════
#  TRANSACTION HISTORY
# ══════════════════════════════════════════════════════════════
def record_transaction(wallet_name, coin, tx_type, direction,
                       from_addr, to_addr, amount, fee=0.0,
                       txid="", status="pending", note="", source="manual"):
    """
    Record a transaction in history.
    tx_type:   'send' | 'receive' | 'transfer_to_exchange' | 'transfer_from_exchange'
    direction: 'out' | 'in'
    source:    'manual' | 'mining' | 'binance_transfer'
    """
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT INTO wallet_transactions
            (wallet_name, coin, tx_type, direction, from_address, to_address,
             amount, fee, txid, status, note, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (wallet_name, coin, tx_type, direction,
              from_addr, to_addr, amount, fee,
              txid, status, note, source))
        tx_id = c.lastrowid
        conn.commit()
        conn.close()
    return tx_id

def update_tx_status(tx_id, status, txid=None, confirmed_at=None):
    """Update transaction status (pending → confirmed / failed)."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        if txid and confirmed_at:
            c.execute("""
                UPDATE wallet_transactions
                SET status=?, txid=?, confirmed_at=?
                WHERE id=?
            """, (status, txid, confirmed_at, tx_id))
        elif txid:
            c.execute("UPDATE wallet_transactions SET status=?, txid=? WHERE id=?",
                      (status, txid, tx_id))
        else:
            c.execute("UPDATE wallet_transactions SET status=? WHERE id=?",
                      (status, tx_id))
        conn.commit()
        conn.close()

def get_transactions(wallet_name, coin=None, limit=100):
    """Return transaction history. Optionally filter by coin."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        if coin:
            c.execute("""
                SELECT * FROM wallet_transactions
                WHERE wallet_name=? AND coin=?
                ORDER BY created_at DESC LIMIT ?
            """, (wallet_name, coin, limit))
        else:
            c.execute("""
                SELECT * FROM wallet_transactions
                WHERE wallet_name=?
                ORDER BY created_at DESC LIMIT ?
            """, (wallet_name, limit))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

# ══════════════════════════════════════════════════════════════
#  MINING CREDITS
# ══════════════════════════════════════════════════════════════
def record_mining_credit(wallet_name, coin, amount, amount_usd=0.0,
                         session_id=None, profile_name="", pool="", algo=""):
    """Record a mining credit to the wallet (auto-called by miner manager)."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT INTO wallet_mining_credits
            (wallet_name, coin, session_id, profile_name, pool, algo, amount, amount_usd)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (wallet_name, coin, session_id, profile_name, pool, algo, amount, amount_usd))
        conn.commit()
        conn.close()

def get_mining_credits(wallet_name, coin=None, limit=200):
    """Return mining credit history."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        if coin:
            c.execute("""
                SELECT * FROM wallet_mining_credits
                WHERE wallet_name=? AND coin=?
                ORDER BY credited_at DESC LIMIT ?
            """, (wallet_name, coin, limit))
        else:
            c.execute("""
                SELECT * FROM wallet_mining_credits
                WHERE wallet_name=?
                ORDER BY credited_at DESC LIMIT ?
            """, (wallet_name, limit))
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

def get_total_mined(wallet_name):
    """Return total amount mined per coin."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            SELECT coin, SUM(amount) as total, SUM(amount_usd) as total_usd
            FROM wallet_mining_credits WHERE wallet_name=?
            GROUP BY coin
        """, (wallet_name,))
        rows = {r[0]: {"total": r[1], "total_usd": r[2]} for r in c.fetchall()}
        conn.close()
        return rows

# ══════════════════════════════════════════════════════════════
#  ADDRESS BOOK
# ══════════════════════════════════════════════════════════════
def save_address(label, coin, address, address_tag="", network="", addr_type="external"):
    """Save an external address (exchange, cold wallet) to address book."""
    if network == "":
        network = coin
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        c    = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO wallet_address_book
            (label, coin, address, address_tag, network, type)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (label, coin, address, address_tag, network, addr_type))
        conn.commit()
        conn.close()

def get_address_book(coin=None):
    """Return address book entries, optionally filtered by coin."""
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c    = conn.cursor()
        if coin:
            c.execute("""
                SELECT * FROM wallet_address_book WHERE coin=?
                ORDER BY label
            """, (coin,))
        else:
            c.execute("SELECT * FROM wallet_address_book ORDER BY coin, label")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows

def delete_address(addr_id):
    with _db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.cursor().execute("DELETE FROM wallet_address_book WHERE id=?", (addr_id,))
        conn.commit()
        conn.close()

# ══════════════════════════════════════════════════════════════
#  PORTFOLIO SUMMARY
# ══════════════════════════════════════════════════════════════
def get_portfolio_summary(wallet_name):
    """
    Return a full portfolio summary for the wallet.
    Joins balances + prices + mining credits.
    """
    balances = {b["coin"]: b for b in get_cached_balances(wallet_name)}
    mined    = get_total_mined(wallet_name)
    prices   = get_cached_prices()
    coins    = load_wallet_addresses(wallet_name)

    total_usd = 0.0
    summary   = []
    for c in coins:
        coin    = c["coin"]
        bal     = balances.get(coin, {})
        balance = bal.get("balance", 0.0) or 0.0
        price   = prices.get(coin, 0.0)
        val_usd = balance * price
        total_usd += val_usd
        summary.append({
            "coin":         coin,
            "address":      c["address"],
            "balance":      balance,
            "price_usd":    price,
            "value_usd":    val_usd,
            "total_mined":  mined.get(coin, {}).get("total", 0.0),
            "network":      c["network"],
            "stale":        bal.get("stale", True),
        })

    return {
        "wallet_name": wallet_name,
        "total_usd":   total_usd,
        "coins":       summary,
        "prices":      prices,
    }



# =============================================================================
# MODULE: wallet_validator.py
# =============================================================================

# wallet_validator.py — Universal Miner Pro ULTIMATE EDITION v4.0
# ─────────────────────────────────────────────────────────────────
# Pre-flight validator for ALL supported mining pools.
# Validates wallet addresses, API keys, worker names, pool URLs,
# and live connectivity — for every profile in miner.db.
#
# NON-BLOCKING: never prevents the app from starting.
# Instead, results are exposed via /api/validate so the dashboard
# can display inline warnings.
#
# Run standalone:   python3 wallet_validator.py
# Import in app:    from wallet_validator import run_validation, ValidationResult

import re
import sys
import json
import hmac
import time
import hashlib
import sqlite3
import os
import threading

try:
    import urllib.request as _urlreq
    import urllib.parse   as _urlparse
    import urllib.error   as _urlerr
except ImportError:
    raise RuntimeError("Python 3 required")

# ══════════════════════════════════════════════════════════════════
#  COLOUR HELPERS
# ══════════════════════════════════════════════════════════════════
def _supports_color():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

_USE_COLOR = _supports_color()

def _c(code, t):
    return ("\033[" + code + "m" + t + "\033[0m") if _USE_COLOR else t

green  = lambda t: _c("92", t)
red    = lambda t: _c("91", t)
yellow = lambda t: _c("93", t)
cyan   = lambda t: _c("96", t)
bold   = lambda t: _c("1",  t)
dim    = lambda t: _c("2",  t)

SEP = dim("─" * 64)

# ══════════════════════════════════════════════════════════════════
#  CONSTANTS
# ══════════════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "miner.db")

# Regex patterns
RE = {
    # Binance / MPH API keys — 64 hex/alnum chars
    "binance_key":   re.compile(r'^[A-Za-z0-9]{64}$'),
    # XMR — starts with 4, 95 chars (standard) or 8x (subaddress)
    "xmr_std":       re.compile(r'^4[0-9A-Za-z]{94}$'),
    "xmr_sub":       re.compile(r'^8[0-9A-Za-z]{94}$'),
    # BTC legacy, SegWit, bech32
    "btc_legacy":    re.compile(r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$'),
    "btc_bech32":    re.compile(r'^bc1[a-zA-HJ-NP-Z0-9]{6,87}$'),
    # DASH P2PKH / P2SH
    "dash":          re.compile(r'^[X7][a-km-zA-HJ-NP-Z1-9]{33}$'),
    # LTC legacy / bech32
    "ltc_legacy":    re.compile(r'^[LM3][a-km-zA-HJ-NP-Z1-9]{25,34}$'),
    "ltc_bech32":    re.compile(r'^ltc1[a-zA-HJ-NP-Z0-9]{6,87}$'),
    # BCH cashaddr / legacy
    "bch_cashaddr":  re.compile(r'^(bitcoincash:)?[qp][a-z0-9]{41}$'),
    "bch_legacy":    re.compile(r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$'),
    # ZEC t-addr / z-addr
    "zec_t":         re.compile(r'^t[13][a-km-zA-HJ-NP-Z1-9]{33}$'),
    "zec_z":         re.compile(r'^zs[0-9a-z]{75}$'),
    # Generic pool stratum URL host:port
    "stratum_url":   re.compile(r'^[a-zA-Z0-9._-]+:\d{2,5}$'),
    # Worker name: alphanumeric + _ + -
    "worker":        re.compile(r'^[a-zA-Z0-9_\-]{1,32}$'),
    # Email
    "email":         re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$'),
    # Unmineable ref code  e.g. abc1-def2
    "unm_ref":       re.compile(r'^[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}$'),
    # Kryptex email-based username  OR wallet address
    "kryptex_user":  re.compile(r'^([^@\s]+@[^@\s]+\.[^@\s]+|[A-Za-z0-9_\-]{6,}|4[0-9A-Za-z]{94})$'),
}

BINANCE_API_BASE = "https://api.binance.com"
POOL_PING_URLS   = {
    "kryptex":      "https://pool.kryptex.com",
    "viabtc":       "https://viabtc.com",
    "unmineable":   "https://unmineable.com",
    "miningpoolhub":"https://miningpoolhub.com",
    "moneroocean":  "https://moneroocean.stream",
    "binance":      "https://pool.binance.com",
}

# ══════════════════════════════════════════════════════════════════
#  DATA CLASS
# ══════════════════════════════════════════════════════════════════
class Issue(object):
    WARN  = "warning"
    ERROR = "error"
    INFO  = "info"

    def __init__(self, level, field, message, profile=None):
        self.level   = level    # "warning" | "error" | "info"
        self.field   = field    # field name / check name
        self.message = message
        self.profile = profile  # profile_name or None

    def to_dict(self):
        return {
            "level":   self.level,
            "field":   self.field,
            "message": self.message,
            "profile": self.profile,
        }

    def __repr__(self):
        return "[{level}] {f}: {m}".format(
            level=self.level.upper(), f=self.field, m=self.message)


class ValidationResult(object):
    def __init__(self):
        self.issues   = []   # list of Issue
        self.ok       = True # False if any ERROR-level issue
        self.checked  = 0    # profiles checked

    def add(self, level, field, message, profile=None):
        self.issues.append(Issue(level, field, message, profile))
        if level == Issue.ERROR:
            self.ok = False

    def errors(self):
        return [i for i in self.issues if i.level == Issue.ERROR]

    def warnings(self):
        return [i for i in self.issues if i.level == Issue.WARN]

    def to_dict(self):
        return {
            "ok":       self.ok,
            "checked":  self.checked,
            "errors":   [i.to_dict() for i in self.errors()],
            "warnings": [i.to_dict() for i in self.warnings()],
            "all":      [i.to_dict() for i in self.issues],
            "summary":  (
                "All checks passed." if self.ok and not self.warnings()
                else ("{e} error(s), {w} warning(s)".format(
                    e=len(self.errors()), w=len(self.warnings())))
            ),
        }


# ══════════════════════════════════════════════════════════════════
#  DB HELPERS
# ══════════════════════════════════════════════════════════════════
def _load_profiles():
    if not os.path.exists(DB_PATH):
        return []
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM profiles ORDER BY updated_at DESC")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return rows
    except Exception as e:
        return []


# ══════════════════════════════════════════════════════════════════
#  NETWORK HELPERS
# ══════════════════════════════════════════════════════════════════
def _http_get(url, headers=None, timeout=8):
    """Returns (status_code, body_str).  status=0 on network error."""
    req = _urlreq.Request(url)
    req.add_header("User-Agent", "UMP-Validator/4.0")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with _urlreq.urlopen(req, timeout=timeout) as r:
            return r.getcode(), r.read().decode("utf-8", errors="replace")
    except _urlerr.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return e.code, body
    except Exception as e:
        return 0, str(e)


def _binance_signed(endpoint, api_key, api_secret, params=None):
    """Signed Binance REST GET.  Returns (status, dict_or_str)."""
    if params is None:
        params = {}
    params["timestamp"]  = str(int(time.time() * 1000))
    params["recvWindow"] = "5000"
    qs  = _urlparse.urlencode(params)
    sig = hmac.new(api_secret.encode(), qs.encode(), hashlib.sha256).hexdigest()
    url = BINANCE_API_BASE + endpoint + "?" + qs + "&signature=" + sig
    status, body = _http_get(url, headers={"X-MBX-APIKEY": api_key})
    try:
        return status, json.loads(body)
    except Exception:
        return status, body


def _ping_url(url):
    """Returns (ok: bool, msg: str)."""
    status, body = _http_get(url, timeout=7)
    if status > 0 and status < 500:
        return True, "Reachable (HTTP " + str(status) + ")"
    if status == 0:
        return False, "Unreachable — " + str(body)[:80]
    return False, "HTTP " + str(status)


# ══════════════════════════════════════════════════════════════════
#  ADDRESS / KEY VALIDATORS (pure format checks)
# ══════════════════════════════════════════════════════════════════
def _chk(result, ok, level, field, ok_msg, fail_msg, profile):
    if ok:
        result.add(Issue.INFO, field, ok_msg, profile)
    else:
        result.add(level, field, fail_msg, profile)
    return ok


def validate_xmr(addr, result, profile):
    a = (addr or "").strip()
    if not a:
        result.add(Issue.ERROR, "xmr_wallet", "XMR wallet address is empty.", profile)
        return False
    ok = bool(RE["xmr_std"].match(a) or RE["xmr_sub"].match(a))
    return _chk(result, ok, Issue.ERROR, "xmr_wallet",
                "XMR address format OK (" + a[:8] + "…)",
                "Invalid XMR address. Must be 95 chars, starting with '4' or '8'.",
                profile)


def validate_btc(addr, result, profile):
    a = (addr or "").strip()
    if not a:
        return True  # BTC wallet optional for most pools
    ok = bool(RE["btc_legacy"].match(a) or RE["btc_bech32"].match(a))
    return _chk(result, ok, Issue.ERROR, "btc_wallet",
                "BTC address format OK (" + a[:8] + "…)",
                "Invalid BTC address. Expected 1…/3…/bc1… format.",
                profile)


def validate_dash(addr, result, profile):
    a = (addr or "").strip().split(".")[0]  # strip .worker suffix
    if not a:
        result.add(Issue.ERROR, "dash_wallet",
                   "DASH wallet/account is empty. Use BINANCE_ACCOUNT.WORKER format.", profile)
        return False
    ok = bool(RE["dash"].match(a))
    # Binance account (email prefix or numeric) is also acceptable
    if not ok and (RE["email"].match(a) or a.isdigit() or len(a) > 5):
        ok = True  # looks like a Binance account name
    return _chk(result, ok, Issue.ERROR, "dash_wallet",
                "DASH wallet/account OK (" + a[:8] + "…)",
                "Invalid DASH address. Expected 34-char address starting with X or 7, "
                "or a Binance account name.",
                profile)


def validate_ltc(addr, result, profile):
    a = (addr or "").strip()
    if not a:
        return True
    ok = bool(RE["ltc_legacy"].match(a) or RE["ltc_bech32"].match(a))
    return _chk(result, ok, Issue.ERROR, "ltc_wallet",
                "LTC address format OK (" + a[:8] + "…)",
                "Invalid LTC address. Expected L…/M…/3…/ltc1… format.",
                profile)


def validate_worker(name, result, profile, field="worker"):
    n = (name or "").strip()
    if not n:
        result.add(Issue.WARN, field, "Worker name is empty — using 'worker1' as default.", profile)
        return False
    ok = bool(RE["worker"].match(n))
    return _chk(result, ok, Issue.WARN, field,
                "Worker name OK: " + n,
                "Worker name '" + n + "' contains invalid characters. "
                "Use only letters, numbers, _ or - (max 32 chars).",
                profile)


def validate_pool_url(url, result, profile):
    u = (url or "").strip()
    if not u:
        result.add(Issue.ERROR, "pool_url", "Pool URL is empty.", profile)
        return False
    # strip stratum+tcp:// prefix for format check
    bare = u
    for prefix in ("stratum+tcp://", "stratum+ssl://", "stratum://"):
        if bare.startswith(prefix):
            bare = bare[len(prefix):]
            break
    ok = bool(RE["stratum_url"].match(bare))
    return _chk(result, ok, Issue.ERROR, "pool_url",
                "Pool URL format OK: " + u,
                "Pool URL '" + u + "' looks invalid. Expected host:port format.",
                profile)


def validate_email(addr, result, profile, field, required=False):
    a = (addr or "").strip()
    if not a:
        if required:
            result.add(Issue.ERROR, field, "Email address is required but empty.", profile)
            return False
        return True
    ok = bool(RE["email"].match(a))
    return _chk(result, ok, Issue.WARN, field,
                "Email format OK: " + a,
                "Email '" + a + "' looks invalid.",
                profile)


def validate_binance_key_format(key, secret, result, profile):
    k = (key or "").strip()
    s = (secret or "").strip()
    if not k:
        result.add(Issue.ERROR, "binance_api_key", "Binance API key is empty.", profile)
        return False
    if not s:
        result.add(Issue.ERROR, "binance_api_secret", "Binance API secret is empty.", profile)
        return False
    ok_k = bool(RE["binance_key"].match(k))
    ok_s = bool(RE["binance_key"].match(s))
    if not ok_k:
        result.add(Issue.ERROR, "binance_api_key",
                   "Binance API key must be exactly 64 alphanumeric characters.", profile)
        return False
    if not ok_s:
        result.add(Issue.ERROR, "binance_api_secret",
                   "Binance API secret must be exactly 64 alphanumeric characters.", profile)
        return False
    result.add(Issue.INFO, "binance_api_key", "API key/secret format OK.", profile)
    return True


# ══════════════════════════════════════════════════════════════════
#  LIVE CHECKS
# ══════════════════════════════════════════════════════════════════
def live_check_binance(api_key, api_secret, result, profile):
    """Hit /api/v3/account — verifies key works and checks permissions."""
    status, data = _binance_signed("/api/v3/account",
                                   api_key.strip(), api_secret.strip())
    if status == 200 and isinstance(data, dict):
        result.add(Issue.INFO, "binance_live_auth",
                   "Binance authentication successful. "
                   "Account type: " + str(data.get("accountType", "?")), profile)
        if data.get("canWithdraw"):
            result.add(Issue.WARN, "binance_api_key",
                       "SECURITY: API key has WITHDRAW permission. "
                       "For mining, regenerate with READ-ONLY permission only.", profile)
        return True
    if isinstance(data, dict):
        code = data.get("code", "")
        msg  = data.get("msg",  "Unknown error")
        if code == -2014:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Binance rejected API key format: " + msg, profile)
        elif code == -1022:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Binance signature invalid — check your API secret: " + msg, profile)
        elif code == -1021:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Timestamp mismatch — check your system clock: " + msg, profile)
        else:
            result.add(Issue.ERROR, "binance_live_auth",
                       "Binance auth error " + str(code) + ": " + msg, profile)
    else:
        result.add(Issue.ERROR, "binance_live_auth",
                   "Unexpected Binance response (HTTP " + str(status) + "): " + str(data)[:80],
                   profile)
    return False


def live_check_mph(api_key, username, result, profile):
    """Validate MPH API key via public API endpoint."""
    if not api_key or not username:
        result.add(Issue.WARN, "mph_api_key",
                   "MPH API key or username is empty — cannot validate live.", profile)
        return False
    url = ("https://miningpoolhub.com/index.php?page=api&action=getuserbalance"
           "&api_key=" + _urlparse.quote(api_key.strip()) +
           "&id=" + _urlparse.quote(username.strip()))
    status, body = _http_get(url, timeout=8)
    if status == 200:
        try:
            d = json.loads(body)
            if "getuserbalance" in d:
                result.add(Issue.INFO, "mph_live_auth",
                           "MPH authentication successful.", profile)
                return True
        except Exception:
            pass
    if status == 0:
        result.add(Issue.WARN, "mph_live_auth",
                   "MPH unreachable — cannot validate. Check network.", profile)
    else:
        result.add(Issue.ERROR, "mph_live_auth",
                   "MPH API key invalid or username mismatch (HTTP " + str(status) + ").", profile)
    return False


def live_check_kryptex(email, worker, result, profile):
    """Kryptex doesn't expose a public account API — do a format check + ping."""
    ok = True
    if not email or not email.strip():
        result.add(Issue.ERROR, "kryptex_email",
                   "Kryptex email/account is empty.", profile)
        ok = False
    else:
        e = email.strip()
        if not (RE["email"].match(e) or len(e) >= 6):
            result.add(Issue.ERROR, "kryptex_email",
                       "Kryptex account '" + e + "' looks invalid.", profile)
            ok = False
        else:
            result.add(Issue.INFO, "kryptex_email",
                       "Kryptex account format OK: " + e, profile)
    validate_worker(worker, result, profile, "kryptex_worker")
    return ok


def live_check_viabtc(username, worker, result, profile):
    ok = True
    if not username or not username.strip():
        result.add(Issue.ERROR, "viabtc_username",
                   "ViaBTC username is empty.", profile)
        ok = False
    else:
        validate_worker(username.strip(), result, profile, "viabtc_username")
    validate_worker(worker, result, profile, "viabtc_worker")
    return ok


def live_check_unmineable(coin, wallet, ref, result, profile):
    ok = True
    if not coin or not coin.strip():
        result.add(Issue.ERROR, "unmineable_coin",
                   "Unmineable payout coin is not set.", profile)
        ok = False
    else:
        result.add(Issue.INFO, "unmineable_coin",
                   "Payout coin: " + coin.strip().upper(), profile)
    if not wallet or not wallet.strip():
        result.add(Issue.ERROR, "unmineable_wallet",
                   "Unmineable payout wallet address is empty.", profile)
        ok = False
    else:
        # Validate wallet format based on payout coin
        c = coin.strip().upper() if coin else ""
        w = wallet.strip()
        addr_ok = False
        if c in ("BTC", "BCH", "BSV"):
            addr_ok = bool(RE["btc_legacy"].match(w) or RE["btc_bech32"].match(w))
        elif c == "LTC":
            addr_ok = bool(RE["ltc_legacy"].match(w) or RE["ltc_bech32"].match(w))
        elif c == "XMR":
            addr_ok = bool(RE["xmr_std"].match(w) or RE["xmr_sub"].match(w))
        else:
            # Generic: just check it's non-trivial
            addr_ok = len(w) >= 20
        if addr_ok:
            result.add(Issue.INFO, "unmineable_wallet",
                       c + " wallet format OK (" + w[:8] + "…)", profile)
        else:
            result.add(Issue.ERROR, "unmineable_wallet",
                       "Wallet address for " + c + " looks invalid: " + w[:16] + "…", profile)
            ok = False
    # Referral code — optional but validate format if present
    if ref and ref.strip():
        r = ref.strip()
        if not RE["unm_ref"].match(r):
            result.add(Issue.WARN, "unmineable_ref",
                       "Referral code '" + r + "' format unexpected (expected xxxx-xxxx).", profile)
    return ok


def live_check_moneroocean(wallet, worker, email, result, profile):
    ok = validate_xmr(wallet, result, profile)
    validate_worker(worker, result, profile, "mo_worker")
    validate_email(email, result, profile, "mo_email", required=False)
    # MoneroOcean provides a public stats endpoint
    if wallet and len(wallet.strip()) == 95:
        url = "https://moneroocean.stream/api/miner/" + wallet.strip()[:20] + "/stats"
        status, body = _http_get(url, timeout=7)
        if status == 200:
            result.add(Issue.INFO, "moneroocean_live",
                       "MoneroOcean pool reachable and wallet accepted.", profile)
        elif status == 0:
            result.add(Issue.WARN, "moneroocean_live",
                       "MoneroOcean unreachable — check network.", profile)
        # 404 just means new/unknown wallet — not an error
    return ok


# ══════════════════════════════════════════════════════════════════
#  PER-POOL DISPATCHER
# ══════════════════════════════════════════════════════════════════
def _validate_profile(p, result):
    pname = p.get("profile_name", "unknown")
    pool  = (p.get("selected_pool") or "").strip().lower()
    coin  = (p.get("selected_coin") or "XMR").strip().upper()
    algo  = (p.get("active_algo")   or "RANDOMX").strip().upper()

    # Always validate common fields
    validate_pool_url(p.get("pool_url"), result, pname)
    validate_worker(p.get("username"), result, pname, "username")

    # XMR wallet — required for RandomX and X11 (unMineable)
    if algo in ("RANDOMX", "X11") or pool in ("kryptex", "moneroocean", "unmineable"):
        xmr = p.get("xmr_wallet") or p.get("mo_wallet") or ""
        if xmr:
            validate_xmr(xmr, result, pname)

    # BTC wallet — validate if provided
    if p.get("btc_wallet"):
        validate_btc(p.get("btc_wallet"), result, pname)

    # ── Pool-specific ──────────────────────────────────────────
    if pool == "binance" or algo == "X11_DIRECT" or coin == "DASH":
        # DASH miner_user is ACCOUNT.WORKER — validate both parts
        miner_user = (p.get("miner_user") or "").strip()
        if "." in miner_user:
            account, worker = miner_user.split(".", 1)
            validate_dash(account, result, pname)
            validate_worker(worker, result, pname, "binance_worker")
        else:
            validate_dash(miner_user, result, pname)
        # Binance API keys
        api_key    = (p.get("binance_api_key")    or "").strip()
        api_secret = (p.get("binance_api_secret") or "").strip()
        if api_key or api_secret:
            fmt_ok = validate_binance_key_format(api_key, api_secret, result, pname)
            if fmt_ok:
                live_check_binance(api_key, api_secret, result, pname)
        else:
            result.add(Issue.WARN, "binance_api_key",
                       "No Binance API key stored — live authentication skipped.", pname)
        validate_email(p.get("binance_email"), result, pname, "binance_email")

    elif pool == "kryptex":
        live_check_kryptex(
            p.get("kryptex_email") or p.get("username"),
            p.get("kryptex_worker") or p.get("username"),
            result, pname)

    elif pool == "viabtc":
        live_check_viabtc(
            p.get("viabtc_username") or p.get("username"),
            p.get("viabtc_worker")   or p.get("username"),
            result, pname)

    elif pool == "unmineable":
        live_check_unmineable(
            p.get("unmineable_coin"),
            p.get("unmineable_wallet") or p.get("xmr_wallet"),
            p.get("unmineable_ref"),
            result, pname)

    elif pool == "moneroocean":
        live_check_moneroocean(
            p.get("mo_wallet") or p.get("xmr_wallet"),
            p.get("mo_worker") or p.get("username"),
            p.get("mo_email"),
            result, pname)

    elif pool == "miningpoolhub":
        mph_user   = p.get("mph_username") or p.get("username") or ""
        mph_apikey = p.get("mph_api_key") or ""
        validate_worker(mph_user, result, pname, "mph_username")
        if mph_apikey:
            live_check_mph(mph_apikey, mph_user, result, pname)
        else:
            result.add(Issue.WARN, "mph_api_key",
                       "MPH API key not configured — live validation skipped.", pname)

    # RandomX / Kryptex XMR path — validate wallet in miner_user
    if algo == "RANDOMX" and pool not in ("binance",):
        miner_user = (p.get("miner_user") or "").strip()
        if miner_user:
            wallet_part = miner_user.split(".")[0]
            if RE["xmr_std"].match(wallet_part) or RE["xmr_sub"].match(wallet_part):
                result.add(Issue.INFO, "miner_user",
                           "XMR wallet in --user string looks valid.", pname)
            elif RE["email"].match(wallet_part):
                result.add(Issue.INFO, "miner_user",
                           "Kryptex email in --user string: " + wallet_part, pname)
            else:
                result.add(Issue.WARN, "miner_user",
                           "Could not recognise wallet format in --user string: '"
                           + wallet_part[:20] + "…'", pname)


# ══════════════════════════════════════════════════════════════════
#  NETWORK CONNECTIVITY SWEEP
# ══════════════════════════════════════════════════════════════════
def _check_pool_connectivity(pools_needed, result):
    for pool_id in pools_needed:
        url = POOL_PING_URLS.get(pool_id)
        if not url:
            continue
        ok, msg = _ping_url(url)
        if ok:
            result.add(Issue.INFO, "network_" + pool_id,
                       pool_id.capitalize() + " pool reachable: " + msg)
        else:
            result.add(Issue.ERROR, "network_" + pool_id,
                       pool_id.capitalize() + " pool UNREACHABLE — " + msg +
                       ". Mining will fail until connectivity is restored.")


# ══════════════════════════════════════════════════════════════════
#  MAIN RUNNER
# ══════════════════════════════════════════════════════════════════
def run_validation(profiles=None, verbose=True):
    """
    Run all pre-flight checks.
    Returns a ValidationResult — NEVER raises an exception.
    The miner is NOT blocked; callers decide what to do with the result.
    """
    result = ValidationResult()

    try:
        if profiles is None:
            profiles = _load_profiles()

        if not profiles:
            result.add(Issue.WARN, "profiles",
                       "No profiles found in miner.db. "
                       "Add a profile via the dashboard before mining.")
            return result

        result.checked = len(profiles)

        # Gather which pools are actually used
        pools_needed = set()
        for p in profiles:
            pid = (p.get("selected_pool") or "").strip().lower()
            if pid in POOL_PING_URLS:
                pools_needed.add(pid)

        # 1 — Connectivity
        _check_pool_connectivity(pools_needed, result)

        # 2 — Per-profile
        for p in profiles:
            try:
                _validate_profile(p, result)
            except Exception as e:
                result.add(Issue.WARN, "validator_error",
                           "Unexpected error validating profile '"
                           + str(p.get("profile_name", "?")) + "': " + str(e),
                           p.get("profile_name"))

    except Exception as e:
        result.add(Issue.WARN, "validator_crash",
                   "Validator encountered an unexpected error: " + str(e))

    return result


# ══════════════════════════════════════════════════════════════════
#  BACKGROUND RUNNER (called by Flask app on startup)
# ══════════════════════════════════════════════════════════════════
_cached_result   = None
_cached_lock     = threading.Lock()
_cached_at       = 0
CACHE_TTL        = 300  # re-validate every 5 minutes

def get_cached_result(force=False):
    """Thread-safe cached validation result for the Flask app."""
    global _cached_result, _cached_at
    with _cached_lock:
        if force or _cached_result is None or (time.time() - _cached_at) > CACHE_TTL:
            _cached_result = run_validation(verbose=False)
            _cached_at     = time.time()
        return _cached_result


def start_background_validation():
    """Kick off first validation in a background thread so Flask boot isn't delayed."""
    def _run():
        get_cached_result(force=True)
    t = threading.Thread(target=_run, daemon=True)
    t.start()


# ══════════════════════════════════════════════════════════════════
#  CLI PRETTY-PRINT
# ══════════════════════════════════════════════════════════════════
def _cli_print(result):
    print()
    print(bold(cyan("╔══════════════════════════════════════════════════════════════╗")))
    print(bold(cyan("║   Universal Miner Pro — Pre-Flight Validator v4.0            ║")))
    print(bold(cyan("║   Pools: Kryptex • ViaBTC • Unmineable • MPH • MO • Binance  ║")))
    print(bold(cyan("╚══════════════════════════════════════════════════════════════╝")))
    print()

    by_profile = {}
    network    = []
    for issue in result.issues:
        if issue.field.startswith("network_") or issue.profile is None:
            network.append(issue)
        else:
            by_profile.setdefault(issue.profile, []).append(issue)

    # Network section
    print(bold("[ NETWORK CONNECTIVITY ]"))
    print(SEP)
    for issue in network:
        if issue.level == Issue.INFO:
            print("  " + green("✔") + "  " + issue.message)
        elif issue.level == Issue.WARN:
            print("  " + yellow("⚠") + "  " + issue.message)
        else:
            print("  " + red("✘") + "  " + issue.message)
    print()

    # Per-profile sections
    for pname, issues in by_profile.items():
        errors   = [i for i in issues if i.level == Issue.ERROR]
        warnings = [i for i in issues if i.level == Issue.WARN]
        infos    = [i for i in issues if i.level == Issue.INFO]
        status   = (green("PASS") if not errors
                    else red("FAIL"))
        print(bold("[ PROFILE: " + pname + " ]") + "  " + status)
        print(SEP)
        for i in errors:
            print("  " + red("✘  ERROR   ") + bold(i.field) + ": " + i.message)
        for i in warnings:
            print("  " + yellow("⚠  WARN    ") + bold(i.field) + ": " + i.message)
        for i in infos:
            print("  " + green("✔  OK      ") + dim(i.field + ": " + i.message))
        print()

    # Summary
    print(bold("[ SUMMARY ]"))
    print(SEP)
    errs  = result.errors()
    warns = result.warnings()
    if result.ok and not warns:
        print(green("  ✔  ALL CHECKS PASSED — miner is clear to start.\n"))
    else:
        if errs:
            print(red("  ✘  " + str(len(errs)) + " error(s) found:\n"))
            for e in errs:
                print(red("     • [" + (e.profile or "global") + "] " + e.message))
            print()
        if warns:
            print(yellow("  ⚠  " + str(len(warns)) + " warning(s):\n"))
            for w in warns:
                print(yellow("     • [" + (w.profile or "global") + "] " + w.message))
            print()
        if errs:
            print(red(bold(
                "  ► Fix the errors above, then re-run:\n"
                "      python3 wallet_validator.py\n"
                "    The miner app has NOT been blocked — but payouts may fail\n"
                "    until configuration is corrected.\n"
            )))
    print(dim("  Profiles checked: " + str(result.checked)))
    print()


if __name__ == "__main__":
    res = run_validation()
    _cli_print(res)
    sys.exit(0 if res.ok else 1)


# =============================================================================
# MODULE: wallet_enforcer.py
# =============================================================================

# wallet_enforcer.py — Universal Miner Pro ULTIMATE EDITION v4.0
# CRITICAL SECURITY MODULE — Forces all pool payouts to internal wallet only.
# No funds can be directed to external addresses via miner configuration.
# External transfers only happen explicitly via wallet_api.py /api/transfer routes.
#
# ARM-safe: no f-strings, no walrus, stdlib only.
# Thread-safe: uses wallet_db._db_lock via load_wallet_addresses().

import os
import re
import sqlite3

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
WALLET_DB = os.path.join(BASE_DIR, "wallet.db")

# ---------------------------------------------------------------------------
# Coin -> internal wallet coin mapping
# ---------------------------------------------------------------------------
WALLET_COIN_ALIAS = {
    "ZEPH": "XMR",   # No ZEPH HD wallet — use XMR receive address
    "SAL":  "XMR",
    "ETHW": "ETH",
    "BCH":  "BTC",
}

# ---------------------------------------------------------------------------
# Resolve the active wallet name (safe outside Flask request context)
# Uses wallet_db.list_wallets() which respects _db_lock.
# Falls back to first wallet in DB — correct behaviour for single-user setup.
# ---------------------------------------------------------------------------
def _resolve_wallet_name():
    """Return the active wallet name or None if no wallet configured."""
    try:
        from wallet_db import list_wallets
        wallets = list_wallets()
        if wallets:
            return wallets[0]["wallet_name"]
        return None
    except Exception as e:
        print("[wallet_enforcer] list_wallets error: " + str(e))
        return None

# ---------------------------------------------------------------------------
# Core: get the internal wallet address for a given coin
# Uses wallet_db.load_wallet_addresses() — thread-safe via _db_lock.
# ---------------------------------------------------------------------------
def get_internal_address(coin):
    """
    Return (address, coin_used) for the given coin from the internal wallet.
    Returns (None, None) if no wallet configured or coin not found.
    Applies WALLET_COIN_ALIAS fallbacks automatically.
    """
    coin        = coin.upper().strip()
    lookup_coin = WALLET_COIN_ALIAS.get(coin, coin)

    wallet_name = _resolve_wallet_name()
    if not wallet_name:
        return None, None

    try:
        from wallet_db import load_wallet_addresses
        rows = load_wallet_addresses(wallet_name)
        for row in rows:
            if str(row.get("coin", "")).upper() == lookup_coin:
                addr = row.get("address") or row.get("address_bech32") or row.get("address_legacy")
                if addr:
                    return str(addr).strip(), lookup_coin
        return None, None
    except Exception as e:
        print("[wallet_enforcer] get_internal_address error: " + str(e))
        return None, None

# ---------------------------------------------------------------------------
# Core: enforce internal wallet addresses in a profile dict
# ---------------------------------------------------------------------------
def enforce_internal_wallet(profile):
    """
    Given a miner profile dict, overwrite all wallet/address fields with
    internal wallet addresses before any miner command is built.
    Returns (modified_profile, warnings[]).

    Fields enforced:
      xmr_wallet        — XMR / ZEPH / SAL / MoneroOcean payout
      btc_wallet        — BTC / Kryptex BTC payout
      eth_wallet        — ETH / ETC / ETHW payout
      ltc_wallet        — LTC payout
      unmineable_wallet — unMineable payout wallet
      mo_wallet         — MoneroOcean wallet
      miner_user        — rewritten when it contains a wallet address
    """
    profile  = dict(profile)   # shallow copy — never mutate caller's dict
    warnings = []

    coin     = str(profile.get("selected_coin", "XMR")).upper().strip()
    pool_id  = str(profile.get("selected_pool", "kryptex")).lower().strip()
    algo_key = str(profile.get("active_algo",   "RANDOMX")).upper().strip()

    # Payout coin: most pools pay the mined coin; MoneroOcean always pays XMR
    if pool_id == "moneroocean":
        payout_coin = "XMR"
    else:
        payout_coin = WALLET_COIN_ALIAS.get(coin, coin)

    # Fetch internal address for payout coin
    internal_addr, addr_coin = get_internal_address(payout_coin)

    if internal_addr is None:
        warnings.append(
            "No internal wallet configured. Create a wallet at /wallet/ first. "
            "Mining is BLOCKED until a wallet exists."
        )
        return profile, warnings

    # ── XMR-family ────────────────────────────────────────────────────────
    if payout_coin in ("XMR", "ZEPH", "SAL") or coin in ("XMR", "ZEPH", "SAL"):
        xmr_addr, _ = get_internal_address("XMR")
        if xmr_addr:
            if profile.get("xmr_wallet", "") != xmr_addr:
                warnings.append("xmr_wallet overridden -> " + xmr_addr[:14] + "...")
            profile["xmr_wallet"]         = xmr_addr
            profile["unmineable_wallet"]  = xmr_addr
            profile["mo_wallet"]          = xmr_addr

    # ── BTC-family ────────────────────────────────────────────────────────
    if payout_coin in ("BTC", "BCH", "LTC"):
        addr, _ = get_internal_address(payout_coin)
        if addr is None:
            addr, _ = get_internal_address("BTC")
        if addr:
            if profile.get("btc_wallet", "") != addr:
                warnings.append("btc_wallet overridden -> " + addr[:14] + "...")
            profile["btc_wallet"] = addr

    # ── ETH-family ───────────────────────────────────────────────────────
    if payout_coin in ("ETH", "ETC", "ETHW"):
        addr, _ = get_internal_address("ETH")
        if addr:
            if profile.get("eth_wallet", "") != addr:
                warnings.append("eth_wallet overridden -> " + addr[:14] + "...")
            profile["eth_wallet"] = addr

    # ── LTC ───────────────────────────────────────────────────────────────
    if payout_coin == "LTC":
        addr, _ = get_internal_address("LTC")
        if addr:
            profile["ltc_wallet"] = addr

    # ── Rewrite miner_user ─────────────────────────────────────────────────
    miner_user = str(profile.get("miner_user", "")).strip()

    if pool_id == "kryptex" and miner_user.startswith("solo:"):
        worker   = _extract_worker(miner_user, pool_id)
        new_user = "solo:" + internal_addr + "/" + worker
        if new_user != miner_user:
            warnings.append("miner_user (Kryptex solo) overridden -> " + new_user[:30] + "...")
        profile["miner_user"] = new_user

    elif pool_id == "unmineable":
        xmr_addr, _ = get_internal_address("XMR")
        if xmr_addr:
            worker   = _extract_worker(miner_user, pool_id)
            ref      = str(profile.get("unmineable_ref", "")).strip()
            ref_part = ("#" + ref) if ref else ""
            new_user = "XMR:" + xmr_addr + "." + worker + ref_part
            if new_user != miner_user:
                warnings.append("miner_user (unMineable) overridden -> " + new_user[:40] + "...")
            profile["miner_user"] = new_user

    elif _looks_like_wallet_address(_strip_pool_prefix(miner_user)):
        # Any other pool where miner_user contains a raw wallet address
        worker   = _extract_worker(miner_user, pool_id)
        new_user = _build_user_string(internal_addr, worker, pool_id, algo_key)
        if new_user and new_user != miner_user:
            warnings.append("miner_user overridden -> " + new_user[:30] + "...")
            profile["miner_user"] = new_user

    return profile, warnings

# ---------------------------------------------------------------------------
# Wallet address detection helpers
# ---------------------------------------------------------------------------
def _strip_pool_prefix(s):
    """Remove pool-specific prefix from a miner_user string for address detection."""
    for prefix in ("solo:", "XMR:", "BTC:", "ETH:", "DASH:", "LTC:"):
        if s.startswith(prefix):
            s = s.split(":", 1)[1]
            break
    # Strip worker suffix
    for sep in ("/", "."):
        if sep in s:
            s = s.split(sep)[0]
    return s.strip()

def _looks_like_wallet_address(s):
    """Return True if s appears to be a crypto wallet address (not a pool username)."""
    if not s or len(s) < 26:
        return False
    patterns = [
        r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$',    # BTC legacy
        r'^bc1[a-z0-9]{6,87}$',                    # BTC bech32
        r'^0x[0-9a-fA-F]{40}$',                    # ETH/ETC
        r'^4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}$',    # XMR primary (95 chars)
        r'^8[0-9AB][1-9A-HJ-NP-Za-km-z]{93}$',    # XMR subaddress (95 chars)
        r'^X[a-km-zA-HJ-NP-Z1-9]{33}$',            # DASH
        r'^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$',    # LTC legacy
        r'^ltc1[a-z0-9]{6,87}$',                   # LTC bech32
        r'^[R][a-km-zA-HJ-NP-Z1-9]{33}$',          # RVN
    ]
    for pat in patterns:
        if re.match(pat, s):
            return True
    return False

def _extract_worker(user_str, pool_id):
    """Extract worker name from a miner_user string."""
    s = user_str.strip()
    for prefix in ("solo:", "XMR:", "BTC:", "ETH:"):
        if s.startswith(prefix):
            s = s[len(prefix):]
    if pool_id == "kryptex" and "/" in s:
        return s.split("/", 1)[1].split("#")[0].strip() or "worker1"
    if "." in s:
        part = s.split(".", 1)[1]
        return part.split("#")[0].strip() or "worker1"
    return "worker1"

def _build_user_string(wallet_addr, worker, pool_id, algo_key):
    """Build the pool-appropriate miner_user string with the internal wallet."""
    if pool_id == "kryptex":
        return "solo:" + wallet_addr + "/" + worker
    if pool_id == "unmineable":
        return "XMR:" + wallet_addr + "." + worker
    return wallet_addr + "." + worker

# ---------------------------------------------------------------------------
# Validation: called by miner_config.py save_profile()
# Returns list of error strings — empty list means OK to save.
# ---------------------------------------------------------------------------
def validate_profile_wallets(profile):
    """
    Reject any profile that still contains a non-internal wallet address
    after enforcement has been applied.  Empty list = OK.
    """
    errors = []
    checks = [
        ("xmr_wallet",        "XMR"),
        ("btc_wallet",        "BTC"),
        ("unmineable_wallet", "XMR"),
        ("mo_wallet",         "XMR"),
        ("eth_wallet",        "ETH"),
        ("ltc_wallet",        "LTC"),
    ]
    for field, check_coin in checks:
        val = str(profile.get(field, "")).strip()
        if not val or not _looks_like_wallet_address(val):
            continue
        internal_addr, _ = get_internal_address(check_coin)
        # No internal wallet configured: skip validation (require_internal_wallet
        # will catch this earlier in get_miner_cmd).
        if internal_addr is None:
            continue
        if val != internal_addr:
            errors.append(
                field + " (" + val[:14] + "...) does not match internal "
                + check_coin + " address. Only the internal wallet receives mining payouts."
            )
    return errors

# ---------------------------------------------------------------------------
# Guard: raises ValueError if no wallet configured — called from get_miner_cmd()
# ---------------------------------------------------------------------------
def require_internal_wallet():
    """Raise ValueError with clear instructions if no internal wallet exists."""
    wallet_name = _resolve_wallet_name()
    if not wallet_name:
        raise ValueError(
            "No internal wallet found. Go to /wallet/ and create a wallet first. "
            "All mining payouts must go to your internal wallet."
        )

